package app.beans;

import app.dto.Person;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 30.12.13
 * Time: 14:59
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="authorisedUserViewBean")
@ViewScoped
public class AuthorisedUserViewScoped {
    @ManagedProperty(value = "#{authorisedUser}")
    private AuthorisedUser authorisedUser;

    @EJB
    PersonsDBLoader personsDBLoader;

    @EJB
    private RootChecker rootChecker;

    private Person person;

    public boolean isTechnicalAM() {
        Person person = getPerson();
        if(person == null) {
            return false;
        }
        return person.isTechnicalAM();
    }

    public Person getPerson() {
        if (authorisedUser == null || authorisedUser.getUser().getLogin() == null) {
            return null;
        }
        if(person == null) {
            person = personsDBLoader.getByLoginName(authorisedUser.getUser().getLogin());
        }
        return person;
    }

    public void setTechnicalAM(boolean v){

    }

    public boolean isProjectM() {
        Person person = getPerson();
        if(person == null) {
            return false;
        }
        return person.isProjectM();
    }

    public void setProjectM(boolean v){

    }

    public boolean getCurrentUserIsRootOrFinanceManager() {
        boolean result = false;
        if(authorisedUser == null) {
            result = false;
        }
        if(
                rootChecker.isRoot(getPerson()) ||
                        getPerson().isFinManager()) {
            result = true;
        }
        return result;
    }

    public boolean isCurrentUserIsHR() {
        boolean result = false;
        if(authorisedUser == null) {
            result = false;
        }
        if(getPerson().isHR()) {
            result = true;
        }
        return result;
    }

    public boolean isCurrentUserIsFinm() {
        if(authorisedUser == null) {
            return false;
        }
        if(getPerson().isFinManager()) {
            return true;
        }
        return false;
    }

    public boolean isCurrentUserIsHrTamPm() {
        boolean result = false;
        if(authorisedUser == null) {
            result = false;
        }
        if(  getPerson().isHR()
           ||getPerson().isTechnicalAM()
           ||getPerson().isProjectM()
                ) {
            result = true;
        }
        return result;
    }

    public boolean getCurrentUserIsRootOrHR() {
        boolean result = false;
        if(authorisedUser == null) {
            result = false;
        }
        if(
                rootChecker.isRoot(getPerson()) ||
                        getPerson().isHR()) {
            result = true;
        }
        return result;
    }

    public boolean getCurrentUserIsRootOrHROrSearchPpl() {
        boolean result = false;
        if(authorisedUser == null) {
            result = false;
        }
        if(
                rootChecker.isRoot(getPerson()) ||
                        getPerson().isHR() || getPerson().isAllowSearchPeople()) {
            result = true;
        }
        return result;
    }

    public boolean getCurrentUserIsRootOrSearchPpl() {
        boolean result = false;
        if(authorisedUser == null) {
            result = false;
        }
        if(
                rootChecker.isRoot(getPerson()) ||
                        getPerson().isAllowSearchPeople()) {
            result = true;
        }
        return result;
    }

    public boolean getCurrentUserIsRootOrTAMOrPM() {
        boolean result = false;
        if(authorisedUser == null) {
            result = false;
        }
        if(
                rootChecker.isRoot(getPerson()) ||
                        getPerson().isTechnicalAM() || getPerson().isProjectM() ) {
            result = true;
        }
        return result;
    }

    public boolean getCurrentUserIsBuhReconciliation() {
        if(authorisedUser == null) {
            return false;
        }
        if(getPerson().isBuhReconciliation()) {
            return true;
        }
        return false;
    }

    public boolean getCurrentUserIsRoot() {
        return rootChecker.isRoot(getPerson());
    }

    public boolean isCurrentUserIsRootReadOnly() {
        return rootChecker.isRootReadOnly((getPerson()));
    }

    public boolean isCurrentUserIsRootNoSales() {
        return rootChecker.isRootNoSales((getPerson()));
    }

    public AuthorisedUser getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUser authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public boolean isAllowModify() {
        if(isCurrentUserIsRootReadOnly()) {
            return false;
        }
        return true;
    }
}
