package app.loaders;

import app.beans.RootChecker;
import app.dto.ExpenseDirect;
import app.dto.ExpenseType;
import app.dto.Person;
import app.dto.Project;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "expensesDirectDBLoader")
@Named(value = "expensesDirectDBLoader")
@Stateless
public class ExpensesDirectDBLoader extends CommonDbLoader<ExpenseDirect> {

    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    ExpenseTypeDBLoader expenseTypeDBLoader;

    @EJB
    private RootChecker rootChecker;

    @Override
    protected Class getEntityClass() {
        return ExpenseDirect.class;
    }

    @Override
    protected Long getId(ExpenseDirect entity) {
        return entity.getId();
    }

    public List<ExpenseDirect> getListForAuthorizedUser(Long projectId, Person authorisedUser) {
        List<ExpenseDirect> result = loadByFieldValue("projectId", projectId, new String[]{"dateExp"});
        if ( ! rootChecker.isRoot(authorisedUser) ) {
            Iterator<ExpenseDirect> itr = result.iterator();
            while (itr.hasNext()) {
                ExpenseDirect item = itr.next();
                ExpenseType expenseType = item.getExpenseType();
                if (expenseType != null && ConstantsHelper.DIRECT_EXPENSE_TEAM_OUTSOURCE.equals(expenseType.getCode())) {
                    itr.remove();
                }
            }
        }
        return result;
    }

    public Number getProjectExpensesDirectSum(Long projectId, Date from, Date to) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from ExpenseDirect t " +
                        " where t.projectId = :projectId " +
                        "   and t.dateExp between :fromDate and :toDate");
        query.setParameter("projectId", projectId);
        query.setParameter("fromDate", from, TemporalType.DATE);
        query.setParameter("toDate", to, TemporalType.DATE);
        return (Number) query.getSingleResult();
    }

    public Number getProjectExpensesDirectSum(Long projectId) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from ExpenseDirect t " +
                        " where t.projectId = :projectId ");
        query.setParameter("projectId", projectId);
        return (Number) query.getSingleResult();
    }

    public Map<Long, Number> getProjectsExpensesDirectSum(List<Long> projectsIds, Date currentDate) {
        String sql = "select t.projectId, sum(t.summa) from ExpenseDirect t " +
                " where t.projectId in ( projectIdsParameters ) " +
                "   and t.dateExp <= :currentDate " +
                " group by t.projectId";

        return getLongNumberMap(sql, projectsIds, new String[] {"currentDate"}, new Object[]{currentDate});
    }

    public Map<Long, Number> getProjectsExpensesDirectSumPlan(List<Long> projectsIds, Date currentDate) {
        String sql = "select t.projectId, sum(t.summa) from ExpenseDirect t " +
                " where t.projectId in ( projectIdsParameters ) " +
                "   and t.dateExp > :currentDate " +
                " group by t.projectId";

        return getLongNumberMap(sql, projectsIds, new String[] {"currentDate"}, new Object[]{currentDate});
    }

    public List<ExpenseDirect> loadByProjectId(Long id) {
        return loadByLinkedId("projectId", id);
    }

    public Number getSumma(Long id) {
        Query q = em.createNamedQuery("ExpenseDirect.summaForId");
        q.setParameter("projectId", id);
        return (Number) q.getSingleResult();
    }

    public Number getSumma(Long id, Date startDate, Date endDate) {
        Query q = em.createNamedQuery("ExpenseDirect.summaForIdByPeriod");
        q.setParameter("projectId", id);
        q.setParameter("startDate", startDate, TemporalType.DATE);
        q.setParameter("endDate", endDate, TemporalType.DATE);
        return (Number) q.getSingleResult();
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public void addAndCopyTillProjectEnd(Long projectId, ExpenseDirect expenseDirect, boolean copyProjectTillEnd) {
        addNew(expenseDirect);
        if(copyProjectTillEnd) {
            copyProjectUntilProjectEnd(projectId, expenseDirect, expenseDirect);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public void updateAndCopyTillProjectEnd(Long projectId, ExpenseDirect expenseDirect, boolean copyProjectTillEnd) {
        ExpenseDirect oldExpenseDirect = null;
        if(copyProjectTillEnd) {
            // ���� �� ������ detach �� ����� update � ���������� oldExpenseDirect ���������� ���� �� ����� ��������
            oldExpenseDirect = getByIdDetached(expenseDirect.getId());
        }

        update(expenseDirect);

        if(copyProjectTillEnd) {
            copyProjectUntilProjectEnd(projectId, expenseDirect, oldExpenseDirect);
        }
    }

    public void copyProjectUntilProjectEnd(Long projectId, ExpenseDirect expenseDirect, ExpenseDirect oldExpenseDirect) {
        Project curProject = projectsDBLoader.getById(projectId);
        List<ExpenseDirect> expenseDirectList = loadByProjectId(projectId);
        Date endDate = curProject.getEndDatePlan();
        Date startDate = expenseDirect.getDateExp();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        int curMonth = calendar.get(Calendar.MONTH) + 1;
        int curDay = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.setTime(endDate);
        int endMonth = calendar.get(Calendar.MONTH);
//        int numberOfMonths = calculateNumberOfMonths(startDate, endDate);
        while( curMonth <= endMonth ) {
            ExpenseDirect foundDocument = getExistDocumentForMonth(curMonth, oldExpenseDirect, expenseDirectList);
            if(foundDocument != null) {
                debug("foundDocument = " + foundDocument.toString());
                Calendar cal = Calendar.getInstance();
                cal.setTime(expenseDirect.getDateExp());
                cal.set(Calendar.MONTH, curMonth);
//                foundDocument.setDateExp(cal.getTime());
                foundDocument.setSumma(expenseDirect.getSumma());
                foundDocument.setPerson(personsDBLoader.getById(expenseDirect.getPerson().getId()));
                foundDocument.setExpenseType(expenseTypeDBLoader.getById(expenseDirect.getExpenseType().getId()));
                foundDocument.setDestination(expenseDirect.getDestination());
                foundDocument.setDescription(expenseDirect.getDescription());
                debug("expensesDirectDBLoader call update for - " + foundDocument.toString() + " oldDocument = " + oldExpenseDirect.toString());
                update(foundDocument);
            } else {
                debug("foundDocument = " + foundDocument);
                foundDocument = new ExpenseDirect();
                foundDocument.setProjectId(projectId);
                foundDocument.setSumma(expenseDirect.getSumma());
                foundDocument.setPerson(personsDBLoader.getById(expenseDirect.getPerson().getId()));
                foundDocument.setExpenseType(expenseTypeDBLoader.getById(expenseDirect.getExpenseType().getId()));
                foundDocument.setDestination(expenseDirect.getDestination());
                foundDocument.setDescription(expenseDirect.getDescription());
                calendar.set(Calendar.MONTH, curMonth);
                calendar.set(Calendar.DAY_OF_MONTH, 1);
                int dayOfMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                if(curDay < dayOfMonth) {
                    dayOfMonth = curDay;
                }
                if(curMonth == endMonth) {
                    calendar.setTime(endDate);
                    dayOfMonth = Math.min(dayOfMonth, calendar.get(Calendar.DAY_OF_MONTH));
                }
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                foundDocument.setDateExp(calendar.getTime());
                debug("expensesDirectDBLoader call add for - " + foundDocument.toString() + " oldDocument = " + oldExpenseDirect.toString());
                addNew(foundDocument);
            }
            curMonth++;
        }
        debug("copyProjectUntilProjectEnd end");
    }

    private ExpenseDirect getExistDocumentForMonth(int curMonth, ExpenseDirect oldExpDirect, List<ExpenseDirect> projectContractsListForAddInProject) {
        debug("getExistDocumentForMonth called");
        Calendar calendar = Calendar.getInstance();
        for(ExpenseDirect curExpenseDirect : projectContractsListForAddInProject) {
            calendar.setTime(curExpenseDirect.getDateExp());
            if(curMonth == calendar.get(Calendar.MONTH)) {
                if( ! isEqual(oldExpDirect, curExpenseDirect)) {
                    debug("not equal oldExpDirect = " + oldExpDirect.toString() + " curExpenseDirect = " + curExpenseDirect.toString());
                    continue;
                } else {
                    debug("equal oldExpDirect = " + oldExpDirect.toString() + " curExpenseDirect = " + curExpenseDirect.toString());
                    return curExpenseDirect;
                }
            }
        }
        return null;
    }

    private boolean isEqual(ExpenseDirect oldValue, ExpenseDirect curValue) {
        if(!compareValuesString(oldValue.getDescription(), curValue.getDescription())) {
            debug("description not equal");
            return false;
        }
        if(!compareValues(oldValue.getPerson(), curValue.getPerson())) {
            debug("person not equal");
            return false;
        }
        if(!compareValues(oldValue.getExpenseType(), curValue.getExpenseType())) {
            debug("expType not equal");
            return false;
        }
        if(!compareValuesString(oldValue.getDestination(), curValue.getDestination())) {
            debug("destination not equal: old => "+ oldValue.getDestination() + " new =>" + curValue.getDestination());
            return false;
        }
        return true;
    }

    private boolean compareValuesString(String oldValue, String curValue) {
        if(oldValue != null && oldValue.trim().length() == 0) {
            oldValue = null;
        }

        if(curValue != null && curValue.trim().length() == 0) {
            curValue = null;
        }

        return compareValues(oldValue, curValue);
    }

    private boolean compareValues(Object oldValue, Object curValue) {
        boolean result = false;
        if(curValue == null && oldValue == null) {
            result = true;
        }
        if(curValue != null && oldValue == null) {
            result = false;
        }
        if(curValue == null && oldValue != null) {
            result = false;
        }
        if(curValue != null && oldValue != null) {
            result = curValue.equals(oldValue);
        }
        return result;
    }

    private void debug(String msg) {
        LogSimple.debug(this, msg);
    }
}
