package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.ClientKoeffs;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 16:52
 * To change this template use File | Settings | File Templates.
 */

//@ManagedBean(name= "projectsDBLoader")
//@SessionScoped
@Named(value = "projectsDBLoader")
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
@Stateless
public class ProjectsDBLoader extends CommonDbLoader<Project> {

    // @ManagedProperty(value="#{projectContractsDBLoader}")
    @EJB
    private ProjectContractsDBLoader projectContractsDBLoader;

    @EJB
    private ProjectTeamDBLoader projectTeamDBLoader;

    @EJB
    private ExpensesTeamDBLoader expensesTeamDBLoader;

    @EJB
    private ExpensesDirectDBLoader expensesDirectDBLoader;

    @EJB
    private IncomeDBLoader incomeDBLoader;

    @EJB
    private CurrentDateBean currentDateBean;

    @EJB
    private PersonsDBLoader personsDBLoader;

    @EJB
    private ClientsDBLoader clientsDBLoader;

    @EJB
    private ProjectTypeDBLoader projectTypeDBLoader;

    @EJB
    private ContractStatusDBLoader contractStatusDBLoader;
    private boolean useClientKoeff = true;

    @Override
    protected void afterAddEntityToDb(Project entity) {
        List<ProjectContract> projectContracts = entity.getProjectContracts();
        if(projectContracts != null) {
            for(ProjectContract row:projectContracts) {
                row.setProjectId(entity.getId());
            }
            projectContractsDBLoader.update(projectContracts, new LinkedList<ProjectContract>());
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(Project currentProject) {
        Project prevState = getById(currentProject.getId());

        if( ! prevState.getEndDatePlan().equals(currentProject.getEndDatePlan())) {
            Long projectId = currentProject.getId();
            List<TeamItem> projectTeam = projectTeamDBLoader.loadByLinkedId("projectId", projectId);
            List<ExpenseTeam> expenseTemplate = new LinkedList<ExpenseTeam>();
            for(TeamItem itemTeam : projectTeam) {
//                final Person person = personsDBLoader.getById(itemTeam.getPersonId());
//                boolean isLegionare
//                        = Person.LegionnaireState.ISLEGIONNAIRE.getValue().equals(person.getLegionnaireState());
//                boolean personMainProject_IsCurrentProject
//                        = currentProject.getId().equals(person.getMainProjectId());
//                if(  ! isLegionare || ! personMainProject_IsCurrentProject ) {
                // ������ ��������� �) �� �������� � ��������� "��������"
                //   ���� �) ��������� "��������" �� ��� �� ��� "��������" ������
                //   �.�. ��� "��������� �������" ���������� �� ��������� / �������
                //    ���� ��������� �������� � ��������� "��������"
                //  ������� �� ������ ���������� ������ "����������"
                //  �� ������ � ������� ��� �������� ��������
                ExpenseTeam expTeamItemForOneDay = new ExpenseTeam();
                expTeamItemForOneDay.setPersonId(itemTeam.getPersonId());
                expTeamItemForOneDay.setLoadPercent(itemTeam.getLoadPercent());
//                    expTeamItemForOneDay.setPrice(person.getDayPrice());
                expenseTemplate.add(expTeamItemForOneDay);
//                }
            }
            expensesTeamDBLoader.modifyEndDate(currentProject.getId(), expenseTemplate,
                    prevState.getEndDatePlan(), currentProject.getEndDatePlan());

            Number projectTeamExpenses
                    = expensesTeamDBLoader.getProjectExpensesTeamSum(projectId);

            currentProject.setEfficiencyProgn(
                    new BigDecimal( getDoubleSafe(currentProject.getPrice()) -
                            (getDoubleSafe(projectTeamExpenses)
                                    + getDoubleSafe(currentProject.getExpense())
                                    + getDoubleSafe(currentProject.getExpensePlan())
                            )
                    )
            );
        }


        super.update(currentProject);
    }

    @Override
    protected void afterUpdateEntityInDb(Project entity) {
        if(entity.getProjectContracts() == null) {
            return;
        }
        projectContractsDBLoader.update(entity.getProjectContracts(),
                projectContractsDBLoader.loadByLinkedId("projectId", entity.getId()));
    }

    @Override
    protected void beforeDeleteEntityInDb(Project entity) {
        projectContractsDBLoader.deleteByProjectId(entity.getId());
    }

    @Override
    protected Class getEntityClass() {
        return Project.class;
    }

    @Override
    protected Long getId(Project entity) {
        return entity.getId();
    }

    public ProjectContractsDBLoader getProjectContractsDBLoader() {
        return projectContractsDBLoader;
    }

    public void setProjectContractsDBLoader(ProjectContractsDBLoader projectContractsDBLoader) {
        this.projectContractsDBLoader = projectContractsDBLoader;
    }

    @Override
    public void enrichModel(List<Project> projects) {
        if(projects == null || projects.size() < 1) {
            return;
        }
        LogSimple.debug(this, "enrichModel started");
        List<ProjectType> projectTypes = projectTypeDBLoader.getAll();
        Map<Long, ProjectType> hProjectTypes = new HashMap();
        for(ProjectType row : projectTypes) {
            hProjectTypes.put(row.getId(), row);
        }

        List<Long> projectsIds = new ArrayList<Long>(projects.size());
        for(Project project: projects) {
            projectsIds.add(project.getId());
        }

        Map<Long, ContractStatus> contractStatuses = new HashMap<Long, ContractStatus>();
        for(ContractStatus row : contractStatusDBLoader.getAll()) {
            contractStatuses.put(row.getId(), row);
        }

        Map<Long, Number> projectsIncome = incomeDBLoader.getProjectsIncomeSum(projectsIds);
        Map<Long, Number> projectsDirectExpenses
                = expensesDirectDBLoader.getProjectsExpensesDirectSum(projectsIds,
                currentDateBean.getCurrentDate() //  ������� ����
        );
        Map<Long, Number> projectsDirectExpensesPlan
                = expensesDirectDBLoader.getProjectsExpensesDirectSumPlan(projectsIds,
                currentDateBean.getCurrentDate() //  ������� ����
        );

        Map<Long, Number> projectsTeamExpensesToCurrentDate
                = expensesTeamDBLoader.getProjectsExpensesTeamSum(projectsIds,
                currentDateBean.getCurrentDate() //  ������� ����
        );

        Map<Long, Number> projectsTeamExpensesAll
                = expensesTeamDBLoader.getProjectsExpensesTeamAllSum(projectsIds);
        BigDecimal teamPercent = ConstantsHelper.BIGDECIMAL_ONE;
        BigDecimal contractsPercent = ConstantsHelper.BIGDECIMAL_ONE;
        Long clientId = null;
        for(Project project: projects) {
            if( ! project.getClient().getId().equals(clientId)) {
                clientId = project.getClient().getId();
                if(useClientKoeff) {
//                teamPercent = new BigDecimal(1+project.getClient().getTeamPercent()/100d);
                    teamPercent = new BigDecimal(ClientKoeffs.getTeamKoeff(project.getClient()));
//                contractsPercent = new BigDecimal(1-project.getClient().getContractsPercent()/100d);
                    contractsPercent = new BigDecimal(ClientKoeffs.getContractKoeff(project.getClient()));
                }
            }
            // ��������� ����� ����������� ��������� �� ����������
            if(project.getPrice() != null) {
                project.setPrice(project.getPrice().multiply(contractsPercent));
            }
            // ��� ����������� ������� ��� �������
            Number incomeSum = projectsIncome.get(project.getId());
            project.setIncome(
                    new BigDecimal(
                            getDoubleSafe(incomeSum)
                    )
            );

            // ��� ������ ������� ������� �� ������� ���� ������������
            Number directExpensesSum = projectsDirectExpenses.get(project.getId());

            // ��� �������� ������ ������� ������� ( ����� ������� ���� )
            Number directExpensesSumPlan = projectsDirectExpensesPlan.get(project.getId());

            // ����� �������� �� ������� � ����� (��������� ��������)
            project.setCalculatedTeamMonthCost(projectTeamDBLoader.getTeamMonthCost(project.getId()));

            if(project.getCalculatedTeamMonthCost() != null) {
                LogSimple.debug(this, "teamMonthCost = " + project.getCalculatedTeamMonthCost());
                project.setCalculatedTeamMonthCost(project.getCalculatedTeamMonthCost().multiply(teamPercent));
            }

            // ����� ����������� �������� �� ������� � ���� ������ ������� �� ������� ����
            Number teamExpensesToCurrentDate
                    = projectsTeamExpensesToCurrentDate.get(project.getId());
            if(teamExpensesToCurrentDate != null) {
                teamExpensesToCurrentDate = new Double(teamExpensesToCurrentDate.doubleValue()*teamPercent.doubleValue());
            }

            project.setExpense(
                    new BigDecimal(
                            getDoubleSafe(teamExpensesToCurrentDate)
                                    + getDoubleSafe(directExpensesSum)
                    )
            );

            project.setExpensePlan(
                    new BigDecimal(
                            +getDoubleSafe(directExpensesSumPlan)
                    )
            );

            // ����� �������������� �������� �� ������� �� �������� ���� ��������� �������
            Number teamExpenses
                    = projectsTeamExpensesAll.get(project.getId());
            if(teamExpenses != null) {
                teamExpenses = new Double(teamExpenses.doubleValue()*teamPercent.doubleValue());
            }

            // ���� ������� ����� ��� ����������� �������
            project.setEfficiencyProgn(
                    new BigDecimal( getDoubleSafe(project.getPrice()) -
                            (getDoubleSafe(teamExpenses)
                                    + getDoubleSafe(directExpensesSum)
                                    + getDoubleSafe(directExpensesSumPlan)
                            )
                    )
            );
            if(project.getProjectManagerId() != null) {
                Person projectManager = personsDBLoader.getById(project.getProjectManagerId());
                project.setProjectMName(projectManager.getLastName() + " " + projectManager.getFirstName());
            }

            if(project.getStatusId() != null) {
                ContractStatus contractStatus = contractStatuses.get(project.getStatusId());
                if(contractStatus != null) {
                    project.setStatusName(contractStatus.getName());
                }
            }

            ProjectType projectType = hProjectTypes.get(project.getType());
            if(projectType != null) {
                project.setProjectTypeName(projectType.getName());
            }
        }
        LogSimple.debug(this, "enrichModel finished");
    }

    public void enrichFinanceModel(List<Project> projects) {
        if(projects == null || projects.size() < 1) {
            return;
        }
        LogSimple.debug(this, "enrichModel started");
        List<ProjectType> projectTypes = projectTypeDBLoader.getAll();
        Map<Long, ProjectType> hProjectTypes = new HashMap();
        for(ProjectType row : projectTypes) {
            hProjectTypes.put(row.getId(), row);
        }

        List<Long> projectsIds = new ArrayList<Long>(projects.size());
        for(Project project: projects) {
            projectsIds.add(project.getId());
        }

        Map<Long, ContractStatus> contractStatuses = new HashMap<Long, ContractStatus>();
        for(ContractStatus row : contractStatusDBLoader.getAll()) {
            contractStatuses.put(row.getId(), row);
        }

        Map<Long, Number> projectsIncome = incomeDBLoader.getProjectsIncomeSum(projectsIds);
        Map<Long, Number> projectsDirectExpenses
                = expensesDirectDBLoader.getProjectsExpensesDirectSum(projectsIds, currentDateBean.getCurrentDate());

        Map<Long, Number> projectsDirectExpensesPlan
                = expensesDirectDBLoader.getProjectsExpensesDirectSumPlan(projectsIds,
                currentDateBean.getCurrentDate() //  ������� ����
        );


        for(Project project: projects) {


            // ��� ����������� ������� ��� �������
            Number incomeSum = projectsIncome.get(project.getId());
            project.setIncome(
                    new BigDecimal(
                            getDoubleSafe(incomeSum)
                    )
            );

            // ��� ������ ������� ������� �� ������� ���� ������������
            Number directExpensesSum = projectsDirectExpenses.get(project.getId());

            // ��� �������� ������ ������� ������� ( ����� ������� ���� )
            Number directExpensesSumPlan = projectsDirectExpensesPlan.get(project.getId());



            project.setExpense(new BigDecimal(getDoubleSafe(directExpensesSum)));
            project.setExpensePlan(new BigDecimal(getDoubleSafe(directExpensesSumPlan)));

            if(project.getProjectManagerId() != null) {
                Person projectManager = personsDBLoader.getById(project.getProjectManagerId());
                project.setProjectMName(projectManager.getLastName() + " " + projectManager.getFirstName());
            }

            if(project.getStatusId() != null) {
                ContractStatus contractStatus = contractStatuses.get(project.getStatusId());
                if(contractStatus != null) {
                    project.setStatusName(contractStatus.getName());
                }
            }

            ProjectType projectType = hProjectTypes.get(project.getType());
            if(projectType != null) {
                project.setProjectTypeName(projectType.getName());
            }
        }
        LogSimple.debug(this, "enrichModel finished");
    }

    private double getDoubleSafe(Number val) {
        if(val == null) {
            return 0;
        }
        else return val.doubleValue();
    }
    //    public Collection<Long> getClientsCollectionByPM(Long id) {
//        List<Project> projects = loadByLinkedId("projectManagerId", id);
//        Set<Long> result = new HashSet<Long>();
//        for(Project row : projects) {
//            result.add(row.getClientId());
//        }
//        return result;
//    }
//
    public List<Project> getProjectsForAuthorizedUser(
            Long authorisedPersonId,
            boolean isTechnicalAM,
            boolean isProjectM,
            boolean isRoot,
            Long clientId) {
        List<Project> projects = null;
        if(isRoot) {
            projects = loadByClientId(clientId);
        } else if(isTechnicalAM) {
            Client client = clientsDBLoader.getById(clientId);
            if(authorisedPersonId.equals(client.getTechnicalAM())) {
                projects = loadByClientId(clientId);
                LogSimple.debug(this, "getProjectsForAuthorizedUser isTechnicalAM projects "+ projects);
            }
        }

        if(projects == null) {
            if(isProjectM) {
                projects = loadByProjectM(clientId, authorisedPersonId);
            }
        }
        if(projects != null) {
            enrichModel(projects);
        }

        return projects;
    }


    public List<Project> getNotClosedProjectsForFin() {
        Query query = getEntityManager().createNamedQuery("Project.getNotClosedProjectsWOSales");
        query.setParameter("statusId", ContractStatus.CLOSED.getId());
        query.setParameter("woClientName", ConstantsHelper.CLIENT_NAME_SALES);
        List<Project> result = query.getResultList();
        if(result != null) {
            enrichFinanceModel(result);
        }
        return result;
    }

    private List<Project> loadByClientId(Long clientId) {
        Query query = getEntityManager().createNamedQuery("Project.getByClientId");
        query.setParameter("clientId", clientId);
        return query.getResultList();
    }

    private List<Project> loadByProjectM(Long clientId, Long authorisedPersonId) {
        Query query = getEntityManager().createNamedQuery("Project.getForClientByProjectM");
        query.setParameter("clientId", clientId);
        query.setParameter("projectManagerId", authorisedPersonId);
        return query.getResultList();
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void updatePersonPrice2(Person entity) {
        projectTeamDBLoader.updatePersonPrice2(entity.getId(), entity.getDayPrice2(), currentDateBean.getCurrentDate());
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void updatePersonPrice2ForAllDates(Person entity) {
        projectTeamDBLoader.updatePersonPrice2ForAllDates(entity.getId(), entity.getDayPrice2());

    }

    public BigDecimal getAssignedContractsSum(List<ProjectContract> projectContracts) {
        double result = 0;
        for(ProjectContract row : projectContracts) {
            result += row.getPrice().doubleValue();
        }
        return new BigDecimal(result);
    }

    public String getAssignedContractsNumbers(List<ProjectContract> projectContracts) {
        StringBuilder result = new StringBuilder();
        Set<String> sortedNumber = new TreeSet<String>();
        for(ProjectContract row : projectContracts) {
            sortedNumber.add(row.getNumber());
        }
        for(String curNumber : sortedNumber) {
            if(result.length() > 0) {
                result.append(", ");
            }
            result.append(curNumber);
        }
        return result.toString();
    }

    public void setUseClientKoeff(boolean useClientKoeff) {
        this.useClientKoeff = useClientKoeff;
    }
}
