package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.*;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "clientReportsDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class ClientReportsDBLoader {
    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    ClientsDBLoader clientsDBLoader;
    @EJB
    ProjectContractsDBLoader projectContractsDBLoader;
    @EJB
    ProjectsReportDBLoader projectsReportDBLoader;
    @EJB
    ExpensesDirectDBLoader expensesDirectDBLoader;
    @EJB
    IncomeDBLoader incomeDBLoader;
    @EJB
    PersonFieldsCryptor personFieldsCryptor;
    @EJB
    CurrentDateBean currentDateBean;
    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<ClientReport> getReportData(Person authorisedPerson, ReportDateFilter reportDateFilter, List<String> selectedDirectionsIds) {
        List<ClientReport> reports = new LinkedList<ClientReport>();
//        List<Client> clients = clientsDBLoader.getAll(new String []{"name"});
        List<Client> clients = clientsDBLoader.getClientsForAuthorizedUser(authorisedPerson);
        Date currentDate = currentDateBean.getCurrentDate();
        for(Client client : clients) {
            if(selectedDirectionsIds != null) {
                if( ! selectedDirectionsIds.contains(client.getDirectionId().toString())) {
                    continue;
                }
            }

            List<Project> projects = projectsDBLoader.loadByFieldValue("client", client);
            if(projects == null || projects.size() == 0) {
                continue;
            }
            ClientReport report = new ClientReport();
            report.setClient(client);
            BigDecimal sumAssignedContracts = new BigDecimal(0);
            BigDecimal expensesActual = new BigDecimal(0);
            BigDecimal incomeActual = new BigDecimal(0);
            Date lastActivityPlannedEndDate = null;
            BigDecimal actualCurrentFTE = new BigDecimal(0);
            BigDecimal actualMiddleFTE = new BigDecimal(0);
            BigDecimal plannedIncome = new BigDecimal(0);
            BigDecimal planRent = new BigDecimal(0);
            Date projectsMinStartDate = null;
            Date projectMaxEndDatePlan = null;
            for(Project project : projects) {
                if(project.getStartDate().after(reportDateFilter.getEndDate())) {
                    continue;
                }
                if(project.getEndDatePlan().before(reportDateFilter.getStartDate())) {
                    continue;
                }
                for(ProjectContract pc : projectContractsDBLoader.loadByProjectId(project.getId())) {
                    sumAssignedContracts = sumAssignedContracts.add(pc.getPrice());
                }
                report.setSumAssignedContracts(sumAssignedContracts);

                for(ExpenseDirect expDirect : expensesDirectDBLoader.loadByProjectId(project.getId())) {
                    expensesActual = expensesActual.add(expDirect.getSumma());
                }
                // ������� �� �������
                Query query = em.createQuery("select sum(t.loadPercent), t.personId, t.price2, t.dateExp from ExpenseTeam t " +
                        " where t.projectId = :projId" +
                        " group by t.personId, t.price2, t.dateExp");
                query.setParameter("projId", project.getId());
                List<Object[]> teamExp = query.getResultList();
                Person fakePerson = new Person();

                for(Object[] row : teamExp) {
                    Date rowDate = (Date) row[3];
                    if(rowDate.after(currentDate)) {
                        continue;
                    }
                    fakePerson.setId((Long) row[1]);
                    fakePerson.setDayPrice2((BigInteger) row[2]);
                    personFieldsCryptor.decryptDayPrice(fakePerson);
                    expensesActual = expensesActual.add(fakePerson.getDayPrice().multiply(new BigDecimal((Double) row[0])).divide(ConstantsHelper.BIGDECIMAL_HUNDRED));
                }

                report.setExpensesActual(expensesActual);

                query = em.createQuery("select sum(t.summa) from Income t where t.projectId = :prjId");
                query.setParameter("prjId", project.getId());
                report.setIncomeActual(getBigDecimalSafe(query));

                lastActivityPlannedEndDate = project.getEndDatePlan();
                if(project.getEndDatePlan().after(lastActivityPlannedEndDate)) {
                    lastActivityPlannedEndDate = project.getEndDatePlan();
                }

                if(project.getPriceQ1() == null && project.getPriceQ2() == null && project.getPriceQ3() == null && project.getPriceQ4() == null) {
                    plannedIncome = plannedIncome.add(project.getPrice());
                } else {
                    plannedIncome = plannedIncome.add(project.getPriceQ1()).add(project.getPriceQ2())
                            .add(project.getPriceQ3()).add(project.getPriceQ4());
                }

                query = em.createQuery("select t.loadPercent, t.dateExp from ExpenseTeam t " +
                        " where t.projectId = :prjId");
                query.setParameter("prjId", project.getId());
                List<Object[]> teamList = query.getResultList();

                double _actualMiddleFTE = 0;
                double _actualCurrentFTE = 0;
                for(Object[] row : teamList) {
                    _actualMiddleFTE += (Double) row[0];
                    Date rowDate = (Date) row[1];
                    if(  currentDate.after(rowDate) || currentDate.equals(rowDate)) {
                        _actualCurrentFTE += (Double) row[0];
                    }
                }
                actualMiddleFTE = actualMiddleFTE.add(new BigDecimal(_actualMiddleFTE));
                actualCurrentFTE = actualCurrentFTE.add(new BigDecimal(_actualCurrentFTE));
                if(projectsMinStartDate == null || projectsMinStartDate.after(project.getStartDate())) {
                    projectsMinStartDate = project.getStartDate();
                }

                if(projectMaxEndDatePlan == null || projectMaxEndDatePlan.before(project.getEndDatePlan())) {
                    projectMaxEndDatePlan = project.getEndDatePlan();
                }
            }
            if(projectsMinStartDate == null ) {
                projectsMinStartDate = reportDateFilter.getStartDate();
            }
            if(projectMaxEndDatePlan == null ) {
                projectMaxEndDatePlan = reportDateFilter.getEndDate();
            }
            double daysForMiddleFTE = DateHelper.calculateDaysBetweenTwoDatesInclusive(projectsMinStartDate, projectMaxEndDatePlan);
            double daysForCurrentFTE = DateHelper.calculateDaysBetweenTwoDatesInclusive(projectsMinStartDate, currentDate);
            if(daysForCurrentFTE == 0) {
                daysForCurrentFTE = 1;
            }
            final int scale = 3;
            final RoundingMode roundMode = RoundingMode.HALF_UP;

            report.setActualCurrentFTE(actualCurrentFTE
                    .divide(new BigDecimal(daysForCurrentFTE), scale, roundMode)
                    .divide(ConstantsHelper.BIGDECIMAL_HUNDRED, scale, roundMode)
                    .doubleValue());
            report.setActualMiddleFTE(actualMiddleFTE
                    .divide(new BigDecimal(daysForMiddleFTE), scale, roundMode)
                    .divide(ConstantsHelper.BIGDECIMAL_HUNDRED, scale, roundMode)
                    .doubleValue());
            //LogSimple.debug(this, " projectId = " + project.getId());
            LogSimple.debug(this, " clientId = " + client.getId());
            LogSimple.debug(this, " client = " + client.getName());
            LogSimple.debug(this, " daysForCurrentFTE = " + daysForCurrentFTE);
            LogSimple.debug(this, " daysForMiddleFTE = " + daysForMiddleFTE);
            LogSimple.debug(this, " _currentFTE = " + actualCurrentFTE);
            LogSimple.debug(this, " _middleFTE = " + actualMiddleFTE);

            report.setPlannedIncome(plannedIncome);
            report.setLastActivityPlannedEndDate(lastActivityPlannedEndDate);
            sumAssignedContracts = report.getSumAssignedContracts();
            expensesActual = report.getExpensesActual();
            if(sumAssignedContracts == null) {
                sumAssignedContracts = new BigDecimal(0);
            }
            if(expensesActual == null) {
                expensesActual = new BigDecimal(0);
            }
            planRent = sumAssignedContracts.subtract(expensesActual);
            report.setPlanRent(planRent);
            if(report.getLastActivityPlannedEndDate() != null) {
                reports.add(report);
            }
        }
        return reports;
    }

    public List<ProjectReport> getReportDataFromProjects(ReportDateFilter reportDateFilter, List<String> selectedClientsIds) {
        debug("getReportDataFromProjects executed");
        debug("selectedClientsIds = " + selectedClientsIds);
        List<ProjectReport> reports = new LinkedList<ProjectReport>();
        Map<String, ProjectReport> clientReport = new TreeMap<String, ProjectReport>();
        List<Client> clients = new LinkedList<Client>();
        if(selectedClientsIds == null) {
           debug("selectedClientsIds == null");
           clients = clientsDBLoader.getAll(new String []{"name"});
        } else {
            debug("selectedClientsIds = " + selectedClientsIds);
            for(String clientId : selectedClientsIds) {
                clients.add(clientsDBLoader.getById(Long.parseLong(clientId)));
            }
            debug("clients = " + clients);
        }

        for(Client client : clients) {
            reports = projectsReportDBLoader.getReportDataByClientId(client.getId(), reportDateFilter);
            String clientName = client.getName();
            ProjectReport sumReport = clientReport.get(clientName);
            if(sumReport == null) {
                sumReport = ProjectReportHelper.createProjectReport(clientName);
                clientReport.put(clientName, sumReport);
            }
            for(ProjectReport report : reports) {
                ProjectReportHelper.accumulate(sumReport, report, false);
            }
            if(sumReport.getWorkDays() != 0) {
                sumReport.setActualAverageFTE(sumReport.getWorkingPersons()/sumReport.getWorkDays());
            }
            sumReport.setDirectionId(client.getDirectionId());
        }
        reports.clear();
        reports.addAll(clientReport.values());
        return reports;
    }

//    private double getDoubleSafe(Double val) {
//        return val != null ? val : val.doubleValue();
//    }
//
    public List<ProjectReport> getDirectionReportData(ReportDateFilter reportDateFilter, List<String> selectedDirectionsIds) {
        List<ProjectReport> result = new LinkedList<ProjectReport>();
        List<ProjectReport> reports = getReportDataFromProjects(reportDateFilter, null);
        for(ProjectReport row : reports) {
            if(selectedDirectionsIds != null) {
                if(selectedDirectionsIds.contains(row.getDirectionId().toString())) {
                    result.add(row);
                }
            } else {
                result.addAll(reports);
            }
        }
        return result;
    }

    private BigDecimal getBigDecimalSafe(Query query) {
        BigDecimal result = (BigDecimal) query.getSingleResult();
        if(result == null) {
            result = ConstantsHelper.BIGDECIMAL_ZERO;
        }
        return result;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}