package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.CurrentDateBean;
import app.dto.AlternateTAMReport;
import app.dto.Person;
import app.helpers.LogSimple;
import app.loaders.AlternateTAMReportDBLoader;
import app.loaders.PersonsDBLoader;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "alternatePMReportTableController")
@ViewScoped
public class AlternatePMReportTableController {

    private String backPath;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private ReportDateFilter reportDateFilter;
    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private PersonsDBLoader personsDBLoader;
    @EJB
    private AlternateTAMReportDBLoader alternateTAMReportDBLoader;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    private List<AlternateTAMReport> reportItems;
    private AlternateTAMReport itogItem;

//    private List<BenchPersonProject> reportPersonProjectsItems;
    private Person alternatePM;

    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        localUuid = getConversationUuid()+"_alternatePMReportTableController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            parameters = new HashMap();
            final Person person = authorisedUser.getPerson();
            alternatePM = person;
            parameters.put("backPath", backPath);
            parameters.put("alternatePM", alternatePM);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            backPath = (String) parameters.get("backPath");
            alternatePM = (Person) parameters.get("alternatePM");
        }
    }

    public List<Person> getAlternateTAMList() {
        return personsDBLoader.getAlternateTAMs();
    }

    public List<AlternateTAMReport> getItems() {
        return reportItems;
    }

//    public List<BenchPersonProject> getReportItems() {
//        return reportPersonProjectsItems;
//    }

//    public void onRowToggle(ToggleEvent event) {
//        reportPersonProjectsItems = ((AlternatePMReport) event.getData()).getWorkProjects();
//    }
//
    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public String doBack() {
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getLocalUuid() {
        return localUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public void doFilter() {
        LogSimple.debug(this, "doFilter executed");
        reportItems = alternateTAMReportDBLoader.getReportData(reportDateFilter, alternatePM.getId());
        double cost = 0;
        for(AlternateTAMReport reportItem: reportItems) {
            cost += reportItem.getCost();
            debug("calculate cost reportItem.getCost() => " + reportItem.getCost());
        }
        itogItem = new AlternateTAMReport();
        itogItem.setCost(cost);
        debug("reportItems = " + reportItems.size());
    }

    public AlternateTAMReport getItogItem() {
        return itogItem;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

    public void setAlternatePM(Person alternatePM) {
        this.alternatePM = alternatePM;
    }

    public Person getAlternatePM() {
        return alternatePM;
    }

    public Long getAlternatePMId() {
        return alternatePM.getId();
    }

    public void setAlternatePMId(Long alternatePMId) {
        alternatePM = personsDBLoader.getById(alternatePMId);
    }
}
