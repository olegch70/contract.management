package app.controllers;

import app.dto.Direction;
import app.dto.ExpenseType;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.loaders.DirectionDBLoader;
import app.loaders.ExpenseTypeDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "expensesTypesListController")
@ViewScoped
public class ExpensesTypesListController extends AbstractTableController {
    private static final String VIEW_NAME = "expensesTypesList";
    @EJB
    private ExpenseTypeDBLoader expenseTypeDBLoader;
    private List<ExpenseType> filteredRows;

    public void childInitModel() {
        getUiTableHelper().calledFromInit(parameters, expenseTypeDBLoader);
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCall(AbstractController caller){
        return doCallByOwnerId(VIEW_NAME, caller, null);
    }

    public String add() {
        return EditExpenseTypeController.doCallAdd(this);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return EditExpenseTypeController.doCallEditByRecordId(this, getSelectedItem().getId());
    }

    @Override
    protected void deleteInternal() {
        expenseTypeDBLoader.delete(getSelectedItem().getId());
    }

    private ExpenseType getSelectedItem() {
        return (ExpenseType) getSelectedItemSuper();
    }

    public List<ExpenseType> getItems() {
        return expenseTypeDBLoader.getAll();
    }
}
