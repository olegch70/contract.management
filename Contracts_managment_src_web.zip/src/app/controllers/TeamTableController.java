package app.controllers;

import app.beans.CurrentDateBean;
import app.beans.FormatterUtil;
import app.dto.*;
import app.dto.Project;
import app.dto.ProjectType;
import app.dto.TeamItem;
import app.helpers.TeamEditHelper;
import app.helpers.ViewNavigationHelper;
import app.loaders.ExpensesTeamDBLoader;
import app.loaders.ProjectTeamDBLoader;
import app.loaders.ProjectsDBLoader;
import app.loaders.PersonsDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AbortProcessingException;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 18.12.13
 * Time: 15:21
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "teamTableController")
@ViewScoped
public class TeamTableController extends AbstractTableController {
    public static final String PROJECT_ID = "projectId";
    public static final String PROJECT_TYPE = "projectType";
    public static final String VIEW_NAME = "teamList";
    @EJB
    private ProjectsDBLoader projectsDBLoader;
    @EJB
    private PersonsDBLoader personsDBLoader;
    @EJB
    private ProjectTeamDBLoader projectTeamDBLoader;

    @EJB
    ExpensesTeamDBLoader expensesTeamDBLoader;

    @EJB
    CurrentDateBean currentDateBean;

    private Long editItemId;
    private List<TeamItem> filteredRows;
    private Project currentProject;

    //����������� ��� ������ �� ����������
    public static final String CONTEXT_SUFFIX = "_editContractTeamController";
    public static final String MARKER_RETURN_FROM_ADD_PERSONS_IN_TEAM = "markerReturnFromAddPersonsInTeam";
    private Date legionnaireEndDate;
    private Double legionnairePercentOffer;
    private BigDecimal clientMonthPrice;

    @Override
    public void childInitModel() throws AbortProcessingException {
        List<TeamItem> model = getCurrentTeam();
        enrichModel(model);
        sortByFIO(model);
        TeamEditHelper.saveModelInParameters(parameters, model);
        currentProject = projectsDBLoader.getById(parentId);
        parameters.put(PROJECT_TYPE, currentProject.getType());
        if(null != parameters.remove(MARKER_RETURN_FROM_ADD_PERSONS_IN_TEAM)) {
            displaySaveReminder();
        }
    }

    private void sortByFIO(List<TeamItem> model) {
        TreeMap<String, TeamItem> sorter = new TreeMap<String, TeamItem>();
        for(TeamItem item: model) {
            sorter.put(item.getPerson().getFIO(), item);
        }

        model.clear();
        model.addAll(sorter.values());
    }

    private void enrichModel(List<TeamItem> model) {
        String sql = "select t from ExpenseTeam t " +
                " where t.projectId = :projectId" +
                "   and t.dateExp = :currentDate";
        Map parameters = new HashMap();
        parameters.put("currentDate", currentDateBean.getCurrentDate());
        parameters.put("projectId", parentId);

        Map<Long, ExpenseTeam> currentDateTeamExpenses = new HashMap<Long, ExpenseTeam>();
        List<ExpenseTeam> teamExpenses
                = expensesTeamDBLoader.getBySqlWithParams(sql, parameters);

        for(ExpenseTeam teamExpense: teamExpenses) {
            currentDateTeamExpenses.put(teamExpense.getPersonId(), teamExpense);
        }

        for(TeamItem row: model) {
            Person person = row.getPerson();
            if(parentId.equals(person.getMainProjectId())) {
                row.setLegionarie(false);
                row.setAttachmentPlanEndDate(person.getLegionnaireEndDate());
            } else {
                row.setLegionarie(true);
                row.setLegionnairePlanEndDate(person.getLegionnaireEndDate());
            }
            ExpenseTeam expenseTeam = currentDateTeamExpenses.get(person.getId());
            if(expenseTeam != null && expenseTeam.getLoadPercent() != null ) {
                row.setLoadPercent(expenseTeam.getLoadPercent());
        }
    }
    }

    public static Long getLocalProjectId(SessionDataHolder sessionDataHolder, String conversationUuid) {
        return getParentIdValue(sessionDataHolder, conversationUuid, VIEW_NAME);
    }

    public static Long getLocalProjectType(SessionDataHolder sessionDataHolder, String conversationUuid) {
        Map parameters = ViewNavigationHelper.getModel(sessionDataHolder, conversationUuid, VIEW_NAME);
        return (Long) parameters.get(PROJECT_TYPE);
    }

    public List<TeamItem> getCurrentTeam() {
        List<TeamItem> model = TeamEditHelper.getModel(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid);
        System.out.println("currentTeam = " + model);
        if(model == null) {
            model = projectTeamDBLoader.loadByLinkedId(PROJECT_ID, parentId);
        }
        return model;
    }

    public static String doCallByProjectId(AbstractController caller, Long projectId){
        return doCallByOwnerId(VIEW_NAME, caller, projectId);
    }

    public String goToAddPerson() {
        parameters.put(MARKER_RETURN_FROM_ADD_PERSONS_IN_TEAM, "1");
        final String result = AddPersonInTeamController.doCall(this);
        return result;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public List<TeamItem> getFilteredRows() {
        if(filteredRows == null) {
            filteredRows = getCurrentTeam();
        }
        return filteredRows;
    }

    public void setFilteredRows(List<TeamItem> filteredRows) {
        this.filteredRows = filteredRows;
        parameters.put("filteredRows", this.filteredRows);
    }

    public String saveTeam() {
        projectTeamDBLoader.saveProjectTeam(parentId, getCurrentTeam());
        return doBack();
    }

    public void showLog() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        if(getSelectedPerson().getId()<0){
            displayUIMessage("��������� ��������� ��� ������������ ����������, ����� ��������� � ���������");
            return;
        }

        if( ! parentId.equals(getSelectedPerson().getPerson().getMainProjectId())) {
            displayUIMessage("��������� �� �� ���� ����������");
            return;
        }

        Person person = personsDBLoader.getById(getSelectedPerson().getPersonId());

        RequestContext rc = RequestContext.getCurrentInstance();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDateBean.getCurrentDate());
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        legionnaireEndDate = calendar.getTime();
        legionnairePercentOffer = getAvailableLegionnairePercent(person);

        rc.execute("PF('dlg').show()");
    }

    public void moveToLegionnaire() {
        Person person = getPersonById(getSelectedPerson().getId());

        double maxLegionnairePercent = getAvailableLegionnairePercent(person);
        if(legionnairePercentOffer > maxLegionnairePercent) {
            displayUIMessage("������� �� ����� ���� ����� " + FormatterUtil.formatDouble(maxLegionnairePercent) + " %");
            return;
        }

        person.setReadyForLegionnaire(true);
        person.setLegionnaireEndDate(legionnaireEndDate);
        person.setLegionnairePercentOffer(legionnairePercentOffer);
    }

    public void saveClientMonthPrice() {
        getTeamItemById(editItemId).setClientMonthPrice(clientMonthPrice);
    }

    public void doShowInfoDialog(Long id) {
        editItemId = id;
        clientMonthPrice = getTeamItemById(id).getClientMonthPrice();
        RequestContext rc = RequestContext.getCurrentInstance();
        rc.execute("PF('monthPriceDlg').show()");
    }

    private Person getPersonById(final Long personId) {
        Person person = null;
        for(TeamItem row : getCurrentTeam()) {
            if(row.getId().equals(personId)) {
                person = row.getPerson();
//                editedRow = row;
                break;
            }
        }
        return person;
    }

    private TeamItem getTeamItemById(final Long personId) {
        TeamItem teamItem = null;
        for(TeamItem row : getCurrentTeam()) {
            if(row.getId().equals(personId)) {
                teamItem = row;
                break;
            }
        }
        return teamItem;
    }

    private double getAvailableLegionnairePercent(Person person) {
        // ToDo ���������� �� ����� ���������� ���������� �������� ����� �������� �� ������� � ���������� ������� �� ������� ����
        //  �� ��������� ���� � �������� �� �������.
        double result = projectTeamDBLoader.getAvailableLegionnairePercent(currentDateBean.getCurrentDate(), person);
        return result;
    }

    public TeamItem getSelectedPerson() {
        return (TeamItem) uiTableHelper.getSelectedItem();
    }

    public void setLegionnaireEndDate(Date legionnaireEndDate) {
        this.legionnaireEndDate = legionnaireEndDate;
    }

    public Date getLegionnaireEndDate() {
        return legionnaireEndDate;
    }

    public Double getLegionnairePercentOffer() {
        return legionnairePercentOffer;
    }

    public void setLegionnairePercentOffer(Double legionnairePercentOffer) {
        this.legionnairePercentOffer = legionnairePercentOffer;
    }

    public BigDecimal getClientMonthPrice() {
        return clientMonthPrice;
    }

    public void setClientMonthPrice(BigDecimal clientMonthPrice) {
        this.clientMonthPrice = clientMonthPrice;
    }

    public boolean isShowOutstaffPrice() {
        if(ProjectType.OUTSTAFF.getId().equals(currentProject.getType())) {
            return true;
        }
        return false;
    }

    @Override
    protected void deleteInternal() {
        TeamEditHelper.removePersonFromTeam(getSelectedPerson(), getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid);
        displaySaveReminder();
    }

    private void displaySaveReminder() {
        displayUIMessage("��� ���������� ��������� ������� ������ \"���������\".");
    }
}
