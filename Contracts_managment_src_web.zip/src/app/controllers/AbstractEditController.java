package app.controllers;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 23.05.14
 * Time: 10:23
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractEditController extends AbstractController {
    public static final String COMMAND_KEY = "command";
    public static final String COMMAND_ADD = "add";
    public static final String COMMAND_EDIT = "edit";
    protected String command;
}
