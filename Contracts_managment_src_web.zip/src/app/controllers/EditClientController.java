package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.dto.Client;
import app.dto.Direction;
import app.dto.Person;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.loaders.ClientsDBLoader;
import app.loaders.DirectionDBLoader;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.01.14
 * Time: 14:43
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editClientController")
@ViewScoped
public class EditClientController extends AbstractEditController {

    private static final String VIEW_NAME = "editClient";
    public static final String CLIENT_ID_KEY = "clientId";

    @EJB
    ClientsDBLoader clientsDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    DirectionDBLoader directionDBLoader;

    private Long clientId;

    private Client client;

    public void childInitModel(){
        System.out.println("initModel() in editClientController started");
        clientId = (Long) parameters.get(CLIENT_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        System.out.println("parameters.put(clientId = " + clientId);
        if(command.equals(COMMAND_ADD)){
            client = new Client();
        } else {
            client = clientsDBLoader.getById(clientId);
        }
        System.out.println("initModel() in editClientController finished");
    }

    public String save() {
        if(command.equals(COMMAND_ADD)){
            clientsDBLoader.addNew(client);
        } else {
            System.out.println("saveClient in add client called");
            clientsDBLoader.update(client);
            System.out.println("saveClient in edit client updated");
        }
        return doBack();
    }

    public static String doCallAdd(AbstractController caller){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long id){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(CLIENT_ID_KEY, id);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        return result;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public List<Person> getPersons() {
        final List<Person> result = personsDBLoader.getTechAM();
        if( ! authorisedUser.getCurrentUserIsRoot() ) {
            final List<Person> currentUserList = new ArrayList<Person>(1);
            currentUserList.add(personsDBLoader.getById(authorisedUser.getPerson().getId()));
            LogSimple.debug(this, "list TechAM => "+Arrays.toString(result.toArray()));
            LogSimple.debug(this, "list currentUser => "+Arrays.toString(currentUserList.toArray()));
            result.retainAll(currentUserList);
            LogSimple.debug(this, "list after retain => "+Arrays.toString(result.toArray()));
        }
        return result;
    }

    public List<Direction> getDirections() {
        return directionDBLoader.getAll();
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

}
