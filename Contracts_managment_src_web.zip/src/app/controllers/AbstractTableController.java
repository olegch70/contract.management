package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.UiTableHelper;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.helpers.ViewNavigationHelper;
import app.helpers.ViewNavigationHelperModel;
import org.primefaces.context.RequestContext;

import javax.faces.bean.ManagedProperty;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.05.14
 * Time: 13:24
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractTableController extends AbstractController {
    private static final String PARENT_KEY = "parentKey";
    @ManagedProperty(value = UiTableHelper.UI_TABLE_HELPER_EL)
    protected UiTableHelper uiTableHelper;
    protected Long parentId;
    private boolean allowToDelete;

    @Override
    protected void loadValuesFromModel() {
        super.loadValuesFromModel();
        parentId = (Long) parameters.get(PARENT_KEY);
        uiTableHelper.connectToDataHolder(parameters);
    }

    public UiTableHelper getUiTableHelper() {
        return uiTableHelper;
    }

    public void setUiTableHelper(UiTableHelper uiTableHelper) {
        this.uiTableHelper = uiTableHelper;
    }

    protected abstract void deleteInternal();

    protected static String doCallByOwnerId(String viewName, AbstractController caller, Long ownerId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), viewName, paramModel);
        paramModel[0].put(PARENT_KEY, ownerId);
        return result;
    }

    public void delete() {
        if(!allowToDelete) {
            return;
        }
        allowToDelete = false;
        try {
            deleteInternal();
            uiTableHelper.deleteItemFromFiltered(uiTableHelper.getSelectedItem());
            UIMessages.displayMessage("������ �������.");
        } catch (Exception e) {
            UIMessages.displayErrorMessage("�� ������� ������� ������.");
            debug("uiTableHelper = "+uiTableHelper);
            LogSimple.error(this, e);
        }
    }

    public static Long getParentIdValue(SessionDataHolder sessionDataHolder, String conversationUuid, String modelName) {
        Map parameters = ViewNavigationHelper.getModel(sessionDataHolder, conversationUuid, modelName);
        return (Long) parameters.get(PARENT_KEY);
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
        allowToDelete = true;
    }

    protected boolean checkSelectedAndDisplayWarning() {
        if(getSelectedItemSuper() != null) {
            return true;
        }
        displayUIMessage("�������� ������� ������.");
        return false;
    }

    protected Object getSelectedItemSuper() {
        return getUiTableHelper().getSelectedItem();
    }
}
