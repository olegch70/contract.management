package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.LogSimple;
import app.helpers.ProjectReportHelper;
import app.loaders.*;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "clientsReportTableController")
@ViewScoped
public class ClientsReportTableController {

    private String backPath;

    @EJB
    private ClientReportsDBLoader clientReportsDBLoader;
    @EJB
    private DirectionReportsDBLoader directionReportsDBLoader;
    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private DirectionDBLoader directionDBLoader;
    @EJB
    private ClientsDBLoader clientsDBLoader;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    private ReportDateFilter reportDateFilter;
    private List<ProjectReport> reportItems;
    private List<ProjectReport> items;
    private Long selectedDirectionId;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private List<String> selectedDirections;
    private List<String> selectedClients;
    private ProjectReport itogItem;

    public void initModel() {
        localUuid = getConversationUuid()+"_clientsReportTableController";
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);

            List<Client> clientsList = getClientsList();
            selectedClients = new ArrayList<String>(clientsList.size());
            for(Client client: clientsList) {
                selectedClients.add(Long.toString(client.getId()));
            }
            saveModelInSession();
        } else {
            backPath = (String) parameters.get("backPath");
        }
    }

    public List<ProjectReport> getItems() {
        return items;
    }

    public List<ProjectReport> getItemsForDirection() {
        return reportItems;
    }

    public String doBack() {
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void doFilter() {
        LogSimple.debug(this, "doFilter executed");
        LogSimple.debug(this, "selectedClients = " + selectedClients);
        items = clientReportsDBLoader.getReportDataFromProjects(getReportDateFilter(), selectedClients);
        itogItem = ProjectReportHelper.accumulateItog(items);
    }

    public void doFilterDirection() {
        reportItems = directionReportsDBLoader.getReportData(getReportDateFilter(), selectedDirections);
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public List<Direction> getDirectionsList() {
        return directionDBLoader.getAll();
    }

    public List<Client> getClientsList() {
        if(authorisedUser.isCurrentUserIsFinm() ) {
            return clientsDBLoader.getClientsWoSales();
        } else {
            return clientsDBLoader.getClientsForAuthorizedUser(authorisedUser.getPerson());
        }
    }

    public void setDirectionsList(List<Direction> directionsList) {
    }

    public Long getSelectedDirectionId() {
        return selectedDirectionId;
    }

    public void setSelectedDirectionId(Long selectedDirectionId) {
        this.selectedDirectionId = selectedDirectionId;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public List<String> getSelectedClients() {
        return selectedClients;
    }

    public void setSelectedClients(List<String> selectedClients) {
        this.selectedClients = selectedClients;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public Map getParameters() {
        return parameters;
    }

    public void setParameters(Map parameters) {
        this.parameters = parameters;
    }

    public String getLocalUuid() {
        return localUuid;
    }

    public void setLocalUuid(String localUuid) {
        this.localUuid = localUuid;
    }

    public List<String> getSelectedDirections() {
        return selectedDirections;
    }

    public void setSelectedDirections(List<String> selectedDirections) {
        this.selectedDirections = selectedDirections;
    }

    public ProjectReport getItogItem() {
        return itogItem;
    }

    public void setItogItem(ProjectReport itogItem) {
        this.itogItem = itogItem;
    }
}
