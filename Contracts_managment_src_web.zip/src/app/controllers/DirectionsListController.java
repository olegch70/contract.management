package app.controllers;

import app.dto.Direction;
import app.dto.Grade;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.loaders.DirectionDBLoader;
import app.loaders.GradeDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "directionsListController")
@ViewScoped
public class DirectionsListController extends AbstractTableController {
    private static final String VIEW_NAME = "directionsList";
    @EJB
    private DirectionDBLoader directionDBLoader;

    public void childInitModel() {
        getUiTableHelper().calledFromInit(parameters, directionDBLoader);
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCall(AbstractController caller){
        return doCallByOwnerId(VIEW_NAME, caller, null);
    }

    public String add() {
        return EditDirectionController.doCallAdd(this);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return EditDirectionController.doCallEditByRecordId(this, getSelectedItem().getId());
    }

    @Override
    protected void deleteInternal() {
        directionDBLoader.delete(getSelectedItem().getId());
    }

    private Direction getSelectedItem() {
        return (Direction) getSelectedItemSuper();
    }

    public List<Direction> getItems() {
        return directionDBLoader.getAll();
    }
}
