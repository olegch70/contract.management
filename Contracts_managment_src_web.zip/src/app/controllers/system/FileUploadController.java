package app.controllers.system;

import app.beans.AuthorisedUserViewScoped;
import app.beans.CurrentDateBean;
import app.beans.DateFormatter;
import app.controllers.SessionDataHolder;
import app.controllers.utils.DataTableUIValuesHolder;
import app.dto.Person;
import app.helpers.LogSimple;
import app.loaders.PersonsDBLoader;
import app.salary.Extractor;
import app.salary.PersonSalaryDto;
import app.salary.SalaryModel;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.*;
import java.math.BigDecimal;
import java.util.*;

/**
 * author: Oleg Chamlay
 * Date: 26.03.14
 * Time: 12:43
 */
@ManagedBean(name= "fileUploadController")
@ViewScoped
public class FileUploadController {

    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;

    private DateFormatter dateFormatter = new DateFormatter();

    @EJB
    PersonsDBLoader personsDBLoader;

    @EJB
    CurrentDateBean currentDateBean;

    private String backPath;
    private String conversationUuid;
    private String fileName;
    private String localUuid;
    private Map parameters;
    private UploadedFile file;
    private List<PersonSalaryDto> items;
    private Extractor extractor;
    private SalaryModel salaryModel;
    private BigDecimal itog;
    private Date docDate;
    private Date fileActualDate;
    private TableValuesHolderPersons tableHelper;

    public void initModel() {
        localUuid = getConversationUuid()+"_fileUploadController";
        parameters = (Map) sessionDataHolder.get(localUuid);
        fileActualDate = currentDateBean.getCurrentDate();
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            tableHelper = new TableValuesHolderPersons();

            parameters.put("tableHelper", tableHelper);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            backPath = (String) parameters.get("backPath");
            tableHelper = (TableValuesHolderPersons) parameters.get("tableHelper");
        }
    }

    public void handleFileUpload(FileUploadEvent event) {
        debug("handleFileUpload executed");
        debug("fileName =  "+ event.getFile().getFileName());
        //String fileName = "C:/wrk/Obychenie/projects/Contracts_managment/uploadedFiles/May_table.xls";
        FacesMessage msg = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");
        FacesContext.getCurrentInstance().addMessage(null, msg);
        fileName = event.getFile().getFileName();
//        String pathname = "C:/wrk/Obychenie/projects/Contracts_managment/uploadedFiles";
//        String uploadedFileName = "uploadedFile.data";
//        File file = new File(pathname+"/"+uploadedFileName);
        extractor = new Extractor();
        salaryModel = new SalaryModel();
        salaryModel.setPersonsSalary(new LinkedList<PersonSalaryDto>());
        try {
            InputStream is = event.getFile().getInputstream();
            try {
                extractor.fillModelFromInputStream(is, salaryModel);
            } finally {
                is.close();
            }
            List<Person> persons = personsDBLoader.getAll();
            Map<String, Person> personsMap = new HashMap<String, Person>(persons.size());
            for(Person person: persons) {
                personsMap.put(person.getFIO(), person);
            }
            for(PersonSalaryDto personSalaryDto: salaryModel.getPersonsSalary()) {
                Person curPerson = personsMap.get(personSalaryDto.getFIO());
                if(curPerson != null) {
                    personSalaryDto.setPerson(curPerson);
                    personsMap.remove(curPerson.getFIO());
                } else {
                    personSalaryDto.addMessage("��������� �� ������ � ����");
                }
            }

            List<PersonSalaryDto> listNotExistsInFile = new LinkedList<PersonSalaryDto>();
            for(Person person: personsMap.values()) {
                if(person.getEmploymentDate() != null && person.getEmploymentDate().after(fileActualDate)) {
                    continue;
                }
                if(person.getDismissalDate() != null && person.getDismissalDate().before(fileActualDate)) {
                    continue;
                }
                PersonSalaryDto notFoundPerson = new PersonSalaryDto();
                notFoundPerson.setFIO(person.getFIO());

                notFoundPerson.addMessage("��������� ����������� � �����."
                                + getNvlDateAsString(" ������ �� ������ ", person.getEmploymentDate(), ".")
                                + getNvlDateAsString(" ������ ", person.getDismissalDate(), ".")
                );
                listNotExistsInFile.add(notFoundPerson);
            }

            Map<String, PersonSalaryDto> sortByFIO = new TreeMap<String, PersonSalaryDto>();
            for (PersonSalaryDto item: listNotExistsInFile) {
                sortByFIO.put(item.getFIO(), item);
            }
            salaryModel.getPersonsSalary().addAll(sortByFIO.values());


        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

    }

    private String getNvlDateAsString(String prefix, Date date, String suffix) {
        if(date == null) {
            return "";
        }
        return prefix + dateFormatter.formatDate(date) + suffix;
    }

    public String doBack() {
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public UploadedFile getFile() {
        return file;
    }

    public void setFile(UploadedFile file) {
        this.file = file;
    }

    public void upload() {
        debug("upload executed");
        debug("fileName =  "+ file.getFileName());
        if(file != null) {
            FacesMessage msg = new FacesMessage("Succesful", file.getFileName() + " is uploaded.");
            FacesContext.getCurrentInstance().addMessage(null, msg);
        }
    }

    public String goBack() {
        final String returnPath = backPath + "?conversationUuid=" + conversationUuid
                + "&faces-redirect=true";
        debug("goBack() called => "+ returnPath);
        return returnPath;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getLocalUuid() {
        return localUuid;
    }

    public void setLocalUuid(String localUuid) {
        this.localUuid = localUuid;
    }

    public List<PersonSalaryDto> getItems() {
        if(salaryModel != null) {
            return salaryModel.getPersonsSalary();
        }
        return null;
    }

    public void setItems(List<PersonSalaryDto> items) {
        this.items = items;
    }

    public BigDecimal getItog() {
        if(salaryModel != null) {
            return salaryModel.getItog();
        }
        return null;
    }

    public void setItog(BigDecimal itog) {
        this.itog = itog;
    }

    public Date getDocDate() {
        if(salaryModel != null) {
            return salaryModel.getDate();
        }
        return null;
    }

    public void setDocDate(Date docDate) {
        this.docDate = docDate;
    }

    public DateFormatter getDateFormatter() {
        return dateFormatter;
    }

    public void setDateFormatter(DateFormatter dateFormatter) {
        this.dateFormatter = dateFormatter;
    }

    public void setFileActualDate(Date fileActualDate) {
        this.fileActualDate = fileActualDate;
    }

    public Date getFileActualDate() {
        return fileActualDate;
    }

    public TableValuesHolderPersons getTableHelper() {
        return tableHelper;
    }

    public void setTableHelper(TableValuesHolderPersons tableHelper) {
        this.tableHelper = tableHelper;
    }


    public class TableValuesHolderPersons extends DataTableUIValuesHolder<Person> {
        private DataTableUIValuesHolder.FilterValue fvFIO = new DataTableUIValuesHolder.FilterValue("fio");
        private DataTableUIValuesHolder.FilterValue fvMessage = new DataTableUIValuesHolder.FilterValue("comment");

        public FilterValue getFvFIO() {
            return fvFIO;
        }

        public FilterValue getFvMessage() {
            return fvMessage;
        }
    }
}
