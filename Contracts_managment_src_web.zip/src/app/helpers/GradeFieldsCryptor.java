package app.helpers;

import app.dto.Grade;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * author: Oleg Chamlay
 * Date: 03.03.14
 * Time: 13:28
 */

@Stateless
public class GradeFieldsCryptor {
    private static BigDecimal scale;
    static {
        scale = new BigDecimal(10000);
        scale.setScale(4);
    }

    @EJB
    private EncryptorDayPrice encryptor;

    public void setEncryptor(EncryptorDayPrice encryptor) {
        this.encryptor = encryptor;
    }

    /**
    * Decrypt summa after loading.
    */
   public void decryptDayPrice(Grade grade) {
       if (grade.getDayPrice2() != null) {
           final String msg = "decryptDayPrice";
//           debug(msg);
           try {
           grade.setDayPrice(
                   encryptor.decryptToBigDecimal(grade.getId(), grade.getDayPrice2(), scale));
           } catch (Throwable th) {
               debug("������ �������������� �������� ��� "+grade.getId() + " " + grade.getDayPrice2());
               throw new RuntimeException(th);
           }
       }
   }

    private void debug(String msg) {
        LogSimple.debug(this, msg);
    }

    /**
    * Encrypt summa before persisting
    */
   public void encryptDayPrice(Grade grade) {
       grade.setDayPrice2(null);
       final BigDecimal dayPrice = grade.getDayPrice();
       debug("encryptDayPrice called. grade.getDayPrice() => "+ dayPrice);
       if (dayPrice != null) {
           final Long id = grade.getId();
           final BigInteger encryptedDayPrice = encryptor.encryptBigDecimalToBigInteger(id, dayPrice, scale);
           grade.setDayPrice2(
                   encryptedDayPrice
           );
       }
   }

    public void decryptFields(Grade value) {
        decryptDayPrice(value);
    }

    public void encryptFields(Grade value) {
        encryptDayPrice(value);
    }
}
