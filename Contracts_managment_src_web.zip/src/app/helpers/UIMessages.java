package app.helpers;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 * author: Oleg Chamlay
 * Date: 15.04.14
 * Time: 11:29
 */
public class UIMessages {
    public static void displayMessage(String messageText) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(messageText));
    }

    public static void displayErrorMessage(String errorMessageText) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMessageText, null));
    }
}
