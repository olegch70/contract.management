package app.helpers;

import app.controllers.TeamTableController;
import app.controllers.SessionDataHolder;
import app.dto.Person;
import app.dto.Project;
import app.dto.ProjectType;
import app.dto.TeamItem;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 19.12.13
 * Time: 17:56
 * To change this template use File | Settings | File Templates.
 */
public class TeamEditHelper {
    static String projectTeamModelKey = "projectTeamModel";

    public static List<TeamItem> getModel(SessionDataHolder sessionDataHolder, String uuid) {
        return (List<TeamItem>) ViewNavigationHelper.getModel(sessionDataHolder, uuid, TeamTableController.VIEW_NAME).get(projectTeamModelKey);
    }

    public static void saveModelInParameters(Map parameters, List<TeamItem> model) {
        parameters.put(projectTeamModelKey, model);
    }

    public static boolean addEmployeesInTeam(Person employee,
                                        SessionDataHolder sessionDataHolder, String uuid,
                                        TeamItem teamItemDto) {
        List<TeamItem> model = getModel(sessionDataHolder, uuid);
        Long projectId = TeamTableController.getLocalProjectId(sessionDataHolder, uuid);
        TeamItem teamItem = new TeamItem();
        teamItem.setId(-(new Date().getTime()));
        teamItem.setProjectId(projectId);
        teamItem.setPerson(employee);
        teamItem.setLoadPercent(teamItemDto.getLoadPercent());
        teamItem.setClientMonthPrice(teamItemDto.getClientMonthPrice());
        if(! model.contains(teamItem)) {
            model.add(teamItem);
            return true;
        }
        return false;
    }

    public static void removePersonFromTeam(TeamItem teamItemForDelete,
                                            SessionDataHolder sessionDataHolder, String uuid) {
        List<TeamItem> model = getModel(sessionDataHolder, uuid);
        model.remove(teamItemForDelete);
    }

    public static boolean needShowClientMonthPrice(
                                             SessionDataHolder sessionDataHolder, String uuid) {
        Long projectType = TeamTableController.getLocalProjectType(sessionDataHolder, uuid);
        if(ProjectType.OUTSTAFF.getId().equals(projectType)) {
            return true;
        }
        return false;
    }


}
