package app.helpers;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 14.04.14
 * Time: 12:50
 * To change this template use File | Settings | File Templates.
 */
public class DateHelper {

    final static double mSecInDay = 1000.0*3600*24;

    public static double calculateDaysBetweenTwoDatesInclusive(Date startDate, Date endDate) {
        return calculateDaysBetweenTwoDatesExclusive(startDate, endDate)+1;
    }

    public static double calculateDaysBetweenTwoDatesExclusive(Date startDate, Date endDate) {
        long diff = endDate.getTime() - startDate.getTime();
        double result = Math.round(((double)diff)/mSecInDay);
        return result;
    }
}
