package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name="PRJ_FOT_INC_EXP_ACTUAL")
public class FotExpIncActual implements IdentificableById, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    private Long id;

    @Column(name = "DATE_FACT")
    @Temporal(TemporalType.DATE)
    private Date date;

    private BigDecimal fot;
    private BigDecimal expense;
    private BigDecimal income;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public BigDecimal getFot() {
        return fot;
    }

    public void setFot(BigDecimal fot) {
        this.fot = fot;
    }

    public BigDecimal getExpense() {
        return expense;
    }

    public void setExpense(BigDecimal expense) {
        this.expense = expense;
    }

    public BigDecimal getIncome() {
        return income;
    }

    public void setIncome(BigDecimal income) {
        this.income = income;
    }

}
