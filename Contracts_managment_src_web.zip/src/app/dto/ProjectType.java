package app.dto;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.12.13
 * Time: 14:50
 * To change this template use File | Settings | File Templates.
 */
public class ProjectType {
    public static final ProjectType FIX = new ProjectType(1L, "����");
    public static final ProjectType FRAME = new ProjectType(2L, "�����");
    public static final ProjectType PROJECT = new ProjectType(3L, "������");
    public static final ProjectType OUTSTAFF = new ProjectType(4L, "��������");
    public static final ProjectType PRESALE_A = new ProjectType(5L, "Presale A");
    public static final ProjectType PRESALE_B = new ProjectType(6L, "Presale B");




    private Long id;
    private String name;
    public ProjectType(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
