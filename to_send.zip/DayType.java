package app.dto;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.12.13
 * Time: 14:50
 * To change this template use File | Settings | File Templates.
 */
public class DayType {
    public static final DayType WORKDAY = new DayType(1L, "������� ����");
    public static final DayType HOLYDAY = new DayType(2L, "��������");


    private Long id;
    private String name;
    public DayType(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
