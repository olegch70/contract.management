--------------------------------------------------------
--  DDL for Index PRJ_EXPENSES_DIRECT_FACT_H_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_EXPENSES_DIRECT_FACT_H_PK" ON "PRJ_EXPENSES_DIRECT_FACT_HIST" ("ID") 
  ;
