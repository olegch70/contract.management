--------------------------------------------------------
--  DDL for Index PRJ_INCOME_H_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_INCOME_H_PK" ON "PRJ_INCOME_HIST" ("ID") 
  ;
