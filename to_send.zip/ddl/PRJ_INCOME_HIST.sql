--------------------------------------------------------
--  DDL for Table PRJ_INCOME_HIST
--------------------------------------------------------

  CREATE TABLE "PRJ_INCOME_HIST" 
   (	"ID" NUMBER(38,0), 
	"PROJECT_ID" NUMBER(38,0), 
	"DATE_INCOME" DATE, 
	"SUMMA" NUMBER(17,2), 
	"DESCRIPTION" VARCHAR2(4000 CHAR), 
	"CREATOR_ID" NUMBER(38,0), 
	"CREATION_DATE" TIMESTAMP (6), 
	"HISTORY_ID" NUMBER(18,0), 
	"HISTORY_OPERATION" VARCHAR2(1 CHAR), 
	"HISTORY_DATE" TIMESTAMP (6), 
	"HISTORY_PERSON_ID" NUMBER(18,0)
   ) ;
