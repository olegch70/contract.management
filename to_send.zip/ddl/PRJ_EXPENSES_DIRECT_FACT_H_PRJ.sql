--------------------------------------------------------
--  DDL for Index PRJ_EXPENSES_DIRECT_FACT_H_PRJ
--------------------------------------------------------

  CREATE INDEX "PRJ_EXPENSES_DIRECT_FACT_H_PRJ" ON "PRJ_EXPENSES_DIRECT_FACT_HIST" ("PROJECT_ID") 
  ;
