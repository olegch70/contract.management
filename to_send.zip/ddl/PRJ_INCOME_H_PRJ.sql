--------------------------------------------------------
--  DDL for Index PRJ_INCOME_H_PRJ
--------------------------------------------------------

  CREATE INDEX "PRJ_INCOME_H_PRJ" ON "PRJ_INCOME_HIST" ("PROJECT_ID") 
  ;
