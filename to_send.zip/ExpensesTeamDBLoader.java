package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.ExpenseTeam;
import app.dto.Person;
import app.helpers.ConstantsHelper;
import app.helpers.ExpenseTeamFieldsCryptor;
import app.helpers.LogSimple;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "expensesTeamDBLoader")
@Named(value = "expensesTeamDBLoader")
@Stateless
public class ExpensesTeamDBLoader extends CommonDbLoader<ExpenseTeam> {

    @EJB
    PersonsDBLoader personsDBLoader;

    @EJB
    ExpenseTeamFieldsCryptor expenseTeamFieldsCryptor;

    @EJB
    CurrentDateBean currentDateBean;

    @Override
    protected Class getEntityClass() {
        return ExpenseTeam.class;
    }

    @Override
    protected Long getId(ExpenseTeam entity) {
        return entity.getId();
    }

    /**
     * ��������� ��������� ���� ��������� �������
     * @param projectId
     * @param template ������ ���������� ������� � ������ �� ���� ����.<br/>
     *                 ����� ����������� ����<br/>
     *                     ExpenseTeam.personId<br/>
     *                   � ExpenseTeam.price - ������� �����
     * @param oldDate ������ ���� (���� ������)
     * @param newDate ����� ����
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void modifyEndDate(Long projectId, List<ExpenseTeam> template, Date oldDate, Date newDate) {
        try {
            Map<Long, Person> persons = new HashMap<Long, Person>(template.size());

            log("������� �������: ���������� ������� " + template.size());
            for(ExpenseTeam itemTemplate : template) {
                Person person = personsDBLoader.getById(itemTemplate.getPersonId());
                persons.put(person.getId(), person);
                log("  " + person);
            }

            if(oldDate.after(newDate)) {
                // ���� ��������� ������� �����������
                log("������� ������� �� ������� �� ������� id "+ projectId
                + " where dateExp > "+ newDate + " and dateExp <= "+ oldDate);
                Query qDelete = em.createQuery(
                        "delete from ExpenseTeam t " +
                                " where t.projectId = :projectId " +
                                "   and t.dateExp > :fromDate " +
                                "   and t.dateExp <= :toDate");
                qDelete.setParameter("projectId", projectId);
                qDelete.setParameter("fromDate", newDate, TemporalType.DATE);
                qDelete.setParameter("toDate", oldDate, TemporalType.DATE);
                qDelete.executeUpdate();

            } else {
                // ���� ��������� ������� �����������
                log("���� ��������� ������� �����������. ������ ���� "+ oldDate
                        + ". ����� ���� "+ newDate
                        +" ��������� ������� � ������� ���� "+ oldDate);
                Calendar calendar = Calendar.getInstance();

                calendar.setTime(oldDate);

                log("");

                while( true ) {
                    // ���������� ���� ����
                    calendar.add(Calendar.DAY_OF_YEAR, 1);
                    Date tmpDate = calendar.getTime();
                    if( tmpDate.after(newDate) ) {
                        break;
                    }

                    log(" ��������� ������ �� ���� "+ tmpDate); 
                    for(ExpenseTeam itemTemplate : template) {
                        ExpenseTeam newItem = new ExpenseTeam();
                        newItem.setDateExp(tmpDate);
                        newItem.setProjectId(projectId);
                        newItem.setPersonId(itemTemplate.getPersonId());
                        Person person = persons.get(itemTemplate.getPersonId());
                        newItem.setPrice2(person.getDayPrice2());
                        newItem.setLoadPercent(itemTemplate.getLoadPercent());

                        em.persist(newItem);
                        log(" ExpenseTeam " + newItem);
                    }
                }
                // ����������� ������� �������� ����������� �� �������� ��������
                Date dateFrom = oldDate;
                Date dateTo = newDate;

                if(oldDate.after(newDate)) {
                    dateFrom = newDate;
                    dateTo = oldDate;
                }

                log(" ����������� ������� �������� ����������� �� �������� �������� " );
                em.flush();

                for(Person person: persons.values()) {
                    restoreMainProjectPercentLoad(person.getId(), person.getMainProjectId(), dateFrom, dateTo);
                }
                em.flush();
            }

        } catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

    public void restoreMainProjectPercentLoad(Long personId, Long mainProjectId, Date fromDate, Date toDate) {
        log(" restoreMainProjectPercentLoad personId "+ personId + " mainProjectId "+ mainProjectId
        + " fromDate "+fromDate+" toDate " + toDate);
        Query query = em.createQuery(
                "select t.dateExp, sum(t.loadPercent) as percentLoad " +
                " from ExpenseTeam t " +
                " where t.dateExp between :fromDate and :toDate " +
                "   and t.projectId <> :projectId " +
                "   and t.personId = :personId " +
                " group by t.dateExp");
        query.setParameter("personId", personId);
        query.setParameter("projectId", mainProjectId);
        query.setParameter("fromDate", fromDate);
        query.setParameter("toDate", toDate);

        List<Object[]> loadOnLegionnaireProjectsList = query.getResultList();
        Map<Date, Double> loadOnLegionnaireProjects = new HashMap<Date, Double>(loadOnLegionnaireProjectsList.size());

        for(Object[] row: loadOnLegionnaireProjectsList) {
            log(" restoreMainProjectPercentLoad loadOnLegionnaireProjectsList dateExp "+ row[0] + " percentLoad "+ row[1]);
            loadOnLegionnaireProjects.put((Date) row[0], (Double) row[1]);
        }

        query = em.createQuery(
                "select t " +
                " from ExpenseTeam t " +
                " where t.dateExp between :fromDate and :toDate " +
                "   and t.projectId = :projectId " +
                "   and t.personId = :personId " +
                " group by t.dateExp");
        query.setParameter("personId", personId);
        query.setParameter("projectId", mainProjectId);
        query.setParameter("fromDate", fromDate);
        query.setParameter("toDate", toDate);

        List<ExpenseTeam> loadOnMainProject = query.getResultList();
        for(ExpenseTeam expenseTeam: loadOnMainProject) {
            log(" restoreMainProjectPercentLoad loadOnMainProject "+ expenseTeam.getDateExp() + " percentLoad "+ expenseTeam.getLoadPercent());
            Double percentLoadOnLegionnaire = loadOnLegionnaireProjects.get(expenseTeam.getDateExp());
            if(percentLoadOnLegionnaire == null) {
                percentLoadOnLegionnaire = ConstantsHelper.DOUBLE_ZERO;
            }
            log(" restoreMainProjectPercentLoad set loadOnMainProject "+ (ConstantsHelper.DOUBLE_HUNDRED.doubleValue() - percentLoadOnLegionnaire.doubleValue()));
            expenseTeam.setLoadPercent(ConstantsHelper.DOUBLE_HUNDRED.doubleValue() - percentLoadOnLegionnaire.doubleValue());
            update(expenseTeam);
        }

    }

    private void log(String s) {
        LogSimple.debug(this, s);
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void deleteByPersonPeriod(Long projectId, Long personId, Date fromDate, Date toDate) {
        Query qDelete = em.createQuery(
                "delete from ExpenseTeam t " +
                        " where t.projectId = :projectId " +
                        "   and t.personId = :personId " +
                        "   and t.dateExp between :fromDate and :toDate ");
        qDelete.setParameter("projectId", projectId);
        qDelete.setParameter("personId", personId);
        qDelete.setParameter("fromDate", fromDate, TemporalType.DATE);
        qDelete.setParameter("toDate", toDate, TemporalType.DATE);
        System.out.println(" DELETE item.getPersonId() = " + personId + " fromDate = " + fromDate
                + " toDate = " + toDate);
        qDelete.executeUpdate();
        em.flush();
    }

    public double getLoadPercentOnMainProject(Long mainProjectId, Long personId, Date date) {
        Query query = em.createQuery(
                "select t.loadPercent " +
                " from ExpenseTeam t " +
                " where t.projectId = :mainProjectId " +
                "   and t.personId = :personId " +
                "   and t.dateExp = :date");
        query.setParameter("mainProjectId", mainProjectId);
        query.setParameter("personId", personId);
        query.setParameter("date", date, TemporalType.DATE);
        Number result = (Number) query.getSingleResult();
        if(result == null) {
            return 0;
        }

        return result.doubleValue();
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void addPersonLoadPercentForPeriod(Long projectId, Long personId, Double loadPercentDelta, Date fromDate, Date toDate) {
        Query qUpdate = em.createQuery(
                "update ExpenseTeam t " +
                        " set t.loadPercent = t.loadPercent + :loadPercent" +
                        " where t.projectId = :projectId " +
                        "   and t.personId = :personId " +
                        "   and t.dateExp between :fromDate and :toDate ");
        qUpdate.setParameter("loadPercent", loadPercentDelta);
        qUpdate.setParameter("projectId", projectId);
        qUpdate.setParameter("personId", personId);
        qUpdate.setParameter("fromDate", fromDate, TemporalType.DATE);
        qUpdate.setParameter("toDate", toDate, TemporalType.DATE);
        System.out.println(" Add ExpenseTeam.loadPercent += "+loadPercentDelta
                + " where item.getPersonId() = " + personId
                + " projectId = " + projectId
                + " fromDate = " + fromDate
                + " toDate = " + toDate);
        qUpdate.executeUpdate();
        // em.flush();
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void updatePersonLoadPercentForPeriod(Long projectId, Long personId, BigInteger loadPercent, Date fromDate, Date toDate) {
        Query qUpdate = em.createQuery(
                "update ExpenseTeam t " +
                        " set t.loadPercent = :loadPercent" +
                        " where t.projectId = :projectId " +
                        "   and t.personId = :personId " +
                        "   and t.dateExp between :fromDate and :toDate ");
        qUpdate.setParameter("loadPercent", loadPercent);
        qUpdate.setParameter("projectId", projectId);
        qUpdate.setParameter("personId", personId);
        qUpdate.setParameter("fromDate", fromDate, TemporalType.DATE);
        qUpdate.setParameter("toDate", toDate, TemporalType.DATE);
        System.out.println(" Update ExpenseTeam.loadPercent = "+loadPercent
                + " where item.getPersonId() = " + personId
                + " projectId = " + projectId
                + " fromDate = " + fromDate
                + " toDate = " + toDate);
        qUpdate.executeUpdate();
        em.flush();
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void updatePersonPrice2ForPeriod(Long projectId, Long personId, BigInteger price2, Date fromDate, Date toDate) {
        Query qUpdate = em.createQuery(
                "update ExpenseTeam t " +
                        " set t.price2 = :price2" +
                        " where t.projectId = :projectId " +
                        "   and t.personId = :personId " +
                        "   and t.dateExp between :fromDate and :toDate ");
        qUpdate.setParameter("price2", price2);
        qUpdate.setParameter("projectId", projectId);
        qUpdate.setParameter("personId", personId);
        qUpdate.setParameter("fromDate", fromDate, TemporalType.DATE);
        qUpdate.setParameter("toDate", toDate, TemporalType.DATE);
        qUpdate.executeUpdate();
        em.flush();
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void addByPersonPeriod(Long projectId, Long personId, Double loadPercent, Date fromDate, Date toDate) {
        LogSimple.MeasureVO measureVOMethodDuration
                = LogSimple.debugWithMeasureStart(this,
                "addByPersonPeriod started for projectId " + projectId + ", " +
                        "personId " + personId + ", " +
                        "loadPercent " + loadPercent + ", " +
                        "fromDate " + fromDate + ", " +
                        "toDate " + toDate);
//        RuntimeException rt = new RuntimeException();
//        StringWriter sw = new StringWriter();
//        PrintWriter pw = new PrintWriter(sw);
//        rt.printStackTrace(pw);
//        LogSimple.debug(this, " at "+sw.toString());

        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(fromDate);

            final Person person = personsDBLoader.getById(personId);
            do {
                Date tmpDate = calendar.getTime();
                if( tmpDate.after(toDate) ) {
                    LogSimple.debug(this, "addByPersonPeriod break for projectId " + projectId+", " +
                                        "personId " + personId+", " +
                                        "loadPercent " + loadPercent + ", " +
                                        "fromDate " + fromDate+
                                        "toDate " + toDate+
                                        "breakDate " + tmpDate);
                    break;
                }
                ExpenseTeam newItem = new ExpenseTeam();
                newItem.setDateExp(tmpDate);
                newItem.setProjectId(projectId);
                newItem.setPersonId(personId);
                newItem.setPrice2(person.getDayPrice2());
                newItem.setLoadPercent(loadPercent);

                em.persist(newItem);

                // ���������� ���� ����
                calendar.add(Calendar.DAY_OF_YEAR, 1);

            } while( true );

        } catch(Throwable t) {
            throw new RuntimeException(t);
        } finally {
            LogSimple.debugWithMeasureFinish(this,
                    "addByPersonPeriod ", measureVOMethodDuration);
        }
    }

    public BigDecimal getProjectExpensesTeamSum(Long projectId, Date fromDate, Date toDate) {
        final String sql = getSqlPart1()
                + "   and t.dateExp between :fromDate and :toDate "
                + getSqlPartGroup();
        Query query = em.createQuery( sql );
        query.setParameter("projectId", projectId);
        query.setParameter("fromDate", fromDate, TemporalType.DATE);
        query.setParameter("toDate", toDate, TemporalType.DATE);
        LogSimple.debug(this, "getExpensesTeamSum sql = " + sql + "\n projectId = " + projectId + " d1 = " + fromDate + " d2 = " + toDate);
        return calculateExpensesSum( query );
    }

    public BigDecimal getProjectExpensesTeamSum(Long projectId) {
        final String sql = getSqlPart1() + getSqlPartGroup();
        Query query = em.createQuery( sql );
        query.setParameter("projectId", projectId);
        return calculateExpensesSum( query );
    }

    private BigDecimal calculateExpensesSum(Query query) {
        double result[] = new double[]{0};
        List<Object[]> resultList = query.getResultList();
        ExpenseTeam expenseTeam = new ExpenseTeam();
        for(Object[] row: resultList) {
            int cnt = ((Number) row[0]).intValue();
            Long personId = (Long) row[1];
            BigInteger price2 = (BigInteger) row[2];
            Number loadPercent = (Number) row[3];
            expenseTeam.setPersonId(personId);
            calculatePersonExpenseInProjectTeam(result, expenseTeam, cnt, price2, loadPercent);
        }
        return new BigDecimal(result[0]);
    }

    private void calculatePersonExpenseInProjectTeam(double result[], ExpenseTeam expenseTeam, int cnt, BigInteger price2, Number loadPercent) {
        if(loadPercent == null) {
            loadPercent = ConstantsHelper.DOUBLE_HUNDRED; // 100 %
        }
        expenseTeam.setPrice2(price2);
        expenseTeamFieldsCryptor.decryptFields(expenseTeam);
        result[0] += expenseTeam.getPrice().doubleValue() * loadPercent.doubleValue() / 100d * cnt ;
    }

    private String getSqlPart1() {
        return "select count(t) as cnt, t.personId, t.price2, t.loadPercent" +
                " from ExpenseTeam t " +
                " where t.projectId = :projectId ";
    }


    private String getSqlPartGroup() {
        return " group by t.personId, t.price2, t.loadPercent";
    }
    public Map<Long, Number> getProjectsExpensesTeamAllSum(List<Long> projectsIds) {
        String sql = "select t.projectId, t.personId, count(t), t.loadPercent, t.price2 from ExpenseTeam t " +
                                " where t.projectId in :projectIdsParameters " +
                                " group by t.projectId, t.personId, t.loadPercent, t.price2" +
                " order by t.projectId, t.personId";

        Query query = em.createQuery(sql);
        query.setParameter("projectIdsParameters", projectsIds);
        List<Object[]> resultList = query.getResultList();

        return getLongNumberMapFromProjectTeamExpenses(resultList);
    }

    public Map<Long, Number> getProjectsExpensesTeamSum(List<Long> projectsIds, Date currentDate) {
        String sql = "select t.projectId, t.personId, count(t), t.loadPercent, t.price2 from ExpenseTeam t " +
                                " where t.dateExp <= :toDate and t.projectId in  :projectIdsParameters  " +
                                " group by t.projectId, t.personId, t.loadPercent, t.price2" +
                " order by t.projectId, t.personId";

        Query query = em.createQuery(sql);
        query.setParameter("toDate", currentDate);
        query.setParameter("projectIdsParameters", projectsIds);
        List<Object[]> resultList = query.getResultList();

        return getLongNumberMapFromProjectTeamExpenses(resultList);
    }

    private Map<Long, Number> getLongNumberMapFromProjectTeamExpenses(List<Object[]> resultList) {
        double projectTeamExpense[] = new double[]{0};
        ExpenseTeam expenseTeam = new ExpenseTeam();
        Iterator<Object[]> iterator = resultList.iterator();
        Object[] row = null;
        if(iterator.hasNext()) {
            row = iterator.next();
        }
        Map<Long, Number> result = new HashMap<Long, Number>();
        while(row != null) {
            Long projectId = (Long) row[0];
            projectTeamExpense[0] = 0.0;
            while(row != null && projectId.equals(row[0]) ) {
                Long personId = (Long) row[1];
                expenseTeam.setPersonId(personId);
                while(row != null && projectId.equals(row[0]) && personId.equals(row[1]) ) {
                    int cnt = ((Number) row[2]).intValue();
                    Number loadPercent = ((Number) row[3]);
                    BigInteger price2 = (BigInteger) row[4];
                    calculatePersonExpenseInProjectTeam(projectTeamExpense, expenseTeam, cnt, price2, loadPercent);
                    if(iterator.hasNext()) {
                        row = iterator.next();
                    } else {
                        row = null;
                    }
                }
            }
            result.put(projectId, new Double(projectTeamExpense[0]));
        }

        return result;
    }

    //    public Map<Long, Number> getProjectsExpensesTeamSum(List<Long> projectsIds, Date currentDate) {
//        ToDo
//                ���������� ��� ������� ������� ��������� ���� ExpenseTeam.price
//
//        String sql = "select t.projectId, sum(t.price) from ExpenseTeam t " +
//                                " where t.dateExp <= :toDate and t.projectId in ( projectIdsParameters ) " +
//                                " group by t.projectId";
//
//        String[] parametersName = new String[]{"toDate"};
//        Object[] parametersValue = new Object[]{currentDate};
//
//        return getLongNumberMap(sql, projectsIds, parametersName, parametersValue);
//    }
//
}
