package app.loaders;

import app.dto.CalendarDay;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Named;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 15.08.14
 * Time: 11:38
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "calendarDBLoader")
@Stateless
public class CalendarBDLoader extends CommonDbLoader<CalendarDay> {

    @EJB
    DayTypesDBLoader dayTypesDBLoader;

    @Override
    protected Class getEntityClass() {
        return CalendarDay.class;
    }

    @Override
    protected Long getId(CalendarDay entity) {
        return entity.getId();
    }
}
