package app.dto;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 16:41
 * To change this template use File | Settings | File Templates.
 */

@Entity
@Table(name="PRJ_PROJECT")
@NamedQueries({
        @NamedQuery(name = "Project.getForClientByProjectM",
        query = "select t from Project t " +
                " where t.client.id = :clientId " +
                "   and t.projectManagerId = :projectManagerId " +
                " order by t.code, t.number"),
        @NamedQuery(name = "Project.getByClientId",
        query = "select t from Project t " +
                " where t.client.id = :clientId " +
                " order by t.code, t.number"),
        @NamedQuery(name = "Project.getClientsByProjectM",
        query = "select distinct t.client from Project t where t.projectManagerId = :projectManagerId order by t.client.name"),
        @NamedQuery(name = "Project.getNotClosedProjects",
        query = "select t from Project t " +
                " where t.statusId <> :statusId " +
                " order by t.startDate, t.code")
})

public class Project implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    @Column(name = "ID")
    private Long id;

    private Long type;
    private String code;

    @Column(name = "PNUMBER")
    private String number;

    private BigDecimal price;

    @Column(name = "PRICE_Q1")
    private BigDecimal  priceQ1;

    @Column(name = "PRICE_Q2")
    private BigDecimal  priceQ2;

    @Column(name = "PRICE_Q3")
    private BigDecimal  priceQ3;

    @Column(name = "PRICE_Q4")
    private BigDecimal  priceQ4;

    @Column(name = "TEAM_COST")
    private BigDecimal  teamCost;

    @Column(name = "START_DATE")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Transient
    private BigDecimal expense;

    @Transient
    private BigDecimal expensePlan;

    @Transient
    private BigDecimal income;

    @Column(name = "END_DATE_PLAN")
    @Temporal(TemporalType.DATE)
    private Date endDatePlan;

    @Column(name = "EFFICIENCE_PROGN")
    private BigDecimal efficiencyProgn;

    @Column(name = "PCOMMENT")
    private String comment;

//    @Column(name = "CLIENT_ID")
//    private Long clientId;

    @ManyToOne()
    @JoinColumn(name = "CLIENT_ID")
    private Client client;

    @Transient
    private Long clientId;

    @Column(name = "PROJECT_MANAGER_ID")
    private Long projectManagerId;

    @Column(name = "STATUS_ID")
    private Long statusId;

    @Column(name = "FTE_PLAN")
    private Double planFTE;

    @Transient
    private List<TeamItem> team;

    @Transient
    private List<ProjectContract> projectContracts;

    @Transient
    private BigDecimal calculatedTeamMonthCost;

    @Transient
    private String projectMName;

    @Transient
    private String projectTypeName;
    @Transient
    private String statusName;

    public List<TeamItem> getTeam() {
        return team;
    }

    public void setTeam(List<TeamItem> team) {
        this.team = team;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getTeamCost() {
        return teamCost;
    }

    public void setTeamCost(BigDecimal teamCost) {
        this.teamCost = teamCost;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public BigDecimal getExpense() {
        return expense;
    }

    public void setExpense(BigDecimal expence) {
        this.expense = expence;
    }

    public BigDecimal getExpensePlan() {
        return expensePlan;
    }

    public void setExpensePlan(BigDecimal expensePlan) {
        this.expensePlan = expensePlan;
    }

    public BigDecimal getIncome() {
        return income;
    }

    public void setIncome(BigDecimal income) {
        this.income = income;
    }

    public Date getEndDatePlan() {
        return endDatePlan;
    }

    public void setEndDatePlan(Date endDatePlan) {
        this.endDatePlan = endDatePlan;
    }

    public BigDecimal getEfficiencyProgn() {
        return efficiencyProgn;
    }

    public void setEfficiencyProgn(BigDecimal efficiencyProgn) {
        this.efficiencyProgn = efficiencyProgn;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getClientId() {
        if( client != null ) {
            return client.getId();
        }
        return clientId;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public List<ProjectContract> getProjectContracts() {
        return projectContracts;
    }

    public void setProjectContracts(List<ProjectContract> projectContracts) {
        this.projectContracts = projectContracts;
    }

    public BigDecimal getPriceQ1() {
        return priceQ1;
    }

    public void setPriceQ1(BigDecimal priceQ1) {
        this.priceQ1 = priceQ1;
    }

    public BigDecimal getPriceQ2() {
        return priceQ2;
    }

    public void setPriceQ2(BigDecimal priceQ2) {
        this.priceQ2 = priceQ2;
    }

    public BigDecimal getPriceQ3() {
        return priceQ3;
    }

    public void setPriceQ3(BigDecimal priceQ3) {
        this.priceQ3 = priceQ3;
    }

    public BigDecimal getPriceQ4() {
        return priceQ4;
    }

    public void setPriceQ4(BigDecimal priceQ4) {
        this.priceQ4 = priceQ4;
    }

    public Long getProjectManagerId() {
        return projectManagerId;
    }

    public String getProjectMName() {
        return projectMName;
    }

    public void setProjectMName(String projectMName) {
        this.projectMName = projectMName;
    }

    public void setProjectManagerId(Long projectManagerId) {
        this.projectManagerId = projectManagerId;
    }

    public BigDecimal getCalculatedTeamMonthCost() {
        return calculatedTeamMonthCost;
    }

    public void setCalculatedTeamMonthCost(BigDecimal calculatedTeamMonthCost) {
        this.calculatedTeamMonthCost = calculatedTeamMonthCost;
    }

    public Long getStatusId() {
        return statusId;
    }

    public void setStatusId(Long statusId) {
        this.statusId = statusId;
    }

    public void setCommentForDisplay(String commentForDisplay) {
    }

    public String getCommentForDisplay() {
        if(comment == null) {
            return "";
        }
        return comment.substring(0, Math.min(20, comment.length()));
    }

    public Double getPlanFTE() {
        return planFTE;
    }

    public void setPlanFTE(Double planFTE) {
        this.planFTE = planFTE;
    }

    public String getProjectTypeName() {
        return projectTypeName;
    }

    public void setProjectTypeName(String projectTypeName) {
        this.projectTypeName = projectTypeName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getStatusName() {
        return statusName;
    }
}
