package app.controllers;

import app.beans.CurrentDateBean;
import app.beans.FormatterUtil;
import app.dto.Person;
import app.dto.Project;
import app.dto.ProjectType;
import app.dto.TeamItem;
import app.helpers.LogSimple;
import app.helpers.TeamEditHelper;
import app.helpers.UIMessages;
import app.loaders.ProjectTeamDBLoader;
import app.loaders.ProjectsDBLoader;
import app.loaders.PersonsDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 18.12.13
 * Time: 15:21
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "teamTableController")
@ViewScoped
public class TeamTableController {
    public static final String PROJECT_ID = "projectId";
    @EJB
    private ProjectsDBLoader projectsDBLoader;
    @EJB
    private PersonsDBLoader personsDBLoader;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    @EJB
    private ProjectTeamDBLoader projectTeamDBLoader;

    @EJB
    CurrentDateBean currentDateBean;

    private String backPath;
    private TeamItem selectedPerson;
    private Long editItemId;
    private String conversationUuid;
    private Map parameters;
    private String localUuid;
    private Long projectId;
    private List<TeamItem> filteredRows;
    private Project currentProject;

    //����������� ��� ������ �� ����������
    public static final String CONTEXT_SUFFIX = "_editContractTeamController";
    private Date legionnaireEndDate;
    private Double legionnairePercentOffer;
    private BigDecimal clientMonthPrice;

    public void initModel() throws AbortProcessingException {
        initializeUuid();
        localUuid = getLocalUuid(conversationUuid);
        LogSimple.debug(this, "localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            LogSimple.debug(this, "parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put(PROJECT_ID, projectId);
            LogSimple.debug(this, "parameters.put(projectId = " + projectId);
            parameters.put("backPath", backPath);
            LogSimple.debug(this, "parameters.put(backPath = " + backPath);
            List<TeamItem> model = projectTeamDBLoader.loadByLinkedId("projectId", projectId);
            enrichModel(model);
            sortByFIO(model);
            sessionDataHolder.add(TeamEditHelper.getLocalUuid(conversationUuid), model);
            saveModelInSession();
        } else {
            LogSimple.debug(this, "parameters ! = null" + parameters);
            projectId = (Long) parameters.get("projectId");
            backPath = (String) parameters.get("backPath");
            List<TeamItem> model = getCurrentTeam();
            sortByFIO(model);
        }
        currentProject = projectsDBLoader.getById(projectId);
        System.out.println("contract = " + currentProject);
        System.out.println("conversationUuid = " + conversationUuid);


    }

    private void sortByFIO(List<TeamItem> model) {
        TreeMap<String, TeamItem> sorter = new TreeMap<String, TeamItem>();
        for(TeamItem item: model) {
            sorter.put(item.getPerson().getFIO(), item);
        }

        model.clear();
        model.addAll(sorter.values());
    }

    private void enrichModel(List<TeamItem> model) {
        for(TeamItem row: model) {
            Person person = row.getPerson();
            if(projectId.equals(person.getMainProjectId())) {
                row.setAttachmentPlanEndDate(person.getLegionnaireEndDate());
            } else {
                row.setLegionnairePlanEndDate(person.getLegionnaireEndDate());
            }
        }
    }

    public static String getLocalUuid(String conversationUuid) {
        return conversationUuid+CONTEXT_SUFFIX;
    }

    public static Long getLocalProjectId(SessionDataHolder sessionDataHolder, String conversationUuid) {
        Map parameters = (Map) sessionDataHolder.get(getLocalUuid(conversationUuid));
        return (Long) parameters.get(PROJECT_ID);
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    public List<TeamItem> getCurrentTeam() {
        List<TeamItem> model = TeamEditHelper.getModel(sessionDataHolder, conversationUuid);
        System.out.println("currentTeam = " + model);
        return model;
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        return facesContext.getViewRoot().getViewId();
    }

    public String goToAddPerson() {
        return "addPersonInTeam?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String doBack() {
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
    }

    public List<TeamItem> getFilteredRows() {
        if(filteredRows == null) {
            filteredRows = getCurrentTeam();
        }
        return filteredRows;
    }

    public void setFilteredRows(List<TeamItem> filteredRows) {
        this.filteredRows = filteredRows;
        LogSimple.debug(this, "setFilteredRows");
        parameters.put("filteredRows", this.filteredRows);
    }

    public String saveTeam() {
        System.out.println("saveTeam started");
        for(TeamItem row : getCurrentTeam()) {
            System.out.println("teamItem.person = " + row.getPerson() + " clientMonthCost = " + row.getClientMonthPrice());
        }
        projectTeamDBLoader.saveProjectTeam(projectId, getCurrentTeam());

        removeModelFromSession();
        System.out.println("saveTeam finished");
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    public void showLog() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        LogSimple.debug(this, "selectedPerson = " + selectedPerson.getId() + " " + selectedPerson.getPerson()
                + " " + selectedPerson.getPersonId());
        if(selectedPerson.getId()<0){
            LogSimple.debug(this, "selectedPerson.getId() < 0 = " + selectedPerson.getId());
            UIMessages.displayMessage("��������� ��������� ��� ������������ ����������, ����� ��������� � ���������");
            return;
        }

        if( ! projectId.equals(selectedPerson.getPerson().getMainProjectId())) {
            UIMessages.displayMessage("��������� �� �� ���� ����������");
            return;
        }

        Person person = personsDBLoader.getById(selectedPerson.getPersonId());

//        if(Person.LegionnaireState.ISLEGIONNAIRE.getValue().equals(person.getLegionnaireState())) {
//            displayUIMessage("��������� ��� ��������� � \"������\".");
//            return;
//        }
//
        RequestContext rc = RequestContext.getCurrentInstance();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDateBean.getCurrentDate());
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        legionnaireEndDate = calendar.getTime();
        legionnairePercentOffer = getAvailableLegionnairePercent(person);

        rc.execute("PF('dlg').show()");
        LogSimple.debug(this, "selectedPerson for show = " + selectedPerson);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public void moveToLegionnaire() {
        System.out.println("moveToLegionnaire started");

        Person person = getPersonById(selectedPerson.getId());

        double maxLegionnairePercent = getAvailableLegionnairePercent(person);
        if(legionnairePercentOffer > maxLegionnairePercent) {
            UIMessages.displayMessage("������� �� ����� ���� ����� "+ FormatterUtil.formatDouble(maxLegionnairePercent) + " %");
            return;
        }

        person.setReadyForLegionnaire(true);
        person.setLegionnaireEndDate(legionnaireEndDate);
        person.setLegionnairePercentOffer(legionnairePercentOffer);
//        editedRow.setLegionnairePlanEndDate(legionnaireEndDate);
        System.out.println("legionnaireEndDate after show = " + legionnaireEndDate);
        System.out.println("person = " + person);
        //projectTeamDBLoader.update(selectedPerson);
//        personsDBLoader.update(person);

//        System.out.println("person from db after update  = " + personsDBLoader.getById(person.getId()));


        System.out.println("moveToLegionnaire ended");
    }

    public void saveClientMonthPrice() {
        System.out.println("saveClientMonthPrice started");
        getTeamItemById(editItemId).setClientMonthPrice(clientMonthPrice);
        System.out.println("saveClientMonthPrice ended");
    }

    public void doShowInfoDialog(Long id) {
        editItemId = id;
        clientMonthPrice = getTeamItemById(id).getClientMonthPrice();
        RequestContext rc = RequestContext.getCurrentInstance();
        rc.execute("PF('monthPriceDlg').show()");
    }

    private Person getPersonById(final Long personId) {
        Person person = null;
        for(TeamItem row : getCurrentTeam()) {
            if(row.getId().equals(personId)) {
                person = row.getPerson();
//                editedRow = row;
                break;
            }
        }
        return person;
    }

    private TeamItem getTeamItemById(final Long personId) {
        TeamItem teamItem = null;
        for(TeamItem row : getCurrentTeam()) {
            if(row.getId().equals(personId)) {
                teamItem = row;
                break;
            }
        }
        return teamItem;
    }

    private double getAvailableLegionnairePercent(Person person) {
        // ToDo ���������� �� ����� ���������� ���������� �������� ����� �������� �� ������� � ���������� ������� �� ������� ����
        //  �� ��������� ���� � �������� �� �������.
        double result = projectTeamDBLoader.getAvailableLegionnairePercent(currentDateBean.getCurrentDate(), person);
        return result;
    }

    public void deletePerson() {
        System.out.println("deletePerson started");
        TeamEditHelper.removePersonFromTeam(selectedPerson, sessionDataHolder, conversationUuid);
        System.out.println("deletePerson ended");
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(selectedPerson != null) {
            return true;
        }

        UIMessages.displayMessage("�������� ������� ������.");
        return false;
    }

    public void setSelectedPerson(TeamItem selectedPerson) {
        this.selectedPerson = selectedPerson;
    }

    public TeamItem getSelectedPerson() {
        return selectedPerson;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public ProjectsDBLoader getProjectsDBLoader() {
        return projectsDBLoader;
    }

    public void setProjectsDBLoader(ProjectsDBLoader projectsDBLoader) {
        this.projectsDBLoader = projectsDBLoader;
    }

    public PersonsDBLoader getPersonsDBLoader() {
        return personsDBLoader;
    }

    public void setPersonsDBLoader(PersonsDBLoader personsDBLoader) {
        this.personsDBLoader = personsDBLoader;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public Project getCurrentProject() {
        return currentProject;
    }

    public void setCurrentProject(Project currentProject) {
        this.currentProject = currentProject;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public ProjectTeamDBLoader getProjectTeamDBLoader() {
        return projectTeamDBLoader;
    }

    public void setProjectTeamDBLoader(ProjectTeamDBLoader projectTeamDBLoader) {
        this.projectTeamDBLoader = projectTeamDBLoader;
    }

    public void setLegionnaireEndDate(Date legionnaireEndDate) {
        this.legionnaireEndDate = legionnaireEndDate;
    }

    public Date getLegionnaireEndDate() {
        return legionnaireEndDate;
    }

    public Double getLegionnairePercentOffer() {
        return legionnairePercentOffer;
    }

    public void setLegionnairePercentOffer(Double legionnairePercentOffer) {
        this.legionnairePercentOffer = legionnairePercentOffer;
    }

    public BigDecimal getClientMonthPrice() {
        return clientMonthPrice;
    }

    public void setClientMonthPrice(BigDecimal clientMonthPrice) {
        this.clientMonthPrice = clientMonthPrice;
    }

    public Long getEditItemId() {
        return editItemId;
    }

    public void setEditItemId(Long editItemId) {
        this.editItemId = editItemId;
    }

    public boolean isShowOutstaffPrice() {
        if(ProjectType.OUTSTAFF.getId().equals(currentProject.getType())) {
            return true;
        }
        return false;
    }
}
