  CREATE TABLE "PRJ_FOT_INC_EXP_ACTUAL" 
   (	"ID" NUMBER(38,0), 
	"DATE_FACT" DATE, 
	"FOT" NUMBER(38,5), 
	"EXPENSE" NUMBER(38,5), 
	"INCOME" NUMBER(38,5)
   ) ;
--------------------------------------------------------
--  Constraints for Table PRJ_FOT_INC_EXP_ACTUAL
--------------------------------------------------------

  ALTER TABLE "PRJ_FOT_INC_EXP_ACTUAL" MODIFY ("ID" NOT NULL ENABLE);