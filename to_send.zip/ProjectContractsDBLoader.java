package app.loaders;

import app.dto.Position;
import app.dto.ProjectContract;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 25.12.13
 * Time: 11:22
 * To change this template use File | Settings | File Templates.
 */
//@ManagedBean(name = "projectContractsDBLoader")
//@SessionScoped
@Stateless
@Named(value = "projectContractsDBLoader")
public class ProjectContractsDBLoader extends CommonDbLoader<ProjectContract>  {

    public final static String MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING = "### ������������� ��������� �������� ��������� �����������. �� �������� ��� ������.";


    @Override
    protected Class getEntityClass() {
        return ProjectContract.class;
    }

    @Override
    protected Long getId(ProjectContract entity) {
        return entity.getId();
    }

    public void update(List<ProjectContract> newList, List<ProjectContract> oldList) {
        Map<Long, ProjectContract> notNew = new HashMap<Long, ProjectContract>();

        for(ProjectContract row : newList){
            if(row.getId() != null && row.getId()<0){
                row.setId(null);
                addNew(row);
            } else {
                notNew.put(row.getId(), row);
            }
        }
        for(ProjectContract oldRow : oldList) {
            ProjectContract newRow = notNew.get(oldRow.getId());
            if(newRow == null){
                delete(oldRow.getId());
            } else {
                if(!newRow.fullEquals(oldRow)) {
                    update(newRow);
                }
            }
        }
    }

    public void copyProjectUntilProjectEnd(List<ProjectContract> projectContractsListForAddInProject,
                                            Date startDate, Date endDate, BigDecimal price, String number,
                                            String description, Long projectId) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        int curMonth = calendar.get(Calendar.MONTH);
        int curDay = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.setTime(endDate);
        int endMonth = calendar.get(Calendar.MONTH);
//        int numberOfMonths = calculateNumberOfMonths(startDate, endDate);
        while( curMonth <= endMonth ) {
            ProjectContract foundDocument = getExistDocumentForMonth(curMonth, projectContractsListForAddInProject);
            if(foundDocument != null) {
                foundDocument.setPrice(price);
                foundDocument.setNumber(number);
                if(description.startsWith(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING)) {
                    foundDocument.setDescription(description);
                } else {
                    foundDocument.setDescription(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING + "\n" + description);
                }
            } else {
                foundDocument = new ProjectContract();
                foundDocument.setProjectId(projectId);
                foundDocument.setId(-(new Date().getTime() + curMonth));//��� ���������� ������� � ��, ��� �������� ������� � null
                foundDocument.setPrice(price);
                if(description.startsWith(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING)) {
                    foundDocument.setDescription(description);
                } else {
                    foundDocument.setDescription(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING + "\n" + description);
                }
                foundDocument.setNumber(number);
                calendar.set(Calendar.MONTH, curMonth);
                calendar.set(Calendar.DAY_OF_MONTH, 1);
                int dayOfMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                if(curDay < dayOfMonth) {
                    dayOfMonth = curDay;
                }
                if(curMonth == endMonth) {
                    calendar.setTime(endDate);
                    dayOfMonth = Math.min(dayOfMonth, calendar.get(Calendar.DAY_OF_MONTH));
                }
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                foundDocument.setDocDate(calendar.getTime());
                projectContractsListForAddInProject.add(foundDocument);
            }
            curMonth++;
        }
    }

    private ProjectContract getExistDocumentForMonth(int curMonth, List<ProjectContract> projectContractsListForAddInProject) {
        Calendar calendar = Calendar.getInstance();
        for(ProjectContract curProjectContract : projectContractsListForAddInProject) {
            calendar.setTime(curProjectContract.getDocDate());
            if(curMonth == calendar.get(Calendar.MONTH)) {
                if(curProjectContract.getDescription().startsWith(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING)) {
                    return curProjectContract;
                }
            }
        }
        return null;
    }

    public void deleteByProjectId(Long id) {
        for(ProjectContract item: loadByLinkedId("projectId", id) ) {
            delete(item.getId());
        }
    }

    public List<ProjectContract> loadByProjectId(Long id) {
        return loadByFieldValue("projectId", id, new String[]{"docDate", "number"});
    }
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public List<ProjectContract> loadByProjectIdNewTransaction(Long id) {
        return loadByFieldValue("projectId", id, new String[]{"docDate", "number"});
    }
}
