package app.controllers;

import app.dto.ProjectContract;
import app.loaders.ProjectsDBLoader;
import app.loaders.ProjectContractsDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 25.12.13
 * Time: 10:52
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="projectContractsPriceListController")
@ViewScoped
public class ProjectContractsPriceListController {

    private Long projectId;
    private String backPath;
    private String conversationUuid;
    //@ManagedProperty(value="#{projectsDBLoader}")
    @EJB
    private ProjectsDBLoader projectsDBLoader;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    //@ManagedProperty(value="#{projectContractsDBLoader}")
    @EJB
    private ProjectContractsDBLoader projectContractsDBLoader;
    private String localUuid;
    private Map parameters;
    private ProjectContract selectedContract;

    public void initModel() throws AbortProcessingException {
        localUuid = getConversationUuid()+"_projectContractsPriceListController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);

        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("projectId", projectId);
            System.out.println("parameters.put(projectId = " + projectId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            System.out.println("parameters projectId class = "+parameters.get("projectId").getClass());
            System.out.println("parameters projectId = "+parameters.get("projectId"));
            projectId = (Long) parameters.get("projectId");
            backPath = (String) parameters.get("backPath");
        }
    }

    public List<ProjectContract> getContracts() {
        return EditProjectController.getProjectContractsFromContext(getConversationUuid(), sessionDataHolder);
    }

    public String addContract() {
        String resultString = "editProjectContract?command=add"
                +"&backPath="+getCurrentPath()
                +"&projectId="+ projectId
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        System.out.println("resultString = " + resultString);
        return resultString;
    }

    public String editContract() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        String resultString = "editProjectContract?projectContractId="+selectedContract.getId()
                +"&command=edit"
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        System.out.println("resultString = " + resultString);
        return resultString;
    }

    public void deleteContract() {
        getContracts().remove(selectedContract);
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
    }

    public String doBack() {
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(selectedContract != null) {
            return true;
        }

        displayUIMessage("�������� ������� ������.");
        return false;
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }


    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public ProjectsDBLoader getProjectsDBLoader() {
        return projectsDBLoader;
    }

    public void setProjectsDBLoader(ProjectsDBLoader projectsDBLoader) {
        this.projectsDBLoader = projectsDBLoader;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public ProjectContractsDBLoader getProjectContractsDBLoader() {
        return projectContractsDBLoader;
    }

    public void setProjectContractsDBLoader(ProjectContractsDBLoader projectContractsDBLoader) {
        this.projectContractsDBLoader = projectContractsDBLoader;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setSelectedContract(ProjectContract selectedContract) {
        this.selectedContract = selectedContract;
    }

    public ProjectContract getSelectedContract() {
        //System.out.println("selectedContract id = " + selectedContract);
        return selectedContract;
    }
}
