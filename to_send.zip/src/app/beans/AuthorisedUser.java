package app.beans;

import app.controllers.SessionDataHolder;
import app.dto.Person;
import app.dto.User;
import app.helpers.LogSimple;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 30.12.13
 * Time: 14:59
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="authorisedUser")
@SessionScoped
public class AuthorisedUser {
    private User authorisedUser;

    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;

    public void setUser(User user) {
        authorisedUser = user;
    }

    public User getUser() {
        return authorisedUser;
    }

    public boolean skipLoginPageIfRegistered() {
        LogSimple.debug(this, "skipLoginPageIfRegistered started");
        boolean result = false;
        if(authorisedUser != null) {
            result = true;
            FacesContext fc = FacesContext.getCurrentInstance();
            LogSimple.debug(this, "isAuthorised authorised user = null");
            ConfigurableNavigationHandler nav =
                    (ConfigurableNavigationHandler) fc.getApplication().getNavigationHandler();
            nav.performNavigation("menuPage?faces-redirect=true");
            LogSimple.debug(this, "isAuthorised nav = " + nav);
        }
        LogSimple.debug(this, "skipLoginPageIfRegistered finished");
        return result;
    }

    public void isAuthorised() {
        System.out.println("isAuthorised started");
        if(authorisedUser == null) {
            FacesContext fc = FacesContext.getCurrentInstance();
            System.out.println("isAuthorised authorised user = null");
            ConfigurableNavigationHandler nav =
                    (ConfigurableNavigationHandler) fc.getApplication().getNavigationHandler();
            nav.performNavigation("loginPage?faces-redirect=true");
            System.out.println("isAuthorised nav = " + nav);
        }
        System.out.println("isAuthorised finished");
    }

    public void logout() {
        authorisedUser = null;
        sessionDataHolder.removeData();
        FacesContext fc = FacesContext.getCurrentInstance();
        ConfigurableNavigationHandler nav =
                (ConfigurableNavigationHandler) fc.getApplication().getNavigationHandler();

        nav.performNavigation("faces-redirect=true");
        fc.getExternalContext().invalidateSession();
    }

//    public boolean isTechnicalAM() {
//        Person person = getPerson();
//        if(person == null) {
//            return false;
//        }
//        return person.isTechnicalAM();
//    }
//
//    public Person getPerson() {
//        if (authorisedUser == null || authorisedUser.getLogin() == null) {
//            return null;
//        }
//        return personsDBLoader.getByLoginName(authorisedUser.getLogin());
//    }
//
//    public void setTechnicalAM(boolean v){
//
//    }
//
//    public boolean isProjectM() {
//        Person person = getPerson();
//        if(person == null) {
//            return false;
//        }
//        return person.isProjectM();
//    }
//
//    public void setProjectM(boolean v){
//
//    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }
}
