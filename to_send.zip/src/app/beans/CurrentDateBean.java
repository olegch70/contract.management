package app.beans;

import app.loaders.CurrentDataDBLoader;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Named;
import java.util.Calendar;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 17:11
 * To change this template use File | Settings | File Templates.
 */
//@ManagedBean(name="currentDateBean")
//@SessionScoped
@Named(value = "currentDateBean")
@Stateless
public class CurrentDateBean {

    @EJB
    CurrentDataDBLoader currentDataDBLoader;

    public Date getCurrentDate(){
        Date currentDate = currentDataDBLoader.getCurrentDate();
        if(currentDate == null) {
            currentDate = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }
}
