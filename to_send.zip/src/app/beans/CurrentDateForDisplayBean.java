package app.beans;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 17:11
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="currentDateForDisplayBean")
@SessionScoped
public class CurrentDateForDisplayBean {
    @EJB
    CurrentDateBean currentDateBean;

    public Date getCurrentDate(){
        return currentDateBean.getCurrentDate();
    }
}
