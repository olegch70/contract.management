package app.beans;

/**
 * Created by oleg on 13.05.2014.
 */
public interface IdentificableById {
    Long getId();
}
