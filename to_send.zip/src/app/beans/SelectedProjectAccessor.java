package app.beans;

import app.controllers.SessionDataHolder;
import app.dto.Client;
import app.dto.Project;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 13.01.14
 * Time: 17:18
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="selectedProjectAccessor")
@ViewScoped
public class SelectedProjectAccessor {
    final String SUFFIX = "_selectedProject";
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;

    public void setSelectedProject(String conversationUuid, Project selectedProject) {
        sessionDataHolder.add(conversationUuid+SUFFIX, selectedProject);
    }

    public void removeSelectedProject(String conversationUuid) {
        sessionDataHolder.remove(conversationUuid+SUFFIX);
    }

    public Project getSelectedProject(String conversationUuid) {
        return (Project) sessionDataHolder.get(conversationUuid+SUFFIX);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public boolean existSelectedProject(String conversationUuid) {
        if(getSelectedProject(conversationUuid) == null) {
            return false;
        } else {
            return true;
        }
    }
}
