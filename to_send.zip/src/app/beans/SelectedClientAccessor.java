package app.beans;

import app.controllers.SessionDataHolder;
import app.dto.Client;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 13.01.14
 * Time: 17:18
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="selectedClientAccessor")
@ViewScoped
public class SelectedClientAccessor {
    final String SUFFIX = "_selectedClient";
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;

    public void setSelectedClient(String conversationUuid, Client selectedClient) {
        sessionDataHolder.add(conversationUuid+SUFFIX, selectedClient);
    }

    public void removeSelectedClient(String conversationUuid) {
        sessionDataHolder.remove(conversationUuid+SUFFIX);
    }

    public Client getSelectedClient(String conversationUuid) {
        return (Client) sessionDataHolder.get(conversationUuid+SUFFIX);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }
}
