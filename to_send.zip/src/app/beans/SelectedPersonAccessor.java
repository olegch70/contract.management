package app.beans;

import app.controllers.SessionDataHolder;
import app.dto.Person;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 13.01.14
 * Time: 17:18
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="selectedPersonAccessor")
@ViewScoped
public class SelectedPersonAccessor {
    final String SUFFIX = "_selectedPerson";
    @ManagedProperty(value="#{sessionDataHolder}")
    private SessionDataHolder sessionDataHolder;

    public void setSelected(String conversationUuid, Person selected) {
        sessionDataHolder.add(conversationUuid+SUFFIX, selected);
    }

    public void removeSelected(String conversationUuid) {
        sessionDataHolder.remove(conversationUuid+SUFFIX);
    }

    public Person getSelected(String conversationUuid) {
        return (Person) sessionDataHolder.get(conversationUuid+SUFFIX);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }
}
