package app.beans;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Calendar;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 17.01.14
 * Time: 10:07
 */
@Named("fmtutl")
@RequestScoped
public class FormatterUtil {
    private DecimalFormat df;

    @PostConstruct
    private void init() {
        df = new DecimalFormat();
        df.setMinimumFractionDigits(0);
        df.setMaximumFractionDigits(0);
        df.setMinimumIntegerDigits(1);
        df.setGroupingSize(3);
        df.setGroupingUsed(true);
        DecimalFormatSymbols newSymbols = new DecimalFormatSymbols();
        newSymbols.setDecimalSeparator('.');
        newSymbols.setGroupingSeparator((char)160);
        df.setDecimalFormatSymbols(newSymbols);
    }

    public String formatBoolean(boolean val) {
        return formatBoolean(val, "[   ]", "[ X ]");
    }

    public String formatBoolean(boolean val, String valueForTrue, String valueForFalse) {
        if(val) {
            return valueForTrue ;
        } else {
            return valueForFalse ;
        }
    }

    public static String formatDouble(Double val) {
        return String.format("%1$.2f", val);
    }

    public static String formatDateLong(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        StringBuilder sb = new StringBuilder();
        int fieldValue = calendar.get(Calendar.DAY_OF_MONTH);
        if(fieldValue < 10) {
           sb.append("0");
        }
        sb.append(fieldValue);
        sb.append(".");

        fieldValue = calendar.get(Calendar.MONTH)+1;
        if(fieldValue < 10) {
           sb.append("0");
        }
        sb.append(fieldValue);
        sb.append(".");

        fieldValue = calendar.get(Calendar.YEAR);
        sb.append(fieldValue);
        return sb.toString();
    }

    public String formatDecimal(Number value) {
        return df.format(value);
    }

    public String formatDecimalNbSp(Number value) {
        if(value == null) {
            return null;
        }
        return df.format(value).replaceAll(" ", "&nbsp;");
    }

}
