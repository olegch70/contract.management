package app.beans;

import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;
import java.util.Calendar;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 30.12.13
 * Time: 16:03
 */
@ManagedBean(name = "dfmt")
@RequestScoped
public class DateFormatter {
    public String formatDate(Date val) {
        if(val == null) {
            return "";
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(val);
        return intToStr(calendar.get(Calendar.DAY_OF_MONTH))
                + "."
                + intToStr(calendar.get(Calendar.MONTH) + 1)
                + "."
                + intToStr(calendar.get(Calendar.YEAR))
                ;
    }

    public String formatDateTime(Date val) {
        if(val == null) {
            return "";
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(val);
        return intToStr(calendar.get(Calendar.DAY_OF_MONTH))
                + "."
                + intToStr(calendar.get(Calendar.MONTH) + 1)
                + "."
                + intToStr(calendar.get(Calendar.YEAR))
                + " "
                + intToStr(calendar.get(Calendar.HOUR_OF_DAY))
                + ":"
                + intToStr(calendar.get(Calendar.MINUTE))
                + ":"
                + intToStr(calendar.get(Calendar.SECOND))
                ;
    }

    private String intToStr(int val) {
        return (val < 10 ? "0" : "") + val;
    }
}
