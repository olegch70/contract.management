package app.report.dto;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 08.04.14
 * Time: 10:09
 * To change this template use File | Settings | File Templates.
 */
public class ReportDateFilter {
    private Date startDate;
    private Date endDate;
    private Integer year;
    private Integer startMonth;
    private Integer endMonth;
    private boolean useOnlyActive;
    private boolean useActivityTypesFrame = true;
    private boolean useOnlyForProjectManager;
    private Long projectManagerId;
    private Period periodEndDatePlan = new Period();

    public class Period {
        private Date from;
        private Date to;
        private boolean usePeriod;

        public Date getFrom() {
            return from;
        }

        public void setFrom(Date from) {
            this.from = from;
        }

        public Date getTo() {
            return to;
        }

        public void setTo(Date to) {
            this.to = to;
        }

        public boolean isUsePeriod() {
            return usePeriod;
        }

        public void setUsePeriod(boolean usePeriod) {
            this.usePeriod = usePeriod;
        }
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getYear() {
        return year;
    }

    public void setStartMonth(Integer startMonth) {
        this.startMonth = startMonth;
    }

    public Integer getStartMonth() {
        return startMonth;
    }

    public void setEndMonth(Integer endMonth) {
        this.endMonth = endMonth;
    }

    public Integer getEndMonth() {
        return endMonth;
    }

    public boolean isUseOnlyActive() {
        return useOnlyActive;
    }

    public void setUseOnlyActive(boolean useOnlyActive) {
        this.useOnlyActive = useOnlyActive;
    }

    public Period getPeriodEndDatePlan() {
        return periodEndDatePlan;
    }

    public boolean isUseActivityTypesFrame() {
        return useActivityTypesFrame;
    }

    public void setUseActivityTypesFrame(boolean useActivityTypesFrame) {
        this.useActivityTypesFrame = useActivityTypesFrame;
    }

    public boolean isUseOnlyForProjectManager() {
        return useOnlyForProjectManager;
    }

    public void setUseOnlyForProjectManager(boolean useOnlyForProjectManager) {
        this.useOnlyForProjectManager = useOnlyForProjectManager;
    }

    public Long getProjectManagerId() {
        return projectManagerId;
    }

    public void setProjectManagerId(Long projectManagerId) {
        this.projectManagerId = projectManagerId;
    }
}
