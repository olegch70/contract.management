package app.report.dto;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 08.04.14
 * Time: 10:09
 * To change this template use File | Settings | File Templates.
 */
public class ReportDateFilter {
    private Date startDate;
    private Date endDate;
    private Integer year;
    private Integer startMonth;
    private Integer endMonth;

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getYear() {
        return year;
    }

    public void setStartMonth(Integer startMonth) {
        this.startMonth = startMonth;
    }

    public Integer getStartMonth() {
        return startMonth;
    }

    public void setEndMonth(Integer endMonth) {
        this.endMonth = endMonth;
    }

    public Integer getEndMonth() {
        return endMonth;
    }
}
