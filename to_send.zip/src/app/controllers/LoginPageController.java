package app.controllers;

import app.beans.AuthorisedUser;
import app.beans.PasswordHasher;
import app.dto.User;
import app.loaders.PersonsDBLoader;
import app.loaders.UserDBLoader;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 30.12.13
 * Time: 11:18
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "loginPageController")
@ViewScoped
public class LoginPageController {

    private String name;
    private String password;
    private String confirmPassword;
    private boolean changePasswordMode;

    private static String MSG_INVALID_LOGIN_OR_PASSWORD = "����������� ����� ����� ��� ������";

    @ManagedProperty(value="#{authorisedUser}")
    AuthorisedUser authorisedUser;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    UserDBLoader userDBLoader;


    public String doLogin() {
        User user = getUser(name);

        if(isLogin(user, password) || (user != null && user.getPassword() == null && user.isPasswordDrop())) {
            if(user.isPasswordDrop()) {
                if(user.getPassword() == null && password.trim().length() != 0) {
                    displayUIMessage(MSG_INVALID_LOGIN_OR_PASSWORD);
                    return null;
                }
                changePasswordMode = true;
                password = "";
                return null;
            }
            return doSuccessfulAuthorization(user);

        } else {
            displayUIMessage(MSG_INVALID_LOGIN_OR_PASSWORD);
        }
        return "";
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    private String doSuccessfulAuthorization(User user) {
        authorisedUser.setUser(user);
        return "menuPage?faces-redirect=true";
    }

    public String doChangePassword() {
        User user = getUser(name);
        if(password.equals(confirmPassword)) {
            if(PasswordHasher.validatePassword(password)) {
                user.setPassword(PasswordHasher.computeHashS(name, password));
                user.setPasswordDrop(false);
                userDBLoader.update(user);
                return doSuccessfulAuthorization(user);
            } else {
                displayUIMessage("������ �� ������������� ��������");
            }
        } else {
            displayUIMessage("������ �� �������");
        }
        confirmPassword = "";
        return "";
    }

    public boolean isChangePasswordMode() {
        return changePasswordMode;
    }

    public void setChangePasswordMode(boolean changePasswordMode) {
        this.changePasswordMode = changePasswordMode;
    }

    private User getUser(String name) {
        return userDBLoader.getUserByLogin(name);
    }

    private boolean isLogin(User user, String password) {
        if(user != null && PasswordHasher.computeHashS(user.getLogin(), password).equals(user.getPassword())) {
            return true;
        }
        return false;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public AuthorisedUser getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUser authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }
}
