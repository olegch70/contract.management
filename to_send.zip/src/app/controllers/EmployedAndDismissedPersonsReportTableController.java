package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.CurrentDateBean;
import app.dto.Client;
import app.dto.Direction;
import app.dto.EmployedAndDismissedReport;
import app.dto.ProjectReport;
import app.helpers.LogSimple;
import app.helpers.ProjectReportHelper;
import app.helpers.ViewNavigationHelperModel;
import app.loaders.*;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "employedAndDismissedPersonsReportTableController")
@ViewScoped
public class EmployedAndDismissedPersonsReportTableController extends AbstractReportController {

    private static final String VIEW_NAME = "employedAndDismissedPersonsReport";
    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private DirectionDBLoader directionDBLoader;
    @EJB
    private EmployedAndDismissedPersonsReportDBLoader employedAndDismissedPersonsReportDBLoader;
    private ReportDateFilter reportDateFilter;
    private List<EmployedAndDismissedReport> items;
    private List<Direction> directionsList;
    private List<String> selectedDirections;


    public List<EmployedAndDismissedReport> getItems() {
        return items;
    }

    @Override
    protected void childInitModel() {
        if(selectedDirections == null) {
            selectedDirections = new LinkedList<String>();
            for(Direction direction: getDirectionsList()) {
                selectedDirections.add(direction.getId().toString());
            }
        }
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public void doFilter() {
        items = employedAndDismissedPersonsReportDBLoader.getReportData(getReportDateFilter(), selectedDirections);
        //itogItem = ProjectReportHelper.accumulateItog(items);
    }

    public static String doCall(ViewNavigationHelperModel viewNavigationHelperModel){
        String resultURL = doCall(VIEW_NAME, viewNavigationHelperModel);
        return resultURL;
    }

    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public List<Direction> getDirectionsList() {
        if(directionsList == null) {
            directionsList = directionDBLoader.getAll();
        }
        return directionsList;
    }

    public void setDirectionsList(List<Direction> directionsList) {
    }

    public List<String> getSelectedDirections() {
        return selectedDirections;
    }

    public void setSelectedDirections(List<String> selectedDirections) {
        this.selectedDirections = selectedDirections;
    }


}
