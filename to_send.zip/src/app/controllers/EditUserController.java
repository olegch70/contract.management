package app.controllers;

import app.beans.PasswordHasher;
import app.dto.Person;
import app.dto.Position;
import app.dto.User;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.loaders.PersonsDBLoader;
import app.loaders.PositionDBLoader;
import app.loaders.UserDBLoader;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 17:06
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editUserController")
@ViewScoped
public class EditUserController extends AbstractEditController {
    private static final String VIEW_NAME = "editUser";
    public static final String PERSON_ID_KEY = "personId";
    @EJB
    private UserDBLoader userDBLoader;
    @EJB
    private PersonsDBLoader personsDBLoader;
    private User user;
    private Long personId;


    public void childInitModel(){
        personId = (Long) parameters.get(PERSON_ID_KEY);
        Person person = personsDBLoader.getById(personId);
        user = userDBLoader.getUserByLogin(person.getLoginName());

        if(user == null){
            user = new User();
        } else {
            user.setPassword("");
        }
    }

    public static String doCallEditUserByRecordId(AbstractController caller, Long id){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(PERSON_ID_KEY, id);
        return result;
    }

    public String save() {
        User existsUser = userDBLoader.getUserByLogin(user.getLogin());
        if( existsUser != null && ! existsUser.getId().equals(user.getId())) {
            displayUIMessage("������������ � ����� ������� ��� ����c�����. <br/> ������� ������ �����.");
            return null;
        }
        Person person = personsDBLoader.getById(personId);
        user.setPasswordDrop(true);
        user.setPassword(PasswordHasher.computeHashS(user.getLogin(), user.getPassword()));
        if(user.getId() == null){
            userDBLoader.addNew(user);
        } else {
            System.out.println("saveUser in edit income called");
            userDBLoader.update(user);
            System.out.println("saveUser in edit income updated");
        }
        if( ! user.getLogin().equals(person.getLoginName())){
            person.setLoginName(user.getLogin());
            personsDBLoader.update(person);
        }
        return doBack();
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }
}
