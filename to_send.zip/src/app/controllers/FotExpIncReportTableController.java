package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.CurrentDateBean;
import app.dto.FotExpIncActual;
import app.dto.FotExpIncReport;
import app.helpers.LogSimple;
import app.loaders.ClientsDBLoader;
import app.loaders.FotExpIncDBLoader;
import app.loaders.FotExpIncReportDBLoader;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "fotExpIncReportTableController")
@ViewScoped
public class FotExpIncReportTableController {

    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private FotExpIncReportDBLoader fotExpIncReportDBLoader;
    @EJB
    private ClientsDBLoader clientsDBLoader;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    private List<FotExpIncActual> reportItems;
    private FotExpIncActual fotExpIncActual;
    private FotExpIncReport fotExpIncReport;
    private String backPath;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private ReportDateFilter reportDateFilter;

    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        localUuid = getConversationUuid()+"_monthsExpIncReportTableController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            reportDateFilter = new ReportDateFilter();
            reportDateFilter.setYear(calendar.get(Calendar.YEAR));
            reportDateFilter.setStartMonth(1);
            reportDateFilter.setEndMonth(calendar.get(Calendar.MONTH) + 1);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            backPath = (String) parameters.get("backPath");
        }
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public List<FotExpIncActual> getItems() {
        return reportItems;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public String doBack() {
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void doFilter() {
        LogSimple.debug(this, "doFilter executed");
        fotExpIncReport = fotExpIncReportDBLoader.getReportData(reportDateFilter);
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public String getLocalUuid() {
        return localUuid;
    }

    public void setLocalUuid(String localUuid) {
        this.localUuid = localUuid;
    }

    public Map getParameters() {
        return parameters;
    }

    public void setParameters(Map parameters) {
        this.parameters = parameters;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public FotExpIncActual getFotExpIncActual() {
        return fotExpIncActual;
    }

    public void setFotExpIncActual(FotExpIncActual fotExpIncActual) {
        this.fotExpIncActual = fotExpIncActual;
    }

    public FotExpIncReport getFotExpIncReport() {
        return fotExpIncReport;
    }

    public void setFotExpIncReport(FotExpIncReport fotExpIncReport) {
        this.fotExpIncReport = fotExpIncReport;
    }
}
