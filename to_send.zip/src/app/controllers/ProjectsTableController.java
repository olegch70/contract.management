package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.SelectedProjectAccessor;
import app.beans.UiTableHelper;
import app.controllers.utils.DataTableUIValuesHolder;
import app.dto.Client;
import app.dto.ContractStatus;
import app.dto.Project;
import app.dto.ProjectType;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.loaders.ClientsDBLoader;
import app.loaders.ContractStatusDBLoader;
import app.loaders.ProjectTeamDBLoader;
import app.loaders.ProjectsDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import java.security.InvalidParameterException;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 15:47
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectsTableController")
@ViewScoped
public class ProjectsTableController {
    @EJB
    private ProjectsDBLoader projectsDBLoader;
    @EJB
    private ContractStatusDBLoader contractStatusDBLoader;
    @EJB
    private ProjectTeamDBLoader projectTeamDBLoader;
    @EJB
    private ClientsDBLoader clientsDBLoader;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{selectedProjectAccessor}")
    SelectedProjectAccessor selectedProjectAccessor;
    private Long clientId;
    private String backPath;
    private String conversationUuid;
    private Map parameters;
    private String localUuid;
    private List<Project> projects;
    private boolean initialized;
    private SelectItem[] statusOptions;
    private Client client;

    @ManagedProperty(value = UiTableHelper.UI_TABLE_HELPER_EL)
    private UiTableHelper uiTableHelper;


    public void initModel() {
        LogSimple.debug(this, "initModel started");
        initialized = true;
        System.out.println("conversationUuid = " + conversationUuid);
        initializeUuid();
        localUuid = getLocalUuid(conversationUuid);
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        createContractStatusOptionsForFilter();
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("clientId", clientId);
            System.out.println("parameters.put(clientId = " + clientId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            uiTableHelper.saveValues(parameters);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            clientId = (Long) parameters.get("clientId");
            backPath = (String) parameters.get("backPath");
            uiTableHelper.restoreValues(parameters);
            uiTableHelper.processItemsToRefresh(projectsDBLoader);
        }
        LogSimple.debug(this, "initModel finished");
    }

    public UiTableHelper getUiTableHelper() {
        return uiTableHelper;
    }

    public void setUiTableHelper(UiTableHelper uiTableHelper) {
        this.uiTableHelper = uiTableHelper;
    }

    private void createContractStatusOptionsForFilter() {
        List<ContractStatus> csList = contractStatusDBLoader.getAll();
        String[] statuses = new String[csList.size()];
        for(int i = 0; i < csList.size(); i++) {
            statuses[i] = csList.get(i).getName();
        }
        statusOptions = createFilterOptions(statuses);
    }

    private static String getLocalUuid(String conversationUuid1) {
        return conversationUuid1 +"_contractsTableController";
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        return currentPath;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String uuid) {
        this.conversationUuid = uuid;
    }

    public List<Project> getProjects() {
        LogSimple.debug(this, "getProject() start. initialized = "+initialized);
        long tStart = System.currentTimeMillis();
        boolean isRoot = authorisedUser.getCurrentUserIsRoot();
        try {
            if(initialized) {
                if(projects == null && clientId != null) {
                    projects = projectsDBLoader
                            .getProjectsForAuthorizedUser(
                                    authorisedUser.getPerson().getId(),
                                    authorisedUser.isTechnicalAM(),
                                    authorisedUser.isProjectM(),
                                        isRoot,
                                    clientId
                            );
                }
                return projects;
            } else {
                return null;
            }
        } finally {
            long tFinish = System.currentTimeMillis();
            LogSimple.debug(this, "getProject() finish. "+(tFinish - tStart)+ " ms");
        }
    }

    public List<Project> getProjectsForFinance() {
        LogSimple.debug(this, "getProject() start. initialized = "+initialized);
        projects = projectsDBLoader.getNotClosedProjectsForFin();
        return projects;
    }

    private String getURLStringForAddViewAndPrepareToRedirect(String projectType, Long projectTypeId) {
        LogSimple.debug(this, "projectType = " + projectType);
        selectedProjectAccessor.removeSelectedProject(conversationUuid);
        return projectType + "?projectId=" +"-1"
                +"&clientId="+clientId
                +"&projectTypeId="+projectTypeId
                +"&command=add"
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private String getViewNameByProjectTypeId(Long id) {
        if(ProjectType.FIX.getId().equals(id)) {
            return "editTradeFix";
        }
        if(ProjectType.FRAME.getId().equals(id)) {
            return "editTradeFrame";
        }
        if(ProjectType.OUTSTAFF.getId().equals(id)) {
            return "editTradeOutStaff";
        }
        if(ProjectType.PROJECT.getId().equals(id)) {
            return "editTradeProject";
        }
        if(ProjectType.PRESALE_A.getId().equals(id)) {
            return "editTradePresaleA";
        }
        if(ProjectType.PRESALE_B.getId().equals(id)) {
            return "editTradePresaleB";
        }
        throw new InvalidParameterException("Unknown project type id = " + id);
    }

    public String doAddFix() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.FIX.getId()), ProjectType.FIX.getId());
    }

    public String doAddFrame() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.FRAME.getId()), ProjectType.FRAME.getId());
    }

    public String doAddOutStaff() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.OUTSTAFF.getId()), ProjectType.OUTSTAFF.getId());
    }

    public String doAddProject() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.PROJECT.getId()), ProjectType.PROJECT.getId());
    }

    public String doAddPresaleA() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.PRESALE_A.getId()), ProjectType.PRESALE_A.getId());
    }

    public String doAddPresaleB() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.PRESALE_B.getId()), ProjectType.PRESALE_B.getId());
    }

    public String doEdit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        String resultString = getViewNameByProjectTypeId(getSelectedItem().getType()) + "?projectId="+ getSelectedItem().getId()
                +"&command=edit"
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        System.out.println("resultString = " + resultString);
        return resultString;
    }

    private Project getSelectedItem() {
        return (Project) uiTableHelper.getSelectedItem();
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(getSelectedItem() != null) {
            return true;
        }

        displayUIMessage("�������� ������� ������.");
        return false;
    }

    public String goToDirectExpenses() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return "projectDirectExpenses?projectId="+ getSelectedItem().getId()
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToIncome(){
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return "projectIncome?projectId="+ getSelectedItem().getId()
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String doTimeLineShow(){
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        final String result = "system/timeLinePage?projectId=" + getSelectedItem().getId()
                +"&backPath=" + getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        return result;
    }

    public String doShowGraphIncomeExpenses(){
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        final String result = "system/graphIncomeExpenses?projectId=" + getSelectedItem().getId()
                +"&backPath=" + getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        return result;
    }

    private void log(String s) {
        LogSimple.debug(this, s);
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
    }

    public void delete() {
        try {
            projectsDBLoader.delete(getSelectedItem().getId());
            uiTableHelper.deleteItemFromFiltered(getSelectedItem());
//            filteredRows = null;
            projects = null;
            UIMessages.displayMessage("������ �������.");
        } catch (Exception e) {
            UIMessages.displayErrorMessage("�� ������� ������� ������.");
            LogSimple.error(this, e);
        }

    }

    public String doEditTeam() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        if(isClosed()) {
            displayUIMessage("������ �������� ������� � �������� ����������");
            return "";
        }
        if(isPaused()) {
            displayUIMessage("������ �������� ������� � ���������������� ����������");
            return "";
        }
        getCurrentSelectedProjectForHeaderInfo();
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return "teamList?projectId="+ getSelectedItem().getId()
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    private boolean isPaused() {
        return getSelectedItem().getStatusId().equals(ContractStatus.PAUSED.getId());
    }

    private boolean isClosed() {
        return getSelectedItem().getStatusId().equals(ContractStatus.CLOSED.getId());
    }

    public String doBack() {
        selectedProjectAccessor.removeSelectedProject(conversationUuid);
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private SelectItem[] createFilterOptions(String[] data)  {
        SelectItem[] options = new SelectItem[data.length + 2];

        options[0] = new SelectItem("", "���");
        options[1] = new SelectItem("��", "�� �������");
        for(int i = 0; i < data.length; i++) {
            options[i + 2] = new SelectItem(data[i], data[i]);
        }

        return options;
    }

    public SelectItem[] getStatusOptions() {
        return statusOptions;
    }

    private void getCurrentSelectedProjectForHeaderInfo() {
        selectedProjectAccessor.removeSelectedProject(conversationUuid);
        selectedProjectAccessor.setSelectedProject(conversationUuid, getSelectedItem());
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getClientId() {
        return clientId;
    }
    public Client getClient() {
        if(client == null) {
            client = clientsDBLoader.getById(clientId);
        }
        return client;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public ProjectTeamDBLoader getProjectTeamDBLoader() {
        return projectTeamDBLoader;
    }

    public void setProjectTeamDBLoader(ProjectTeamDBLoader projectTeamDBLoader) {
        this.projectTeamDBLoader = projectTeamDBLoader;
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public SelectedProjectAccessor getSelectedProjectAccessor() {
        return selectedProjectAccessor;
    }

    public void setSelectedProjectAccessor(SelectedProjectAccessor selectedProjectAccessor) {
        this.selectedProjectAccessor = selectedProjectAccessor;
    }

    public boolean allowAddActivity() {
        if(authorisedUser.getCurrentUserIsRoot()) {
            // root ����� ��������� ����������
            return true;
        }
        if(clientId == null) {
            return false;
        }
        if( authorisedUser.getPerson().getId().equals(getClient().getTechnicalAM())) {
            if(authorisedUser.getPerson().isTechnicalAM()) {
                return true;
            }
        }

        return false;
    }

    public boolean allowEdit() {
        if(authorisedUser.getCurrentUserIsRoot()) {
            // root ����� ������������� ����������
            return true;
        }

        if(clientId == null) {
            return false;
        }

        if( authorisedUser.getPerson().getId().equals(getClient().getTechnicalAM())) {
            if(authorisedUser.getPerson().isTechnicalAM()) {
                return true;
            }
        }

        return false;
    }
}
