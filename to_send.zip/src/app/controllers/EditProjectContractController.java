package app.controllers;

import app.dto.ProjectContract;
import app.dto.ProjectType;
import app.helpers.ViewNavigationHelper;
import app.loaders.ProjectContractsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AbortProcessingException;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 25.12.13
 * Time: 12:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editProjectContractController")
@ViewScoped
public class EditProjectContractController extends AbstractEditController {

    private static final String VIEW_NAME = "editProjectContract";
    private static final String PROJECT_ID_KEY = "projectId";
    private static final String PROJECT_CONTRACT_ID_KEY = "projectContractId";
    private ProjectContract projectContract;
    @EJB
    private ProjectContractsDBLoader projectContractsDBLoader;
    private Long projectId;
    private Long projectContractId;
    boolean copyProjectTillEnd;
    public final static String MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING = "## ������������� ��������� ��������. �� �������� ��� ������.";

    public void childInitModel() throws AbortProcessingException {
        command = (String) parameters.get(COMMAND_KEY);
        projectContractId = (Long) parameters.get(PROJECT_CONTRACT_ID_KEY);
        projectId = (Long) parameters.get(PROJECT_ID_KEY);

            if(command.equals(COMMAND_ADD)){
                projectContract = new ProjectContract();
                setFieldsForNew(projectContract, 0);
            } else {
                for(ProjectContract row : EditProjectController.getProjectContractsFromContext(conversationUuid, getViewNavigationHelperModel().getSessionDataHolder()))
                {
                    if(row.getId().equals(projectContractId)){
                        projectContract = row;
                        if(projectId == null) {
                            projectId = projectContract.getProjectId();
                        }
                        break;
                    }
                }
            }

    }

    public static String doCallAdd(AbstractController caller, Long projectId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long projectContractId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        paramModel[0].put(PROJECT_CONTRACT_ID_KEY, projectContractId);
        return result;
    }

    private void setFieldsForNew(ProjectContract projectContract1, int add) {
        projectContract1.setProjectId(projectId);
        projectContract1.setId(-(new Date().getTime() + add));//��� ���������� ������� � ��, ��� �������� ������� � null
    }

    public String saveContract() {
        List<ProjectContract> projectContractsListForAddInProject
                = EditProjectController.getProjectContractsFromContext(conversationUuid, getViewNavigationHelperModel().getSessionDataHolder());
        if(command.equals(COMMAND_ADD)){
            if( ! copyProjectTillEnd) {
                projectContractsListForAddInProject.add(projectContract);
            } else {
                copyProjectUntilProjectEnd(projectContractsListForAddInProject);
            }
        } else {
            if( ! copyProjectTillEnd) {
//                projectContractsListForAddInProject.remove(projectContract);
//                projectContractsListForAddInProject.add(projectContract);
            } else {
                copyProjectUntilProjectEnd(projectContractsListForAddInProject);
            }
        }
        return doBack();
    }

    private void copyProjectUntilProjectEnd(List<ProjectContract> projectContractsListForAddInProject) {
        Date endDate = EditProjectController.getProjectFromContext(conversationUuid, getViewNavigationHelperModel().getSessionDataHolder()).getEndDatePlan();
        Date startDate = projectContract.getDocDate();
        BigDecimal price = projectContract.getPrice();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        int curMonth = calendar.get(Calendar.MONTH);
        int curDay = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.setTime(endDate);
        int endMonth = calendar.get(Calendar.MONTH);
//        int numberOfMonths = calculateNumberOfMonths(startDate, endDate);
        while( curMonth <= endMonth ) {
            ProjectContract foundDocument = getExistDocumentForMonth(curMonth, projectContractsListForAddInProject);
            if(foundDocument != null) {
                foundDocument.setPrice(projectContract.getPrice());
                foundDocument.setNumber(projectContract.getNumber());
                if(projectContract.getDescription().startsWith(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING)) {
                    foundDocument.setDescription(projectContract.getDescription());
                } else {
                    foundDocument.setDescription(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING + "\n" + projectContract.getDescription());
                }
            } else {
                foundDocument = new ProjectContract();
                setFieldsForNew(foundDocument, curMonth);
                foundDocument.setPrice(projectContract.getPrice());
                if(projectContract.getDescription().startsWith(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING)) {
                    foundDocument.setDescription(projectContract.getDescription());
                } else {
                    foundDocument.setDescription(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING + "\n" + projectContract.getDescription());
                }
                foundDocument.setNumber(projectContract.getNumber());
                calendar.set(Calendar.MONTH, curMonth);
                calendar.set(Calendar.DAY_OF_MONTH, 1);
                int dayOfMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                if(curDay < dayOfMonth) {
                    dayOfMonth = curDay;
                }
                if(curMonth == endMonth) {
                    calendar.setTime(endDate);
                    dayOfMonth = Math.min(dayOfMonth, calendar.get(Calendar.DAY_OF_MONTH));
                }
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                foundDocument.setDocDate(calendar.getTime());
                projectContractsListForAddInProject.add(foundDocument);
            }
            curMonth++;
        }
    }

    private ProjectContract getExistDocumentForMonth(int curMonth, List<ProjectContract> projectContractsListForAddInProject) {
        Calendar calendar = Calendar.getInstance();
        for(ProjectContract curProjectContract : projectContractsListForAddInProject) {
            calendar.setTime(curProjectContract.getDocDate());
            if(curMonth == calendar.get(Calendar.MONTH)) {
                if(curProjectContract.getDescription().startsWith(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING)) {
                    return curProjectContract;
                }
            }
        }
        return null;
    }

    public boolean isOutStaffType() {
        boolean result = false;
        Long curProjectType = EditProjectController.getProjectFromContext(conversationUuid, getViewNavigationHelperModel().getSessionDataHolder()).getType();
        if(ProjectType.OUTSTAFF.getId().equals(curProjectType)) {
            result = true;
        }
        return result;
    }

    private Integer calculateNumberOfMonths(Date startDate, Date endDate) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        int startDateMonth = cal.get(Calendar.MONTH);
        cal.setTime(endDate);
        int endDateMonth = cal.get(Calendar.MONTH);
        int result = endDateMonth - startDateMonth + 1;
        return result;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public ProjectContract getProjectContract() {
        return projectContract;
    }

    public void setProjectContract(ProjectContract projectContract) {
        this.projectContract = projectContract;
    }

    public boolean isCopyProjectTillEnd() {
        return copyProjectTillEnd;
    }

    public void setCopyProjectTillEnd(boolean copyProjectTillEnd) {
        this.copyProjectTillEnd = copyProjectTillEnd;
    }
}
