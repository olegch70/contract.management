package app.controllers;

import app.dto.ProjectContract;
import app.dto.ProjectType;
import app.loaders.ProjectContractsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AbortProcessingException;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 25.12.13
 * Time: 12:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editProjectContractController")
@ViewScoped
public class EditProjectContractController {

    private Long projectContractId;
    private String backPath;
    private String conversationUuid;
    private Map parameters;
    private String localUuid;
    private ProjectContract projectContract;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    //@ManagedProperty(value="#{projectContractsDBLoader}")
    @EJB
    private ProjectContractsDBLoader projectContractsDBLoader;
    private String command;
    private Long projectId;
    boolean copyProjectTillEnd;
    public final static String MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING = "## ������������� ��������� ��������. �� �������� ��� ������.";

    public void initModel() throws AbortProcessingException {
        System.out.println("initModel() in EditProjectContractController started");
        initializeUuid();
        localUuid = getConversationUuid()+"_editProjectContractController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("projectContractId", projectContractId);
            parameters.put("projectId", projectId);
            System.out.println("parameters.put(projectContractId = " + projectContractId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            if(command.equals("add")){
                projectContract = new ProjectContract();
                setFieldsForNew(projectContract, 0);
            } else {
                for(ProjectContract row : EditProjectController.getProjectContractsFromContext(getConversationUuid(), sessionDataHolder))
                {
                    if(row.getId().equals(projectContractId)){
                        projectContract = row;
                        if(projectId == null) {
                            projectId = projectContract.getProjectId();
                        }
                        break;
                    }
                }
                System.out.println("projectContract = " + projectContract);
            }
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            System.out.println("parameters projectContractId = " + parameters.get("projectContractId"));
            projectContractId = (Long) parameters.get("projectContractId");
            projectId = (Long) parameters.get("projectContractId");
            backPath = (String) parameters.get("backPath");
        }

        System.out.println("initModel() in EditProjectContractController finished");
    }

    private void setFieldsForNew(ProjectContract projectContract1, int add) {
        projectContract1.setProjectId(projectId);
        projectContract1.setId(-(new Date().getTime() + add));//��� ���������� ������� � ��, ��� �������� ������� � null
    }

    public String saveContract() {
        System.out.println("saveProject in edit project contract called");
        List<ProjectContract> projectContractsListForAddInProject
                = EditProjectController.getProjectContractsFromContext(getConversationUuid(), sessionDataHolder);
        if(command.equals("add")){
            if( ! copyProjectTillEnd) {
                projectContractsListForAddInProject.add(projectContract);
            } else {
                copyProjectUntilProjectEnd(projectContractsListForAddInProject);
            }
        } else {
            System.out.println("saveProject in edit project contract updated");
            if( ! copyProjectTillEnd) {
//                projectContractsListForAddInProject.remove(projectContract);
//                projectContractsListForAddInProject.add(projectContract);
            } else {
                copyProjectUntilProjectEnd(projectContractsListForAddInProject);
            }
        }
        System.out.println("update backPath = " + backPath);
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void copyProjectUntilProjectEnd(List<ProjectContract> projectContractsListForAddInProject) {
        Date endDate = EditProjectController.getProjectFromContext(getConversationUuid(), sessionDataHolder).getEndDatePlan();
        Date startDate = projectContract.getDocDate();
        BigDecimal price = projectContract.getPrice();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        int curMonth = calendar.get(Calendar.MONTH);
        int curDay = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.setTime(endDate);
        int endMonth = calendar.get(Calendar.MONTH);
//        int numberOfMonths = calculateNumberOfMonths(startDate, endDate);
        while( curMonth <= endMonth ) {
            ProjectContract foundDocument = getExistDocumentForMonth(curMonth, projectContractsListForAddInProject);
            if(foundDocument != null) {
                foundDocument.setPrice(projectContract.getPrice());
                foundDocument.setNumber(projectContract.getNumber());
                if(projectContract.getDescription().startsWith(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING)) {
                    foundDocument.setDescription(projectContract.getDescription());
                } else {
                    foundDocument.setDescription(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING + "\n" + projectContract.getDescription());
                }
            } else {
                foundDocument = new ProjectContract();
                setFieldsForNew(foundDocument, curMonth);
                foundDocument.setPrice(projectContract.getPrice());
                if(projectContract.getDescription().startsWith(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING)) {
                    foundDocument.setDescription(projectContract.getDescription());
                } else {
                    foundDocument.setDescription(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING + "\n" + projectContract.getDescription());
                }
                foundDocument.setNumber(projectContract.getNumber());
                calendar.set(Calendar.MONTH, curMonth);
                calendar.set(Calendar.DAY_OF_MONTH, 1);
                int dayOfMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                if(curDay < dayOfMonth) {
                    dayOfMonth = curDay;
                }
                if(curMonth == endMonth) {
                    calendar.setTime(endDate);
                    dayOfMonth = Math.min(dayOfMonth, calendar.get(Calendar.DAY_OF_MONTH));
                }
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                foundDocument.setDocDate(calendar.getTime());
                projectContractsListForAddInProject.add(foundDocument);
            }
            curMonth++;
        }
    }

    private ProjectContract getExistDocumentForMonth(int curMonth, List<ProjectContract> projectContractsListForAddInProject) {
        Calendar calendar = Calendar.getInstance();
        for(ProjectContract curProjectContract : projectContractsListForAddInProject) {
            calendar.setTime(curProjectContract.getDocDate());
            if(curMonth == calendar.get(Calendar.MONTH)) {
                if(curProjectContract.getDescription().startsWith(MARKER_INFO_FOR_AUTOMATICALLY_GENERATED_STRING)) {
                    return curProjectContract;
                }
            }
        }
        return null;
    }

    public boolean isOutStaffType() {
        boolean result = false;
        Long curProjectType = EditProjectController.getProjectFromContext(getConversationUuid(), sessionDataHolder).getType();
        if(ProjectType.OUTSTAFF.getId().equals(curProjectType)) {
            result = true;
        }
        return result;
    }

    private Integer calculateNumberOfMonths(Date startDate, Date endDate) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        int startDateMonth = cal.get(Calendar.MONTH);
        cal.setTime(endDate);
        int endDateMonth = cal.get(Calendar.MONTH);
        int result = endDateMonth - startDateMonth + 1;
        return result;
    }

    public String doBack() {
        removeModelFromSession();
        System.out.println("backPath on doBack = " + backPath);
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public void setProjectContractId(Long contractId) {
        this.projectContractId = contractId;
    }

    public Long getProjectContractId() {
        return projectContractId;
    }

    public ProjectContract getProjectContract() {
        return projectContract;
    }

    public void setProjectContract(ProjectContract projectContract) {
        this.projectContract = projectContract;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public ProjectContractsDBLoader getProjectContractsDBLoader() {
        return projectContractsDBLoader;
    }

    public void setProjectContractsDBLoader(ProjectContractsDBLoader projectContractsDBLoader) {
        this.projectContractsDBLoader = projectContractsDBLoader;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String getCommand() {
        return command;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public boolean isCopyProjectTillEnd() {
        return copyProjectTillEnd;
    }

    public void setCopyProjectTillEnd(boolean copyProjectTillEnd) {
        this.copyProjectTillEnd = copyProjectTillEnd;
    }
}
