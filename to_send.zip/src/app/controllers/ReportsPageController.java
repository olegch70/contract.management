package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.RootChecker;
import app.controllers.report.ActivityPersonsReportController;
import app.controllers.report.PersonWithSalaryReportController;
import app.helpers.ViewNavigationHelperModel;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 12.03.14
 * Time: 12:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "reportsPageController")
@ViewScoped
public class ReportsPageController {

    @ManagedProperty(value="#{viewNavigationHelperModel}")
    private ViewNavigationHelperModel viewNavigationHelperModel;

    public static final String REPORTS_PATH = "reports/";
    @EJB
    private RootChecker rootChecker;

    @ManagedProperty(value="#{authorisedUserViewBean}")
    private AuthorisedUserViewScoped authorisedUser;

    @ManagedProperty(value="#{sessionDataHolder}")
    private SessionDataHolder sessionDataHolder;

    private String localUuid;
    //private String conversationUuid;
    private Map parameters;
    private String backPath;


    public void initModel() {
        System.out.println("conversationUuid = " + getConversationUuid());
        localUuid = getConversationUuid()+"_ReportsPageController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            backPath = (String) parameters.get("backPath");
        }
    }

    public String goToClientsReport() {
        return  "clientsReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToClientReport() {
        return  "clientReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToDirectionReport() {
        return  "directionReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToFrameReport() {
        return  "frameReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToBenchPersonsReport() {
        return  "benchPersonsReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToDirectExpensesReport() {
        return  "directExpensesReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToDirectExpensesReportFact() {
        return  "/reports/directExpensesReportFact?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToIncomesReport() {
        return  "incomesReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToDomainCostReport() {
        return  "domainCostReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToFotExpIncReport() {
        return  "fotExpIncReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToPresaleReport() {
        return  "presaleReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToAlternateTAMReport() {
        return  REPORTS_PATH +"alternateTAMReport?backPath="+getCurrentPath()
                +"&conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public String goToPersonsWithSalary() {
        return PersonWithSalaryReportController.doCall(viewNavigationHelperModel);
    }

    public String goToActivityWithPersons() {
        return ActivityPersonsReportController.doCall(viewNavigationHelperModel);
    }

    public String goToEmployedAndDismissedPersons() {
        return EmployedAndDismissedPersonsReportTableController.doCall(viewNavigationHelperModel);
    }


    public String goBack() {
        removeModelFromSession();
        return  backPath+"?conversationUuid="+getConversationUuid()
                +"&faces-redirect=true";
    }

    public boolean getCurrentUserIsRoot() {
        if(authorisedUser == null) {
            return false;
        }
        return rootChecker.isRoot(authorisedUser.getPerson());
    }

    public boolean getCurrentUserIsRootOrPM() {
        if(authorisedUser == null) {
            return false;
        }
        if(rootChecker.isRoot(authorisedUser.getPerson()) || getAuthorisedUser().isProjectM()) {
            return true;
        }
        return false;
    }

    public boolean getCurrentUserIsRootOrHr() {
        if(authorisedUser == null) {
            return false;
        }
        if(getCurrentUserIsRoot() || getAuthorisedUser().isCurrentUserIsHR()) {
            return true;
        }
        return false;
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        return facesContext.getViewRoot().getViewId();
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getConversationUuid() {
        return viewNavigationHelperModel.getConversationUuid();
    }

    public ViewNavigationHelperModel getViewNavigationHelperModel() {
        return viewNavigationHelperModel;
    }

    public void setViewNavigationHelperModel(ViewNavigationHelperModel viewNavigationHelperModel) {
        this.viewNavigationHelperModel = viewNavigationHelperModel;
    }

}
