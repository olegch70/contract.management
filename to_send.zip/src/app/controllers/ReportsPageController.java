package app.controllers;
 
import app.beans.AuthorisedUserViewScoped;
import app.beans.RootChecker;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 12.03.14
 * Time: 12:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "reportsPageController")
@ViewScoped
public class ReportsPageController {

    @EJB
    private RootChecker rootChecker;

    @ManagedProperty(value="#{authorisedUserViewBean}")
    private AuthorisedUserViewScoped authorisedUser;

    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;

    private String localUuid;
    private String conversationUuid;
    private Map parameters;
    private String backPath;


    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        localUuid = conversationUuid+"_ReportsPageController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            backPath = (String) parameters.get("backPath");
        }
    }

    public String goToClientsReport() {
        return  "clientsReport?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToClientReport() {
        return  "clientReport?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToDirectionReport() {
        return  "directionReport?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToFrameReport() {
        return  "frameReport?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToBenchPersonsReport() {
        return  "benchPersonsReport?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToDirectExpensesReport() {
        return  "directExpensesReport?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToDomainCostReport() {
        return  "domainCostReport?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToFotExpIncReport() {
        return  "fotExpIncReport?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goBack() {
        removeModelFromSession();
        return  backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public boolean getCurrentUserIsRoot() {
        if(authorisedUser == null) {
            return false;
        }
        return rootChecker.isRoot(authorisedUser.getPerson());
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        return facesContext.getViewRoot().getViewId();
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }
}
