package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.RootChecker;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 12.03.14
 * Time: 12:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "directoriesPageController")
@ViewScoped
public class DirectoriesPageController {

    @EJB
    private RootChecker rootChecker;

    @ManagedProperty(value="#{authorisedUserViewBean}")
    private AuthorisedUserViewScoped authorisedUser;

    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;

    private String localUuid;
    private String conversationUuid;
    private Map parameters;
    private String backPath;


    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        localUuid = conversationUuid+"_DirectoriesPageController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            backPath = (String) parameters.get("backPath");
        }
    }

    public String goToPersons() {
        return  "personsList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToPositions() {
        return  "positionsList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToGrades() {
        return  "gradesList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToDirections() {
        return  "directionsList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToExpTypes() {
        return  "expensesTypesList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToFOT() {
        return  "fotExpIncList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }


    public String goBack() {
        removeModelFromSession();
        return  backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public boolean getCurrentUserIsRoot() {
        if(authorisedUser == null) {
            return false;
        }
        return rootChecker.isRoot(authorisedUser.getPerson());
    }

    public boolean getCurrentUserIsRootOrHR() {
        boolean result = false;
        if(authorisedUser == null) {
            result = false;
        }
        if(
                rootChecker.isRoot(authorisedUser.getPerson()) ||
                        authorisedUser.getPerson().isHR()) {
            result = true;
        }
        return result;
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        return facesContext.getViewRoot().getViewId();
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }
}
