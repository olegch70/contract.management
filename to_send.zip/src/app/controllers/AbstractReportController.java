package app.controllers;

import app.helpers.ViewNavigationHelper;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 21.05.14
 * Time: 11:50
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractReportController extends AbstractController {
    @Override
    protected void afterDoBack() {
        ViewNavigationHelper.removeModelForConversation(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid);
    }
}
