package app.controllers;

import app.dto.Direction;
import app.dto.Grade;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.loaders.DirectionDBLoader;
import app.loaders.GradeDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "directionsListController")
@ViewScoped
public class DirectionsListController {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;

    @EJB
    private DirectionDBLoader directionDBLoader;

    private String backPath;
    private String localUuid;
    private String conversationUuid;
    private Map parameters;
    private List<Direction> filteredRows;
    private Direction selectedItem;

    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        localUuid = getConversationUuid()+"_directionsListController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);

        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            filteredRows = (List) parameters.get("filteredRows");
            backPath = (String) parameters.get("backPath");
        }
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(selectedItem != null) {
            return true;
        }

        UIMessages.displayMessage("�������� ������� ������.");
        return false;
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public String doBack() {
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void delete() {
        try {
            directionDBLoader.delete(selectedItem.getId());
            UIMessages.displayMessage("������ �������.");
        } catch (Exception e) {
            UIMessages.displayErrorMessage("�� ������� ������� ������.");
            LogSimple.error(this, e);
        }
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return "editDirection?command=edit"
                +"&backPath="+getCurrentPath()
                +"&directionId="+ selectedItem.getId()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String add() {
        return "editDirection?command=add"
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public List<Direction> getItems() {
        return directionDBLoader.getAll();
    }

    public List<Direction> getFilteredRows() {
        return filteredRows;
    }

    public void setFilteredRows(List<Direction> filteredRows) {
        this.filteredRows = filteredRows;
    }

    public Direction getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(Direction selectedItem) {
        this.selectedItem = selectedItem;
    }
}
