package app.controllers;

import app.dto.Direction;
import app.loaders.CommonDbLoader;
import app.loaders.DirectionDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "directionsListController")
@ViewScoped
public class DirectionsListController extends AbstractTableControllerGeneric<Direction> {
    private static final String VIEW_NAME = "directionsList";
    @EJB
    private DirectionDBLoader directionDBLoader;

    protected CommonDbLoader getDbLoader() {
        return directionDBLoader;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCall(AbstractController caller){
        return doCall(VIEW_NAME, caller, null);
    }

    @Override
    protected String add() {
        return EditDirectionController.doCallAdd(this);
    }

    @Override
    protected String edit() {
        return EditDirectionController.doCallEditByRecordId(this, getSelectedItemSuper().getId());
    }

}
