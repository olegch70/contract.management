package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.dto.Client;
import app.dto.Direction;
import app.dto.Person;
import app.helpers.LogSimple;
import app.loaders.ClientsDBLoader;
import app.loaders.DirectionDBLoader;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.01.14
 * Time: 14:43
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editClientController")
@ViewScoped
public class EditClientController {

    @EJB
    ClientsDBLoader clientsDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    DirectionDBLoader directionDBLoader;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    private AuthorisedUserViewScoped authorisedUser;

    private Long clientId;
    private String backPath;
    private String command;
    private String conversationUuid;
    private Map parameters;
    private String localUuid;
    private Client client;

    public void initModel(){
        System.out.println("initModel() in editClientController started");
        initializeUuid();
        localUuid = getConversationUuid()+"_editClientController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("clientId", clientId);
            System.out.println("parameters.put(clientId = " + clientId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            if(command.equals("add")){
                client = new Client();
            } else {
                client = clientsDBLoader.getById(clientId);
            }
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            System.out.println("parameters clientId = " + parameters.get("clientId"));
            clientId = (Long) parameters.get("clientId");
            backPath = (String) parameters.get("backPath");
        }

        System.out.println("initModel() in editClientController finished");
    }

    public String save() {

        if(command.equals("add")){
            clientsDBLoader.addNew(client);
        } else {
            System.out.println("saveClient in add client called");
            clientsDBLoader.update(client);
            System.out.println("saveClient in edit client updated");
        }
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String doBack() {
        removeModelFromSession();
        System.out.println("backPath on doBack = " + backPath);
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public List<Person> getPersons() {
        final List<Person> result = personsDBLoader.getTechAM();
        if( ! authorisedUser.getCurrentUserIsRoot() ) {
            final List<Person> currentUserList = new ArrayList<Person>(1);
            currentUserList.add(personsDBLoader.getById(authorisedUser.getPerson().getId()));
            LogSimple.debug(this, "list TechAM => "+Arrays.toString(result.toArray()));
            LogSimple.debug(this, "list currentUser => "+Arrays.toString(currentUserList.toArray()));
            result.retainAll(currentUserList);
            LogSimple.debug(this, "list after retain => "+Arrays.toString(result.toArray()));
        }
        return result;
    }

    public List<Direction> getDirections() {
        return directionDBLoader.getAll();
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getClientId() {
        return clientId;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String getCommand() {
        return command;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }
}
