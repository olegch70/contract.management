package app.controllers;

import app.dto.Client;
import app.dto.Direction;
import app.dto.Person;
import app.helpers.LogSimple;
import app.loaders.ClientsDBLoader;
import app.loaders.CommonDbLoader;
import app.loaders.DirectionDBLoader;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.01.14
 * Time: 14:43
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editClientController")
@ViewScoped
public class EditClientController extends AbstractEditControllerGeneric<Client> {

    private static final String VIEW_NAME = "editClient";

    @EJB
    ClientsDBLoader clientsDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    DirectionDBLoader directionDBLoader;

    @Override
    protected Client createNewItem() {
        return new Client();
    }

    @Override
    protected CommonDbLoader<Client> getDbLoader() {
        return clientsDBLoader;
    }

    public static String doCallAdd(AbstractController caller){
        return doCallAdd(caller, VIEW_NAME);
    }
    public static String doCallEditByRecordId(AbstractController caller, Long id){
        return doCallEditByRecordId(caller, id, VIEW_NAME);
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public List<Person> getPersons() {
        final List<Person> result = personsDBLoader.getTechAM();
        if( ! authorisedUser.getCurrentUserIsRoot() ) {
            final List<Person> currentUserList = new ArrayList<Person>(1);
            currentUserList.add(personsDBLoader.getById(authorisedUser.getPerson().getId()));
            LogSimple.debug(this, "list TechAM => "+Arrays.toString(result.toArray()));
            LogSimple.debug(this, "list currentUser => "+Arrays.toString(currentUserList.toArray()));
            result.retainAll(currentUserList);
            LogSimple.debug(this, "list after retain => "+Arrays.toString(result.toArray()));
        }
        return result;
    }

    public List<Direction> getDirections() {
        return directionDBLoader.getAll();
    }

}
