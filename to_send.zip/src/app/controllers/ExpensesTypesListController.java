package app.controllers;

import app.dto.ExpenseType;
import app.loaders.CommonDbLoader;
import app.loaders.ExpenseTypeDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "expensesTypesListController")
@ViewScoped
public class ExpensesTypesListController extends AbstractTableControllerGeneric<ExpenseType> {
    private static final String VIEW_NAME = "expensesTypesList";
    @EJB
    private ExpenseTypeDBLoader expenseTypeDBLoader;

    @Override
    protected CommonDbLoader getDbLoader() {
        return expenseTypeDBLoader;
    }

    @Override
    public List<ExpenseType> getItems() {
        return expenseTypeDBLoader.getAll();
    }

    public static String doCall(AbstractController caller){
        return doCall(VIEW_NAME, caller);
    }

    @Override
    protected String add() {
        return EditExpenseTypeController.doCallAdd(this);
    }

    @Override
    protected String edit() {
        return EditExpenseTypeController.doCallEditByRecordId(this, getSelectedItemSuper().getId());
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }
}
