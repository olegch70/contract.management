package app.controllers;

import app.dto.Direction;
import app.dto.ExpenseType;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.loaders.DirectionDBLoader;
import app.loaders.ExpenseTypeDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "expensesTypesListController")
@ViewScoped
public class ExpensesTypesListController {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;

    @EJB
    private ExpenseTypeDBLoader expenseTypeDBLoader;

    private String backPath;
    private String localUuid;
    private String conversationUuid;
    private Map parameters;
    private List<ExpenseType> filteredRows;
    private ExpenseType selectedItem;

    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        localUuid = getConversationUuid()+"_expensesTypesListController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);

        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            filteredRows = (List) parameters.get("filteredRows");
            backPath = (String) parameters.get("backPath");
        }
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(selectedItem != null) {
            return true;
        }

        UIMessages.displayMessage("�������� ������� ������.");
        return false;
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public String doBack() {
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void delete() {
        try {
            expenseTypeDBLoader.delete(selectedItem.getId());
            UIMessages.displayMessage("������ �������.");
        } catch (Exception e) {
            UIMessages.displayErrorMessage("�� ������� ������� ������.");
            LogSimple.error(this, e);
        }
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return "editExpenseType?command=edit"
                +"&backPath="+getCurrentPath()
                +"&expenseTypeId="+ selectedItem.getId()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String add() {
        return "editExpenseType?command=add"
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public List<ExpenseType> getItems() {
        return expenseTypeDBLoader.getAll();
    }

    public List<ExpenseType> getFilteredRows() {
        return filteredRows;
    }

    public void setFilteredRows(List<ExpenseType> filteredRows) {
        this.filteredRows = filteredRows;
    }

    public ExpenseType getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(ExpenseType selectedItem) {
        this.selectedItem = selectedItem;
    }
}
