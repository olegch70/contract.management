package app.controllers;

import app.beans.IdentificableById;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.05.14
 * Time: 13:24
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractTableControllerGeneric<ItemClass extends IdentificableById> extends AbstractTableController {

    public List<ItemClass> getItems() {
        if(null != getDbLoader()) {
            return getDbLoader().getAll();
        }
        return null;
    }
}
