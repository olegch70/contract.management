package app.controllers;

import app.helpers.ViewNavigationHelper;

import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 23.05.14
 * Time: 10:23
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractEditController extends AbstractController {
    public static final String COMMAND_KEY = "command";
    public static final String COMMAND_ADD = "add";
    public static final String COMMAND_EDIT = "edit";

    protected String command;

    private static final String ITEM_ID_KEY = "itemId";
    protected Long itemId;


    @Override
    protected void childInitModel() {
        if(command == null) {
            super.childInitModel();
            itemId = (Long) parameters.get(ITEM_ID_KEY);
            command = (String) parameters.get(COMMAND_KEY);
            debug("childInitModel called. command => '" + command + "'");
            if (command.equals(COMMAND_ADD)) {
                childInitModelCommandAdd();
            } else {
                childInitModelCommandEdit();
            }
        }
    }

    protected void childInitModelCommandAdd() {}
    protected void childInitModelCommandEdit() {}


    protected static String doCallAdd(AbstractController caller, String viewName) {
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), viewName, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        return result;
    }

    protected static String doCallEditByRecordId(AbstractController caller, Long id, String viewName) {
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), viewName, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        paramModel[0].put(ITEM_ID_KEY, id);
        return result;
    }



}
