package app.controllers;

import app.beans.FormatterUtil;
import app.dto.Person;
import app.dto.TeamItem;
import app.helpers.TeamEditHelper;
import app.loaders.PersonsDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AbortProcessingException;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 16:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="addPersonInTeamController")
@ViewScoped
public class AddPersonInTeamController extends AbstractTableController {

    @EJB
    private PersonsDBLoader personsDBLoader;
    private static final String VIEW_NAME = "addPersonInTeam";
    private List<Person> persons;
    private List<Person> filteredRows;
    private Set<Long> addedPersons = new HashSet<Long>();
    private String legionnaireEndDate;
    private String percentLoad;
    private double dPercentLoad;
    private String legionnaireFIO;
    private BigDecimal clientMonthPrice;

    @Override
    public void childInitModel() throws AbortProcessingException {
        for(TeamItem teamItem : TeamEditHelper.getModel(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid) ) {
            addedPersons.add(teamItem.getPersonId());
        }
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCall(AbstractController caller){
        return doCall(VIEW_NAME, caller, null);
    }

    public void doShowInfoDialog(Long id) {
        personId_inInfoDialog = id;
        Person person = personsDBLoader.getById(personId_inInfoDialog);
        legionnaireFIO = person.getFIO();

        if(person.getMainProjectId() != null) {
            legionnaireEndDate = FormatterUtil.formatDateLong(person.getLegionnaireEndDate());
            dPercentLoad = person.getLegionnairePercentOffer();
        } else {
            dPercentLoad = 100;
            legionnaireEndDate = null;
        }
        percentLoad = FormatterUtil.formatDouble(dPercentLoad) + " %";
        RequestContext rc = RequestContext.getCurrentInstance();
        rc.execute("PF('dlgInfo').show()");
    }

    private Long personId_inInfoDialog;

    public void doAddCurrent(){
        doAdd(personId_inInfoDialog);
        personId_inInfoDialog = null;
        legionnaireEndDate = null;
        percentLoad = null;
        dPercentLoad = 0;
        legionnaireFIO = null;
        clientMonthPrice = null;
    }

    public void doAdd(Long id){
        addedPersons.add(id);
//        Person person = personsDBLoader.getById(id);
        Person person = personsDBLoader.getByIdDetached(id);
        TeamItem addTeamItemDto = new TeamItem();
        addTeamItemDto.setLoadPercent(dPercentLoad);
        addTeamItemDto.setClientMonthPrice(clientMonthPrice);
        boolean added = TeamEditHelper.addEmployeesInTeam(person, getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid,
                addTeamItemDto);

        if(! added ) {
            displayUIMessage("��������� ��� ������� � ������� �������.");
        }
        if(persons != null ) {
            Person personForRemove = new Person();
            personForRemove.setId(id);
            persons.remove(personForRemove);
        }
    }

    public List<Person> getPersons() {
        if(persons == null) {
            persons = personsDBLoader.getAllowedToIncludeIntoTeam();
        }
        return persons;
    }

    public void setFilteredRows(List<Person> filteredRows) {
        this.filteredRows = filteredRows;
    }

    public List<Person> getFilteredRows() {
        if(filteredRows == null) {
            filteredRows = getPersons();
        }
        return filteredRows;
    }

    public boolean notIncludedIntoTeam(Long id) {
        return ! addedPersons.contains(id);
    }

    public boolean showButton(Long id) {
        if(notIncludedIntoTeam(id)) {
            Person currentPerson = personsDBLoader.getById(id);
            if(currentPerson.getMainProject() != null) {
                if( ! currentPerson.isReadyForLegionnaire()) {
                    return false;
                }
            }
        } else {
            return false;
        }
        return true;
    }

    public String getLegionnaireEndDate() {
        return legionnaireEndDate;
    }

    public void setLegionnaireEndDate(String legionnaireEndDate) {
        this.legionnaireEndDate = legionnaireEndDate;
    }

    public String getPercentLoad() {
        return percentLoad;
    }

    public void setPercentLoad(String percentLoad) {
        this.percentLoad = percentLoad;
    }

    public BigDecimal getClientMonthPrice() {
        return clientMonthPrice;
    }

    public void setClientMonthPrice(BigDecimal clientMonthPrice) {
        this.clientMonthPrice = clientMonthPrice;
    }

    public boolean isClientMonthPriceRendered() {
        if(conversationUuid == null) {
            return false;
        } else {
            return TeamEditHelper.needShowClientMonthPrice(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid);
        }
    }


    public void setLegionnaireFIO(String legionnaireFIO) {
        this.legionnaireFIO = legionnaireFIO;
    }

    public String getLegionnaireFIO() {
        return legionnaireFIO;
    }

    public boolean isLegionnaire() {
        return legionnaireEndDate != null;
    }

    @Override
    protected void deleteInternal() {

    }
}
