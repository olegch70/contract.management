package app.controllers;

import app.beans.IdentificableById;
import app.helpers.ViewNavigationHelper;

import java.util.List;
import java.util.Map;

/**
 * Created by oleg on 01.08.2014.
 */
public abstract class AbstractEditProjectAddictedController<ItemClass extends IdentificableById>
        extends AbstractEditControllerGeneric<ItemClass> {
    protected static final String PROJECT_ID_KEY = "projectId";

    protected Long projectId;

//    public static void doProjectAddictedSetCallParameters(Map[] paramModel, Long projectId, String command, Long itemId) {
//        debugStatic("doProjectAddictedSetCallParameters. projectId => " + projectId);
//        paramModel[0].put(PROJECT_ID_KEY, projectId);
//        AbstractEditControllerGeneric.doAbstractEditControllerSetCallParameters(paramModel, command, itemId);
//    }
//
    @Override
    protected void childInitModel() {
        projectId = (Long) parameters.get(PROJECT_ID_KEY);
        debugStatic("childInitModel. projectId => "+ projectId);
        super.childInitModel();
    }

    protected void childInitModelCommandEdit() {
        debug("childInitModelCommandEdit called");
        super.childInitModelCommandEdit();
        if(item == null) {
            debug("childInitModelCommandEdit item == null - search in items linked to project");
            List<ItemClass> itemsList = getDbLoader().loadByLinkedId(PROJECT_ID_KEY, projectId);
            for (ItemClass row : itemsList) {
                if (row.getId().equals(itemId)) {
                    item = row;
                    break;
                }
            }
        }
    }

    protected static String doCallDetailPageForAdd(String viewName, AbstractController caller, Long projectId) {
        return doCallDetailPageForCommand(viewName, caller, null, projectId, COMMAND_ADD);
    }

    protected static String doCallDetailPageForEdit(String viewName, AbstractController caller, Long itemId, Long projectId) {
        return doCallDetailPageForCommand(viewName, caller, itemId, projectId, COMMAND_EDIT);
    }

    private static String doCallDetailPageForCommand(String viewName, AbstractController caller, Long itemId, Long projectId, String commandEdit) {
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), viewName, paramModel);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        AbstractEditControllerGeneric.doAbstractEditControllerSetCallParameters(paramModel, commandEdit, itemId);
        return result;
    }


}
