package app.controllers;

import app.dto.Position;
import app.helpers.ViewNavigationHelper;
import app.loaders.PositionDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 17:06
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editPositionController")
@ViewScoped
public class EditPositionController extends AbstractEditController {
    private static final String VIEW_NAME = "editPosition";
    public static final String POSITION_ID_KEY = "positionId";
    @EJB
    private PositionDBLoader positionDBLoader;
    private Position position;
    private Long positionId;

    public void childInitModel(){
        positionId = (Long) parameters.get(POSITION_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
            if(command.equals(COMMAND_ADD)){
                position = new Position();
            } else {
                position = positionDBLoader.getById(positionId);
            }
    }

    public static String doCallAdd(AbstractController caller){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long id){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(POSITION_ID_KEY, id);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        return result;
    }

    public String save() {
        if(command.equals(COMMAND_ADD)){
            positionDBLoader.addNew(position);
        } else {
            positionDBLoader.update(position);
        }
        return doBack();
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }
}
