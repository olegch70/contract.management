package app.controllers.report;

import app.beans.CurrentDateBean;
import app.beans.DateFormatter;
import app.controllers.AbstractReportController;
import app.controllers.system.PersonProjectsTimelineController;
import app.dto.Project;
import app.dto.report.ActivityPersonReport;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelperModel;
import app.loaders.ProjectsDBLoader;
import app.loaders.report.ActivityPersonReportDBLoader;
import app.report.dto.ReportDateFilter;
import app.salary.Extractor;
import app.salary.PersonSalaryDto;
import app.salary.SalaryModel;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name = "activityPersonsReportController")
@ViewScoped
public class ActivityPersonsReportController extends AbstractReportController {

    private static final String VIEW_NAME = "/reports/activityPersonsReport";
    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    ActivityPersonReportDBLoader activityPersonReportDBLoader;
    @EJB
    ProjectsDBLoader projectsDBLoader;
    @Inject
    DateFormatter dateFormatter;

    private List<ActivityPersonReport> reportItems;
    private ReportDateFilter reportDateFilter;
    private double mouseX;
    private double mouseY;
    private String order = activityPersonReportDBLoader.ORDER_PERSON;

    public List<ActivityPersonReport> getItems() {
        return reportItems;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public void doFilter() {
        LogSimple.debug(this, "doFilter executed");
        reportItems = activityPersonReportDBLoader.getReportData(reportDateFilter, order);
        StringBuilder sb = new StringBuilder();


        for(ActivityPersonReport item: reportItems) {
            sb.setLength(0);
            Date employmentDate = item.getPerson().getEmploymentDate();
            Date dismissalDate = item.getPerson().getDismissalDate();

            if(employmentDate != null || dismissalDate != null) {
                Date startDate = reportDateFilter.getStartDate();
                Date endDate = reportDateFilter.getEndDate();
                if(   employmentDate != null
                        && ! ( employmentDate.after(endDate)
                        || employmentDate.before(startDate)
                )
                        ) {
                    sb.append("�������� �  "+ dateFormatter.formatDate(employmentDate));
                }

                if(   dismissalDate != null
                        && ! ( dismissalDate.after(endDate)
                        || dismissalDate.before(startDate)
                )
                        ) {
                    if(sb.length() > 0) {
                        sb.append(", ");
                    }
                    sb.append("���� ���������� "+ dateFormatter.formatDate(dismissalDate));
                }
                if(sb.length() > 0) {
                    sb.insert(0, "( ");
                    sb.append(" )");
                }
                item.setComment(sb.toString());
            }
        }
    }

    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public static String doCall(ViewNavigationHelperModel viewNavigationHelperModel){
        String resultURL = doCall(VIEW_NAME, viewNavigationHelperModel);
        return resultURL;
    }

    private String infoMessageBody;
    public String getInfoMessageBody() {
        return infoMessageBody;
    }

    public void doShowInfoForProject(Long projectId) {
        Project project = projectsDBLoader.getById(projectId);
        StringBuilder sb = new StringBuilder();
        sb.append("������: <strong>").append(project.getClient().getName()).append("</strong>")
                .append("<br/>��� ����������: <strong>").append(project.getCode()).append("</strong>");
        if(project.getComment() != null) {
            String[] parts = project.getComment().split("\n");
            for (String part : parts) {
                if (part == null || part.isEmpty()) {
                    continue;
                }
                sb.append("<br/>").append(part);
            }
        }

        infoMessageBody = sb.toString() ;

        RequestContext.getCurrentInstance().execute("PF('infoMessage').show()");
    }

    public String doTimeLineShow(Long personId) {
        PersonProjectsTimelineController.doCall(conversationUuid, personId);
        return null;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getOrder() {
        return order;
    }
}
