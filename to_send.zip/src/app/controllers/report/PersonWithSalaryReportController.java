package app.controllers.report;

import app.beans.CurrentDateBean;
import app.beans.DateFormatter;
import app.controllers.AbstractReportController;
import app.dto.Person;
import app.dto.ProjectReport;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelperModel;
import app.loaders.PersonWithSalaryReportDBLoader;
import app.report.dto.ReportDateFilter;
import app.salary.Extractor;
import app.salary.PersonSalaryDto;
import app.salary.SalaryModel;
import org.primefaces.event.FileUploadEvent;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "personsWithSalaryReportController")
@ViewScoped
public class PersonWithSalaryReportController extends AbstractReportController {

    private static final String VIEW_NAME = "/reports/personsWithSalaryReport";
    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private PersonWithSalaryReportDBLoader personWithSalaryReportDBLoader;
    private List<PersonSalaryDto> reportItems;
    private ReportDateFilter reportDateFilter;
    private String fileName;
    private Extractor extractor;
    private SalaryModel salaryModel;
    private boolean showUploadDataColumn;
    private DateFormatter dateFormatter = new DateFormatter();
    private Date fileActualDate;

    public List<PersonSalaryDto> getItems() {
        return reportItems;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
//        return "PERSON_WITH_SALARY";
    }

    public void childInitModel() {
        fileActualDate = currentDateBean.getCurrentDate();
    }

    public void doFilter() {
        LogSimple.debug(this, "doFilter executed");
        reportItems = personWithSalaryReportDBLoader.getReportData(reportDateFilter);
    }

    public void handleFileUpload(FileUploadEvent event) {
        debug("handleFileUpload executed");
        debug("fileName =  "+ event.getFile().getFileName());
        FacesMessage msg = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");
        FacesContext.getCurrentInstance().addMessage(null, msg);
        fileName = event.getFile().getFileName();
        extractor = new Extractor();
        salaryModel = new SalaryModel();
        salaryModel.setPersonsSalary(new LinkedList<PersonSalaryDto>());
        try {
            InputStream is = event.getFile().getInputstream();
            try {
                extractor.fillModelFromInputStream(is, salaryModel);
            } finally {
                is.close();
            }
            List<PersonSalaryDto> persons = personWithSalaryReportDBLoader.getReportData(reportDateFilter);
            Map<String, Person> personsMap = new HashMap<String, Person>(persons.size());
            for(PersonSalaryDto row: persons) {
                personsMap.put(row.getPerson().getFIO(), row.getPerson());
            }
            for(PersonSalaryDto personSalaryDto: salaryModel.getPersonsSalary()) {
                Person curPerson = personsMap.get(personSalaryDto.getFIO());
                if(curPerson != null) {
                    personSalaryDto.setPerson(curPerson);
                    if(curPerson.getGrade().intValue() != personSalaryDto.getGrade()) {
                        personSalaryDto.addMessage("������ �� ���������");
                    }
                    personsMap.remove(curPerson.getFIO());
                } else {
                    personSalaryDto.addMessage("��������� �� ������ � ����");
                }
            }

            List<PersonSalaryDto> listNotExistsInFile = new LinkedList<PersonSalaryDto>();
            for(Person person: personsMap.values()) {
                if(person.getEmploymentDate() != null && person.getEmploymentDate().after(fileActualDate)) {
                    continue;
                }
                if(person.getDismissalDate() != null && person.getDismissalDate().before(fileActualDate)) {
                    continue;
                }
                PersonSalaryDto notFoundPerson = new PersonSalaryDto();
                notFoundPerson.setFIO(person.getFIO());
                notFoundPerson.setPerson(person);

                notFoundPerson.addMessage("��������� ����������� � �����."
                        + getNvlDateAsString(" ������ �� ������ ", person.getEmploymentDate(), ".")
                        + getNvlDateAsString(" ������ ", person.getDismissalDate(), ".")
                );
                listNotExistsInFile.add(notFoundPerson);
            }

            Map<String, PersonSalaryDto> sortByFIO = new TreeMap<String, PersonSalaryDto>();
            for (PersonSalaryDto item: listNotExistsInFile) {
                sortByFIO.put(item.getFIO(), item);
            }
            salaryModel.getPersonsSalary().addAll(sortByFIO.values());
            showUploadDataColumn = true;
            reportItems = salaryModel.getPersonsSalary();
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

    }

    private String getNvlDateAsString(String prefix, Date date, String suffix) {
        if(date == null) {
            return "";
        }
        return prefix + dateFormatter.formatDate(date) + suffix;
    }

    public boolean isShowColumn() {
        return showUploadDataColumn;
    }

    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public static String doCall(ViewNavigationHelperModel viewNavigationHelperModel){
        String resultURL = doCall(VIEW_NAME, viewNavigationHelperModel);
        return resultURL;
    }
}
