package app.controllers.report;

import app.beans.CurrentDateBean;
import app.controllers.AbstractReportController;
import app.dto.Person;
import app.dto.ProjectReport;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelperModel;
import app.loaders.PersonWithSalaryReportDBLoader;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.Calendar;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "personsWithSalaryReportController")
@ViewScoped
public class PersonWithSalaryReportController extends AbstractReportController {

    private static final String VIEW_NAME = "/reports/personsWithSalaryReport";
    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private PersonWithSalaryReportDBLoader personWithSalaryReportDBLoader;
    private List<Person> reportItems;
    private ReportDateFilter reportDateFilter;

    public List<Person> getItems() {
        return reportItems;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
//        return "PERSON_WITH_SALARY";
    }

    public void doFilter() {
        LogSimple.debug(this, "doFilter executed");
        List<ProjectReport> resultForClient;
        reportItems = personWithSalaryReportDBLoader.getReportData(reportDateFilter);
    }

    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public static String doCall(ViewNavigationHelperModel viewNavigationHelperModel){
        String resultURL = doCall(VIEW_NAME, viewNavigationHelperModel);
        return resultURL;
    }
}
