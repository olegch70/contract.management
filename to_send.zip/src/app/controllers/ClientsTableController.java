package app.controllers;

import app.beans.SelectedClientAccessor;
import app.dto.Client;
import app.helpers.ViewNavigationHelper;
import app.loaders.ClientsDBLoader;
import app.loaders.CommonDbLoader;
import app.loaders.ProjectsDBLoader;
import org.primefaces.event.SelectEvent;

import javax.ejb.EJB;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.List;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 14:19
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "clientsTableController")
@ViewScoped
public class ClientsTableController extends AbstractTableControllerGeneric<Client> {
    final static String VIEW_NAME = "clientsList";
    @EJB
    private ClientsDBLoader clientsDBLoader;
    @EJB
    private ProjectsDBLoader projectDBLoader;
    @ManagedProperty(value="#{selectedClientAccessor}")
    private SelectedClientAccessor selectedClientAccessor;

    protected CommonDbLoader getDbLoader() {
        return clientsDBLoader;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }


    @Override
    protected String add() {
        return EditClientController.doCallAdd(this);
    }

    @Override
    public String edit() {
        if( ! currentUserIsRoot() && ! currentUserIsTamInSelectedClient()) {
            displayUIMessage("���� ������ ��������� ��� ���� ����� ���������������.");
            return null;
        }
        return EditClientController.doCallEditByRecordId(this, getSelectedItemSuper().getId());
    }

    public List<Client> getClients() {
        List<Client> result = clientsDBLoader.getClientsForAuthorizedUser(authorisedUser.getPerson());

        clientsDBLoader.enrichModel(result);
        return result;
    }

    private boolean currentUserIsTamInSelectedClient() {
        return ((Client) getSelectedItemSuper()).getTechnicalAM().equals(getAuthorisedUser().getPerson().getId());
    }

    private boolean currentUserIsRoot() {
        return getAuthorisedUser().getCurrentUserIsRoot();
    }

    public String goToProjects() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        selectedClientAccessor.setSelectedClient(conversationUuid, (Client) getSelectedItemSuper());
        return ProjectsTableController.doCallByClientId(this, getSelectedItemSuper().getId());
    }

    public String doCallAndCreateUUID() {
        String conversationUuid = UUID.randomUUID().toString();
        return ViewNavigationHelper.prepareForCallAndGetURL(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid, VIEW_NAME);
    }

    @Override
    protected void beforeDoBack() {
        selectedClientAccessor.removeSelectedClient(conversationUuid);
    }

    @Override
    protected void afterDoBack() {
        conversationEnd();
    }

    public void onRowSelect(SelectEvent event) {
        FacesContext fc = FacesContext.getCurrentInstance();
        ConfigurableNavigationHandler nav = (ConfigurableNavigationHandler) fc.getApplication().getNavigationHandler();
        nav.performNavigation(goToProjects());
    }

    public SelectedClientAccessor getSelectedClientAccessor() {
        return selectedClientAccessor;
    }

    public void setSelectedClientAccessor(SelectedClientAccessor selectedClientAccessor) {
        this.selectedClientAccessor = selectedClientAccessor;
    }

}
