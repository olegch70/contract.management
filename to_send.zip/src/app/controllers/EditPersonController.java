package app.controllers;

import app.beans.CurrentDateBean;
import app.beans.DayPriceConverter;
import app.dto.Grade;
import app.dto.Person;
import app.dto.Position;
import app.helpers.ConstantsHelper;
import app.helpers.PersonFieldsCryptor;
import app.helpers.ViewNavigationHelper;
import app.loaders.ExpensesTeamDBLoader;
import app.loaders.GradeDBLoader;
import app.loaders.PersonsDBLoader;
import app.loaders.PositionDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 17:06
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editPersonController")
@ViewScoped
public class EditPersonController extends AbstractEditController {
    public static final String MSG_ON_ADD_USER_EXISTS = "������� � ���������� ������� ��� ����������";
    private static final String VIEW_NAME = "editPerson";
    public static final String PERSON_ID_KEY = "personId";
    @EJB
    private PersonsDBLoader personsDBLoader;
    @EJB
    private PositionDBLoader positionDBLoader;

    @EJB
    private ExpensesTeamDBLoader expensesTeamDBLoader;

    @EJB
    GradeDBLoader gradeDBLoader;

    @EJB
    private PersonFieldsCryptor personFieldsCryptor;

    @EJB
    private DayPriceConverter dayPriceConverter;

    @EJB
    private CurrentDateBean currentDateBean;

    private Long personId;
    private Person person;
    private boolean teamExpensesExists;
    private boolean dismissalDateAssigned;
    private List<Person> alternatePMList;

    public void childInitModel() {
        personId = (Long) parameters.get(PERSON_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        if(command.equals(COMMAND_ADD)){
            person = new Person();
            person.setOnSite(true);
        } else {
            person = personsDBLoader.getById(personId);
            dismissalDateAssigned = person.getDismissalDate() != null;
            Grade decryptedGrade = gradeDBLoader.getByCode(person.getGrade());
            if(decryptedGrade != null) {
                // ������� ���� �� ������ (��� ������� ������� ���� ��� 21 ������� ��� � ������)
                person.setDayPrice(decryptedGrade.getDayPrice());
            } else {
                person.setDayPrice(ConstantsHelper.BIGDECIMAL_GRADE_BIG);
            }
            teamExpensesExists = expensesTeamDBLoader.expensesExistsForPerson(personId);
        }
    }

    public List<Position> getPositions() {
        return positionDBLoader.getAll();
    }

    public static String doCallAdd(AbstractController caller){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long id){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(PERSON_ID_KEY, id);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        return result;
    }

    public String save() {
        Grade grade = gradeDBLoader.getByCode(person.getGrade());
        if(grade == null) {
            displayUIMessage("grade ���������� �� ������. ������� ���������� ��������");
            return null;
        }

        person.setLastName(person.getLastName().trim());
        person.setFirstName(person.getFirstName().trim());
        person.setMiddleName(person.getMiddleName().trim());

        if(command.equals(COMMAND_ADD)){
            if(isPersonFound(person)) {
                displayUIMessage(MSG_ON_ADD_USER_EXISTS);
                return null;
            } else {
                debug("save called. person.getDayPrice() => " + person.getDayPrice());
                person.setDayPrice(null);
                person.setGrade(null);
                personsDBLoader.addNew(person);
                debug("save called. person.getId() => " + person.getId());
            }
        } else {
            Person oldValues = personsDBLoader.getById(personId);
            person.setMainProject(oldValues.getMainProject());
            if( ! authorisedUser.getCurrentUserIsRoot() ) {
//                LogSimple.debug(this, "person.getGrade().longValue() => "+person.getGrade().longValue()
//                        +" oldValues.getGrade().longValue() => "+oldValues.getGrade().longValue()
//                        +" ConstantsHelper.GRADE_NO_GRADE.longValue() => "+ ConstantsHelper.GRADE_NO_GRADE.longValue());
//                logDebug("save called. 6");
                if(     person.getGrade().longValue() == ConstantsHelper.GRADE_NO_GRADE.longValue()
                        && person.getGrade().longValue() != oldValues.getGrade().longValue()
                        ) {
                    displayUIMessage("������ ������������� �������� ������ ���������� ������ " + ConstantsHelper.GRADE_NO_GRADE.longValue());
                    return null;
                }

//                if(     person.getDismissalDate() != null
//                    && ! person.getDismissalDate().equals(oldValues.getDismissalDate())
//                    && person.getDismissalDate().after(currentDateBean.getCurrentDate())
//                        ) {
//                    displayUIMessage("������ ������������� ���� ���������� ���������� � ������� ����.");
//                    return null;
//                }
            }
        }


        if(isSamePerson(person)) {
            person.setDayPrice(dayPriceConverter.convertPriceFrom21WorkDayToCalendarDay(grade.getDayPrice()));
            person.setGrade(new BigDecimal(grade.getCode()));
            personFieldsCryptor.encryptFields(person);

            person.setDayPrice(null);
            person.setGrade(null);
            personsDBLoader.updateFromUI(person);
        } else {
            displayUIMessage("���� ��������� ��� ���������������");
            return null;
        }
        return doBack();
    }

    private boolean isPersonFound(Person person) {
        boolean result;
        Person foundedPerson = personsDBLoader.getByFIO(person);
        if(foundedPerson == null) {
            result = false;
        } else {
            result = true;
        }
        return result;
    }

    private boolean isSamePerson(Person person) {
        boolean result = false;
        Person loadedPerson = personsDBLoader.getById(person.getId());
        if(loadedPerson.getId().equals(person.getId())) {
            if(loadedPerson.getFirstName().trim().equals(person.getFirstName().trim()) &&
                    loadedPerson.getLastName().trim().equals(person.getLastName().trim()) &&
                    loadedPerson.getMiddleName().trim().equals(person.getMiddleName().trim())) {
                result = true;
            } else {
                if( ! isPersonFound(person)){
                    result = true;
                }
            }
        }
        return result;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public boolean isAllowChangeEmploymentDate() {
        return ! teamExpensesExists;
    }

    public boolean isAllowChangeDismissalDate() {
        return ! dismissalDateAssigned || authorisedUser.getCurrentUserIsRoot();
    }

    public List<Person> getAlternatePMList() {
        return personsDBLoader.getPM();
    }
}
