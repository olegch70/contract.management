package app.controllers;

import app.beans.DayPriceConverter;
import app.dto.Grade;
import app.dto.Person;
import app.dto.Position;
import app.dto.User;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.loaders.GradeDBLoader;
import app.loaders.PersonsDBLoader;
import app.loaders.PositionDBLoader;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 17:06
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editPersonController")
@ViewScoped
public class EditPersonController {
    public static final String MSG_ON_ADD_USER_EXISTS = "������� � ���������� ������� ��� ����������";
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    @EJB
    private PersonsDBLoader personsDBLoader;
    @EJB
    private PositionDBLoader positionDBLoader;

    @EJB
    GradeDBLoader gradeDBLoader;

    @EJB
    private PersonFieldsCryptor personFieldsCryptor;

    @EJB
    private DayPriceConverter dayPriceConverter;

    private String backPath;
    private String command;
    private Long personId;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private Person person;
    private User user;


    public void initModel(){
        System.out.println("initModel() in editPersonController started");
        initializeUuid();
        localUuid = getConversationUuid()+"_editPersonController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("personId", personId);
            System.out.println("parameters.put(personId = " + personId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            if(command.equals("add")){
                person = new Person();
                person.setOnSite(true);
            } else {
                person = personsDBLoader.getById(personId);
                Grade decryptedGrade = gradeDBLoader.getByCode(person.getGrade());
                if(decryptedGrade != null) {
                    // ������� ���� �� ������ (��� ������� ������� ���� ��� 21 ������� ��� � ������)
                    person.setDayPrice(decryptedGrade.getDayPrice());
                } else {
                    person.setDayPrice(ConstantsHelper.BIGDECIMAL_GRADE_BIG);
                }
            }
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            System.out.println("parameters incomeId = " + parameters.get("incomeId"));
            personId = (Long) parameters.get("personId");
            backPath = (String) parameters.get("backPath");
        }

        System.out.println("initModel() in editPersonController finished");
    }

    public List<Position> getPositions() {
        return positionDBLoader.getAll();
    }

    public String save() {
        Grade grade = gradeDBLoader.getByCode(person.getGrade());
        if(grade == null) {
            addUserMessageInIU("grade ���������� �� ������. ������� ���������� ��������");
            return null;
        }

        person.setLastName(person.getLastName().trim());
        person.setFirstName(person.getFirstName().trim());
        person.setMiddleName(person.getMiddleName().trim());

//        person.setDayPrice(grade.getDayPrice());

        if(command.equals("add")){
            if(isPersonFound(person)) {
                addUserMessageInIU(MSG_ON_ADD_USER_EXISTS);
                return null;
            } else {
                logDebug("save called. person.getDayPrice() => " + person.getDayPrice());
//                BigDecimal savedDayPrice = person.getDayPrice();
                person.setDayPrice(null);
                person.setGrade(null);
                personsDBLoader.addNew(person);
//                person.setDayPrice(savedDayPrice);
                logDebug("save called. person.getId() => " + person.getId());
//            personsDBLoader.getById(person.getId());
//            personFieldsCryptor.encryptFields(person);
            }
        }
        if(isSamePerson(person)) {
            person.setDayPrice(dayPriceConverter.convertPriceFrom21WorkDayToCalendarDay(grade.getDayPrice()));
            person.setGrade(new BigDecimal(grade.getCode()));
            personFieldsCryptor.encryptFields(person);

            person.setDayPrice(null);
            person.setGrade(null);
            personsDBLoader.updateFromUI(person);
        } else {
            addUserMessageInIU("���� ��������� ��� ���������������");
            return null;
        }

        System.out.println("savePerson in edit Person updated");
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void addUserMessageInIU(String msgOnAddUserExists) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(msgOnAddUserExists));
    }

    private boolean isPersonFound(Person person) {
        boolean result;
        Person foundedPerson = personsDBLoader.getByFIO(person);
        if(foundedPerson == null) {
            result = false;
        } else {
            result = true;
        }
        return result;
    }

    private boolean isSamePerson(Person person) {
        boolean result = false;
        Person loadedPerson = personsDBLoader.getById(person.getId());
        if(loadedPerson.getId().equals(person.getId())) {
            if(loadedPerson.getFirstName().trim().equals(person.getFirstName().trim()) &&
               loadedPerson.getLastName().trim().equals(person.getLastName().trim()) &&
               loadedPerson.getMiddleName().trim().equals(person.getMiddleName().trim())) {
                result = true;
            } else {
                if( ! isPersonFound(person)){
                    result = true;
                }
            }
        }
        return result;
    }

    private void logDebug(String logMsg) {
        LogSimple.debug(this, logMsg);
    }

    public String doBack() {
        removeModelFromSession();
        System.out.println("backPath on doBack = " + backPath);
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }
}
