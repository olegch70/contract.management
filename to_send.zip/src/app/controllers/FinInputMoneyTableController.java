package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.SelectedProjectAccessor;
import app.dto.ContractStatus;
import app.dto.Project;
import app.dto.ProjectType;
import app.loaders.ContractStatusDBLoader;
import app.loaders.ProjectsDBLoader;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import java.security.InvalidParameterException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 14.03.14
 * Time: 12:28
 * To change this template use File | Settings | File Templates.
 */
//ToDo ������� ����������
@ManagedBean(name= "finInputMoneyTableController")
@ViewScoped
public class FinInputMoneyTableController {
    @EJB
    private ProjectsDBLoader projectsDBLoader;
    @EJB
    private ContractStatusDBLoader contractStatusDBLoader;
    @ManagedProperty(value="#{sessionDataHolder}")
    private SessionDataHolder sessionDataHolder;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{selectedProjectAccessor}")
    SelectedProjectAccessor selectedProjectAccessor;

    private String backPath;
    private String conversationUuid;
    private Map parameters;
    private String localUuid;
    private List<Project> projects;
    private boolean initialized;
    private String filterValue;
    private List<Project> filteredRows;
    private SelectItem[] statusOptions;
    private Project selectedProject;

    public void initModel() {
        initialized = true;
        initializeUuid();
        localUuid = getLocalUuid(conversationUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        createContractStatusOptionsForFilter();
        if(parameters == null) {
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            saveModelInSession();
        } else {
            backPath = (String) parameters.get("backPath");
            filteredRows = (List) parameters.get("filteredRows");
            filterValue = (String) parameters.get("filterValue");
        }
    }

    private void createContractStatusOptionsForFilter() {
        List<ContractStatus> csList = contractStatusDBLoader.getAll();
        String[] statuses = new String[csList.size()];
        for(int i = 0; i < csList.size(); i++) {
            statuses[i] = csList.get(i).getName();
        }
        statusOptions = createFilterOptions(statuses);
    }

    private static String getLocalUuid(String conversationUuid1) {
        return conversationUuid1 +"_finInputMoneyTableController";
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String uuid) {
        this.conversationUuid = uuid;
    }

    public Project getSelectedProject() {
        return selectedProject;
    }

    public void setSelectedProject(Project selectedProject) {
        this.selectedProject = selectedProject;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            conversationUuid = UUID.randomUUID().toString();
        }
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        return currentPath;
    }

    private String getViewNameByProjectTypeId(Long id) {
        if(ProjectType.FIX.getId().equals(id)) {
            return "editTradeFix";
        }
        if(ProjectType.FRAME.getId().equals(id)) {
            return "editTradeFrame";
        }
        if(ProjectType.OUTSTAFF.getId().equals(id)) {
            return "editTradeOutStaff";
        }
        if(ProjectType.PROJECT.getId().equals(id)) {
            return "editTradeProject";
        }
        if(ProjectType.PRESALE_A.getId().equals(id)) {
            return "editTradePresaleA";
        }
        if(ProjectType.PRESALE_B.getId().equals(id)) {
            return "editTradePresaleB";
        }
        throw new InvalidParameterException("Unknown project type id = " + id);
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(selectedProject != null) {
            return true;
        }

        displayUIMessage("�������� ������� ������.");
        return false;
    }

    public String goToDirectExpenses() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        return "projectDirectExpenses?projectId="+ selectedProject.getId()
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToIncome(){
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        return "projectIncome?projectId="+ selectedProject.getId()
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    private boolean isPaused() {
        return selectedProject.getStatusId().equals(ContractStatus.PAUSED.getId());
    }

    private boolean isClosed() {
        return selectedProject.getStatusId().equals(ContractStatus.CLOSED.getId());
    }

    public String doBack() {
        selectedProjectAccessor.removeSelectedProject(conversationUuid);
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void setFilterValue(String filterValue) {
        this.filterValue = filterValue;
        parameters.put("filterValue", this.filterValue);
    }

    public String getFilterValue() {
        return filterValue;
    }

    public void setFilteredRows(List<Project> filteredRows) {
        this.filteredRows = filteredRows;
        parameters.put("filteredRows", this.filteredRows);

    }

    public List<Project> getFilteredRows() {
        if(filteredRows == null) {
            filteredRows = getProjects();
        }
        return filteredRows;
    }

    private SelectItem[] createFilterOptions(String[] data)  {
        SelectItem[] options = new SelectItem[data.length + 2];

        options[0] = new SelectItem("", "���");
        options[1] = new SelectItem("��", "�� �������");
        for(int i = 0; i < data.length; i++) {
            options[i + 2] = new SelectItem(data[i], data[i]);
        }

        return options;
    }

    public SelectItem[] getStatusOptions() {
        return statusOptions;
    }

    private void getCurrentSelectedProjectForHeaderInfo() {
        selectedProjectAccessor.removeSelectedProject(conversationUuid);
        selectedProjectAccessor.setSelectedProject(conversationUuid, selectedProject);
    }

    private void saveModelInSession() {
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        sessionDataHolder.remove(localUuid);
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public SelectedProjectAccessor getSelectedProjectAccessor() {
        return selectedProjectAccessor;
    }

    public void setSelectedProjectAccessor(SelectedProjectAccessor selectedProjectAccessor) {
        this.selectedProjectAccessor = selectedProjectAccessor;
    }

    public List<Project> getProjects() {
        projects = projectsDBLoader.getNotClosedProjectsForFin(authorisedUser.getCurrentUserIsBuhReconciliation());
        return projects;
    }
}
