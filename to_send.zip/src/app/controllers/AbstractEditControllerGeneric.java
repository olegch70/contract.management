package app.controllers;

import app.beans.IdentificableById;
import app.loaders.CommonDbLoader;

import java.util.Map;

/**
 * Created by oleg on 01.08.2014.
 */
public abstract class AbstractEditControllerGeneric<ItemClass extends IdentificableById> extends AbstractEditController {
    protected static final String ITEM_ID_KEY = "itemId";

    protected Long itemId;
    protected ItemClass item;
    public ItemClass getItem() {
        return item;
    }

    @Override
    protected void childInitModel() {
        itemId = (Long) parameters.get(ITEM_ID_KEY);
        super.childInitModel();
    }

    @Override
    protected void childInitModelCommandAdd() {
        item = createNewItem();
    }

    @Override
    protected void childInitModelCommandEdit() {
        item = getDbLoader().getById(itemId);
    }

    protected abstract ItemClass createNewItem();

    public void setItem(ItemClass item) {
        debug("setItem called");
        this.item = item;
    }

    public String save() {
        boolean result = true;
        try {
            if (command.equals(COMMAND_ADD)) {
                result = checkBeforeSaveForAdd();
                if(result) {
                    saveForAdd();
                    return doBack();
                }
            } else {
                result = checkBeforeSaveForEdit();
                if(result) {
                    saveForEdit();
                    return doBack();
                }
            }
            return null;
        } catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

    protected boolean checkBeforeSaveForEdit() {
        return true;
    }

    protected boolean checkBeforeSaveForAdd() {
        return true;
    }

    protected void saveForEdit() {
        getDbLoader().update(item);
    }

    protected void saveForAdd() {
        getDbLoader().addNew(item);
    }

    protected abstract CommonDbLoader<ItemClass> getDbLoader();

    public static void doAbstractEditControllerSetCallParameters(Map[] paramModel, String command, Long itemId) {
        paramModel[0].put(COMMAND_KEY, command);
        if(command.equals(COMMAND_EDIT)) {
            assert( itemId != null );
            paramModel[0].put(ITEM_ID_KEY, itemId);
        }
    }
}
