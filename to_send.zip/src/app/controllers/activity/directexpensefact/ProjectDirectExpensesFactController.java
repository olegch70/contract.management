package app.controllers.activity.directexpensefact;

import app.controllers.AbstractController;
import app.controllers.AbstractTableController;
import app.dto.ExpenseDirectFact;
import app.loaders.directexpensefact.ExpensesDirectFactDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 18:30
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectDirectExpensesFactController")
@ViewScoped
public class ProjectDirectExpensesFactController extends AbstractTableController  {
    private static final String VIEW_NAME = "/activity/direct_expense_fact/list";
    @EJB
    private ExpensesDirectFactDBLoader expensesDirectFactDBLoader;

    private List<ExpenseDirectFact> items;
//    private String infoForDeletingRow;

    public String add() {
        return EditDirectExpenseFactController.doCallAdd(this, parentId);
    }

    public String edit() {
//        if( ! checkSelectedAndDisplayWarning()) {
//            return null;
//        }
        return EditDirectExpenseFactController.doCallEditByRecordId(this, parentId, getSelectedItem().getId());
    }

    @Override
    public void deleteInternal() {
        expensesDirectFactDBLoader.delete(getSelectedItem().getId());
    }

    private ExpenseDirectFact getSelectedItem() {
        return (ExpenseDirectFact) uiTableHelper.getSelectedItem();
    }

    public static String doCallByProjectId(AbstractController caller, Long projectId){
        String result = doCall(VIEW_NAME, caller, projectId);
        return result;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

//    public String getInfoForDeletingRow() {
//        return infoForDeletingRow;
//    }

//    private String getCurrentPath() {
//        FacesContext facesContext = FacesContext.getCurrentInstance();
//        String currentPath = facesContext.getViewRoot().getViewId();
//        System.out.println("currentPath = " + currentPath);
//        return currentPath;
//    }
//
    public List<ExpenseDirectFact> getItems() {
        if(items == null) {
            items = expensesDirectFactDBLoader.getListForAuthorizedUser(parentId, authorisedUser.getPerson());
        }
        return items;
    }

}
