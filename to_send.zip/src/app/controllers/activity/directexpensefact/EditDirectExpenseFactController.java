package app.controllers.activity.directexpensefact;

import app.controllers.AbstractController;
import app.controllers.AbstractEditController;
import app.dto.ExpenseDirectFact;
import app.dto.ExpenseType;
import app.dto.Person;
import app.helpers.ViewNavigationHelper;
import app.loaders.ExpenseTypeDBLoader;
import app.loaders.PersonsDBLoader;
import app.loaders.directexpensefact.ExpensesDirectFactDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editDirectExpenseFactController")
@ViewScoped
public class EditDirectExpenseFactController extends AbstractEditController {

    private static final String VIEW_NAME = "/activity/direct_expense_fact/edit";

    public static final String ITEM_ID_KEY = "itemId";
    public static final String PROJECT_ID_KEY = "projectId";

    @EJB
    private ExpensesDirectFactDBLoader itemDBLoader;
    @EJB
    private PersonsDBLoader personsDBLoader;
    @EJB
    private ExpenseTypeDBLoader expenseTypeDBLoader;

    private Long itemId;
    private boolean copyProjectTillEnd;
    private String command;
    private Long projectId;
    private Long initiatorPersonId;
    private Long expenseTypeId;
    private ExpenseDirectFact item;
    private List<Person> expInitiators;
    private List<ExpenseType> expenseTypes;

    public void childInitModel(){
        System.out.println("initModel() in EditProjectContractController started");
        itemId = (Long) parameters.get(ITEM_ID_KEY);
        projectId = (Long) parameters.get(PROJECT_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        expInitiators = personsDBLoader.getAll(new String[]{"lastName", "firstName", "middleName"});
        expenseTypes = expenseTypeDBLoader.getListForAuthorizedUser(authorisedUser.getPerson());
        if(command.equals(COMMAND_ADD)){
            item = new ExpenseDirectFact();
            item.setProjectId(projectId);
        } else {
            List<ExpenseDirectFact> expDirList = itemDBLoader.loadByLinkedId("projectId", projectId);
            for(ExpenseDirectFact row : expDirList)
            {
                if(row.getId().equals(itemId)){
                    item = row;
                    break;
                }
            }
            debug("expenseDirectFact = " + item);
        }
        if(item.getPerson() != null) {
            initiatorPersonId = item.getPerson().getId();
        }
        if(item.getExpenseType() != null) {
            expenseTypeId = item.getExpenseType().getId();
        }

        debug("initModel() finished");
    }

    public List<Person> getExpInitiators() {
        return expInitiators;
    }

    public static String doCallAdd(AbstractController caller, Long projectId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        paramModel[0].put(PROJECT_ID_KEY, projectId);return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long projectId, Long expenseId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(ITEM_ID_KEY, expenseId);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        paramModel[0].put(COMMAND_KEY, "edit");
        return result;
    }

    public String saveExpense() {
        debug("saveExpense in edit expenseDirectFact called");
        item.setPerson(personsDBLoader.getById(initiatorPersonId));
        item.setExpenseType(expenseTypeDBLoader.getById(expenseTypeId));
        if(command.equals(COMMAND_ADD)){
            itemDBLoader.addNew(item);
        } else {
            itemDBLoader.update(item);
            System.out.println("saveExpense in expenseDirectFact updated");
        }
        return doBack();
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public boolean isDestinationRendered() {
        return authorisedUser.getCurrentUserIsRoot();
    }

    public ExpenseDirectFact getItem() {
        return item;
    }

    public void setItem(ExpenseDirectFact value) {
        this.item = value;
    }

    public Long getInitiatorPersonId() {
        return initiatorPersonId;
    }

    public void setInitiatorPersonId(Long initiatorPersonId) {
        this.initiatorPersonId = initiatorPersonId;
    }

    public List<ExpenseType> getExpenseTypes() {
        return expenseTypes;
    }

    public void setExpenseTypes(List<ExpenseType> expenseTypes) {
        this.expenseTypes = expenseTypes;
    }

    public Long getExpenseTypeId() {
        return expenseTypeId;
    }

    public void setExpenseTypeId(Long expenseTypeId) {
        this.expenseTypeId = expenseTypeId;
    }

}
