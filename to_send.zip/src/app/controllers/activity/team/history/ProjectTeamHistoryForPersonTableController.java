package app.controllers.activity.team.history;

import app.controllers.AbstractController;
import app.controllers.AbstractTableController;
import app.dto.TeamItemHistory;
import app.loaders.ProjectTeamPersonsHistoryDBLoader;
import app.loaders.ProjectsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 14:19
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectTeamHistoryForPersonTableController")
@ViewScoped
public class ProjectTeamHistoryForPersonTableController extends AbstractTableController {
    @EJB
    private ProjectTeamPersonsHistoryDBLoader projectTeamPersonsHistoryDBLoader;
    @EJB
    private ProjectsDBLoader projectDBLoader;

    final static String VIEW_NAME = "/activity/team/history/personHistoryList";

    @Override
    protected void childInitModel() {
        getUiTableHelper().calledFromInit(parameters, projectTeamPersonsHistoryDBLoader);
    }

    private TeamItemHistory getSelectedItem() {
        return (TeamItemHistory) getSelectedItemSuper();
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public List<TeamItemHistory> getItems() {
        CallParameters callParams = (CallParameters) callParameters;
        if(callParameters != null) {
            List<TeamItemHistory> result = projectTeamPersonsHistoryDBLoader.getByProjectIdPersonId(callParams.projectId, callParams.personId);
            projectTeamPersonsHistoryDBLoader.enrichModel(result);

            return result;
        } else {
            return null;
        }
    }

    public static String doCall(AbstractController caller, Long projectId, Long personId){
        CallParameters callParameters = new CallParameters();
        callParameters.projectId = projectId;
        callParameters.personId = personId;
        return doCall(VIEW_NAME, caller, callParameters);
    }

    private static class CallParameters {
        Long projectId;
        Long personId;
    }

    @Override
    protected void deleteInternal() {
    }
}
