package app.controllers.activity.team.history;

import app.controllers.AbstractController;
import app.controllers.AbstractTableController;
import app.controllers.system.data.restore.RestorerProjectTeamPersonsHistory;
import app.dto.Person;
import app.loaders.ProjectTeamPersonsHistoryDBLoader;
import app.loaders.ProjectsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 14:19
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectTeamPersonsHistoryTableController")
@ViewScoped
public class ProjectTeamPersonsHistoryTableController extends AbstractTableController {
    @EJB
    private ProjectTeamPersonsHistoryDBLoader projectTeamPersonsHistoryDBLoader;
    @EJB
    private ProjectsDBLoader projectDBLoader;
    @EJB
    RestorerProjectTeamPersonsHistory restorerProjectTeamPersonsHistory;

    final static String VIEW_NAME = "/activity/team/history/personsList";

    @Override
    protected void childInitModel() {
        getUiTableHelper().calledFromInit(parameters, projectTeamPersonsHistoryDBLoader);
    }

    private Person getSelectedItem() {
        return (Person) getSelectedItemSuper();
    }

    @Override
    protected void deleteInternal() {
        throw new UnsupportedOperationException();
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public List<Person> getItems() {
        return projectTeamPersonsHistoryDBLoader.getPersons(parentId);
    }

    public static String doCallByProjectId(AbstractController caller, Long projectId){
        return doCall(VIEW_NAME, caller, projectId);
    }

    public String doShowHsitory() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        // uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return ProjectTeamHistoryForPersonTableController.doCall(this, parentId, getSelectedItem().getId());
    }

    public void doFillFromTeamExpenses() {
        debug("doFillFromTeamExpenses started");
        restorerProjectTeamPersonsHistory.restoreForProjectTeam(parentId);
        debug("doFillFromTeamExpenses finished");
    }
}
