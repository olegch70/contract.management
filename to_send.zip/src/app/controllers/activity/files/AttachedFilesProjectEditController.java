package app.controllers.activity.files;

import app.controllers.AbstractController;
import app.controllers.AbstractEditProjectAddictedController;
import app.dto.AttachedFileProject;
import app.loaders.AttachedFileProjectDBLoader;
import app.loaders.CommonDbLoader;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.sql.SQLException;
import java.util.Date;

/**
 * Created by oleg on 01.08.2014.
 */
@ManagedBean(name= "editAttachedFilesProjectController")
@ViewScoped
public class AttachedFilesProjectEditController extends AbstractEditProjectAddictedController<AttachedFileProject> {
    private static final String VIEW_NAME = "/activity/files/edit";

    @EJB
    private AttachedFileProjectDBLoader itemDBLoader;

    @Override
    protected CommonDbLoader<AttachedFileProject> getDbLoader() {
        return itemDBLoader;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCallAdd(AbstractController caller, Long projectId){
        return AbstractEditProjectAddictedController.doCallDetailPageForAdd(VIEW_NAME, caller, projectId);
    }

    public static String doCallEditByRecordId(AbstractController caller, Long projectId, Long itemId){
        return AbstractEditProjectAddictedController.doCallDetailPageForEdit(VIEW_NAME, caller, itemId, projectId);
    }

    @Override
    protected AttachedFileProject createNewItem() {
        AttachedFileProject result = new AttachedFileProject();
        result.setProjectId(projectId);
        return result;
    }

    public void handleFileUpload(FileUploadEvent event) throws SQLException {
        UploadedFile uploadedFile = event.getFile();
        byte[] uploadedFileContents = uploadedFile.getContents();
        item.setContent(uploadedFileContents);
        item.setContentLengthByte(uploadedFileContents.length);

        String uploadedFileName = uploadedFile.getFileName();
        item.setFileName(uploadedFileName);
        debug("1. item.fileName => " + item.getFileName() + " uploadedFileName => " + uploadedFileName);

        item.setDateModification(new Date());
        debug("2. item.fileName => " + item.getFileName() + " uploadedFileName => " + uploadedFileName);
    }

    @Override
    protected boolean checkBeforeSaveForEdit() {
        return checkAssignedFile();
    }

    @Override
    protected boolean checkBeforeSaveForAdd() {
        return checkAssignedFile();
    }

    private boolean checkAssignedFile() {
        if(item.getFileName() == null || item.getFileName().isEmpty()) {
            displayUIMessage("�������� ���� ��� ��������.");
            return false;
        }
        return true;
    }

}
