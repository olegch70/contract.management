package app.controllers.activity.files;

import app.controllers.AbstractController;
import app.controllers.AbstractTableController;
import app.dto.AttachedFileProject;
import app.loaders.AttachedFileProjectDBLoader;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by oleg on 30.07.2014.
 */
@ManagedBean(name= "attachedFilesProjectListController")
@ViewScoped
public class AttachedFilesProjectListController extends AbstractTableController {

    private static final String VIEW_NAME = "/activity/files/list";

    @EJB
    private AttachedFileProjectDBLoader activityAttachedFilesDBLoader;

    public static String doCallByProjectId(AbstractController caller, Long projectId){
        return doCall(VIEW_NAME, caller, projectId);
    }

    public String add() {
        return AttachedFilesProjectEditController.doCallAdd(this, parentId);
    }

    @Override
    protected String edit() {
        return AttachedFilesProjectEditController.doCallEditByRecordId(this, parentId, getSelectedItem().getId());
    }

    private AttachedFileProject getSelectedItem() {
        return (AttachedFileProject) getSelectedItemSuper();
    }

    @Override
    protected void deleteInternal() {
        activityAttachedFilesDBLoader.delete(getSelectedItem().getId());
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public List<AttachedFileProject> getItems() {
        return activityAttachedFilesDBLoader.loadByFieldValue("projectId", parentId, new String[]{"fileName"});
    }

    public boolean isAllowModify() {
        if( ! authorisedUser.isAllowModify()) {
            return false;
        }
        return true;
    }

    public StreamedContent doAttachedFileDownload(Long itemId) throws SQLException {
        AttachedFileProject attachedFileProject = activityAttachedFilesDBLoader.getById(itemId);
        InputStream stream = new ByteArrayInputStream(attachedFileProject.getContent());
        return new DefaultStreamedContent(stream, "application/octet-stream", attachedFileProject.getFileName());
    }
}
