package app.controllers.utils;

import app.dto.ExportMode;
import app.helpers.LogSimple;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.xssf.usermodel.*;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.05.14
 * Time: 11:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "tableExportController")
@ViewScoped
public class TableExportController {
    public static final char THOUSAND_SEPARATOR = 0xA0;
    private boolean currentExportMode;
    private List<ExportMode> exportModeList;

    public boolean getCurrentExportMode() {
        return currentExportMode;
    }

    public void setCurrentExportMode(boolean currentExportMode) {
        this.currentExportMode = currentExportMode;
    }

//    public boolean isCurrentPageExportMode() {
//        return currentExportMode;
//    }

    public void postProcessXLS(Object document) {
        XSSFWorkbook wb = (XSSFWorkbook) document;
        XSSFSheet sheet = wb.getSheetAt(0);
        XSSFRow header = null;

        XSSFCellStyle cellStyleWODecimal = wb.createCellStyle();
        cellStyleWODecimal.setDataFormat(HSSFDataFormat.getBuiltinFormat("#,##0"));

        XSSFCellStyle cellStyleWithDecimal = wb.createCellStyle();
        cellStyleWithDecimal.setDataFormat(HSSFDataFormat.getBuiltinFormat("#,##0.0"));

        final int[] numberOfFractionPart = new int[1];
        for(int i=0; i <= sheet.getPhysicalNumberOfRows();i++) {
            header = sheet.getRow(i);

            if(header != null) {
                for(int j=0; j <= header.getPhysicalNumberOfCells();j++) {
                    XSSFCell cell = header.getCell(j);
                    if(cell != null) {
                        cell.getStringCellValue();
                        cell.toString();
//                        debug("cell[ row = " + i + " col = " + j + " ] .getStringCellValue() = " +
//                                cell.getStringCellValue() + " toString = " + cell.toString());
                        //1234.34
                        //1234,34
                        //1 234

                        Double cellDoubleValue = getDoubleValue(cell.getStringCellValue(), numberOfFractionPart);
                        if(cellDoubleValue != null) {
                            cell.setCellValue(cellDoubleValue);
                            if(numberOfFractionPart[0] > 0) {
                                cell.setCellStyle(cellStyleWithDecimal);
                            } else {
                                cell.setCellStyle(cellStyleWODecimal);
                            }
                        }
                    }
                }
            }
        }
    }

    public Double getDoubleValue(String stringCellValue, int[] numberOfFractionalPart) {
        //byte[] byteString = stringCellValue.getBytes();
        int decimalSeparatorCnt = 0;
        int decimalSeparatorFirstPosition = -1;
        int numberFirstPosition = -1;
        int minusPosition = -1;
        numberOfFractionalPart[0] = 0;
        for(int i=0;i < stringCellValue.length();i++) {
            char b = stringCellValue.charAt(i);
            if(b >= '0' && b <= '9') {
                if(numberFirstPosition == -1) {
                    numberFirstPosition = i;
                }
                if(decimalSeparatorFirstPosition != -1) {
                    numberOfFractionalPart[0]++;
                }
            } else if(b == ',' || b == '.') {
                if(decimalSeparatorFirstPosition == -1) {
                    decimalSeparatorFirstPosition = i;
                }
                decimalSeparatorCnt++;
            } else if(b == ' ' || b == THOUSAND_SEPARATOR) {

            } else if(b == '-') {
                minusPosition = i;
            } else {
                return null;
            }
        }
        if(decimalSeparatorCnt > 1) {
            return null;
        }
        if(minusPosition > numberFirstPosition || minusPosition > decimalSeparatorFirstPosition) {
            return null;
        }
        String result = stringCellValue.replaceAll(",", ".").replaceAll(" ", "").replaceAll(new String(new char[]{THOUSAND_SEPARATOR}), "");
        try {
            return Double.parseDouble(result);
        } catch (Exception e) {
            debug("error parse double " + result);
            LogSimple.error(this, e);
        }
        return null;

    }

    private void debug(String msg) {
        LogSimple.debug(this, msg);
    }

    public List<ExportMode> getExportModeList() {
        if(exportModeList == null) {
            exportModeList = new LinkedList<ExportMode>();
            exportModeList.add(new ExportMode(ExportMode.WHOLE_TABLE.getName(), false));
            exportModeList.add(new ExportMode(ExportMode.CURRENT_PAGE.getName(), true));
        }
        return exportModeList;
    }

    public void setExportModeList(List<ExportMode> exportModeList) {
        this.exportModeList = exportModeList;
    }

}
