package app.controllers.utils;

import app.beans.IdentificableById;
import app.helpers.LogSimple;
import app.loaders.CommonDbLoader;

import java.util.*;

/**
 * author: Oleg Chamlay
 * Date: 06.05.14
 * Time: 16:33
 */
public class DataTableUIValuesHolder<DtoClass extends IdentificableById> {

    private ValuesHolder valuesHolder;

    private Integer paginatorRowsInPage = new Integer(15);
    private String rowsPerPageTemplate = "5,10,15,30,40,60";
    private String emptyMessage = "������� � ���������� ����������� �� ����������";
    private String paginatorTemplate = "{CurrentPageReport}  {FirstPageLink} {PreviousPageLink} {PageLinks} {NextPageLink} {LastPageLink} {RowsPerPageDropdown}";

    public class ValuesHolder {
        private Integer firstPage;
        private List<DtoClass> filteredRows;
        private DtoClass selectedItem;
        private List<DtoClass> itemsToRefresh;

        private Map<String, Object> filterFieldValues;

        public Map<String, Object> getFilterFieldValues() {
            if(filterFieldValues == null) {
                filterFieldValues = new HashMap<String, Object>();
            }
            return filterFieldValues;
        }

        public void setFilterFieldValues(Map<String, Object> filterFieldValues) {
            this.filterFieldValues = filterFieldValues;
        }
    }

    public ValuesHolder getValuesHolder() {
        if(valuesHolder == null) {
            valuesHolder = new ValuesHolder();
        }
        return valuesHolder;
    }

    public void setValuesHolder(ValuesHolder valuesHolder) {
        this.valuesHolder = valuesHolder;
    }

    private ItemLoaderFromDb<DtoClass> itemLoaderFromDb;

    public DtoClass getSelectedItem() {
        return getValuesHolder().selectedItem;
    }

    public void setSelectedItem(DtoClass selectedItem) {
        getValuesHolder().selectedItem = selectedItem;
    }

    public String getPaginatorTemplate() {
        return paginatorTemplate;
    }

    public void setPaginatorTemplate(String paginatorTemplate) {
        this.paginatorTemplate = paginatorTemplate;
    }

    public String getEmptyMessage() {
        return emptyMessage;
    }

    public void setEmptyMessage(String emptyMessage) {
        this.emptyMessage = emptyMessage;
    }

    public String getRowsPerPageTemplate() {
        return rowsPerPageTemplate;
    }

    public void setRowsPerPageTemplate(String rowsPerPageTemplate) {
        this.rowsPerPageTemplate = rowsPerPageTemplate;
    }

    public void setFilteredRows(List<DtoClass> filteredRows) {
        getValuesHolder().filteredRows = filteredRows;
    }

    public List<DtoClass> getFilteredRows() {
        return getValuesHolder().filteredRows;
    }

    public void setFirstPage(Integer firstPage) {
        getValuesHolder().firstPage = firstPage;
    }

    public Integer getFirstPage() {
        return getValuesHolder().firstPage != null ? getValuesHolder().firstPage: new Integer(0);
    }

    public Integer getPaginatorRowsInPage() {
        return paginatorRowsInPage;
    }

    public void setPaginatorRowsInPage(Integer paginatorRowsInPage) {
        this.paginatorRowsInPage = paginatorRowsInPage;
    }

    public void deleteItemFromFiltered(DtoClass item) {
        if(getValuesHolder().filteredRows != null) {
            getValuesHolder().filteredRows.remove(item);
        }
    }

    public void registerItemForRefreshItemInFuture(DtoClass item) {
        if(getValuesHolder().itemsToRefresh == null) {
            getValuesHolder().itemsToRefresh = new LinkedList<DtoClass>();
        }
        getValuesHolder().itemsToRefresh.add(item);
    }

    public List<DtoClass> getItemsToRefresh() {
        return getValuesHolder().itemsToRefresh;
    }

    public void clearItemsToRefresh() {
        getValuesHolder().itemsToRefresh = null;
    }

//    public List<DtoClass> processItemsToRefresh() {
//        return processItemsToRefresh(itemLoaderFromDb);
//    }

    public void processItemsToRefresh(final CommonDbLoader<DtoClass> loader) {
        if(getItemsToRefresh() != null) {
            final List<DtoClass> itemsToRefresh = processItemsToRefresh(new DataTableUIValuesHolder.ItemLoaderFromDb<DtoClass>() {
                @Override
                public DtoClass loadFromDb(DtoClass item) {
                    try {
                        DtoClass itemById = loader.getById(item.getId());
                        return itemById;
                    } catch (Throwable t) {
                        LogSimple.debug(this, "loaderClass => "+loader.getClass().getName()+ ", itemClass => "+item.getClass().getName()+", id => "+item.getId()+", exception message => "+ t.getMessage());
                        throw new RuntimeException(t);
                    }
                }
            });

            loader.enrichModel(itemsToRefresh);
            clearItemsToRefresh();
        }

    }

    private List<DtoClass> processItemsToRefresh(ItemLoaderFromDb<DtoClass> itemLoaderFromDb) {
        boolean needUpdateSelectedItem = false;
        if(getSelectedItem() != null) {
            needUpdateSelectedItem = true;
        }
        //log("needUpdateSelectedItem => "+needUpdateSelectedItem+", selected item "+getSelectedItem());
        Map<Long, DtoClass> itemsToRefresh = new HashMap<Long, DtoClass>(getItemsToRefresh().size());

        for(DtoClass item : getItemsToRefresh()) {
            DtoClass freshItem = itemLoaderFromDb.loadFromDb(item);
            itemsToRefresh.put(freshItem.getId(), freshItem);
            if(needUpdateSelectedItem) {
                if(getSelectedItem().getId().equals(freshItem.getId())) {
                    setSelectedItem(freshItem);
                    needUpdateSelectedItem = false;
                }
            }
        }

        if(itemsToRefresh.size() > 0 && getValuesHolder().filteredRows != null) {
            ArrayList<DtoClass> _filteredRows = new ArrayList<DtoClass>(getValuesHolder().filteredRows.size());

            for(DtoClass item: getValuesHolder().filteredRows) {
                DtoClass itemsForAdd = itemsToRefresh.get(item.getId());
                if(itemsForAdd == null) {
                    itemsForAdd = item;
                }
                _filteredRows.add(itemsForAdd);
            }
            getValuesHolder().filteredRows.clear();
            getValuesHolder().filteredRows.addAll(_filteredRows);
        }

        List<DtoClass> result = new ArrayList<DtoClass>(itemsToRefresh.size());
        result.addAll(itemsToRefresh.values());
        return result;
    }

    public void setItemLoaderFromDb(ItemLoaderFromDb<DtoClass> itemLoaderFromDb) {
        this.itemLoaderFromDb = itemLoaderFromDb;
    }

    private void log(String s) {
        LogSimple.debug(this, s);
    }

    // --------------------------------
    public class FilterValue {
        private final String fieldName;
        private String value;

        public FilterValue(String fieldName) {
            this.fieldName = fieldName;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    public interface ItemLoaderFromDb<ItemClass> {
        ItemClass loadFromDb(ItemClass item);
    }
}
