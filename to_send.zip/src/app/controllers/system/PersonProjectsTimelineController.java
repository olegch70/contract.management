package app.controllers.system;

import app.beans.SelectedPersonAccessor;
import app.controllers.datamodel.TimeLineTeamExpense;
import app.dto.ExpenseTeam;
import app.dto.Person;
import app.dto.Project;
import app.helpers.LogSimple;
import app.loaders.ExpensesTeamDBLoader;
import app.loaders.PersonsDBLoader;
import app.loaders.ProjectsDBLoader;
import org.primefaces.context.RequestContext;
import org.primefaces.extensions.model.timeline.TimelineEvent;
import org.primefaces.extensions.model.timeline.TimelineModel;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * author: Oleg Chamlay
 * Date: 26.03.14
 * Time: 12:43
 */
@ManagedBean(name= "personProjectsTimelineController")
@ViewScoped
public class PersonProjectsTimelineController {

    private TimelineModel model;
    private String backPath;
    private String conversationUuid;
    private Long personId;

    @EJB
    ProjectsDBLoader projectsDBLoader;

    @EJB
    ExpensesTeamDBLoader expensesTeamDBLoader;

    @EJB
    PersonsDBLoader personsDBLoader;

    @ManagedProperty(value="#{selectedPersonAccessor}")
    private SelectedPersonAccessor selectedPersonAccessor;

    public void initModel() {
        model = readModel();
    }

    public void setModel(TimelineModel model) {
        this.model = model;
    }

    public TimelineModel getModel() {
        return model;
    }

    private TimelineModel readModel() {
        Calendar calendar = Calendar.getInstance();
        TimelineModel result = new TimelineModel();
        Person person = personsDBLoader.getById(personId);
        selectedPersonAccessor.setSelected(conversationUuid, person);

        List<ExpenseTeam> expenses = expensesTeamDBLoader.loadByFieldValue("personId", personId,
                new String[]{"projectId", "dateExp", "loadPercent"});
        debug("person = " + person.getFIO());
        debug("expenses = " + expenses.size());
        if(expenses.size() < 1) {
            return result;
        }
        Iterator<ExpenseTeam> iterator = expenses.iterator();
        ExpenseTeam expense = iterator.next();
        while(expense != null) {

            final long projectId = expense.getProjectId();
            debug(" start personId => " + personId);

            while(    expense != null
                   && projectId == expense.getProjectId().longValue()
                    ) {
                TimeLineTeamExpense data = new TimeLineTeamExpense();
                Date fromDate = expense.getDateExp();
                Date toDate = fromDate;
                calendar.setTime(fromDate);
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);

                calendar.add(Calendar.DAY_OF_MONTH, 1);

                Date nextDate = calendar.getTime();
                double currentLoadPercent = expense.getLoadPercent().doubleValue();
                data.setCaption(String.format("%1$.0f", expense.getLoadPercent())+" %");
                debug(" fromDate => " + fromDate);
                debug(" currentLoadPercent => "+currentLoadPercent);
                debug(" data.caption => " + data.getCaption());
                Date toDatePrev = toDate;
                while(    expense != null
                        && currentLoadPercent == expense.getLoadPercent().doubleValue()
                        && projectId == expense.getProjectId().longValue()
                        && nextDate.after(expense.getDateExp())
                        ) {
                    toDatePrev = toDate;
                    if(iterator.hasNext()) {
                        expense = iterator.next();
                        if(projectId == expense.getProjectId().longValue()) {
                            toDate = expense.getDateExp();
                            calendar.add(Calendar.DAY_OF_MONTH, 1);
                            nextDate = calendar.getTime();
                        }
                    } else {
                        expense = null;
                    }
                }
                calendar.setTime(toDatePrev);
                if( expense != null && projectId == expense.getProjectId().longValue()) {
                    // ��������� �������
                    calendar.set(Calendar.HOUR_OF_DAY, 22);
                    calendar.set(Calendar.MINUTE, 0);
                    calendar.set(Calendar.SECOND, 0);
                    calendar.set(Calendar.MILLISECOND, 0);
                } else {
                    // ��������� ������
                    calendar.set(Calendar.HOUR_OF_DAY, 23);
                    calendar.set(Calendar.MINUTE, 59);
                    calendar.set(Calendar.SECOND, 50);
                    calendar.set(Calendar.MILLISECOND, 0);
                }
                toDate = calendar.getTime();

                result.add(new TimelineEvent(data, fromDate, toDate, false, getProjectCaption(projectId)));
                debug(" result.add(new TimelineEvent("+data.getCaption()+", "+fromDate+", "+toDate+", false, "+ getProjectCaption(projectId)+"))");
            }

        }

        return result;
    }

    public String getProjectCaption(Long projectId) {
        Project project = projectsDBLoader.getById(projectId);
        String result = project.getClient().getName() + " / " + project.getCode();
        return result;
    }

    private static String safeToString(Object obj) {
        return obj == null ? "" : obj.toString();
    }

    public void closeWindow(ActionEvent event) {
  //      selectedPersonAccessor.removeSelected(conversationUuid);
        RequestContext.getCurrentInstance().execute("window.close();");
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public SelectedPersonAccessor getSelectedPersonAccessor() {
        return selectedPersonAccessor;
    }

    public void setSelectedPersonAccessor(SelectedPersonAccessor selectedPersonAccessor) {
        this.selectedPersonAccessor = selectedPersonAccessor;
    }

    public static void doCall(String conversationUuid, Long personId) {
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        String basePath = "";
        try {
            basePath = new URL(request.getScheme(),
                    request.getServerName(),
                    request.getServerPort(),
                    request.getContextPath()).toString();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        if( ! basePath.endsWith("/")) {
            basePath += "/";
        }

        final String result = basePath+"system/timeLinePersonPage.jsf?personId=" + personId
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        RequestContext.getCurrentInstance().execute("window.open('" + result + "')");
    }
}
