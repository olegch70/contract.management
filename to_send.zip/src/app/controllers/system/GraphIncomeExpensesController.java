package app.controllers.system;

import app.beans.CurrentDateBean;
import app.controllers.datamodel.TimeLineTeamExpense;
import app.dto.ExpenseTeam;
import app.dto.Person;
import app.dto.Project;
import app.helpers.ClientKoeffs;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.loaders.ExpensesTeamDBLoader;
import app.loaders.PersonsDBLoader;
import app.loaders.ProjectsDBLoader;
import org.primefaces.model.chart.CartesianChartModel;
import org.primefaces.model.chart.ChartSeries;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.math.BigDecimal;
import java.util.*;

/**
 * author: Oleg Chamlay
 * Date: 26.03.14
 * Time: 12:43
 */
@ManagedBean(name= "graphIncomeExpensesController")
@ViewScoped
public class GraphIncomeExpensesController {

    private CartesianChartModel modelFact;
    private CartesianChartModel modelPlan;
    private String backPath;
    private String conversationUuid;
    private Long projectId;

    @EJB
    ProjectsDBLoader projectsDBLoader;

    @EJB
    ExpensesTeamDBLoader expensesTeamDBLoader;

    @EJB
    PersonsDBLoader personsDBLoader;

    @EJB
    private PersonFieldsCryptor personFieldsCryptor;

    @EJB
    CurrentDateBean currentDateBean;
    private Double maxY;

    public void initModel() {
        readModel();
    }

//    public void setModel(TimelineModel modelFact) {
//        this.modelFact = modelFact;
//    }

    public CartesianChartModel getModelFact() {
        return modelFact;
    }

    public CartesianChartModel getModelPlan() {
        return modelPlan;
    }

    public void setModelFact(CartesianChartModel modelFact) {
        this.modelFact = modelFact;
    }

    public void setModelPlan(CartesianChartModel modelPlan) {
        this.modelPlan = modelPlan;
    }

    private void readModel() {
        debug("readModel");
        modelFact = new CartesianChartModel();
        modelPlan = new CartesianChartModel();
        TimeLineTeamExpense data = new TimeLineTeamExpense();
        Project project = projectsDBLoader.getById(projectId);

        // ��������������� ��������� ������� - �������� �� % ��������� � �������
        double contractPercent = ClientKoeffs.getContractKoeff(project.getClient());
        project.setPrice(project.getPrice().multiply(new BigDecimal(contractPercent)));

        data.setCaption("");

        class DataHolder {
            Date date;
            double teamExpenses;
            double directExpenses;
            double directIncome;
        };

        TreeMap<Date, DataHolder> expensesByDate = new TreeMap<Date, DataHolder>(new Comparator<Date>() {
            @Override
            public int compare(Date o1, Date o2) {
                return o1.compareTo(o2);
            }
        });

        {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(project.getStartDate());
            while(true) {
                Date curDate = calendar.getTime();
                if(curDate.after(project.getEndDatePlan())) {
                    break;
                }
                expensesByDate.put(curDate, new DataHolder());
                calendar.add(Calendar.DAY_OF_MONTH, 1);
            }
        }

        {
            List<ExpenseTeam> expensesTeam = expensesTeamDBLoader.loadByFieldValue("projectId", projectId,
                    new String[]{"dateExp"});
            Person tmpPerson = new Person();
            double accumulatedValue = 0;
            Iterator<Map.Entry<Date, DataHolder>> dataHolderIterator = expensesByDate.entrySet().iterator();
            Map.Entry<Date, DataHolder> dataHolderItem = dataHolderIterator.next();

            for(ExpenseTeam listItem : expensesTeam) {

                while( listItem.getDateExp().after(dataHolderItem.getKey())) {
                    dataHolderItem.getValue().teamExpenses = accumulatedValue;
                    dataHolderItem = dataHolderIterator.next();
                }

                tmpPerson.setId(listItem.getPersonId());
                tmpPerson.setDayPrice2(listItem.getPrice2());
                personFieldsCryptor.decryptDayPrice(tmpPerson);
                // �) �������� �� 100
                // �) ���� doubleValue()
                // �) ����� �� 100 - ������������ �������� .

                double price = tmpPerson.getDayPrice().doubleValue();

                accumulatedValue += price * listItem.getLoadPercent().doubleValue() / 100;
            }

            while( true ) {
                dataHolderItem.getValue().teamExpenses = accumulatedValue;
                if( ! dataHolderIterator.hasNext()) {
                    break;
                }
                dataHolderItem = dataHolderIterator.next();
            }


        }



        ChartSeries teamExpensesFact = new ChartSeries();
        teamExpensesFact.setLabel("����������� ������� �� �������");
        ChartSeries projectActivityPlanPriceFact = new ChartSeries();
        projectActivityPlanPriceFact.setLabel("��������� ��������");

        ChartSeries projectActivityPlanPricePlan = new ChartSeries();
        projectActivityPlanPricePlan.setLabel("��������� ��������");

        modelFact.addSeries(teamExpensesFact);
        modelFact.addSeries(projectActivityPlanPriceFact);

        ChartSeries teamExpensesPlan = new ChartSeries();
        teamExpensesPlan.setLabel("�������� ������� �� �������");
        modelPlan.addSeries(teamExpensesPlan);
        modelPlan.addSeries(projectActivityPlanPricePlan);

        // ��������������� ��������� ������� - �������� �� % ��������� � �������
        double teamPercent = ClientKoeffs.getTeamKoeff(project.getClient());

        for(DataHolder value: expensesByDate.values()) {
            value.teamExpenses = value.teamExpenses * teamPercent;
        }

        Calendar calendar = Calendar.getInstance();
        int fields[] = new int[3];
        StringBuilder sb = new StringBuilder();

        Set<Date> keys = expensesByDate.keySet();
        int cnt = 0;
        Date currentDate = currentDateBean.getCurrentDate();
        DataHolder value = null;
        for(Date key: keys) {
            debug("readModel => "+ key);
            cnt++;
            value = expensesByDate.get(key);
            calendar.setTime(key);
            fields[0] = calendar.get(Calendar.YEAR);
            fields[1] = calendar.get(Calendar.MONTH) + 1;
            fields[2] = calendar.get(Calendar.DAY_OF_MONTH);

            if(cnt == keys.size() || fields[2] == 1 || currentDate.equals(key)) {
                sb.setLength(0);
                for(int val: fields) {
                    if(sb.length() > 0) { sb.append('.'); }
                    if(val < 10) { sb.append("0"); }
                    sb.append(val);
                }
                final String sKey = sb.toString();
                if( ! currentDate.after(key) ) {
                    teamExpensesPlan.set(sKey, value.teamExpenses);
                    projectActivityPlanPricePlan.set(sKey, project.getPrice());
//                    teamExpensesFact.set(sKey, 0);
                }

                if( ! key.after(currentDate) ) {
                    teamExpensesFact.set(sKey, value.teamExpenses);
                    projectActivityPlanPriceFact.set(sKey, project.getPrice());
//                    teamExpensesPlan.set(sKey, 0);
                }
            }

        }
        maxY = value.teamExpenses;
        double projectPrice = project.getPrice().doubleValue();
        if(projectPrice > maxY) {
            maxY = projectPrice;
        }
        maxY = maxY * 1.05;
    }

    public String goBack() {
        final String returnPath = backPath + "?conversationUuid=" + conversationUuid
                + "&faces-redirect=true";
        debug("goBack() called => "+ returnPath);
        return returnPath;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public void setMaxY(Double maxY) {
        this.maxY = maxY;
    }

    public Double getMaxY() {
        return maxY;
    }

}
