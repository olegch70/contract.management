package app.controllers.system;

import app.beans.CurrentDateBean;
import app.controllers.datamodel.TimeLineTeamExpense;
import app.dto.*;
import app.helpers.ClientKoeffs;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.loaders.*;
import app.loaders.directexpensefact.ExpensesDirectFactDBLoader;
import org.primefaces.model.chart.CartesianChartModel;
import org.primefaces.model.chart.ChartSeries;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.math.BigDecimal;
import java.util.*;

/**
 * author: Oleg Chamlay
 * Date: 26.03.14
 * Time: 12:43
 */
@ManagedBean(name= "graphIncomeExpensesController")
@ViewScoped
public class GraphIncomeExpensesController {

    private CartesianChartModel modelFact;
    private CartesianChartModel modelPlan;
    private String backPath;
    private String conversationUuid;
    private Long projectId;

    @EJB
    ProjectsDBLoader projectsDBLoader;

    @EJB
    ExpensesTeamDBLoader expensesTeamDBLoader;

    @EJB
    ExpensesDirectDBLoader expensesDirectDBLoader;

    @EJB
    ExpensesDirectFactDBLoader expensesDirectFactDBLoader;

    @EJB
    IncomeDBLoader incomeDBLoader;

    @EJB
    PersonsDBLoader personsDBLoader;

    @EJB
    private PersonFieldsCryptor personFieldsCryptor;

    @EJB
    CurrentDateBean currentDateBean;

    private Double maxY;
    private Double minY;

    public void initModel() {
        readModel();
    }

//    public void setModel(TimelineModel modelFact) {
//        this.modelFact = modelFact;
//    }

    public CartesianChartModel getModelFact() {
        return modelFact;
    }

    public CartesianChartModel getModelPlan() {
        return modelPlan;
    }

    public void setModelFact(CartesianChartModel modelFact) {
        this.modelFact = modelFact;
    }

    public void setModelPlan(CartesianChartModel modelPlan) {
        this.modelPlan = modelPlan;
    }

    private void readModel() {
        debug("readModel");
        modelFact = new CartesianChartModel();
//        modelPlan = new CartesianChartModel();
        TimeLineTeamExpense data = new TimeLineTeamExpense();
        Project project = projectsDBLoader.getById(projectId);

        if( ! project.getStartDate().before(project.getEndDatePlan())) {
            return;
        }

        // ��������������� ��������� ������� - �������� �� % ��������� � �������
        double contractPercent = ClientKoeffs.getContractKoeff(project.getClient());
        project.setPrice(project.getPrice().multiply(new BigDecimal(contractPercent)));

        data.setCaption("");

        debug("readModel 1");

        TreeMap<Date, DataHolder> expensesByDate = new TreeMap<Date, DataHolder>(new Comparator<Date>() {
            @Override
            public int compare(Date o1, Date o2) {
                return o1.compareTo(o2);
            }
        });

        {
            Calendar calendarEndDate = Calendar.getInstance();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(project.getEndDatePlan());
            calendar.setTime(project.getStartDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);

            while(true) {
                if(calendar.getTime().after(project.getEndDatePlan()) ) {
                    break;
                }
                calendarEndDate.setTime(calendar.getTime());
                calendarEndDate.set(Calendar.DAY_OF_MONTH, calendarEndDate.getActualMaximum(Calendar.DAY_OF_MONTH));
                Date curDate = calendarEndDate.getTime();
//                DataHolder dataHolder = new DataHolder();
//                dataHolder.date = curDate;
//                dataHolder.month = calendarEndDate.get(Calendar.MONTH);
//                expensesByDate.put(curDate, dataHolder);
                getDataHolder(expensesByDate, calendar, curDate);

                calendar.add(Calendar.MONTH, 1);
                debug("readModel 1.1 => curDate => "+ curDate);
            }
        }

        debug("readModel 2");

        {
            List<ExpenseTeam> expensesTeam = expensesTeamDBLoader.loadByFieldValue("projectId", projectId,
                    new String[]{"dateExp"});
            Person tmpPerson = new Person();
            DataHolder currentDataHolder = null;
            Calendar calendar = Calendar.getInstance();
            for(ExpenseTeam listItem : expensesTeam) {
                calendar.setTime(listItem.getDateExp());
                int month = calendar.get(Calendar.MONTH);
                if(currentDataHolder == null || currentDataHolder.month != month) {
                    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
                    Date lastDateInMonth = calendar.getTime();
                    currentDataHolder = expensesByDate.get(lastDateInMonth);
                    if(currentDataHolder == null) {
                        currentDataHolder = getDataHolder(expensesByDate, calendar, lastDateInMonth);
                    }
                }

                Double loadPercent = listItem.getLoadPercent();
                if(loadPercent != null) {
                    tmpPerson.setId(listItem.getPersonId());
                    tmpPerson.setDayPrice2(listItem.getPrice2());
                    personFieldsCryptor.decryptDayPrice(tmpPerson);
                    // �) �������� �� 100
                    // �) ���� doubleValue()
                    // �) ����� �� 100 - ������������ �������� .

                    double price = tmpPerson.getDayPrice().doubleValue();
                    currentDataHolder.teamExpenses += price * loadPercent.doubleValue() / 100;
                }
            }
        }

        { // ������� ������� ��������
            List<ExpenseDirect> expensesPlan = expensesDirectDBLoader.loadByFieldValue("projectId", projectId,
                    new String[]{"dateExp"});
            DataHolder currentDataHolder = null;
            Calendar calendar = Calendar.getInstance();
            for(ExpenseDirect expensePlan : expensesPlan) {
                calendar.setTime(expensePlan.getDateExp());
                int month = calendar.get(Calendar.MONTH);
                if(currentDataHolder == null || currentDataHolder.month != month) {
                    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
                    Date lastDateInMonth = calendar.getTime();
                    currentDataHolder = getDataHolder(expensesByDate, calendar, lastDateInMonth);
                }

                String name = expensePlan.getExpenseType() != null ? expensePlan.getExpenseType().getName() : "";
                currentDataHolder.addExpenseByName(name, expensePlan.getSumma().doubleValue());
            }
        }

        { // ������� ������� �����������
            List<ExpenseDirectFact> expensesFact = expensesDirectFactDBLoader.loadByFieldValue("projectId", projectId,
                    new String[]{"dateExp"});
            DataHolder currentDataHolder = null;
            Calendar calendar = Calendar.getInstance();
            for(ExpenseDirectFact expenseFact : expensesFact) {
                calendar.setTime(expenseFact.getDateExp());
                int month = calendar.get(Calendar.MONTH);
                if(currentDataHolder == null || currentDataHolder.month != month) {
                    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
                    Date lastDateInMonth = calendar.getTime();
                    currentDataHolder = getDataHolder(expensesByDate, calendar, lastDateInMonth);
                }

                String name = expenseFact.getExpenseType() != null ? expenseFact.getExpenseType().getName() : "";
                currentDataHolder.addExpenseFactByName(name, expenseFact.getSumma().doubleValue());
            }
        }

        { // ����������� ����� ������� �����������
            List<Income> incomeFact = incomeDBLoader.loadByFieldValue("projectId", projectId,
                    new String[]{"dateIncome"});
            DataHolder currentDataHolder = null;
            Calendar calendar = Calendar.getInstance();
            for(Income expenseFact : incomeFact) {
                calendar.setTime(expenseFact.getDateIncome());
                int month = calendar.get(Calendar.MONTH);
                if(currentDataHolder == null || currentDataHolder.month != month) {
                    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
                    Date lastDateInMonth = calendar.getTime();
                    currentDataHolder = getDataHolder(expensesByDate, calendar, lastDateInMonth);
                }

                currentDataHolder.directIncome += expenseFact.getSumma().doubleValue();
            }
        }

        debug("readModel 3");

        ChartSeries seriesBalancePlan = new ChartSeries();
        seriesBalancePlan.setLabel("������ ����");
        ChartSeries seriesBalanceFact = new ChartSeries();
        seriesBalanceFact.setLabel("������ ����");
//        ChartSeries projectActivityPlanPrice = new ChartSeries();
//        projectActivityPlanPrice.setLabel("�������� �����������");

        modelFact.addSeries(seriesBalancePlan);
        modelFact.addSeries(seriesBalanceFact);
//        modelFact.addSeries(projectActivityPlanPrice);


        // ��������������� ��������� ������� - �������� �� % ��������� � �������
        double teamPercent = ClientKoeffs.getTeamKoeff(project.getClient());

        for(DataHolder value: expensesByDate.values()) {
            value.teamExpenses = value.teamExpenses * teamPercent;
        }

        Set<Date> keys = expensesByDate.keySet();
        DataHolder value = null;
        double project_price = project.getPrice().doubleValue();
        double project_price_accumulator = 0;
        double project_price_by_month = 0;
        double monthBalanceFact = 0;
        if(keys.size() > 0) {
            project_price_by_month = project_price / keys.size();
        }

        debug("readModel 4");

        maxY = 0.0;
        minY = 0.0;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDateBean.getCurrentDate());
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date currentMonthEndDate = calendar.getTime();
        for(Date key: keys) {
            debug("readModel => "+ key);
            value = expensesByDate.get(key);
            //calendar.setTime(key);

            project_price_accumulator += project_price_by_month;
            double monthBalancePlan = project_price_accumulator - value.teamExpenses;
            for(Double expense: value.getExpensesMap().values()) {
                monthBalancePlan -= expense.doubleValue();
            }
            maxY = Math.max(maxY, monthBalancePlan);
            minY = Math.min(minY, monthBalancePlan);
            seriesBalancePlan.set(key.getTime(), Math.round(monthBalancePlan));
            if( ! currentMonthEndDate.before(value.date)) {
                monthBalanceFact += value.directIncome - value.teamExpenses;
                for (Double expenseFact : value.getExpensesFactMap().values()) {
                    monthBalanceFact -= expenseFact.doubleValue();
                }
                maxY = Math.max(maxY, monthBalanceFact);
                minY = Math.min(minY, monthBalanceFact);
                seriesBalanceFact.set(key.getTime(), Math.round(monthBalanceFact));
            }
        }

        maxY = maxY * 1.05;
        minY = minY * 1.05;
        debug("readModel done");

    }

    private DataHolder getDataHolder(TreeMap<Date, DataHolder> expensesByDate, Calendar calendar, Date lastDateInMonth) {
        DataHolder currentDataHolder;
        currentDataHolder = new DataHolder();
        currentDataHolder.date = lastDateInMonth;
        currentDataHolder.month = calendar.get(Calendar.MONTH);
        expensesByDate.put(lastDateInMonth, currentDataHolder);
        return currentDataHolder;
    }


    private void readModelOld() {
        debug("readModel");
        modelFact = new CartesianChartModel();
        modelPlan = new CartesianChartModel();
        TimeLineTeamExpense data = new TimeLineTeamExpense();
        Project project = projectsDBLoader.getById(projectId);

        // ��������������� ��������� ������� - �������� �� % ��������� � �������
        double contractPercent = ClientKoeffs.getContractKoeff(project.getClient());
        project.setPrice(project.getPrice().multiply(new BigDecimal(contractPercent)));

        data.setCaption("");

        class DataHolder {
            Date date;
            double teamExpenses;
            double directExpenses;
            double directIncome;
        };

        TreeMap<Date, DataHolder> expensesByDate = new TreeMap<Date, DataHolder>(new Comparator<Date>() {
            @Override
            public int compare(Date o1, Date o2) {
                return o1.compareTo(o2);
            }
        });

        {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(project.getStartDate());
            while(true) {
                Date curDate = calendar.getTime();
                if(curDate.after(project.getEndDatePlan())) {
                    break;
                }
                expensesByDate.put(curDate, new DataHolder());
                calendar.add(Calendar.DAY_OF_MONTH, 1);
            }
        }

        {
            List<ExpenseTeam> expensesTeam = expensesTeamDBLoader.loadByFieldValue("projectId", projectId,
                    new String[]{"dateExp"});
            Person tmpPerson = new Person();
            double accumulatedValue = 0;
            Iterator<Map.Entry<Date, DataHolder>> dataHolderIterator = expensesByDate.entrySet().iterator();
            Map.Entry<Date, DataHolder> dataHolderItem = dataHolderIterator.next();

            for(ExpenseTeam listItem : expensesTeam) {

                while( listItem.getDateExp().after(dataHolderItem.getKey())) {
                    dataHolderItem.getValue().teamExpenses = accumulatedValue;
                    dataHolderItem = dataHolderIterator.next();
                }

                tmpPerson.setId(listItem.getPersonId());
                tmpPerson.setDayPrice2(listItem.getPrice2());
                personFieldsCryptor.decryptDayPrice(tmpPerson);
                // �) �������� �� 100
                // �) ���� doubleValue()
                // �) ����� �� 100 - ������������ �������� .

                double price = tmpPerson.getDayPrice().doubleValue();

                accumulatedValue += price * listItem.getLoadPercent().doubleValue() / 100;
            }

            while( true ) {
                dataHolderItem.getValue().teamExpenses = accumulatedValue;
                if( ! dataHolderIterator.hasNext()) {
                    break;
                }
                dataHolderItem = dataHolderIterator.next();
            }


        }



        ChartSeries teamExpensesFact = new ChartSeries();
        teamExpensesFact.setLabel("����������� ������� �� �������");
        ChartSeries projectActivityPlanPriceFact = new ChartSeries();
        projectActivityPlanPriceFact.setLabel("��������� ��������");

        ChartSeries projectActivityPlanPricePlan = new ChartSeries();
        projectActivityPlanPricePlan.setLabel("��������� ��������");

        modelFact.addSeries(teamExpensesFact);
        modelFact.addSeries(projectActivityPlanPriceFact);

        ChartSeries teamExpensesPlan = new ChartSeries();
        teamExpensesPlan.setLabel("�������� ������� �� �������");
        modelPlan.addSeries(teamExpensesPlan);
        modelPlan.addSeries(projectActivityPlanPricePlan);

        // ��������������� ��������� ������� - �������� �� % ��������� � �������
        double teamPercent = ClientKoeffs.getTeamKoeff(project.getClient());

        for(DataHolder value: expensesByDate.values()) {
            value.teamExpenses = value.teamExpenses * teamPercent;
        }

        Calendar calendar = Calendar.getInstance();
        int fields[] = new int[3];
        StringBuilder sb = new StringBuilder();

        Set<Date> keys = expensesByDate.keySet();
        int cnt = 0;
        Date currentDate = currentDateBean.getCurrentDate();
        DataHolder value = null;
        double project_price = Math.round(project.getPrice().doubleValue());
        for(Date key: keys) {
            debug("readModel => "+ key);
            cnt++;
            value = expensesByDate.get(key);
            calendar.setTime(key);
            fields[0] = calendar.get(Calendar.MONTH) + 1;
            fields[1] = calendar.get(Calendar.DAY_OF_MONTH);
            fields[2] = calendar.get(Calendar.YEAR);

            if(cnt == keys.size() || fields[1] == 1 || currentDate.equals(key)) {
                sb.setLength(0);
                for(int val: fields) {
                    if(sb.length() > 0) { sb.append('/'); }
                    if(val < 10) { sb.append("0"); }
                    sb.append(val);
                }
                final String sKey = sb.toString();
                if( ! currentDate.after(key) ) {
                    teamExpensesPlan.set(key.getTime(), Math.round(value.teamExpenses));
                    projectActivityPlanPricePlan.set(key.getTime(), project_price);
//                    teamExpensesFact.set(sKey, 0);
                }

                if( ! key.after(currentDate) ) {
                    teamExpensesFact.set(key.getTime(), Math.round(value.teamExpenses));
                    projectActivityPlanPriceFact.set(key.getTime(), project_price);
//                    teamExpensesPlan.set(sKey, 0);
                }
            }

        }
        maxY = value.teamExpenses;
        double projectPrice = project_price;
        if(projectPrice > maxY) {
            maxY = projectPrice;
        }
        maxY = maxY * 1.05;
    }

    public String goBack() {
        final String returnPath = backPath + "?conversationUuid=" + conversationUuid
                + "&faces-redirect=true";
        debug("goBack() called => "+ returnPath);
        return returnPath;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public void setMaxY(Double maxY) {
        this.maxY = maxY;
    }

    public Double getMaxY() {
        return maxY;
    }

    public Double getMinY() {
        return minY;
    }

    private static class DataHolder {
        Date date;
        int month;
        double teamExpenses;
        double directExpenses;
        double directIncome;
        Map<String, Double> expenses = new TreeMap<String, Double>();
        Map<String, Double> expensesFact = new TreeMap<String, Double>();

        public void addExpenseByName(String name, double v) {
            accumulateExpenses(name, v, expenses);
        }

        public void addExpenseFactByName(String name, double v) {
            accumulateExpenses(name, v, expensesFact);
        }

        protected void accumulateExpenses(String name, double v, Map<String, Double> expenses1) {
            String key = safeString(name);
            Double currentValue = expenses1.get(key);
            if(currentValue == null) {
                currentValue = new Double(v);
                expenses1.put(key, currentValue);
            } else {
                expenses1.put(key, new Double(currentValue.doubleValue() + v ));
            }
        }

        public Map<String, Double> getExpensesMap() {
            return expenses;
        }

        public Map<String, Double> getExpensesFactMap() {
            return expensesFact;
        }

        private String safeString(String name) {
            return name == null ? "" : name;
        }
    };

}
