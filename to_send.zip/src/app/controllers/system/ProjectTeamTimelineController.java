package app.controllers.system;

import app.controllers.datamodel.TimeLineTeamExpense;
import app.dto.ExpenseTeam;
import app.dto.Person;
import app.dto.Project;
import app.helpers.LogSimple;
import app.loaders.ExpensesTeamDBLoader;
import app.loaders.PersonsDBLoader;
import app.loaders.ProjectsDBLoader;
import org.primefaces.extensions.model.timeline.TimelineEvent;
import org.primefaces.extensions.model.timeline.TimelineModel;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.*;

/**
 * author: Oleg Chamlay
 * Date: 26.03.14
 * Time: 12:43
 */
@ManagedBean(name= "projectTeamTimelineController")
@ViewScoped
public class ProjectTeamTimelineController {

    private TimelineModel model;
    private String backPath;
    private String conversationUuid;
    private Long projectId;

    @EJB
    ProjectsDBLoader projectsDBLoader;

    @EJB
    ExpensesTeamDBLoader expensesTeamDBLoader;

    @EJB
    PersonsDBLoader personsDBLoader;


    public void initModel() {
        model = readModel();
    }

    public void setModel(TimelineModel model) {
        this.model = model;
    }

    public TimelineModel getModel() {
        return model;
    }

    private TimelineModel readModel() {
        Calendar calendar = Calendar.getInstance();
        TimelineModel result = new TimelineModel();
        TimeLineTeamExpense data = new TimeLineTeamExpense();
        Project project = projectsDBLoader.getById(projectId);
        data.setCaption("");
        calendar.setTime(project.getEndDatePlan());

        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);

        result.add(new TimelineEvent(data, project.getStartDate(), calendar.getTime(), false,
                "    . . . ���������� . . . "));
        List<ExpenseTeam> expenses = expensesTeamDBLoader.loadByFieldValue("projectId", projectId,
                new String[]{"personId", "dateExp", "loadPercent"});

        if(expenses.size() < 1) {
            return result;
        }
        Iterator<ExpenseTeam> iterator = expenses.iterator();
        ExpenseTeam expense = iterator.next();
        Map<String, List<TimelineEvent>> personsFio = new TreeMap<String, List<TimelineEvent>>();
        while(expense != null) {
            Person person = personsDBLoader.getById(expense.getPersonId());
            final long personId = expense.getPersonId();
            debug(" start personId => " + personId);

            while(    expense != null
                   && personId == expense.getPersonId().longValue()
                    ) {
                data = new TimeLineTeamExpense();
                Date fromDate = expense.getDateExp();
                Date toDate = fromDate;
                calendar.setTime(fromDate);
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);

                calendar.add(Calendar.DAY_OF_MONTH, 1);

                Date nextDate = calendar.getTime();
                double currentLoadPercent = expense.getLoadPercent().doubleValue();
                data.setCaption(String.format("%1$.0f", expense.getLoadPercent())+" %");
                debug(" fromDate => " + fromDate);
                debug(" currentLoadPercent => "+currentLoadPercent);
                debug(" data.caption => " + data.getCaption());
                Date toDatePrev = toDate;
                while(    expense != null
                        && currentLoadPercent == expense.getLoadPercent().doubleValue()
                        && personId == expense.getPersonId().longValue()
                        && nextDate.after(expense.getDateExp())
                        ) {
                    toDatePrev = toDate;
                    if(iterator.hasNext()) {
                        expense = iterator.next();
                        if(personId == expense.getPersonId().longValue()) {
                            toDate = expense.getDateExp();
                            calendar.add(Calendar.DAY_OF_MONTH, 1);
                            nextDate = calendar.getTime();
                        }
                    } else {
                        expense = null;
                    }
                }
                calendar.setTime(toDatePrev);
                if( expense != null && personId == expense.getPersonId().longValue()) {
                    // ��������� �������
                    calendar.set(Calendar.HOUR_OF_DAY, 22);
                    calendar.set(Calendar.MINUTE, 0);
                    calendar.set(Calendar.SECOND, 0);
                    calendar.set(Calendar.MILLISECOND, 0);
                } else {
                    // ��������� ���������
                    calendar.set(Calendar.HOUR_OF_DAY, 23);
                    calendar.set(Calendar.MINUTE, 59);
                    calendar.set(Calendar.SECOND, 50);
                    calendar.set(Calendar.MILLISECOND, 0);
                }
                toDate = calendar.getTime();

                String fio = person.getFIO();
                TimelineEvent event = new TimelineEvent(data, fromDate, toDate, false, fio);
                List<TimelineEvent> events = personsFio.get(fio);
                if(events == null) {
                    events = new LinkedList<TimelineEvent>();
                    personsFio.put(fio, events);
                }
                events.add(event);
                result.add(event);
                debug(" result.add(new TimelineEvent(" + data.getCaption() + ", " + fromDate + ", " + toDate + ", false, " + fio + "))");
            }

        }

        int rowNum = 1;
        for(String fio: personsFio.keySet()) {
            List<TimelineEvent> events = personsFio.get(fio);
            String sRowNum = String.format("%1$" + 3 + "s", "" + (rowNum++));
            String nFio = sRowNum + ". " + fio;
            for(TimelineEvent event: events) {
                event.setGroup(nFio);
            }
        }

        return result;
    }

    public String goBack() {
        final String returnPath = backPath + "?conversationUuid=" + conversationUuid
                + "&faces-redirect=true";
        debug("goBack() called => "+ returnPath);
        return returnPath;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }
}
