package app.controllers.system.data.restore;

import app.dto.ExpenseTeam;
import app.dto.Person;
import app.dto.TeamItem;
import app.dto.TeamItemHistory;
import app.dto.validator.ProjectTeamPersonHistory;
import app.dto.validator.ProjectTeamPersonHistoryValidator;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.loaders.PersonsDBLoader;
import app.loaders.ProjectTeamDBLoader;
import app.loaders.ProjectTeamPersonsHistoryDBLoader;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigInteger;
import java.util.*;

/**
 * Created by oleg on 18.07.2014.
 */

@Stateless
public class RestorerProjectTeamPersonsHistory {
    @PersistenceContext(unitName = ConstantsHelper.PERSISTENCE_UNIT_NAME)
    protected EntityManager em;

    @Inject
    ProjectTeamDBLoader projectTeamDBLoader;

    @Inject
    PersonsDBLoader personsDBLoader;

    @Inject
    ProjectTeamPersonsHistoryDBLoader projectTeamPersonsHistoryDBLoader;

    public void restoreForProjectTeam(Long projectId) {
        Query q = em.createQuery(
                 "select distinct t.personId "
                +" from ExpenseTeam t "
                +" where t.projectId = :projectId");
        q.setParameter("projectId", projectId);
        List<Long> projectTeamPersonsId = (List<Long>) q.getResultList();

        List<TeamItem> projectTeam = projectTeamDBLoader.getByProjectId(projectId);
        Map<Long, TeamItem> personsIds = new HashMap<Long, TeamItem>(projectTeam.size());
        for(TeamItem item: projectTeam) {
            personsIds.put(item.getId(), item);
        }

        TeamItem utilTeamItem = new TeamItem();
        for(Long personId: projectTeamPersonsId) {
            TeamItem item = personsIds.get(personId);
            if(item == null) {
                item = utilTeamItem;
                item.setPerson(personsDBLoader.getById(personId));
                item.setClientMonthPrice(null);
            }
            restoreForProjectTeamPerson(projectId, item);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public void restoreForProjectTeamPerson(Long projectId, TeamItem teamItem) {
        Person person = teamItem.getPerson();
        boolean fLogging = person.getLastName().startsWith("���������")
                        || person.getLastName().startsWith("����")
                        || person.getLastName().startsWith("������")
                ;
        Query q = em.createNamedQuery("ExpenseTeam.expensesForPersonInProject");
        q.setParameter("projectId", projectId);
        q.setParameter("personId", person.getId());
        TeamItemHistory prototype = new TeamItemHistory();
        prototype.setProjectId(projectId);
        prototype.setPerson(person);
        prototype.setClientMonthPrice(teamItem.getClientMonthPrice());

        final List<TeamItemHistory> history = createFromProjectPersonExpenses(q.getResultList(), prototype);
        if(fLogging) {
            debug("new TeamItemHistory`s");
            for (TeamItemHistory item: history) {
                debug(item.toString());
            }
        }

        final List<TeamItemHistory> oldHistory = projectTeamPersonsHistoryDBLoader.getByProjectIdPersonId(projectId, person.getId());
        if(fLogging) {
            debug("old TeamItemHistory`s");
            for (TeamItemHistory item: history) {
                debug(item.toString());
            }
        }
        Iterator<TeamItemHistory> itrNew = history.iterator();
        Iterator<TeamItemHistory> itrOld = oldHistory.iterator();
        TeamItemHistory itemNew;
        TeamItemHistory itemOld;

        while(itrNew.hasNext() && itrOld.hasNext()) {
            itemNew = itrNew.next();
            itemOld = itrOld.next();
            if( ! itemNew.equalsFull(itemOld)) {
                if(fLogging) {
                    debug("items not equal newItem => " + itemNew.toString()+ ", oldItem => " + itemOld.toString());
                }

                itemOld.setProjectId(itemNew.getProjectId());
                itemOld.setPerson(itemNew.getPerson());
                itemOld.setClientMonthPrice(itemNew.getClientMonthPrice());
                itemOld.setPrice2(itemNew.getPrice2());
                itemOld.setLoadPercent(itemNew.getLoadPercent());
                itemOld.setPeriodStart(itemNew.getPeriodStart());
                itemOld.setPeriodFinish(itemNew.getPeriodFinish());

                em.persist(itemOld);

            } else {
                if(fLogging) {
                    debug("items equal " + itemNew.toString());
                }
            }
        }

        if( ! itrNew.hasNext() && itrOld.hasNext() ) {
            itemOld = itrOld.next();
            if(fLogging) {
                debug("item delete " + itemOld.toString());
            }
            em.remove(itemOld);
        }

        if( itrNew.hasNext() && ! itrOld.hasNext() ) {
            itemNew = itrNew.next();
            if(fLogging) {
                debug("item add " + itemNew.toString());
            }
            em.persist(itemNew);
        }

        em.flush();
    }

    /**
     * �������������� ����������� �������� �� ����� ������� ������� �� ��������� ����������
     * @param expenses
     * @return
     */

    public @ProjectTeamPersonHistory List<TeamItemHistory> createFromProjectPersonExpenses(List<ExpenseTeam> expenses, TeamItemHistory prototype) {
        if(expenses == null || expenses.size() == 0) {
            return new ArrayList<TeamItemHistory>(0);
        }
        List<TeamItemHistory> result = new LinkedList<TeamItemHistory>();
        Iterator<ExpenseTeam> iterator = expenses.iterator();
        Calendar calendar = Calendar.getInstance();
        int lastStepsNumber = 0;
        ExpenseTeam expense = iterator.next();
        do {
            if(lastStepsNumber == 1) {
                lastStepsNumber = 2;
            }

            TeamItemHistory expenseTeamHistory = new TeamItemHistory();
            result.add(expenseTeamHistory);
            expenseTeamHistory.setProjectId(prototype.getProjectId());
            expenseTeamHistory.setPerson(prototype.getPerson());
            expenseTeamHistory.setClientMonthPrice(prototype.getClientMonthPrice());
            expenseTeamHistory.setPrice2(expense.getPrice2());
            BigInteger currentPrice = expense.getPrice2();

            double currentLoadPercent = expense.getLoadPercent().doubleValue();
            expenseTeamHistory.setLoadPercent(currentLoadPercent);

            Date fromDate = expense.getDateExp();
            expenseTeamHistory.setPeriodStart(fromDate);
//            debug("0. expenseTeamHistory.start => "+expenseTeamHistory.toString());
            calendar.setTime(fromDate);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);

            Date candidatePeriodFinish = fromDate;
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            Date expectedNextDate = calendar.getTime();
//            debug("1. candidatePeriodFinish = > "+ candidatePeriodFinish);
//            debug("2. expectedNextDate = > "+ expectedNextDate);
            while(lastStepsNumber == 0
                    && isNextDayForSequence(expense, currentPrice, currentLoadPercent, expectedNextDate)
            )
            {
                candidatePeriodFinish = expense.getDateExp();
                // candidatePeriodFinish = calendar.getTime(); // ��� ������������ ���������� ��������� ������������ ����������� ����
                calendar.add(Calendar.DAY_OF_MONTH, 1);
                expectedNextDate = calendar.getTime();
//                debug("3. candidatePeriodFinish = > "+ candidatePeriodFinish);
//                debug("4. expectedNextDate = > "+ expectedNextDate);

                expense = iterator.next();
                if(! iterator.hasNext()) {
                    if( isNextDayForSequence(expense, currentPrice, currentLoadPercent, expectedNextDate )) {
                        candidatePeriodFinish = expense.getDateExp();
//                        debug("5. expectedNextDate = > "+ expectedNextDate);
                        lastStepsNumber = 2;
                    } else {
                        lastStepsNumber = 1;
//                        debug("6. lastStepsNumber = > "+ lastStepsNumber);
                    }
                }
            }

            expenseTeamHistory.setPeriodFinish(candidatePeriodFinish);
//            debug("10. expenseTeamHistory.finish => " + expenseTeamHistory.toString());
        } while (lastStepsNumber != 2);

        if( ! ProjectTeamPersonHistoryValidator.isValid(result)) {
            throw new IllegalStateException("List<TeamItemHistory> is invalid");
        }
        return result;
    }

    private boolean isNextDayForSequence(ExpenseTeam expense, BigInteger currentPrice, double currentLoadPercent, Date expectedNextDate) {
        return currentLoadPercent == expense.getLoadPercent().doubleValue()
                && currentPrice.equals(expense.getPrice2())
                && !expectedNextDate.before(expense.getDateExp());
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }
}
