package app.controllers.datamodel;

import app.dto.Client;
import app.helpers.LogSimple;
import app.loaders.ClientsDBLoader;
import org.primefaces.model.SelectableDataModel;

import javax.faces.model.ListDataModel;
import java.util.List;

/**
 * author: Oleg Chamlay
 * Date: 22.01.14
 * Time: 20:39
 */


public class ClientsDataModel extends ListDataModel<Client> implements SelectableDataModel<Client> {

    private ClientsDBLoader clientsDBLoader;

    public ClientsDataModel() {
    }

    public ClientsDataModel(List<Client> data) {
        super(data);
        LogSimple.debug(this, "ClientsDataModel created with list.size() => "+ data.size());
    }

    @Override
    public Object getRowKey(Client client) {
        LogSimple.debug(this, "getRowKey "+ client);
        if(client == null) {
            return null;
        }
        return client.getId();
    }

    @Override
    public Client getRowData(String rowKey) {
        LogSimple.debug(this, "getRowData for rowKey => "+ rowKey);
        return clientsDBLoader.getById(rowKey);
    }

    public void setClientsDBLoader(ClientsDBLoader clientsDBLoader) {
        this.clientsDBLoader = clientsDBLoader;
    }
}
