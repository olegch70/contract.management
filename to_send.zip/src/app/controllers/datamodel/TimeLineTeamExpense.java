package app.controllers.datamodel;

import app.dto.Person;

import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 26.03.14
 * Time: 12:49
 */
public class TimeLineTeamExpense {
    private String caption;
    private Date fromDate;
    private Date toDate;
    private long percentLoad;

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public long getPercentLoad() {
        return percentLoad;
    }

    public void setPercentLoad(long percentLoad) {
        this.percentLoad = percentLoad;
    }
}
