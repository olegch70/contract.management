package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.CurrentDateBean;
import app.dto.Direction;
import app.dto.ProjectType;
import app.dto.report.DomainCost;
import app.helpers.LogSimple;
import app.loaders.*;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "domainCostReportController")
@ViewScoped
public class DomainCostReportController {

    private String backPath;
    @EJB
    private DirectionReportsDBLoader directionReportsDBLoader;
    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private DirectionDBLoader directionDBLoader;
    @EJB
    private ProjectTypeDBLoader projectTypeDbLoader;
    @EJB
    DomainCostReportDBLoader domainCostReportDBLoader;

    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{sessionDataHolder}")
    private SessionDataHolder sessionDataHolder;
    private ReportDateFilter reportDateFilter;
    private Collection<DomainCost> reportItems;
    private Long selectedDirectionId;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private List<String> selectedDirections;
    private List<String> selectedActivityTypes;
    private DomainCost itogItem;

    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        localUuid = getConversationUuid()+"_clientsReportTableController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            reportDateFilter = new ReportDateFilter();
            reportDateFilter.setYear(calendar.get(Calendar.YEAR));
            reportDateFilter.setStartMonth(1);
            reportDateFilter.setEndMonth(calendar.get(Calendar.MONTH) + 1);
            parameters.put("reportDateFilter", reportDateFilter);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            backPath = (String) parameters.get("backPath");
            reportDateFilter = (ReportDateFilter) parameters.get("reportDateFilter");
        }
    }

    public Collection<DomainCost> getItems() {
        return reportItems;
    }

//    public List<ClientReport> getItemsForDirection() {
//        return reportItems;
//    }
//
    public String doBack() {
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void doFilter() {
        LogSimple.debug(this, "doFilter executed");
        reportItems = domainCostReportDBLoader.getReportData(getReportDateFilter(), selectedDirections, selectedActivityTypes);
        itogItem = new DomainCost();
        for(DomainCost row: reportItems) {
            itogItem.setIncome(itogItem.getIncome().add(row.getIncome()));
            itogItem.setExpenseTeam(itogItem.getExpenseTeam().add(row.getExpenseTeam()));
            itogItem.setExpenseDirect(itogItem.getExpenseDirect().add(row.getExpenseDirect()));
        }
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public ReportDateFilter getReportDateFilter() {
/*
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
*/
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public List<Direction> getDirectionsList() {
        List<Direction> directionsList = directionDBLoader.getAll();
        List<Direction> result = new ArrayList<Direction>(directionsList.size()+1);
        result.add(DirectionDBLoader.DIRECTION_BENCH);
        result.addAll(directionsList);
        return result;
    }

    public List<ProjectType> getActivityTypesList() {
        return projectTypeDbLoader.getAll();
    }

    public void setDirectionsList(List<Direction> directionsList) {
    }

    public Long getSelectedDirectionId() {
        return selectedDirectionId;
    }

    public void setSelectedDirectionId(Long selectedDirectionId) {
        this.selectedDirectionId = selectedDirectionId;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public Map getParameters() {
        return parameters;
    }

    public void setParameters(Map parameters) {
        this.parameters = parameters;
    }

    public String getLocalUuid() {
        return localUuid;
    }

    public void setLocalUuid(String localUuid) {
        this.localUuid = localUuid;
    }

    public List<String> getSelectedDirections() {
        if(selectedDirections == null) {
            List<Direction> directions = getDirectionsList();
            selectedDirections = new ArrayList<String>(directions.size());
            for(Direction direction : directions) {
                selectedDirections.add(direction.getId().toString());
            }
        }
        return selectedDirections;
    }

    public void setSelectedActivityTypes(List<String> selectedSelectedActivityTypes) {
        this.selectedActivityTypes = selectedSelectedActivityTypes;
    }

    public List<String> getSelectedActivityTypes() {
        if(selectedActivityTypes == null) {
            List<ProjectType> activityTypes = getActivityTypesList();
            selectedActivityTypes = new ArrayList<String>(activityTypes.size());
            for(ProjectType activityType : activityTypes) {
                selectedActivityTypes.add(activityType.getId().toString());
            }
        }
        return selectedActivityTypes;
    }

    public void setSelectedDirections(List<String> selectedDirections) {
        this.selectedDirections = selectedDirections;
    }

    public void setItogItem(DomainCost itogItem) {
        this.itogItem = itogItem;
    }

    public DomainCost getItogItem() {
        return itogItem;
    }
}
