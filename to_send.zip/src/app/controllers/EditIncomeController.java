package app.controllers;

import app.dto.ExpenseDirect;
import app.dto.Income;
import app.loaders.ExpensesDirectDBLoader;
import app.loaders.IncomeDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editIncomeController")
@ViewScoped
public class EditIncomeController {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    //@ManagedProperty(value="#{incomeDBLoader}")
    @EJB
    private IncomeDBLoader incomeDBLoader;
    private Long incomeId;
    private String backPath;
    private String command;
    private Long projectId;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private Income income;

    public void initModel(){
        System.out.println("initModel() in editIncomeController started");
        initializeUuid();
        localUuid = getConversationUuid()+"_editIncomeController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("projectId", projectId);
            System.out.println("parameters.put(projectId = " + projectId);
            parameters.put("incomeId", incomeId);
            System.out.println("parameters.put(incomeId = " + incomeId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            if(command.equals("add")){
                income = new Income();
                income.setProjectId(projectId);
            } else {
                List<Income> incomeList = incomeDBLoader.loadByLinkedId("projectId", projectId);
                for(Income row : incomeList)
                {
                    if(row.getId().equals(incomeId)){
                        income = row;
                        break;
                    }
                }
                System.out.println("expenseDirect = " + income);
            }
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            System.out.println("parameters incomeId = " + parameters.get("incomeId"));
            incomeId = (Long) parameters.get("incomeId");
            backPath = (String) parameters.get("backPath");
        }

        System.out.println("initModel() in editIncomeController finished");
    }

    public String saveIncome() {
        System.out.println("saveIncome in edit income called");
        if(command.equals("add")){
            incomeDBLoader.addNew(income);
        } else {
            incomeDBLoader.update(income);
            System.out.println("saveIncome in edit income updated");
        }
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String doBack() {
        removeModelFromSession();
        System.out.println("backPath on doBack = " + backPath);
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public Income getIncome() {
        return income;
    }

    public void setIncome(Income income) {
        this.income = income;
    }

    public void setIncomeId(Long incomeId) {
        this.incomeId = incomeId;
    }

    public Long getIncomeId() {
        return incomeId;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String getCommand() {
        return command;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public IncomeDBLoader getIncomeDBLoader() {
        return incomeDBLoader;
    }

    public void setIncomeDBLoader(IncomeDBLoader incomeDBLoader) {
        this.incomeDBLoader = incomeDBLoader;
    }
}
