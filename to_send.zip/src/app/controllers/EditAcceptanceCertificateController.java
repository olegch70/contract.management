package app.controllers;

import app.beans.CurrentDateBean;
import app.dto.AcceptanceCertificate;
import app.dto.Income;
import app.helpers.ViewNavigationHelper;
import app.loaders.AcceptanceCertificateDBLoader;
import app.loaders.IncomeDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editAcceptanceCertificateController")
@ViewScoped
public class EditAcceptanceCertificateController extends AbstractEditController {

    private static final String VIEW_NAME = "editAcceptanceCertificate";
    public static final String ACCEPT_CERTIFICATE_ID_KEY = "acceptCertificateId";
    public static final String PROJECT_ID_KEY = "projectId";

    @EJB
    private AcceptanceCertificateDBLoader acceptanceCertificateDBLoader;
    @EJB
    private CurrentDateBean currentDateBean;

    private Long acceptCertificateId;
    private Long projectId;
    private AcceptanceCertificate acceptanceCertificate;

    public void childInitModel(){
        acceptCertificateId = (Long) parameters.get(ACCEPT_CERTIFICATE_ID_KEY);
        projectId = (Long) parameters.get(PROJECT_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        if(command.equals(COMMAND_ADD)){
            acceptanceCertificate = new AcceptanceCertificate();
            acceptanceCertificate.setProjectId(projectId);
        } else {
            List<AcceptanceCertificate> certificatesList = acceptanceCertificateDBLoader.loadByLinkedId(PROJECT_ID_KEY, projectId);
            for(AcceptanceCertificate row : certificatesList)
            {
                if(row.getId().equals(acceptCertificateId)){
                    acceptanceCertificate = row;
                    break;
                }
            }
        }
    }

    public String save() {
        addCreatorInfo(acceptanceCertificate);
        if(command.equals(COMMAND_ADD)){
            acceptanceCertificateDBLoader.addNew(acceptanceCertificate);
        } else {
            acceptanceCertificateDBLoader.update(acceptanceCertificate);
        }
        return doBack();
    }

    private void addCreatorInfo(AcceptanceCertificate acceptanceCertificate) {
        Date curDate = new Date();
        debug("creationDate = " + curDate);
        debug("creatorId = " + authorisedUser.getAuthorisedUser().getUser().getId());
        acceptanceCertificate.setCreationDate(curDate);
        acceptanceCertificate.setCreatorId(authorisedUser.getPerson().getId());
    }


    public static String doCallAdd(AbstractController caller, Long projectId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long projectId, Long acceptCertificateId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(ACCEPT_CERTIFICATE_ID_KEY, acceptCertificateId);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        paramModel[0].put(COMMAND_KEY, "edit");
        return result;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public AcceptanceCertificate getAcceptanceCertificate() {
        return acceptanceCertificate;
    }

    public void setAcceptCertificate(AcceptanceCertificate acceptanceCertificate) {
        this.acceptanceCertificate = acceptanceCertificate;
    }

}
