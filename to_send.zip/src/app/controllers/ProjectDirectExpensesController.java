package app.controllers;

import app.beans.CurrentDateBean;
import app.dto.ExpenseDirect;
import app.loaders.ExpensesDirectDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 18:30
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectDirectExpensesController")
@ViewScoped
public class ProjectDirectExpensesController extends AbstractTableController  {
    private static final String VIEW_NAME = "projectDirectExpenses";
    @EJB
    private ExpensesDirectDBLoader expensesDirectDBLoader;
    @EJB
    private CurrentDateBean currentDateBean;

    private Double summaAll;
    private Double summaPlan;
    private List<ExpenseDirect> items;

    public String add() {
        return EditDirectExpenseController.doCallAdd(this, parentId);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return EditDirectExpenseController.doCallEditByRecordId(this, parentId, getSelectedItem().getId());
    }

    @Override
    public void deleteInternal() {
        expensesDirectDBLoader.delete(getSelectedItem().getId());
    }

    private ExpenseDirect getSelectedItem() {
        return (ExpenseDirect) uiTableHelper.getSelectedItem();
    }

    public static String doCallByProjectId(AbstractController caller, Long projectId){
        return doCall(VIEW_NAME, caller, projectId);
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

//    public String getInfoForDeletingRow() {
//        return infoForDeletingRow;
//    }

//    private String getCurrentPath() {
//        FacesContext facesContext = FacesContext.getCurrentInstance();
//        String currentPath = facesContext.getViewRoot().getViewId();
//        System.out.println("currentPath = " + currentPath);
//        return currentPath;
//    }
//

    public List<ExpenseDirect> getItems() {
        if(items == null) {
            List<ExpenseDirect> result = expensesDirectDBLoader.getListForAuthorizedUser(parentId, authorisedUser.getPerson());
            double _summaAll=0;
            double _summaPlan=0;
            Date currentDate = currentDateBean.getCurrentDate();

            for(ExpenseDirect item: result) {
                double documentSumma = item.getSumma().doubleValue();
                _summaAll+= documentSumma;
                if(item.getDateExp().after(currentDate)) {
                    _summaPlan += documentSumma;
                }
            }
            summaAll = _summaAll;
            summaPlan = _summaPlan;
            items = result;
        }
        return items;
    }

    public Double getSummaAll() {
        return summaAll;
    }

    public Double getSummaPlan() {
        return summaPlan;
    }
}
