package app.controllers;

import app.dto.ExpenseDirect;
import app.helpers.LogSimple;
import app.loaders.ExpensesDirectDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 18:30
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectDirectExpensesController")
@ViewScoped
public class ProjectDirectExpensesController {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    //@ManagedProperty(value="#{expensesDirectDBLoader}")
    @EJB
    private ExpensesDirectDBLoader expensesDirectDBLoader;
    private Long projectId;
    private String backPath;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private ExpenseDirect selectedExpense;
    private String infoForDeletingRow;

    public void initModel() {
        initializeUuid();
        localUuid = getConversationUuid()+"_projectDirectExpensesController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);

        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("projectId", projectId);
            System.out.println("parameters.put(projectId = " + projectId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null ");
            System.out.println("parameters projectId = " + parameters.get("projectId"));
            projectId = (Long) parameters.get("projectId");
            backPath = (String) parameters.get("backPath");
        }
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    public String add() {
        return "editDirectExpense?command=add"
                +"&backPath="+getCurrentPath()
                +"&projectId="+ projectId
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return "editDirectExpense?command=edit"
                +"&backPath="+getCurrentPath()
                +"&projectId="+ projectId
                +"&expenseId="+ selectedExpense.getId()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void delete() {
        expensesDirectDBLoader.delete(selectedExpense.getId());
    }

    public String doBack() {
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(selectedExpense != null) {
            return true;
        }

        displayUIMessage("�������� ������� ������.");
        return false;
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }
    public String getInfoForDeletingRow() {
        return infoForDeletingRow;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public List<ExpenseDirect> getItems() {
        return expensesDirectDBLoader.loadByFieldValue("projectId", projectId, new String[]{"dateExp"});
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public ExpensesDirectDBLoader getExpensesDirectDBLoader() {
        return expensesDirectDBLoader;
    }

    public void setExpensesDirectDBLoader(ExpensesDirectDBLoader expensesDirectDBLoader) {
        this.expensesDirectDBLoader = expensesDirectDBLoader;
    }

    public void setSelectedItem(ExpenseDirect selectedExpense) {
        this.selectedExpense = selectedExpense;
    }

    public ExpenseDirect getSelectedItem() {
        return selectedExpense;
    }
}
