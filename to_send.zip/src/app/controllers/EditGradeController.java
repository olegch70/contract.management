package app.controllers;

import app.dto.Grade;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.loaders.GradeDBLoader;
import app.loaders.PositionDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 14:36
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editGradeController")
@ViewScoped
public class EditGradeController extends AbstractEditController {
    private static final String VIEW_NAME = "editGrade";
    public static final String GRADE_ID_KEY = "gradeId";
    @EJB
    private GradeDBLoader gradeDBLoader;
    private Long gradeId;
    private Grade grade;

    public void childInitModel(){
        gradeId = (Long) parameters.get(GRADE_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        if(command.equals(COMMAND_ADD)){
                grade = new Grade();
            } else {
                grade = gradeDBLoader.getById(gradeId);
                grade = gradeDBLoader.getByCode(grade.getCode());
            }
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCallAdd(AbstractController caller){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long id){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(GRADE_ID_KEY, id);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        return result;
    }

    public String save() {
        LogSimple.debug(this, " ����� = " + grade.getCode());
        if(command.equals("add")){
            gradeDBLoader.addNew(grade);
        } else {
            System.out.println("saveGrade called");
            gradeDBLoader.update(grade);
            System.out.println("saveGrade updated");
        }
        return doBack();
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }
}
