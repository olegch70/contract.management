package app.controllers;

import app.dto.Position;
import app.loaders.CommonDbLoader;
import app.loaders.PositionDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 16:09
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "positionsListController")
@ViewScoped
public class PositionsListController extends AbstractTableControllerGeneric<Position> {

    private static final String VIEW_NAME = "positionsList";
    @EJB
    private PositionDBLoader positionDBLoader;

    protected CommonDbLoader getDbLoader() {
        return positionDBLoader;
    }

    public List<Position> getItems() {
        return positionDBLoader.getAllWithNotActual();
    }

    public static String doCall(AbstractController caller){
        return doCall(VIEW_NAME, caller, null);
    }

    protected String add() {
        return EditPositionController.doCallAdd(this);
    }

    protected String edit() {
        return EditPositionController.doCallEditByRecordId(this, getSelectedItemSuper().getId());
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }
}
