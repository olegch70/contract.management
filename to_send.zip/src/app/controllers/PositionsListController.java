package app.controllers;

import app.dto.Person;
import app.dto.Position;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.loaders.PersonsDBLoader;
import app.loaders.PositionDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 16:09
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "positionsListController")
@ViewScoped
public class PositionsListController {

    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    @EJB
    private PositionDBLoader positionDBLoader;
    private String backPath;
    private String localUuid;
    private String conversationUuid;
    private Map parameters;
    private Position selectedItem;
    private List<Position> filteredRows;

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        initializeUuid();
        localUuid = getConversationUuid()+"_positionsListController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);

        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            filteredRows = (List) parameters.get("filteredRows");
            backPath = (String) parameters.get("backPath");
        }
    }

    public List<Position> getItems() {
        return positionDBLoader.getAllWithNotActual();
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    public String add() {
        return "editPosition?command=add"
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return "editPosition?command=edit"
                +"&backPath="+getCurrentPath()
                +"&positionId="+ selectedItem.getId()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void delete() {
        try {
            positionDBLoader.delete(selectedItem.getId());
            UIMessages.displayMessage("������ �������.");
        } catch (Exception e) {
            UIMessages.displayErrorMessage("�� ������� ������� ������.");
            LogSimple.error(this, e);
        }

    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public String doBack() {
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(selectedItem != null) {
            return true;
        }

        UIMessages.displayMessage("�������� ������� ������.");
        return false;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public Position getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(Position selectedItem) {
        this.selectedItem = selectedItem;
    }

    public void setFilteredRows(List<Position> filteredRows) {
        this.filteredRows = filteredRows;
        LogSimple.debug(this, "setFilteredRows");
        parameters.put("filteredRows", this.filteredRows);

    }

    public List<Position> getFilteredRows() {
        LogSimple.debug(this, "getFilteredRows");
        if(filteredRows == null) {
            filteredRows = getItems();
        }
        return filteredRows;
    }
}
