package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.LogSimple;
import app.loaders.*;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "frameReportTableController")
@ViewScoped
public class FrameReportTableController {

    private String backPath;

    @EJB
    private FrameReportDBLoader frameReportsDBLoader;
    @EJB
    private CurrentDateBean currentDateBean;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{sessionDataHolder}")
    private SessionDataHolder sessionDataHolder;
    private ReportDateFilter reportDateFilter;
    private List<FrameReport> items;
    private String conversationUuid;
    private String localUuid;
    private Integer reportYear;
    private Map parameters;
    private List<String> selectedQuarters;
    private List<String> selectedTypes;
    private List<ProjectType> projectTypes;

    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        localUuid = getConversationUuid()+"_clientsReportTableController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        projectTypes = getTypesForFilter();
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            selectedTypes = new ArrayList<String>(getTypesForFilter().size());
            for(ProjectType projectType: getTypesForFilter()) {
                selectedTypes.add(projectType.getId().toString());
            }
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            reportYear = calendar.get(Calendar.YEAR);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            backPath = (String) parameters.get("backPath");
        }
    }

    private List<ProjectType> getTypesForFilter() {
        List<ProjectType> result = new ArrayList<ProjectType>(2);
        result.add(ProjectType.FRAME);
        result.add(ProjectType.PRESALE_B);
        return  result;
    }

    public List<FrameReport> getItems() {
        return items;
    }

    public String doBack() {
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void doFilter() {
        LogSimple.debug(this, "doFilter executed");
        items = frameReportsDBLoader.getReportData(reportYear, selectedQuarters, selectedTypes);
    }


    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public Map getParameters() {
        return parameters;
    }

    public void setParameters(Map parameters) {
        this.parameters = parameters;
    }

    public String getLocalUuid() {
        return localUuid;
    }

    public void setLocalUuid(String localUuid) {
        this.localUuid = localUuid;
    }

    public Integer getReportYear() {
        return reportYear;
    }

    public void setReportYear(Integer reportYear) {
        this.reportYear = reportYear;
    }

    public List<String> getSelectedQuarters() {
        return selectedQuarters;
    }

    public void setSelectedQuarters(List<String> selectedQuarters) {
        this.selectedQuarters = selectedQuarters;
    }

    public List<String> getSelectedTypes() {
        return selectedTypes;
    }

    public void setSelectedTypes(List<String> selectedTypes) {
        this.selectedTypes = selectedTypes;
    }

    public List<ProjectType> getProjectTypes() {
        return projectTypes;
    }

    public void setProjectTypes(List<ProjectType> projectTypes) {
        this.projectTypes = projectTypes;
    }
}
