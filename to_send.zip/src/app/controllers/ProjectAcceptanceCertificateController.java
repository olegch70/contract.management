package app.controllers;

import app.dto.AcceptanceCertificate;
import app.dto.Income;
import app.loaders.AcceptanceCertificateDBLoader;
import app.loaders.IncomeDBLoader;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 18:30
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectAcceptanceCertificateController")
@ViewScoped
public class ProjectAcceptanceCertificateController extends AbstractTableController {

    private static final String VIEW_NAME = "projectAcceptanceCertificate";

    @EJB
    private AcceptanceCertificateDBLoader acceptanceCertificateDBLoader;
    @EJB
    private PersonsDBLoader personsDBLoader;
    private String infoForDeletingRow;

    public static String doCallByProjectId(AbstractController caller, Long projectId){
        return doCall(VIEW_NAME, caller, projectId);
    }

    public String add() {
        return EditAcceptanceCertificateController.doCallAdd(this, parentId);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return EditAcceptanceCertificateController.doCallEditByRecordId(this, parentId, getSelectedItem().getId());
    }

    private AcceptanceCertificate getSelectedItem() {
        return (AcceptanceCertificate) getSelectedItemSuper();
    }

    @Override
    protected void deleteInternal() {
        acceptanceCertificateDBLoader.delete(getSelectedItem().getId());
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public String getInfoForDeletingRow() {
        return infoForDeletingRow;
    }

    public List<AcceptanceCertificate> getCertificates() {
        List<AcceptanceCertificate> certificates = acceptanceCertificateDBLoader.loadByFieldValue("projectId", parentId, new String[]{"startDate", "summa"});
        addCreatorFIO(certificates);
        return certificates;
    }

    private void addCreatorFIO(List<AcceptanceCertificate> certificates) {
        for(AcceptanceCertificate row: certificates) {
            if(row.getCreatorId() != null) {
                String creatorFIO = personsDBLoader.getById(row.getCreatorId()).getFIO();
                row.setCreatorFIO(creatorFIO);
            } else {
                row.setCreatorFIO("-");
            }
        }
    }

    public boolean isAllowModify() {
        if( ! authorisedUser.isAllowModify()) {
            return false;
        }

        if( authorisedUser.getCurrentUserIsRootOrFinanceManager()) {
            return true;
        }
        return false;
    }

    public boolean isAllowAdd() {
        if( ! authorisedUser.isAllowModify()) {
            return false;
        }

        if( authorisedUser.getCurrentUserIsRootOrFinanceManager() ) {
            return true;
        }
        return false;
    }
}
