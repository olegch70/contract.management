package app.controllers;

import app.dto.Direction;
import app.dto.ExpenseType;
import app.helpers.LogSimple;
import app.loaders.DirectionDBLoader;
import app.loaders.ExpenseTypeDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 14:36
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editExpenseTypeController")
@ViewScoped
public class EditExpenseTypeController {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    @EJB
    private ExpenseTypeDBLoader expenseTypeDBLoader;
    private String backPath;
    private String command;
    private Long expenseTypeId;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private ExpenseType expenseType;

    public void initModel(){
        System.out.println("initModel() in editGradeController started");
        localUuid = getConversationUuid()+"_editGradeController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("expenseTypeId", expenseTypeId);
            System.out.println("parameters.put(expenseTypeId = " + expenseTypeId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            if(command.equals("add")){
                expenseType = new ExpenseType();
            } else {
                expenseType = expenseTypeDBLoader.getById(expenseTypeId);
            }
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            System.out.println("parameters expenseTypeId = " + parameters.get("expenseTypeId"));
            expenseTypeId = (Long) parameters.get("expenseTypeId");
            backPath = (String) parameters.get("backPath");
        }

        System.out.println("initModel() in editGradeController finished");
    }

    public String save() {
        LogSimple.debug(this, "��� ������ = " + expenseType.getName());
        if(command.equals("add")){
            expenseTypeDBLoader.addNew(expenseType);
        } else {
            System.out.println("saveGrade called");
            expenseTypeDBLoader.update(expenseType);
            System.out.println("saveGrade updated");
        }
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String doBack() {
        removeModelFromSession();
        System.out.println("backPath on doBack = " + backPath);
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public Long getExpenseTypeId() {
        return expenseTypeId;
    }

    public void setExpenseTypeId(Long expenseTypeId) {
        this.expenseTypeId = expenseTypeId;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public ExpenseType getExpenseType() {
        return expenseType;
    }

    public void setExpenseType(ExpenseType expenseType) {
        this.expenseType = expenseType;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }
}
