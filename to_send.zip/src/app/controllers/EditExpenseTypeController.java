package app.controllers;

import app.dto.Direction;
import app.dto.ExpenseType;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.loaders.DirectionDBLoader;
import app.loaders.ExpenseTypeDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 14:36
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editExpenseTypeController")
@ViewScoped
public class EditExpenseTypeController extends AbstractEditController {
    public static final String EXPENSE_TYPE_ID_KEY = "expenseTypeId";
    private static final String VIEW_NAME = "editExpenseType";
    @EJB
    private ExpenseTypeDBLoader expenseTypeDBLoader;
    private Long expenseTypeId;
    private ExpenseType expenseType;

    public void childInitModel(){
        expenseTypeId = (Long) parameters.get(EXPENSE_TYPE_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        if(command.equals(COMMAND_ADD)){
                expenseType = new ExpenseType();
            } else {
                expenseType = expenseTypeDBLoader.getById(expenseTypeId);
            }
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCallAdd(AbstractController caller){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long id){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(EXPENSE_TYPE_ID_KEY, id);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        return result;
    }

    public String save() {
        if(command.equals(COMMAND_ADD)){
            expenseTypeDBLoader.addNew(expenseType);
        } else {
            expenseTypeDBLoader.update(expenseType);
        }
        return doBack();
    }

    public ExpenseType getExpenseType() {
        return expenseType;
    }

    public void setExpenseType(ExpenseType expenseType) {
        this.expenseType = expenseType;
    }
}
