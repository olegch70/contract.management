package app.controllers;

import app.beans.CurrentDateBean;
import app.dto.CalendarDay;
import app.dto.DayType;
import app.helpers.CalendarXMLParser;
import app.helpers.dto.CalendarPartModel;
import app.helpers.dto.MonthStatistic;
import app.loaders.CalendarDBLoader;
import app.loaders.CommonDbLoader;
import app.loaders.DayTypesDBLoader;
import org.primefaces.event.FileUploadEvent;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="calendarListController")
@ViewScoped
public class CalendarListController extends AbstractTableControllerGeneric<CalendarDay> {
    private static final String VIEW_NAME = "calendarList";
    public static final String WORK_DAY = "�������";
    public static final String PRE_HOLIDAY = "���������������";
    public static final String HOLIDAY = "��������";
    public static final String ENTITY_FIELD_NAME = "date";
    @EJB
    private CalendarDBLoader calendarDBLoader;
    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private DayTypesDBLoader dayTypesDBLoader;
    @Inject
    private CalendarXMLParser calendarXMLParser;
    private CalendarPartModel model;
    private List<CalendarDay> items;
    private Integer year;
    private boolean state;

    protected CommonDbLoader getDbLoader() {
        return calendarDBLoader;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public void doSave() {
        saveNewOrUpdateDataFromParsedXML(items);
        items = null;
        state = false;
    }

    public boolean isSaveAfterDownload() {
        return state;
    }

    private void saveNewOrUpdateDataFromParsedXML(List<CalendarDay> daysParsedFromXML) {
        for(CalendarDay day: daysParsedFromXML) {
            final List<CalendarDay> loadedCalendarDayListWithSingleValue =
                    calendarDBLoader.loadByFieldValue(ENTITY_FIELD_NAME, day.getDate());
            CalendarDay loadedDay = new CalendarDay();
            if(loadedCalendarDayListWithSingleValue != null && loadedCalendarDayListWithSingleValue.size() > 0) {
                loadedDay = loadedCalendarDayListWithSingleValue.get(0); //�������, ��� ������ ���� ��������� ���������
                // � ������ ������ �������� 1 �������
            }
            if(loadedDay != null) {
                if(loadedDay.getType() != day.getType()) {
                    loadedDay.setType(day.getType());
                    calendarDBLoader.update(loadedDay);
                }
            } else {
                day.setId(null); //�������� �������� ��������� id
                calendarDBLoader.addNew(day);
            }
        }
    }

    public List<Integer> getYears() {
        List<Integer> years = new LinkedList<Integer>();
        Integer startYear = getYear() - 3;
        for(int i = 0; i < 15; i++) {
            years.add(startYear);
            startYear++;
        }
        return years;
    }

    public List<MonthStatistic> getMonthsInfo() {
        List<MonthStatistic> result = calculateMonthsStatistic(getCalendarDays());
        return result;
    }

    private List<MonthStatistic> calculateMonthsStatistic(List<CalendarDay> calendarDays) {
       List<MonthStatistic> result = new ArrayList<MonthStatistic>(12);
        String[] monthNames = new String[] {"���", "���", "���", "���", "���", "���", "���", "���", "���", "���", "���", "���"};
        for(int i=0; i < 12; i++) {
            MonthStatistic month = new MonthStatistic();
            month.setMonthName(monthNames[i]);
            result.add(month);
        }
        Calendar calendar = Calendar.getInstance();
        for(CalendarDay day: calendarDays) {
            calendar.setTime(day.getDate());
            MonthStatistic month = result.get(calendar.get(Calendar.MONTH));
            debug("dayTypeId = " + day.getType() + " dayTypeName = " + day.getTypeName());
            if(DayType.WORKDAY.getName().equals(day.getTypeName())) {
                month.setWorkdays(month.getWorkdays()+1);
            } else {
                month.setHolidays(month.getHolidays()+1);
            }
            month.setTotal(month.getTotal()+1);
        }
        return result;
    }


    public static String doCall(AbstractController caller){
        return doCall(VIEW_NAME, caller, null);
    }

    public List<CalendarDay> getCalendarDays() {
        if(items == null) {
            items = calendarDBLoader.getCalendarDaysByYear(getYear());
            debug("items class = " + items.getClass().getCanonicalName());
        }
        addTypeNames(items);
        return items;
    }

    public void onYearChange() {
        if(year !=null && !year.equals("")) {
            items = calendarDBLoader.getCalendarDaysByYear(getYear());
        }
    }

    public void handleFileUpload(FileUploadEvent event) {
        debug("handleFileUpload executed");
        debug("fileName =  "+ event.getFile().getFileName());
        FacesMessage msg = new FacesMessage("Succesful", event.getFile().getFileName() + " is uploaded.");
        FacesContext.getCurrentInstance().addMessage(null, msg);
        try {
            InputStream is = event.getFile().getInputstream();
            try {
                model = calendarXMLParser.modelFromInputStream(is);
                items = fillCalendarListFromParsedXMLModel(model);
                state = true;
            } finally {
                is.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private List<CalendarDay> fillCalendarListFromParsedXMLModel(CalendarPartModel model) {
        Map<Date, String> dates = model.getDates();
        Map<Date, CalendarDay> sortedDates = new TreeMap<Date, CalendarDay>();

        long cnt = -1;
        for(Map.Entry<Date, String> row: dates.entrySet()) {

            CalendarDay day = new CalendarDay();
            day.setId(cnt--);
            day.setDate(row.getKey());
            if(WORK_DAY.equals(row.getValue()) || PRE_HOLIDAY.equals(row.getValue())) {
                day.setType(1);
            } else {
                day.setType(2);
            }
            sortedDates.put(row.getKey(), day);
        }
        List<CalendarDay> result = new ArrayList<CalendarDay>(sortedDates.size());
        result.addAll(sortedDates.values());
        return result;
    }

    private void addTypeNames(List<CalendarDay> calendarDays) {
        for(CalendarDay row: calendarDays) {
            if(row.getType() != 0) {
                row.setTypeName((dayTypesDBLoader.getById(row.getType())).getName());
            }
        }
    }

    @Override
    protected String add() {
        return EditCalendarDayController.doCallAdd(this);
    }

    @Override
    protected String edit() {
        return EditCalendarDayController.doCallEditByRecordId(this, getSelectedItemSuper().getId());
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getYear() {
        if(year == null) {
            Calendar calendar = Calendar.getInstance();
            year = calendar.get(Calendar.YEAR);
        }
        return year;
    }
}
