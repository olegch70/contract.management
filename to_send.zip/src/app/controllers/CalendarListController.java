package app.controllers;

import app.dto.CalendarDay;
import app.dto.Direction;
import app.loaders.CalendarDBLoader;
import app.loaders.CommonDbLoader;
import app.loaders.DayTypesDBLoader;
import app.loaders.DirectionDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="calendarListController")
@ViewScoped
public class CalendarListController extends AbstractTableControllerGeneric<CalendarDay> {
    private static final String VIEW_NAME = "calendarList";
    @EJB
    private CalendarDBLoader calendarDBLoader;
    @EJB
    private DayTypesDBLoader dayTypesDBLoader;

    protected CommonDbLoader getDbLoader() {
        return calendarDBLoader;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCall(AbstractController caller){
        return doCall(VIEW_NAME, caller, null);
    }

    public List<CalendarDay> getCalendarDays() {
        List<CalendarDay> result = getItems();
        addTypeNames(result);
        return result;
    }

    private void addTypeNames(List<CalendarDay> calendarDays) {
        for(CalendarDay row: calendarDays) {
            if(row.getType() != 0) {
                row.setTypeName((dayTypesDBLoader.getById(row.getType())).getName());
            }
        }
    }

    @Override
    protected String add() {
        return EditCalendarDayController.doCallAdd(this);
    }

    @Override
    protected String edit() {
        return EditCalendarDayController.doCallEditByRecordId(this, getSelectedItemSuper().getId());
    }

}
