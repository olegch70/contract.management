package app.controllers;

import app.beans.IdentificableById;
import app.beans.UiTableHelper;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.helpers.ViewNavigationHelper;
import app.loaders.CommonDbLoader;
import org.primefaces.context.RequestContext;

import javax.faces.bean.ManagedProperty;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.05.14
 * Time: 13:24
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractTableController extends AbstractController {
//    protected static final String CALL_PARAMETERS_KEY = "callParametersKey";
    @ManagedProperty(value = UiTableHelper.UI_TABLE_HELPER_EL)
    protected UiTableHelper uiTableHelper;
    protected Long parentId;
    private boolean allowToDelete;

    @Override
    protected void loadValuesFromModel() {
        super.loadValuesFromModel();
        if(callParameters != null && callParameters instanceof Long) {
            parentId = (Long) callParameters;
        }
        uiTableHelper.connectToDataHolder(parameters);
    }

    protected void childInitModel() {
        if(null != getDbLoader()) {
            getUiTableHelper().calledFromInit(parameters, getDbLoader());
        }
    }

    protected CommonDbLoader getDbLoader() {
        return null;
    }

    public static Long getParentIdValue(SessionDataHolder sessionDataHolder, String conversationUuid, String modelName) {
        Map parameters = ViewNavigationHelper.getModel(sessionDataHolder, conversationUuid, modelName);
        return (Long) parameters.get(CALL_PARAMETERS_KEY);
    }

    public UiTableHelper getUiTableHelper() {
        return uiTableHelper;
    }

    public void setUiTableHelper(UiTableHelper uiTableHelper) {
        this.uiTableHelper = uiTableHelper;
    }

    protected void deleteInternal() {
        if(null != getDbLoader()) {
            getDbLoader().delete(getSelectedItemSuper().getId());
        }
    }

    public void delete() {
        if(!allowToDelete) {
            return;
        }
        allowToDelete = false;
        try {
            deleteInternal();
            uiTableHelper.deleteItemFromFiltered(uiTableHelper.getSelectedItem());
            UIMessages.displayMessage("������ �������.");
        } catch (Exception e) {
            UIMessages.displayErrorMessage("�� ������� ������� ������.");
            debug("uiTableHelper = "+uiTableHelper);
            LogSimple.error(this, e);
        }
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
        allowToDelete = true;
    }

    protected boolean checkSelectedAndDisplayWarning() {
        if(getSelectedItemSuper() != null) {
            return true;
        }
        displayUIMessage("�������� ������� ������.");
        return false;
    }

    protected IdentificableById getSelectedItemSuper() {
        return getUiTableHelper().getSelectedItem();
    }

    public String doAdd() {
        return add();
    }

    public String doEdit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        String result = edit();
        if(result != null && ! result.trim().isEmpty()) {
            uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItemSuper());
        }
        return result;
    }

    protected String edit() {
        return null;
    }

    protected String add() {
        return null;
    }


}
