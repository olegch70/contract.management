package app.controllers;

import app.dto.CalendarDay;
import app.dto.DayType;
import app.dto.Direction;
import app.helpers.ViewNavigationHelper;
import app.loaders.CalendarDBLoader;
import app.loaders.DayTypesDBLoader;
import app.loaders.DirectionDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 14:36
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editCalendarDayController")
@ViewScoped
public class EditCalendarDayController extends AbstractEditController {
    public static final String CALENDAR_DAY_ID_KEY = "calendarDayId";
    private static final String VIEW_NAME = "editCalendarDay";
    @EJB
    private CalendarDBLoader calendarDBLoader;
    @EJB
    private DayTypesDBLoader dayTypesDBLoader;
    private CalendarDay calendarDay;
    private Long calendarId;

    public void childInitModel(){
        calendarId = (Long) parameters.get(CALENDAR_DAY_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        if(command.equals(COMMAND_ADD)){
            calendarDay = new CalendarDay();
        } else {
            calendarDay = calendarDBLoader.getById(calendarId);
        }
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public List<DayType> getTypes() {
        List<DayType> result = new LinkedList<DayType>();
        result.addAll(dayTypesDBLoader.getAll());
        return result;
    }

    public static String doCallAdd(AbstractController caller){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long id){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(CALENDAR_DAY_ID_KEY, id);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        return result;
    }

    public String save() {
        if(command.equals(COMMAND_ADD)){
            calendarDBLoader.addNew(calendarDay);
        } else {
            calendarDBLoader.update(calendarDay);
        }
        return doBack();
    }

    public CalendarDay getCalendarDay() {
        return calendarDay;
    }

    public void setCalendarDay(CalendarDay calendarDay) {
        this.calendarDay = calendarDay;
    }
}
