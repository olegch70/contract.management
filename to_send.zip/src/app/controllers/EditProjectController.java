package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.dto.*;
import app.helpers.LogSimple;
import app.loaders.*;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 18:21
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean (name= "editProjectController")
@ViewScoped
public class EditProjectController {

    private Long projectId;
    private Project project;
    //@ManagedProperty(value="#{projectsDBLoader}")
    @EJB
    private ProjectsDBLoader projectsDBLoader;
    @EJB
    private ClientsDBLoader clientsDBLoader;

    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    //@ManagedProperty(value="#{projectTypeDBLoader}")
    @EJB
    private ProjectTypeDBLoader projectTypeDBLoader;
    @EJB
    private PersonsDBLoader personsDBLoader;
    //@ManagedProperty(value="#{projectContractsDBLoader}")
    @EJB
    private ProjectContractsDBLoader projectContractsDBLoader;
    @EJB
    private ContractStatusDBLoader contractStatusDBLoader;
    @EJB
    private ProjectTeamDBLoader projectTeamDBLoader;

    private String backPath;
    private Date projectStartDate;
    private String conversationUuid;
    private Map parameters;
    private String localUuid;
    private String command;
    private String projectTypeName;
    private Long clientId;
    private Long projectTypeId;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    private AuthorisedUserViewScoped authorisedUser;

    public void initModel() throws AbortProcessingException {
        System.out.println("initModel() in EditProjectController started");
        localUuid = getLocalUuid(getConversationUuid());
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);

        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("clientId", clientId);
            parameters.put("projectTypeId", projectTypeId);
            parameters.put("projectId", projectId);
            parameters.put("command",command);
            System.out.println("parameters.put(projectId = " + projectId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            if(isAddMode()){
                project = new Project();
                project.setType(projectTypeId);
                project.setClientId(clientId);
                project.setClient(clientsDBLoader.getById(clientId));
                project.setStatusId(ContractStatus.ACTIVE.getId());
            }
            if(command.equals("edit")){
                project = projectsDBLoader.getById(projectId);
                LogSimple.debug(this, "project = " + project);
                project.setProjectContracts(null);
            }
            parameters.put("project", project);
            saveModelInSession();
        } else {
//            LogSimple.debug(this, "parameters ! = null "+parameters);
//            LogSimple.debug(this, "parameters projectId class = " + parameters.get("projectId").getClass());
//            LogSimple.debug(this, "parameters projectId = "+parameters.get("projectId"));
            clientId = (Long) parameters.get("clientId");
            projectTypeId = (Long) parameters.get("projectTypeId");
            projectId = (Long) parameters.get("projectId");
            command = (String) parameters.get("command");
            backPath = (String) parameters.get("backPath");
            project = (Project) parameters.get("project");

        }

        LogSimple.debug(this, "initModel() in EditProjectController finished");
    }

    private static String getLocalUuid(String conversationUuid1) {
        return conversationUuid1 +"_contractEditController";
    }

    public void setProjectTypeName(String value) {
    }

    public String getProjectTypeName() {
        if(projectTypeName == null) {
            List<ProjectType> types = getTypes();
            for(ProjectType row : types) {
                if(row.getId().equals(project.getType())){
                    projectTypeName = row.getName();
                }
            }
        }
        return projectTypeName;
    }

    public BigDecimal getAssignedContractsSum() {
        prepareContractsForShow();
        return projectsDBLoader.getAssignedContractsSum(project.getProjectContracts());
    }

    public String getAssignedContractsNumbers() {
        prepareContractsForShow();
        return projectsDBLoader.getAssignedContractsNumbers(project.getProjectContracts());
    }

    private void saveModelInSession() {
        LogSimple.debug(this, "called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        LogSimple.debug(this, "called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            LogSimple.debug(this, "conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            LogSimple.debug(this, "SconversationUuid = " + conversationUuid);
        }
    }

    public List<ContractStatus> getStatuses() {
        LogSimple.debug(this, "project.getType() = " + project.getType());
        LogSimple.debug(this, "ProjectType.PRESALE_A.getId() = " + ProjectType.PRESALE_A.getId());
        List<ContractStatus> result = new LinkedList<ContractStatus>();
        if(project.getType().equals(ProjectType.PRESALE_A.getId())) {
            LogSimple.debug(this, "equals");
            result.addAll(contractStatusDBLoader.getPresaleAStatuses());
        } else {
            LogSimple.debug(this, "not equals");
            result.addAll(contractStatusDBLoader.getOnOffStatuses());
        }
        if( ! authorisedUser.isTechnicalAM() || ! authorisedUser.getCurrentUserIsRoot()) {
            result = contractStatusDBLoader.disableClosedStatus(result);
        }
        return result;
    }

    public String saveProject() {
        if(isFrameProject() || isPresaleBProject()) {
            addTotalPriceForQ4Project();
        } else {
            project.setPrice(getAssignedContractsSum());
        }
        if( ! isFrameProject()) {
            project.setNumber(getAssignedContractsNumbers());
        }
        if(command.equals("add")){
//            project.setClient(clientsDBLoader.getById(project.getClientId()));
            projectsDBLoader.addNew(project);
        } else {
            if(isNotActiveProject()) {
                projectTeamDBLoader.dropTeamList(project.getId());
                LogSimple.debug(this, "Team has been dropped in project with Id = " + project.getId());
            }
            projectsDBLoader.update(project);
        }
        LogSimple.debug(this, "update backPath = " + backPath);
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private boolean isNotActiveProject() {
        if(project.getStatusId().equals(ContractStatus.CLOSED.getId())
                || project.getStatusId().equals(ContractStatus.PAUSED.getId())) {
            return true;
        }
        return false;
    }

    private boolean isProjectPriceChanged() {
        return ! getAssignedContractsSum().equals(project.getPrice());
    }

    private boolean isProjectNumberChanged() {
        return ! getAssignedContractsNumbers().equals(project.getNumber());
    }

    private boolean isPresaleBProject() {
        return project.getType().equals(ProjectType.PRESALE_B.getId());
    }

    private boolean isFrameProject() {
        return project.getType().equals(ProjectType.FRAME.getId());
    }

    private boolean isOutstaffProject() {
        return project.getType().equals(ProjectType.OUTSTAFF.getId());
    }

    private void addTotalPriceForPresaleBProject() {
        BigDecimal price = project.getPriceQ1().add(project.getPriceQ2()).add(project.getPriceQ3()).add(project.getPriceQ4());
        project.setPrice(price);
    }

    private void addTotalPriceForQ4Project() {
        BigDecimal price = project.getPriceQ1().add(project.getPriceQ2()).add(project.getPriceQ3()).add(project.getPriceQ4());
        project.setPrice(price);
    }

    public boolean isAddMode() {
        if("add".equals(command)) {
            return true;
        }
        return false;
    }

    public String doBack() {
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToContractsPrices() {
        prepareContractsForShow();
        String resultString = "projectContractsPriceList?projectId="+projectId
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        System.out.println("resultString = " + resultString);
        return resultString;
    }

    private static final String PROJECT_CONTRACTS = "projectContracts";

    private void prepareContractsForShow() {
        if(project.getProjectContracts() == null) {
            project.setProjectContracts(projectContractsDBLoader.loadByProjectId(projectId));
            System.out.println(project.getProjectContracts());
        }
    }

    public static List<ProjectContract> getProjectContractsFromContext(String conversationUuid,
                                                                       SessionDataHolder sessionDataHolder){
        Project project = getProjectFromContext(conversationUuid, sessionDataHolder);
        return project.getProjectContracts();
    }

    public static Project getProjectFromContext(String conversationUuid,
                                                                       SessionDataHolder sessionDataHolder){
        String localUuid = getLocalUuid(conversationUuid);
        Map parameters = (Map) sessionDataHolder.get(localUuid);
        Project project = (Project) parameters.get("project");
        return project;
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setTypes(List<ProjectType> types) {
    }

    public List<ProjectType> getTypes() {
        return projectTypeDBLoader.getAll();
    }

    public List<Person> getPersons() {
        final List<Person> result = personsDBLoader.getPM();
        if( ! authorisedUser.getCurrentUserIsRoot() ) {
            if( ! authorisedUser.getPerson().getId().equals(getProject().getClient().getTechnicalAM())) {
            final List<Person> currentUserList = new ArrayList<Person>(1);
            currentUserList.add(personsDBLoader.getById(authorisedUser.getPerson().getId()));
            result.retainAll(currentUserList);
            }
        }
        return result;
    }

    public ProjectTypeDBLoader getProjectTypeDBLoader() {
        return projectTypeDBLoader;
    }

    public void setProjectTypeDBLoader(ProjectTypeDBLoader projectTypeDBLoader) {
        this.projectTypeDBLoader = projectTypeDBLoader;
    }

    public ProjectContractsDBLoader getProjectContractsDBLoader() {
        return projectContractsDBLoader;
    }

    public void setProjectContractsDBLoader(ProjectContractsDBLoader projectContractsDBLoader) {
        this.projectContractsDBLoader = projectContractsDBLoader;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String getCommand() {
        return command;
    }

    public ProjectsDBLoader getProjectsDBLoader() {
        return projectsDBLoader;
    }

    public void setProjectsDBLoader(ProjectsDBLoader projectsDBLoader) {
        this.projectsDBLoader = projectsDBLoader;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        System.out.println("projectContractId = " + projectId);
        return projectId;
    }

    public Date getProjectStartDate() {
        return projectStartDate;
    }

    public void setProjectStartDate(Date projectStartDate) {
        this.projectStartDate = projectStartDate;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Project getProject() {
       /* if (contract == null) {

            contract = projectsDBLoader.getContractById(Integer.getInteger(contractId));
            System.out.println("contract = " + contract);
        }
        */
        return project;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }


    public void setProjectTypeNeedChoose(boolean projectTypeNeedChoose) {
    }

    public boolean isProjectTypeNeedChoose() {
        if(project.getType() == null){
            return true;
        }
        return false;
    }

    public void projectTypeChoosed() {
    }

    public boolean isPriceQShowed() {
        return ProjectType.PRESALE_B.getId().equals(project.getType());
    }

    public void setPriceQShowed(boolean value) {

    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setProjectTypeId(Long projectTypeId) {
        this.projectTypeId = projectTypeId;
    }

    public Long getProjectTypeId() {
        return projectTypeId;
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public boolean isNotAllowedToEditFields() {
        if(authorisedUser.getPerson().isFinManager()) {
            return true;

        }
        return false;
    }

    public boolean isNotAllowedToEditFieldsQ() {
        if(authorisedUser.getCurrentUserIsRoot()) {
            // root ����� ������ �������� Q-���
            return false;
        }
        boolean result = isNotAllowedToEditFields();
        if(result) {
            // FinManager �� ����� ������ ����� Q-���
            return result;
        }

        if("add".equals(command) ) {
            // ������ �������� Q-��� ����� ��� ���������� 
            return false;
        }

        return true;
    }

    public boolean isNotAllowedToEditFte() {
        if(authorisedUser.getCurrentUserIsRoot()) {
            // root ����� ������ �������� FTE
            return false;
        }
        boolean result = isNotAllowedToEditFields();
        if(result) {
            // FinManager �� ����� ������ FTE
            return result;
        }

        if("add".equals(command) ) {
            // ������ �������� FTE ����� ��� ����������
            return false;
        }

        return true;
    }
}
