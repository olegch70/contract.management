package app.controllers;

import app.beans.RootChecker;
import app.controllers.system.PersonProjectsTimelineController;
import app.dto.Person;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.loaders.CommonDbLoader;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 16:09
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "personsListController")
@ViewScoped
public class PersonsListController extends AbstractTableControllerGeneric<Person> {

    public static final String FILTER_KEY_SHOW_GRADE_ONE = "showGradeOne";
    public static final String FILTER_KEY_SHOW_DISMISSED = "showDismissed";
    private static final String VIEW_NAME = "personsList";

    @EJB
    private PersonsDBLoader personsDBLoader;

    @EJB
    private PersonFieldsCryptor personFieldsCryptor;

    @EJB
    private RootChecker rootChecker;

    private List<Person> listOfItems;

    @Override
    protected CommonDbLoader getDbLoader() {
        return personsDBLoader;
    }

    public List<Person> getItems() {
        if(listOfItems == null ) {
            listOfItems = personsDBLoader.getAll(new String[]{"lastName", "firstName", "middleName"});
            if(getShowDismissed()) {
                listOfItems = getDismissedPersons(listOfItems);
            } else {
                listOfItems = getWorkingPersons(listOfItems);
            }

            if(getShowGradeOne() ) {
                listOfItems = getGradeOnePersons(listOfItems);
            }
            personsDBLoader.enrichModel(listOfItems);
        }
        return listOfItems;
    }

    public static String doCall(AbstractController caller){
        return doCall(VIEW_NAME, caller, null);
    }

    protected String add() {
        return EditPersonController.doCallAdd(this);
    }

    protected String edit() {
        return EditPersonController.doCallEditByRecordId(this, getSelectedItemSuper().getId());
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    private List<Person> getWorkingPersons(List<Person> listOfItems) {
        return filterList(listOfItems, new Filter<Person>() {
            public boolean accept(Person person) {
                return person.getDismissalDate() == null;
            }
        });
    }

    private List<Person> getDismissedPersons(List<Person> listOfItems) {
        return filterList(listOfItems, new Filter<Person>() {
            public boolean accept(Person person) {
                return person.getDismissalDate() != null;
            }
        });
    }

    private List<Person> filterList(List<Person> listOfItems, Filter filter) {
        List<Person> result = new LinkedList<Person>();
        for(Person person: listOfItems) {
            if(filter.accept(person)) {
                result.add(person);
            }
        }
        return result;
    }

    private List<Person> getGradeOnePersons(List<Person> listOfItems) {
        final Person fakePerson = new Person();
        return filterList(listOfItems, new Filter<Person>() {
            public boolean accept(Person person) {
                try {
                    fakePerson.setId(person.getId());
                    fakePerson.setGrade2(person.getGrade2());
                    personFieldsCryptor.decryptGrade(fakePerson);
                    return fakePerson.getGrade().compareTo(ConstantsHelper.BIGDECIMAL_ONE) == 0;
                } catch (Throwable t) {
                    LogSimple.debug(this, "getGradeOnePersons. personId = "+ person.getId()+ " grade2 => "+ person.getGrade2()+ " grade => "+ fakePerson.getGrade());
                }
                return true;
            }
        });
    }

    public void showPersonsWithoutGrade() {
        listOfItems = getPersonsWithoutGrade(getItems());
    }

    private List<Person> getPersonsWithoutGrade(List<Person> listOfItems) {
        final Person fakePerson = new Person();

        return filterList(listOfItems, new Filter<Person>() {
            public boolean accept(Person person) {
                fakePerson.setId(person.getId());
                fakePerson.setDayPrice2(person.getDayPrice2());
                personFieldsCryptor.decryptDayPrice(fakePerson);
                if (fakePerson.getDayPrice().compareTo(ConstantsHelper.BIGDECIMAL_GRADE_BIG) == 0) {
                    return true;
                }
                return false;
            }
        });
    }

    public String doTimeLineShow(){
        PersonProjectsTimelineController.doCall(conversationUuid, getSelectedItemSuper().getId());
        return null;
    }

    public String editUser() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return EditUserController.doCallEditUserByRecordId(this, getSelectedItemSuper().getId());
    }

    public boolean getCurrentUserIsRoot() {
        return rootChecker.isRoot(authorisedUser.getPerson());
    }

    public void setShowDismissed(Boolean value ) {
        uiTableHelper.getFieldFilter().put(FILTER_KEY_SHOW_DISMISSED, value);
        reloadFromDb();
    }

    public Boolean getShowDismissed() {
        return getBooleanFilterValue(FILTER_KEY_SHOW_DISMISSED);
    }

    public void setShowGradeOne(Boolean value) {
        uiTableHelper.getFieldFilter().put(FILTER_KEY_SHOW_GRADE_ONE, value);
        reloadFromDb();
    }

    public Boolean getShowGradeOne() {
        return getBooleanFilterValue(FILTER_KEY_SHOW_GRADE_ONE);
    }

    private Boolean getBooleanFilterValue(String filterKey) {
        Object result = uiTableHelper.getFieldFilter().get(filterKey);
        return getBooleanSafe(result);
    }

    private void reloadFromDb() {
        listOfItems = null;
        getItems();
    }

    private Boolean getBooleanSafe(Object result) {
        if(result == null) {
            return Boolean.FALSE;
        }

        if( ! (result instanceof Boolean) ) {
            return false;
        }

        return (Boolean) result;
    }

    private interface Filter<Class> {
        boolean accept(Class item);
    }
}
