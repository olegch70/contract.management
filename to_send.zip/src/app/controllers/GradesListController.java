package app.controllers;

import app.beans.UiTableHelper;
import app.controllers.utils.DataTableUIValuesHolder;
import app.dto.Grade;
import app.loaders.GradeDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "gradesListController")
@ViewScoped
public class GradesListController {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;

    @EJB
    private GradeDBLoader gradeDBLoader;

    private String backPath;
    private String localUuid;
    private String conversationUuid;
    private Map parameters;
    private List<Grade> items;

    @ManagedProperty(value = UiTableHelper.UI_TABLE_HELPER_EL)
    private UiTableHelper uiTableHelper;

    public void initModel() {
        localUuid = getConversationUuid()+"_gradesListController";
        parameters = (Map) sessionDataHolder.get(localUuid);

        if(parameters == null) {
            System.out.println("parameters = = null");
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            uiTableHelper.saveValues(parameters);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            backPath = (String) parameters.get("backPath");
            uiTableHelper.restoreValues(parameters);
            uiTableHelper.processItemsToRefresh(gradeDBLoader);
        }
    }

    public UiTableHelper getUiTableHelper() {
        return uiTableHelper;
    }

    public void setUiTableHelper(UiTableHelper uiTableHelper) {
        this.uiTableHelper = uiTableHelper;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    private void saveModelInSession() {
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(uiTableHelper.getSelectedItem() != null) {
            return true;
        }

        displayUIMessage("�������� ������� ������.");
        return false;
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        return currentPath;
    }

    public String doBack() {
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        uiTableHelper.registerItemForRefreshItemInFuture(uiTableHelper.getSelectedItem());
        return "editGrade?command=edit"
                +"&backPath="+getCurrentPath()
                +"&gradeId="+ ((Grade) uiTableHelper.getSelectedItem()).getId()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String add() {
        return "editGrade?command=add"
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public List<Grade> getItems() {
        if(items == null) {
            items = gradeDBLoader.getAll(new String[]{"code"});
            gradeDBLoader.enrichModel(items);
        }
        return items;
    }
}
