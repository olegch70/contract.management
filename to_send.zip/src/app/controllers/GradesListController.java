package app.controllers;

import app.dto.Grade;
import app.loaders.CommonDbLoader;
import app.loaders.GradeDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 13:44
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "gradesListController")
@ViewScoped
public class GradesListController extends AbstractTableControllerGeneric<Grade> {
    private static final String VIEW_NAME = "gradesList";
    @EJB
    private GradeDBLoader gradeDBLoader;
    private List<Grade> items;

    @Override
    protected CommonDbLoader getDbLoader() {
        return gradeDBLoader;
    }


    public List<Grade> getItems() {
        if(items == null) {
            items = gradeDBLoader.getAll(new String[]{"code"});
            gradeDBLoader.enrichModel(items);
        }
        return items;
    }

    public static String doCall(AbstractController caller){
        return doCall(VIEW_NAME, caller);
    }

    @Override
    protected String add() {
        return EditGradeController.doCallAdd(this);
    }

    @Override
    protected String edit() {
        return EditGradeController.doCallEditByRecordId(this, getSelectedItemSuper().getId());
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }
}
