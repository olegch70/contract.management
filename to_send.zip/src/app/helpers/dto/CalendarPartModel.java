package app.helpers.dto;

import java.util.Date;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 18.08.14
 * Time: 10:47
 * To change this template use File | Settings | File Templates.
 */
public class CalendarPartModel {
    private Date startDate;
    private Date endDate;
    private Map<Date, String> dates;

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Map<Date, String> getDates() {
        return dates;
    }

    public void setDates(Map<Date, String> dates) {
        this.dates = dates;
    }
}
