package app.helpers.dto;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.08.14
 * Time: 10:59
 * To change this template use File | Settings | File Templates.
 */
public class MonthStatistic {

    private String monthName;
    private int workdays;
    private int holidays;
    private int total;

    public String getMonthName() {
        return monthName;
    }

    public void setMonthName(String monthName) {
        this.monthName = monthName;
    }

    public int getWorkdays() {
        return workdays;
    }

    public void setWorkdays(int workdays) {
        this.workdays = workdays;
    }

    public int getHolidays() {
        return holidays;
    }

    public void setHolidays(int holidays) {
        this.holidays = holidays;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
