package app.helpers.dto;

/**
 * Created by oleg on 06.08.2014.
 */
public class CalculateDetailModel {
    private String title;
    private StringBuilder descriptionBuffer = new StringBuilder();
    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void decriptionAdd(String s) {
        descriptionBuffer.append(s);
    }

    public void decriptionAddNl(String s) {
        decriptionAdd(s);
        decriptionAdd("<br/>");
    }

    public String getDescription() {
        return descriptionBuffer.toString();
    }
}
