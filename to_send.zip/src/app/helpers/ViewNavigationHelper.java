package app.helpers;

import app.controllers.SessionDataHolder;

import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.05.14
 * Time: 11:08
 * To change this template use File | Settings | File Templates.
 */

public class ViewNavigationHelper {

    public static final String CALL_MARKER_KEY = "callMarker";
    private static final String CALL_URL_KEY = "callURL";
    private static final String VIEW_NAME_REMOVE_MODEL_ON_ERROR_KEY = "viewNameForRemoveModelOnError";
    public static final String ACTUAL_MARKER_KEY = "actualMarker";
    private static final String ACTUAL_URL_KEY = "actualURL";
    public static final String BACK_PATH_KEY = "backPath";
    public static final String MAIN_MENU_VIEW_NAME = "menuPage";
    private static final String MODEL_FOR_CONVERSATION = "modelForConversation";
    public static final String MESSAGE_DISPLAYED_ON_START_KEY = "MessageDisplayedOnStart";
    public static final String VIEW_NAME_FOR_DELETE_MODEL = "viewNameForDeleteModel";

    public static String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        return facesContext.getViewRoot().getViewId();
    }

    public static String prepareForCallAndGetURL(ViewNavigationHelperModel vnhm, String viewName, Map[] paramModel) {
        return prepareForCallAndGetURL(vnhm, viewName, paramModel, null);
    }
    public static String prepareForCallAndGetURL(ViewNavigationHelperModel vnhm, String viewName, Map[] paramModel, String modelName) {
        return prepareForCallAndGetURL(vnhm.getSessionDataHolder(),
                vnhm.getConversationUuid(), viewName, paramModel, modelName);
    }

    public static String prepareForCallAndGetURL(SessionDataHolder sessionDataHolder, String conversationUuid, String viewName) {
        return prepareForCallAndGetURL(sessionDataHolder, conversationUuid, viewName, null);
    }

    public static String prepareForCallAndGetURL(SessionDataHolder sessionDataHolder, String conversationUuid, String viewName, Map[] modelForReturn) {
        return prepareForCallAndGetURL(sessionDataHolder, conversationUuid, viewName, modelForReturn, null);
    }
    public static String prepareForCallAndGetURL(SessionDataHolder sessionDataHolder, String conversationUuid, String viewName, Map[] modelForReturn, String modelName) {
        if(modelName == null) {
            modelName = viewName;
        }
        Map model = initializeModel(sessionDataHolder, conversationUuid, modelName);

        String backPath = ViewNavigationHelper.getCurrentPath();
        String callMarker = UUID.randomUUID().toString();
        final String resultURL = viewName + "?" + ViewNavigationHelperModel.CONVERSATION_UUID_PARAMETER_NAME + "=" + conversationUuid
                + "&" + ViewNavigationHelperModel.CALL_MARKER_PARAMETER_NAME + "=" + callMarker
                + "&faces-redirect=true";
        model.put(BACK_PATH_KEY, backPath);

        registerExpectableMarkerAndURL(sessionDataHolder, conversationUuid, callMarker, resultURL);
        Map conversationModel = getModelForConversation(sessionDataHolder, conversationUuid);
        conversationModel.put(VIEW_NAME_REMOVE_MODEL_ON_ERROR_KEY, modelName);
        if(modelForReturn != null && modelForReturn.length > 0) {
            modelForReturn[0] = model;
        }

        return resultURL;
    }

    private static void registerExpectableMarkerAndURL(SessionDataHolder sessionDataHolder, String conversationUuid,
                                                       String callMarker, String resultURL) {
        Map model = getModelForConversation(sessionDataHolder, conversationUuid);
        model.put(CALL_MARKER_KEY, callMarker);
        model.put(CALL_URL_KEY, resultURL);
    }

    private static void registerViewNameForDeleteModel(SessionDataHolder sessionDataHolder, String conversationUuid,
                                                       String modelNameForDelete) {
        Map model = getModelForConversation(sessionDataHolder, conversationUuid);
        model.put(VIEW_NAME_FOR_DELETE_MODEL, modelNameForDelete);
    }

    private static Map initializeModel(SessionDataHolder sessionDataHolder, String conversationUuid, String modelName) {
        final String key = getLocalUUID(conversationUuid, modelName);
        Map model = (Map) sessionDataHolder.get(key);
        if(model == null) {
            model = new HashMap();
            sessionDataHolder.add(key, model);
        }
        return model;
    }

    private static void removeModel(SessionDataHolder sessionDataHolder, String conversationUuid, String modelName) {
        final String key = getLocalUUID(conversationUuid, modelName);
        sessionDataHolder.remove(key);
    }

    public static String doBack(ViewNavigationHelperModel model, String modelName) {
        String conversationUuid = model.getConversationUuid();
        if(conversationUuid == null) {
            return MAIN_MENU_VIEW_NAME+"?faces-redirect=true";
        }
        final Map mapModel = getModel(model.getSessionDataHolder(), conversationUuid, modelName);
        if(mapModel == null) {
            return MAIN_MENU_VIEW_NAME+"?faces-redirect=true";
        }
        String backPath = (String) mapModel.get(BACK_PATH_KEY);
        if(backPath == null) {
            return MAIN_MENU_VIEW_NAME+"?faces-redirect=true";
        }
        registerViewNameForDeleteModel(model.getSessionDataHolder(), conversationUuid, modelName);

        String callMarker = UUID.randomUUID().toString();
        final String resultURL = backPath + "?conversationUuid=" + conversationUuid
                + "&" + ViewNavigationHelperModel.CALL_MARKER_PARAMETER_NAME + "=" + callMarker
                + "&faces-redirect=true";
        registerExpectableMarkerAndURL(model.getSessionDataHolder(), conversationUuid, callMarker, resultURL);

//        debug("doBack => "+resultURL);
        return resultURL;
    }

    public static Map getModelForConversation(SessionDataHolder sessionDataHolder, String conversationUuid) {
        return initializeModel(sessionDataHolder, conversationUuid, MODEL_FOR_CONVERSATION);
    }

    public static void removeModelForConversation(SessionDataHolder sessionDataHolder, String conversationUuid) {
        final String key = getLocalUUID(conversationUuid, MODEL_FOR_CONVERSATION);
        sessionDataHolder.remove(key);
    }

    public static Map getModel(ViewNavigationHelperModel viewNavigationHelperModel, String modelName) {
        return getModel(viewNavigationHelperModel.getSessionDataHolder(), viewNavigationHelperModel.getConversationUuid(), modelName);
    }

    public static Map getModel(SessionDataHolder sessionDataHolder, String conversationUuid, String modelName) {
        String localUUID = getLocalUUID(conversationUuid, modelName);
        Map result = (Map) sessionDataHolder.get(localUUID);
        if(result == null) {
            debug("getModel return NULL."
                    +'\n'+"sessionDataHolder => "+sessionDataHolder
                    +'\n'+"conversationUuid => " + conversationUuid
                    +'\n'+"modelName => " + modelName
                    +'\n'+"localUUID => " + localUUID
            );
        }
        return result;
    }

    public static String getLocalUUID(String conversationUuid, String modelName) {
        return conversationUuid+"_"+modelName;
    }

    public static boolean checkValidCall(ViewNavigationHelperModel viewNavigationHelperModel) {
        String conversationUuidFromURL = viewNavigationHelperModel.getConversationUuid();
        String callMarkerFromURL = viewNavigationHelperModel.getCallMarker();
        if(conversationUuidFromURL == null || callMarkerFromURL == null) {
            return false;
        }
        Map model = getModelForConversation(viewNavigationHelperModel.getSessionDataHolder(), conversationUuidFromURL);
        if(model == null) {
            return false;
        }
        String callMarker = (String) model.get(CALL_MARKER_KEY);
        if(callMarker == null) {
            callMarker = (String) model.get(ACTUAL_MARKER_KEY);
        }
        return callMarkerFromURL.equals(callMarker);
    }

    private static void debug(String msg) {
        LogSimple.debug(Thread.currentThread(), msg);
    }

    public static void redirectToMainMenu() {
        redirectTo(MAIN_MENU_VIEW_NAME);
    }

    public static void redirectToActualPage(SessionDataHolder sessionDataHolder, String conversationUuid, String msg) {
        Map model = getModel(sessionDataHolder, conversationUuid, MODEL_FOR_CONVERSATION);
        if(model == null) {
            redirectToMainMenu();
            return;
        }
        String actualURL = (String) model.get(ACTUAL_URL_KEY);
        model.remove(CALL_MARKER_KEY);
        model.remove(CALL_URL_KEY);
        model.put(MESSAGE_DISPLAYED_ON_START_KEY, msg);
        String viewNameForDelete = (String) model.remove(VIEW_NAME_REMOVE_MODEL_ON_ERROR_KEY);
        if(viewNameForDelete != null) {
            removeModel(sessionDataHolder, conversationUuid, viewNameForDelete);
        }
        if(actualURL == null) {
//            debug("model for conversation = " + conversationUuid + " model = " + model);
            redirectToMainMenu();
            removeModelForConversation(sessionDataHolder, conversationUuid);
            return;
        }
//        debug("actualURL for redirect = " + actualURL);
        redirectToWOFacesRedirect(actualURL);
    }

    public static String getAndRemoveMessageForInit(SessionDataHolder sessionDataHolder, String conversationUuid) {
        Map model = getModelForConversation(sessionDataHolder, conversationUuid);
        return (String) model.remove(MESSAGE_DISPLAYED_ON_START_KEY);
    }

    public static void redirectToWOFacesRedirect(String viewName) {
        FacesContext fc = FacesContext.getCurrentInstance();
        ConfigurableNavigationHandler nav =
                (ConfigurableNavigationHandler) fc.getApplication().getNavigationHandler();
        nav.performNavigation(viewName);
    }

    public static void redirectTo(String viewName) {
        redirectToWOFacesRedirect(viewName + "?faces-redirect=true");
    }

    public static void setExpectableAsActual(SessionDataHolder sessionDataHolder, String conversationUuid) {
//        debug("setExpectableAsActual called");
        Map model = getModelForConversation(sessionDataHolder, conversationUuid);
        String callMarker = (String) model.remove(CALL_MARKER_KEY);
        String callURL = (String) model.remove(CALL_URL_KEY);
        if(callMarker != null) {
            model.put(ACTUAL_MARKER_KEY, callMarker);
            model.put(ACTUAL_URL_KEY, callURL);
        }
        String viewNameForDelete = (String) model.remove(VIEW_NAME_FOR_DELETE_MODEL);
        if(viewNameForDelete != null) {
            removeModel(sessionDataHolder, conversationUuid, viewNameForDelete);
        }
        model.remove(VIEW_NAME_REMOVE_MODEL_ON_ERROR_KEY);
//        debug("conversation = " + conversationUuid + " model = " + model);
    }
}
