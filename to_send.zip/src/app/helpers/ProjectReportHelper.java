package app.helpers;

import app.dto.ProjectReport;

import java.util.List;

/**
 * author: Oleg Chamlay
 * Date: 22.04.14
 * Time: 19:39
 */
public class ProjectReportHelper {
    public static ProjectReport createProjectReport(String caption) {
        ProjectReport result;
        result = new ProjectReport();
        result.setCaption(caption);
        result.setActualCurrentFTE(0d);
        result.setActualAverageFTE(0d);
        result.setWorkDays(0d);
        result.setWorkingPersons(0d);
        result.setPlanFTE(0d);
        result.setPrice(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setTeamExpense(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setTeamExpenseFromYearStart(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setExpense(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setExpenseFromYearStart(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setIncome(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setIncomeFromYearStart(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setGradeAverage(0d);
        result.setGradeSum(0d);
        result.setCountPersonInTeam(0d);
        result.setEfficiencyProgn(ConstantsHelper.BIGDECIMAL_ZERO);
//        result.setEndDatePlan(new Date());
        return result;
    }

    public static void accumulate(ProjectReport accumulator, ProjectReport addingPart) {
        accumulate(accumulator, addingPart, true);
    }

    public static void accumulate(ProjectReport accumulator, ProjectReport addingPart, boolean calcActualAverageFTE) {
        accumulator.incCountForAverage(addingPart.getCountPersonInTeam());
        accumulator.setGradeSum(accumulator.getGradeSum() + addingPart.getGradeSum());

        accumulator.setActualCurrentFTE(accumulator.getActualCurrentFTE() + addingPart.getActualCurrentFTE());
        accumulator.setWorkDays(accumulator.getWorkDays() + addingPart.getWorkDays());

        if(addingPart.getWorkingPersons() != null){
            accumulator.setWorkingPersons(accumulator.getWorkingPersons() + addingPart.getWorkingPersons());
        }
        accumulator.setPlanFTE(accumulator.getPlanFTE() + addingPart.getPlanFTE());
        accumulator.setPrice(accumulator.getPrice().add(addingPart.getPrice()));

        accumulator.setTeamExpense(accumulator.getTeamExpense().add(addingPart.getTeamExpense()));
        accumulator.setTeamExpenseFromYearStart(accumulator.getTeamExpenseFromYearStart().add(addingPart.getTeamExpenseFromYearStart()));

        accumulator.setExpense(accumulator.getExpense().add(addingPart.getExpense()));
        accumulator.setExpenseFromYearStart(accumulator.getExpenseFromYearStart().add(addingPart.getExpenseFromYearStart()));

        accumulator.setIncome(accumulator.getIncome().add(addingPart.getIncome()));
        accumulator.setIncomeFromYearStart(accumulator.getIncomeFromYearStart().add(addingPart.getIncomeFromYearStart()));

        accumulator.setEfficiencyProgn(accumulator.getEfficiencyProgn().add(addingPart.getEfficiencyProgn()));
        if(calcActualAverageFTE ) {
            if(accumulator.getWorkDays() != 0) {
                accumulator.setActualAverageFTE(accumulator.getWorkingPersons()/ accumulator.getWorkDays());
            }
        }


        if(accumulator.getEndDatePlan() == null) {
            accumulator.setEndDatePlan(addingPart.getEndDatePlan());
        } else {
            if(addingPart.getEndDatePlan() != null && accumulator.getEndDatePlan().before(addingPart.getEndDatePlan())) {
                accumulator.setEndDatePlan(addingPart.getEndDatePlan());
            }
        }
        setGradeOverage(accumulator);
    }

    public static ProjectReport accumulateItog(List<ProjectReport> reportItems) {
        ProjectReport result = ProjectReportHelper.createProjectReport("");
        for (ProjectReport item: reportItems) {
            accumulate(result, item);
        }
        setGradeOverage(result);
        return result;
    }

    private static void setGradeOverage(ProjectReport result) {
        if(result.getCountPersonInTeam() != 0) {
            result.setGradeAverage(result.getGradeSum() / result.getCountPersonInTeam());
        } else {
            result.setGradeAverage(0);
        }
    }
}
