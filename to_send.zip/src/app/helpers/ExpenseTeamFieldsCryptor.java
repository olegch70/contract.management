package app.helpers;

import app.dto.ExpenseTeam;

import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 * author: Oleg Chamlay
 * Date: 03.03.14
 * Time: 13:28
 */

@Stateless
public class ExpenseTeamFieldsCryptor {
//    private static BigDecimal scale;
//    static {
//        scale = new BigDecimal(10000);
//        scale.setScale(4);
//    }

    @EJB
    private EncryptorDayPrice encryptor;

    /**
    * Decrypt summa after loading.
    */
   public void decryptDayPrice(ExpenseTeam expenseItem) {
       if (expenseItem.getPrice2() != null) {
//           LogSimple.debug(this, "decryptPrice");
           expenseItem.setPrice(
                   encryptor.decryptToBigDecimal(expenseItem.getPersonId(), expenseItem.getPrice2(),
                           PersonFieldsCryptor.scale));
       }
   }
   /**
    * Encrypt summa before persisting
    */
//   public void encryptDayPrice(ExpenseTeam expenseItem) {
//       expenseItem.setPrice2(null);
//       final BigDecimal dayPrice = expenseItem.getPrice21day();
//       LogSimple.debug(this, "encryptPrice called. expenseItem.getPrice21day() => "+ dayPrice);
//       if (dayPrice != null) {
//           final Long id = expenseItem.getId();
//           final BigInteger encryptedDayPrice = encryptor.encryptBigDecimalToBigInteger(id, dayPrice, scale);
//           expenseItem.setPrice2(
//                   encryptedDayPrice
//           );
//       }
//   }

    public void decryptFields(ExpenseTeam expenseItem) {
        decryptDayPrice(expenseItem);
    }

//    public void encryptFields(ExpenseTeam expenseItem) {
//        encryptDayPrice(expenseItem);
//    }
}
