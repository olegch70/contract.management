package app.helpers;

/**
 * author: Oleg Chamlay
 * Date: 23.01.14
 * Time: 14:20
 */
public class SafeEquals {
    public static boolean equals(Object obj1, Object obj2) {
        if( obj1 == null && obj2 == null) return true;
        if( obj1 == null && obj2 != null ) return false;
        if( obj1 != null && obj2 == null ) return false;
        return obj1.equals(obj2);
    }
}
