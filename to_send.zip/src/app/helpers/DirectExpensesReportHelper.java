package app.helpers;

import app.dto.DirectExpenseReport;
import app.dto.ProjectReport;

import java.math.BigDecimal;
import java.util.List;

/**
 * author: Oleg Chamlay
 * Date: 22.04.14
 * Time: 19:39
 */
public class DirectExpensesReportHelper {
    public static BigDecimal accumulateItog(List<DirectExpenseReport> reportItems) {
        BigDecimal result = new BigDecimal(0);
        for (DirectExpenseReport item: reportItems) {
            result = result.add(item.getPrice());
        }
        return result;
    }
}
