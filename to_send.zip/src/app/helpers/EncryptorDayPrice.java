package app.helpers;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import javax.ejb.Stateless;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
 * author: Oleg Chamlay
 * Date: 03.03.14
 * Time: 13:40
 */

@Stateless
public class EncryptorDayPrice {

    private Cipher cipherEncrypt;
    private Cipher cipherDecrypt;
    // ToDo ����� ���� �� �������� ���������
    private static byte[] keyBytes = new byte[]{-37, 3, -59, -39, 116, -73, -42, -14, 16, 39};

    public EncryptorDayPrice() {
      // ToDo ����� �������� �� �������� ���������
        final String CIPHER_ALG = "Blowfish";
        try {
            cipherEncrypt = Cipher.getInstance(CIPHER_ALG);
            cipherDecrypt = Cipher.getInstance(CIPHER_ALG);
        } catch (NoSuchAlgorithmException ex) {
            logError(ex);
        } catch (NoSuchPaddingException ex) {
            logError(ex);
        }
        try {
            SecretKey _secretKey
                        = new SecretKeySpec(keyBytes, 0, keyBytes.length, CIPHER_ALG);
            cipherEncrypt.init(Cipher.ENCRYPT_MODE, _secretKey);
            cipherDecrypt.init(Cipher.DECRYPT_MODE, _secretKey);
        } catch (InvalidKeyException ex) {
            throw new RuntimeException(ex);
        }
    }

    private Cipher getCipherEncrypt() {
        return cipherEncrypt;
    }

    private Cipher getCipherDecrypt() {
        return cipherDecrypt;
    }


    public BigInteger encryptBigDecimalToBigInteger(Long key, BigDecimal value, BigDecimal scale) {
        BigDecimal bdValue = value;
        if(scale != ConstantsHelper.BIGDECIMAL_ONE) {
            bdValue = bdValue.multiply(scale);
        }
        final BigInteger biValue = bdValue.toBigInteger();

        final byte[] bValue = encrypt_part1(biValue, key);

        final BigInteger result = ecrypt_part2(bValue);

        return result;
    }

    public BigDecimal decryptToBigDecimal(final Long key, final BigInteger encryptedValue, final BigDecimal scale) {
        byte bValue[] = bigIntegerToByteArray(encryptedValue);
        bValue = padByteArrayTo_8(bValue, encryptedValue);

        byte[] arrDecryptedValue;
        byte[] arrKey;
        try {
            Cipher cipherDecrypt = getCipherDecrypt();
            arrDecryptedValue = callCipher_doFinalDecrypt(cipherDecrypt, bValue);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }

        arrKey = bigIntegerToByteArray(BigInteger.valueOf(key.longValue()));
        xorArrays(arrDecryptedValue, arrKey);

        BigDecimal result = new BigDecimal(byteArrayToBigInteger(arrDecryptedValue));
        result.setScale(scale.scale(), RoundingMode.HALF_UP);
        if(scale != ConstantsHelper.BIGDECIMAL_ONE) {
            result = result.divide(scale, scale.scale(), RoundingMode.HALF_UP);
        }
        return result;
    }

    private byte[] padByteArrayTo_8(final byte[] bValue, final BigInteger encryptedValue) {
        if(bValue.length < 8) {
            final byte[] tmp = new byte[8];
            int maxI = 8 - bValue.length;
            byte fillValue;
            if(encryptedValue.signum() < 0) {
                fillValue = -1;
            } else {
                fillValue = 0;
            }
            for(int i = 0; i < maxI; i++) {
                tmp[i] = fillValue;
            }
            System.arraycopy(bValue, 0,
                              tmp, maxI,
                    bValue.length);
            return tmp;
        } else {
            return bValue;
        }
    }

    private byte[] encrypt_part1(BigInteger biValue, Long key) {
        final byte[] bValue = bigIntegerToByteArray(biValue);
        final byte[] keyAsBytes = bigIntegerToByteArray(BigInteger.valueOf(key.longValue()));
        xorArrays(bValue, keyAsBytes);
        return bValue;
    }

    private BigInteger ecrypt_part2(byte[] bValue) throws RuntimeException {
        byte[] arrEncryptedValue;
        try {
            Cipher cipher = getCipherEncrypt();
            arrEncryptedValue = callCipher_doFinalEncrypt(cipher, bValue);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
        final BigInteger result = byteArrayToBigInteger(arrEncryptedValue);
        return result;
    }

    private byte[] bigIntegerToByteArray(BigInteger biValue) {
        final byte[] result = biValue.toByteArray();
        return result;
    }

    private BigInteger byteArrayToBigInteger(byte[] bytes) {
        return new BigInteger(bytes);
    }

    private void xorArrays(final byte[] bValue, final byte[] arrKey) {
        int maxIndex = Math.min(bValue.length, arrKey.length);
        for(int i=0; i < maxIndex; i++) {
            bValue[i] = (byte) (bValue[i] ^ arrKey[i]);
        }
    }

    private byte[] callCipher_doFinalDecrypt(Cipher cipher, byte[] bValue) throws BadPaddingException, IllegalBlockSizeException {
        return cipher.doFinal(bValue);
    }

    private byte[] callCipher_doFinalEncrypt(Cipher cipher, byte[] bValue) throws BadPaddingException, IllegalBlockSizeException {
        return cipher.doFinal(bValue);
    }

    private void log(String msg) {
        LogSimple.debug(this, msg);
    }

    private void logError(Throwable ex) {
        LogSimple.error(this, ex);
    }
}
