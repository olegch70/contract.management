package app.helpers;

import app.dto.DirectExpenseReport;
import app.dto.IncomeReport;

import java.math.BigDecimal;
import java.util.List;

/**
 * author: Oleg Chamlay
 * Date: 22.04.14
 * Time: 19:39
 */
public class IncomesReportHelper {
    public static BigDecimal accumulateItog(List<IncomeReport> reportItems) {
        BigDecimal result = new BigDecimal(0);
        for (IncomeReport item: reportItems) {
            result = result.add(item.getPrice());
        }
        return result;
    }
}
