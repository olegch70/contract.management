package app.helpers;
 
import java.math.BigDecimal;

/**
 * author: Oleg Chamlay
 * Date: 13.03.14
 * Time: 15:47
 */
public class ConstantsHelper {
    public static final Double DOUBLE_ZERO = new Double(0);
    public static final Double DOUBLE_HUNDRED = new Double(100);
    public static final BigDecimal BIGDECIMAL_ZERO = new BigDecimal(0);
    public static final BigDecimal BIGDECIMAL_ONE;
    public static final BigDecimal BIGDECIMAL_HUNDRED = new BigDecimal(100);
    public static final BigDecimal BIGDECIMAL_GRADE_BIG = new BigDecimal(9999999999d);
    /////��������� ��� ������ ��������
    public static final String DIRECT_EXPENSE_TEAM_PREMIUM = "premium";
    public static final String DIRECT_EXPENSE_TEAM_OVERTIME = "overtime";

    static {
        BIGDECIMAL_ONE = new BigDecimal("1.0");
        BIGDECIMAL_ONE.setScale(0);
    }
}
