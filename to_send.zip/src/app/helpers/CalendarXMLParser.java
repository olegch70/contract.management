package app.helpers;

import app.helpers.dto.CalendarPartModel;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.inject.Named;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 18.08.14
 * Time: 10:45
 * To change this template use File | Settings | File Templates.
 */
@Named
public class CalendarXMLParser {

    public CalendarPartModel modelFromInputStream(InputStream is) {
        try {
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setNamespaceAware(true);

            DocumentBuilder builder = builderFactory.newDocumentBuilder();
            Document xmlDocument = builder.parse(new InputSource(is));

            XPathFactory factory = XPathFactory.newInstance();
            XPath xPath = factory.newXPath();

            XPathExpression xPathExpressionBeginDate = xPath.compile("/calendar/@BeginDate");
            String beginDate = (String) xPathExpressionBeginDate.evaluate(xmlDocument, XPathConstants.STRING);
            debug("beginDate = " + beginDate);
            XPathExpression xPathExpressionEndDate = xPath.compile("/calendar/@EndDate");
            String endDate = (String) xPathExpressionEndDate.evaluate(xmlDocument, XPathConstants.STRING);
            debug("endDate = " + endDate);

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);

            CalendarPartModel model = new CalendarPartModel();
            model.setStartDate(getDateFromString(beginDate, calendar));
            model.setEndDate(getDateFromString(endDate, calendar));

            XPathExpression xPathExpressionDateRecords = xPath.compile("/calendar/Record");
            NodeList nodeList =  (NodeList) xPathExpressionDateRecords.evaluate(xmlDocument, XPathConstants.NODESET);
//
            Map<Date, String> workDates = new HashMap<Date, String>();
            for (int index = 0; index < nodeList.getLength(); index++) {
                NamedNodeMap attributes = nodeList.item(index).getAttributes();
                final String sDate = attributes.getNamedItem("date").getNodeValue();
                final String dateType = attributes.getNamedItem("dateType").getNodeValue();
//                debug(sDate);
//                debug(dateType);
                workDates.put(getDateFromString(sDate, calendar), dateType);
            }

            calendar.setTime(model.getStartDate());
            int holidaysCount = 0;
            int workdaysCount = 0;
            while( ! model.getEndDate().before(calendar.getTime())) {
                if(workDates.get(calendar.getTime()) == null) {
                    workDates.put(calendar.getTime(), "��������");
                    debug("�������� => " + calendar.getTime());
                    holidaysCount++;
                } else {
                    workdaysCount++;
                }
                calendar.add(Calendar.DAY_OF_MONTH, 1);
            }

            model.setDates(workDates);
            debug("workdays = " + workdaysCount + " holidays = " + holidaysCount);

            return model;
        } catch(Throwable e) {
            throw new RuntimeException(e);
        }

    }

    private Date getDateFromString(String stringDate, Calendar calendar) {
        calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(stringDate.substring(0,2)));
        calendar.set(Calendar.MONTH, Integer.parseInt(stringDate.substring(3,5))-1);
        calendar.set(Calendar.YEAR, Integer.parseInt(stringDate.substring(6,10)));
        return calendar.getTime();
    }

    private void debug(String msg) {
        LogSimple.debug(this, msg);
    }


}
