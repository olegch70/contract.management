package app.helpers;

/**
 * author: Oleg Chamlay
 * Date: 03.03.14
 * Time: 11:31
 */
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 * author: Oleg Chamlay
 * Date: 27.02.14
 * Time: 9:55
 */
public class SumCipher {
    private static Key key;

    private static byte[] padByteArrayTo_8(byte[] bSumma, BigInteger encryptedSumma) {
        if(bSumma.length < 8) {
            byte[] tmp = new byte[8];
            int maxI = 8 - bSumma.length;
            byte fillValue;
            if(encryptedSumma.signum() < 0) {
                fillValue = -1;
            } else {
                fillValue = 0;
            }
            for(int i = 0; i < maxI; i++) {
                tmp[i] = fillValue;
            }
            System.arraycopy(bSumma, 0,
                              tmp, maxI,
                    bSumma.length);
            bSumma = tmp;
        }
        return bSumma;
    }

    private static void xorArrays(byte[] bSumma, byte[] arrKey) {
        int maxIndex = Math.min(bSumma.length, arrKey.length);
        for(int i=0; i < maxIndex; i++) {
            bSumma[i] = (byte) (bSumma[i] ^ arrKey[i]);
        }
    }

    private static byte[] callCipher_doFinalDecrypt(Cipher cipher, byte[] bSumma) throws BadPaddingException, IllegalBlockSizeException {
        return cipher.doFinal(bSumma);
    }

    private static byte[] callCipher_doFinalEncrypt(Cipher cipher, byte[] bSumma) throws BadPaddingException, IllegalBlockSizeException {
        return cipher.doFinal(bSumma);
    }

    private static Cipher cipherEncrypt;
    private static Cipher cipherDecrypt;

    private static SecretKey secretKey;
    static {
        try {
            cipherEncrypt = Cipher.getInstance("Blowfish");
            cipherDecrypt = Cipher.getInstance("Blowfish");
            System.out.println("cipherEncrypt == cipherDecrypt"+(cipherEncrypt == cipherDecrypt));
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(SumCipher.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(SumCipher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static Cipher getCipherEncrypt() throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException {
        return cipherEncrypt;
    }

    private static Cipher getCipherDecrypt() throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException {
//        setSecretKey(_secretKey);
        return cipherDecrypt;
    }

    public static void setSecretKey(SecretKey _secretKey) {
        if( secretKey != _secretKey ) {
            try {
                cipherEncrypt.init(Cipher.ENCRYPT_MODE, _secretKey);
                cipherDecrypt.init(Cipher.DECRYPT_MODE, _secretKey);
                secretKey = _secretKey;
            } catch (InvalidKeyException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    private static BigInteger ecrypt_part2(byte[] bSumma) throws RuntimeException {
        byte[] arrEncryptedSumma;
        try {
            Cipher cipher = getCipherEncrypt();
            arrEncryptedSumma = callCipher_doFinalEncrypt(cipher, bSumma);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
        final BigInteger result = byteArrayToBigInteger(arrEncryptedSumma);
        return result;
    }

    private static byte[] encrypt_part1(BigInteger summa, Long key) {
        byte[] bSumma;
        bSumma = bigIntegerToByteArray(summa);
        byte[] keyAsBytes = bigIntegerToByteArray(BigInteger.valueOf(key.longValue()));
        xorArrays(bSumma, keyAsBytes);
        return bSumma;
    }

    private Key getKey() {
        return key;
    }

    public void setKey(Key key) {
        this.key = key;
    }

    static public Key generateKey(long init) {
        System.out.println("init => "+ init + Long.toBinaryString(init) );
        int intInit = 0;
        long i448 = 448;        // 0b1_1100_0000
        final long mask8 = 248; // 0b  1111_1000
        int i32 = 0x20; // 0b10_0000
        final long mask3 = 0x7; // 0b0111
        // 0b1111_1111_1111_1111  �������� ��������� init
        // 0b1111_1111_1111_1000 - ����� ��� ������� ����� - ��������� 8
        // 0b0000_0001_1100_0000 - ������������ ����� 448
        // 0b0000_0001_1111_1000 - ���������� ����� �����

        for(int i = 0; i < 21 /* 64/3 */; i++) {
            if( (init & mask3) != 0 ) {
                break;
            }
            init = init >> 3;
        }
        init = init & (i448 | mask8);
        if(init > i448) {
            init = init - i448;
        }

        if(init < i32) {
          init = init + i32;
        }

        init = init + i32;
        init = init & (i448 | mask8);


        intInit = (int) init;
        System.out.println("init => "+ init + " result " + intInit+ " " +Integer.toBinaryString(intInit));
        KeyGenerator keyGenerator = null;

        try {
            keyGenerator = KeyGenerator.getInstance("Blowfish");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        keyGenerator.init(intInit);
        SecretKey secretKey = keyGenerator.generateKey();
        return secretKey;
    }


    private static byte[] keyBytes = new byte[]{-37, 3, -59, -39, 116, -73, -42, -14, 16, 39};

    private static final SecretKey _secretKey
            = new SecretKeySpec(keyBytes, 0, keyBytes.length, "Blowfish");

    public static SecretKey getSecretKey() {
        return _secretKey;
    }

    /**
     * ���������� ����� � �������������� �������������� ���������� (������� ����������� ����� ������)
     *
     * @param key - ���������� ���� ������ - ������������ �������� �� ����������
     * @param summa - ����� - �������  -9999999999999999 (16 ������)
     *                        ��������  9999999999999999 (16 ������)
     *                                  1234567890123456
     * @return �������������� ����� - ����� 20 ������ ( ������� ������ "�����" )
     */
    public static BigInteger encrypt(Long key, BigInteger summa) {
//        SecretKey secretKey = getSecretKey();
//        log("key "+ secretKey.getAlgorithm()+ " "+ Arrays.toString(secretKey.getEncoded()));
//        log("summa for encrypt "+ summa+ " bytes "+ Arrays.toString(bSumma)
//                + "( "+bSumma.length+" )");

        byte bSumma[];
        bSumma = encrypt_part1(summa, key);

        BigInteger result = ecrypt_part2(bSumma);

        return result;
    }

    /**
     * ����������� �������������� �����
     * @param key ���������� ���� ������ - ������������ �������� �� ����������
     * @param encryptedSumma    - ����� ������� ���������� ������������
     * @return
     */
    public static BigInteger decrypt(Long key, BigInteger encryptedSumma) {
//        SecretKey secretKey = getSecretKey();
        byte bSumma[] = bigIntegerToByteArray(encryptedSumma);
        bSumma = padByteArrayTo_8(bSumma, encryptedSumma);

        byte[] arrDecryptedSumma;
        byte[] arrKey;
        try {
            Cipher cipherDecrypt = getCipherDecrypt();
            arrDecryptedSumma = callCipher_doFinalDecrypt(cipherDecrypt, bSumma);
        } catch (Throwable e) {
            logg("summa for decrypt "+ encryptedSumma + " bytes "+ Arrays.toString(bSumma));
            throw new RuntimeException(e);
        }

        arrKey = bigIntegerToByteArray(BigInteger.valueOf(key.longValue()));
        xorArrays(arrDecryptedSumma, arrKey);

        final BigInteger result = byteArrayToBigInteger(arrDecryptedSumma);
        return result;
    }

    private static void log(String s) {
//        logg(s);
    }

    private static void logg(String s) {
        System.out.println(s);
    }

    public static byte[] bigIntegerToByteArray(BigInteger summa) {
        byte[] result = summa.toByteArray();
        return result;
    }

    public static BigInteger byteArrayToBigInteger(byte[] bytes) {
        return new BigInteger(bytes);
    }
}
