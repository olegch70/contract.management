package app.helpers;

import app.dto.Client;

/**
 * Created by oleg on 16.05.14.
 */
public class ClientKoeffs {
    public static double getTeamKoeff(Client client) {
        return 1 + client.getTeamPercent()/100d;
    }

    public static double getContractKoeff(Client client) {
        return 1 - client.getContractsPercent()/100d;
    }
}
