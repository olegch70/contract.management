package app.helpers;

import java.io.InputStream;

/**
 * Created by oleg on 17.08.2014.
 */
public class CalendarXmlLoader {
    public Object[] loadFromStream(InputStream in) {
        return null;
    }
}
