package app.test.controllers;

import app.dto.Position;
import app.helpers.LogSimple;
import app.loaders.PositionDBLoader;

import javax.annotation.Resource;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;

/**
 * author: Oleg Chamlay
 * Date: 20.12.13
 * Time: 15:39
 */

@ManagedBean(name= "dbConnectController")
@ViewScoped
public class DbConnectController {
    @Resource(name="project")
    private javax.sql.DataSource projectDs;
    private String testResult = "none";

//    @Resource(name = "positionDBLoader")
    @ManagedProperty(value="#{positionDBLoader}")
    PositionDBLoader positionDBLoader;

    public PositionDBLoader getPositionDBLoader() {
        return positionDBLoader;
    }

    public void setPositionDBLoader(PositionDBLoader positionDBLoader) {
        this.positionDBLoader = positionDBLoader;
    }

    public String doTestConnect() {
        try {
            Connection conn = projectDs.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            try {
                stmt = conn.prepareStatement("select sysdate from dual");
                rs = stmt.executeQuery();
                while (rs.next()) {
                    testResult = rs.getObject(1).toString();
                }
                log("query executed");
            } finally {
                if(rs != null) {
                    rs.close();
                }
                if(stmt != null) {
                    stmt.close();
                }
                conn.close();
            }
        } catch (Throwable t) {
            testResult = t.toString();
            log(t.toString());
        }
        log("��������� �������: "+ testResult);
        return null;
    }

    public void doAddNew() {
        try {
            log("positionDBLoader.addNew(position) start");
            Position position = new Position();
            position.setName("TestPosition");
            positionDBLoader.addNew(position);
            log("positionDBLoader.addNew(position) done. position => "+ position);

            log("positionDBLoader.getAll() start");
            List<Position> positions = positionDBLoader.getAll();
            for(Position row: positions) {
                log(row.toString());
            }
            log("positionDBLoader.getAll() done");
            testResult = "ok. added => "+ position;
        } catch (Exception ex) {
            testResult = ex.toString();
            log(testResult);
        }
    }

    public void doUpdatePosition() {
        try {
            log("doUpdatePosition() start");
            List<Position> positions = positionDBLoader.getAll();
            testResult = "ok";
            for(Position row: positions) {
                log(row.toString());
                testResult += " before => " + row + "\n";
                row.setName("�������� � " + new Date());
                positionDBLoader.update(row);
                testResult += " after => " + row;
                break;
            }
            log("doUpdatePosition() done");
        } catch (Exception ex) {
            testResult = ex.toString();
            LogSimple.error(this, ex);
        }
    }

    public void doDeletePosition() {
        try {
            log("doDeletePosition() start");
            List<Position> positions = positionDBLoader.getAll();
            for(Position row: positions) {
                log(row.toString());
                positionDBLoader.delete(row.getId());
                break;
            }
            log("doDeletePosition() done");
            testResult = "ok";
        } catch (Exception ex) {
            testResult = ex.toString();
            LogSimple.error(this, ex);
        }
    }

    private void log(String s) {
        System.out.println(s);
    }

    public void setTestResult(String testResult) {
        this.testResult = testResult;
    }

    public String getTestResult() {
        return testResult;
    }
}
