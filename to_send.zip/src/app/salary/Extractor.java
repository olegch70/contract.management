package app.salary;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 28.04.14
 * Time: 12:26
 * To change this template use File | Settings | File Templates.
 */
public class Extractor {

    private int headerFioCellNum = 1;
    private int headerSumCellNum = 3;
    private int personFioCellNum = 1;
    private int personSumCellNum = 3;
    private int itogCaptionCellNum = 1;
    private int itogSumCellNum = 3;
    private int dateRowNum = 2;
    private int dateCellNum = 4;
    private SalaryModel salaryModel;
    private HSSFWorkbook workBook;
    private List<PersonSalaryDto> personsSalaryList;

    public SalaryModel extractModelFromFile(String fileName, SalaryModel salaryModel) {
        this.salaryModel = salaryModel;
        personsSalaryList = salaryModel.getPersonsSalary();
        try {
            return extractModelFromFileWithException(new FileInputStream(fileName));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public SalaryModel fillModelFromInputStream(InputStream inputStream, SalaryModel salaryModel) {
        this.salaryModel = salaryModel;
        personsSalaryList = salaryModel.getPersonsSalary();
        try {
            return extractModelFromFileWithException(inputStream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private SalaryModel extractModelFromFileWithException(InputStream inputStream) throws IOException {
        POIFSFileSystem fs = new POIFSFileSystem(inputStream);

        workBook = new HSSFWorkbook(fs);

        HSSFSheet sheet = workBook.getSheetAt(0);
        int rows = sheet.getPhysicalNumberOfRows();
        debug("Number of rows: "+rows);
        int firstRowNum = sheet.getFirstRowNum();
        int lastRowNum = sheet.getLastRowNum();
        debug("First row num: " + firstRowNum + " Last Row Num: " + lastRowNum);
        int state = 0; // 0 - ��������� ���� �� ������ �����; 1 - ��������� ������ �����; 2 - ��������� �����


        for (int r = firstRowNum; r <= lastRowNum; r++) {
            HSSFRow row = sheet.getRow(r);
            if(row == null) {
                debug("skip row "+ r);
                continue;
            }
            int cells = row.getPhysicalNumberOfCells();
            debug("number of cells in row( "+r+" ): "+cells);
            short firstCellNum = row.getFirstCellNum();
            debug("row first cell num: "+ firstCellNum);
            short lastCellNum = row.getLastCellNum();
            debug("row last cell num: "+ lastCellNum);
            if(state == 0) {
                if(isLastRowOfHeader(row)) {
                    state = 1; // 1 - ��������� ������ �����
                    continue;
                } else {
                    findDateAndFillModel(row);
                }
            }
            if(state == 1) {
                if(isLastRowOfPersonList(row)) {
                    state = 2; // 2 - ��������� ������
                    fillItogInModel(row);
                    continue;
                } else {
                    fillPersonDataInModel(row);
                }
            }
        }

        return salaryModel;
    }

    private void fillItogInModel(HSSFRow row) {
        HSSFCell cellItog = row.getCell(itogSumCellNum);
        double itog = 0;
        if(cellItog.getCellType() == Cell.CELL_TYPE_NUMERIC) {
            itog = cellItog.getNumericCellValue();
        } else if(cellItog.getCellType() == Cell.CELL_TYPE_STRING) {
            final String stringCellValue = cellItog.getStringCellValue();
            itog = setItogInModel(itog, stringCellValue);
        } else if(cellItog.getCellType() == Cell.CELL_TYPE_FORMULA) {
            FormulaEvaluator evaluator = workBook.getCreationHelper().createFormulaEvaluator();
            CellValue cellValue = evaluator.evaluate(cellItog);
            switch (cellValue.getCellType()) {
                case Cell.CELL_TYPE_NUMERIC:
                    itog = cellValue.getNumberValue();
                    break;
                case Cell.CELL_TYPE_STRING:
                    itog = setItogInModel(itog, cellValue.getStringValue());
                    break;
                default:
                    salaryModel.addMessage("��������� ��������� ����");
            }
        }
        salaryModel.setItog(new BigDecimal(itog).setScale(2, RoundingMode.HALF_UP));
    }

    private double setItogInModel(double itog, String stringCellValue) {
        try {
            itog = Double.parseDouble(stringCellValue);
        } catch(Throwable e) {
            salaryModel.addMessage("������ �������������� ����� �� ������ � ����� " + e.getMessage());
        }
        return itog;
    }

    private void fillPersonDataInModel(HSSFRow row) {
        HSSFCell cellFio = row.getCell(personFioCellNum);
        HSSFCell cellSum = row.getCell(personSumCellNum);
        PersonSalaryDto personSalaryDto = new PersonSalaryDto();
        personsSalaryList.add(personSalaryDto);
        final int actualExcelRowNum = row.getRowNum() + 1;
        CellReference sumCellReference = new CellReference(actualExcelRowNum, personSumCellNum);
        CellReference nameCellReference = new CellReference(actualExcelRowNum, personFioCellNum);
        final String actualExcelSumCellNum = sumCellReference.getCellRefParts()[2]; //������� �������� �������
        final String actualExcelNameCellNum = nameCellReference.getCellRefParts()[2]; //������� �������� �������
        debug("cellRefParts = "+sumCellReference.getCellRefParts().toString());
        if(cellFio != null) {
            final String stringCellValue = cellFio.getStringCellValue();
            if(stringCellValue.trim().length() != 0) {
                personSalaryDto.setFIO(stringCellValue.trim());
            }
        }
        if(personSalaryDto.getFIO() == null || personSalaryDto.getFIO().length() == 0) {
            personSalaryDto.addMessage("������: "+actualExcelRowNum+", �������: "+ actualExcelNameCellNum +" - ������ �������");
        }
        if(cellSum != null) {
            if(cellSum.getCellType() == Cell.CELL_TYPE_NUMERIC) {
                final double cellValue = cellSum.getNumericCellValue();
                debug("double cellValue personSumma = " + cellValue);
                personSalaryDto.setSalary(new BigDecimal(cellValue).setScale(2, RoundingMode.HALF_UP));
            } else {
                personSalaryDto.addMessage("������: "+ actualExcelRowNum +", �������: "+ actualExcelSumCellNum +" - �������� �� �������� ������");
            }
        } else {
            personSalaryDto.addMessage("������: "+actualExcelRowNum+", �������: "+actualExcelSumCellNum+" - ������ �����");
        }
    }

    private void findDateAndFillModel(HSSFRow row) {
        if(dateRowNum == row.getRowNum()) {
            HSSFCell cellDate = row.getCell(dateCellNum);
            if(cellDate != null) {
                Date date = cellDate.getDateCellValue();
                salaryModel.setDate(date);
            }
        }
    }

    private boolean isLastRowOfPersonList(HSSFRow row) {
        HSSFCell cellItog = row.getCell(itogCaptionCellNum);
        if(cellItog == null) {
            return false;
        }
        if( ! "�����:".equals(cellItog.getStringCellValue())){
            return false;
        }
        return true;
    }

    private boolean isLastRowOfHeader(HSSFRow row) {
        HSSFCell cellFio = row.getCell(headerFioCellNum);
        HSSFCell cellSum = row.getCell(headerSumCellNum);
        if(cellFio == null) {
            return false;
        }
        if(cellSum == null) {
            return false;
        }
        if("���".equals(cellFio.getStringCellValue())){
            debug("cell stringValue" + cellFio.getStringCellValue());
            debug("cell toString" + cellFio.toString());

        } else {
            return false;
        }
        if( ! "����� � ������".equals(cellSum.getStringCellValue())){
            return false;
        }
        return true;
    }

    private static void debug(String msg) {
        System.out.println(msg);
    }

    private static void debug(String msg, int r, int c) {
        debug("r = " + r + " c = " + c + " " + msg);
    }
}
