package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 26.12.13
 * Time: 9:19
 */
@Entity
@Table(name="PRJ_EXPENSES_DIRECT")
public class ExpenseDirect implements IdentificableById, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    private Long id;

    @Column(name = "PROJECT_ID")
    private Long projectId;

    @Column(name = "DATE_EXP")
    @Temporal(TemporalType.DATE)
    private Date dateExp;

    private BigDecimal summa;

    private String description;

    @ManyToOne()
    @JoinColumn(name = "EXPENSE_TYPE_ID")
    private ExpenseType expenseType;

    @ManyToOne()
    @JoinColumn(name = "INITIATOR_ID")
    private Person person;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Date getDateExp() {
        return dateExp;
    }

    public void setDateExp(Date dateExp) {
        this.dateExp = dateExp;
    }

    public BigDecimal getSumma() {
        return summa;
    }

    public void setSumma(BigDecimal price) {
        this.summa = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public ExpenseType getExpenseType() {
        return expenseType;
    }

    public void setExpenseType(ExpenseType expenseType) {
        this.expenseType = expenseType;
    }
}
