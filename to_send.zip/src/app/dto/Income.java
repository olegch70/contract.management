package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 26.12.13
 * Time: 9:19
 */
@Entity
@Table(name="PRJ_INCOME")
public class Income extends IncomeSuper {

    private static final long serialVersionUID = 1L;

    @Override
    public String toString() {
        return "Income {" + toStringInternal() + "}";
    }

}
