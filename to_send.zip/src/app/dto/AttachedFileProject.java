package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import javax.sql.rowset.serial.SerialBlob;
import java.io.Serializable;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 26.12.13
 * Time: 9:19
 */
@Entity
@Table(name="PRJ_ATTACHEDFILES_PROJECT")
public class AttachedFileProject implements IdentificableById, Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    private Long id;

    @Column(name = "PROJECT_ID")
    private Long projectId;

    @Column(name = "DATE_MODIFICATION")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateModification;

    @Column(name = "FILE_NAME")
    private String fileName;

    private String description;

    @Basic(fetch = FetchType.LAZY)
    @Lob
    private byte[] content;

    @Column(name = "CONTENT_LENGTH_BYTE")
    private int contentLengthByte;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Date getDateModification() {
        return dateModification;
    }

    public void setDateModification(Date dateModification) {
        this.dateModification = dateModification;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getContent() throws SQLException {
        return content;
    }

    public void setContent(byte[] newContent) throws SQLException {
        content = newContent;
    }

    public int getContentLengthByte() {
        return contentLengthByte;
    }

    public void setContentLengthByte(int contentLengthByte) {
        this.contentLengthByte = contentLengthByte;
    }

}
