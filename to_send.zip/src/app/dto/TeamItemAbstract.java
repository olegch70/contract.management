package app.dto;

import app.beans.IdentificableById;
import app.helpers.ConstantsHelper;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by oleg on 18.07.2014.
 */
@MappedSuperclass
public abstract class TeamItemAbstract implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy= GenerationType.IDENTITY, generator="SEQ")
    @Column(name = "ID")
    protected Long id;
    @Column(name = "PROJECT_ID")
    protected Long projectId;

    @ManyToOne()
    @JoinColumn(nullable = true, insertable = true, updatable = true, unique = true,
            name = "PERSON_ID")
    protected Person person;

    @Column(name = "LOAD_PERCENT")
    protected Double loadPercent;

    @Column(name = "CLIENT_MONTH_PRICE")
    protected BigDecimal clientMonthPrice;

    public Double getLoadPercent() {
        if(loadPercent == null) {
            return ConstantsHelper.DOUBLE_ZERO;
        }
        return loadPercent;
    }

    public void setLoadPercent(Double loadPercent) {
        this.loadPercent = loadPercent;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getPersonId() {
        if(person == null) {
            return null;
        }
        return person.getId();
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Position getPosition() {
        if( person != null ) {
            return person.getPosition();
        }
        return null;
    }

    public BigDecimal getClientMonthPrice() {
        return clientMonthPrice;
    }

    public void setClientMonthPrice(BigDecimal clientMonthPrice) {
        this.clientMonthPrice = clientMonthPrice;
    }


    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TeamItem teamItem = (TeamItem) o;
        if (!person.getId().equals(teamItem.person.getId())) return false;
        return true;
    }

    @Override
    public int hashCode() {
        return person.getId().hashCode();
    }

    public boolean equalsFull(Object o) {
        if (this == o) return true;
        if (!(o instanceof TeamItemAbstract)) return false;

        TeamItemAbstract that = (TeamItemAbstract) o;

        if (clientMonthPrice != null ? !clientMonthPrice.equals(that.clientMonthPrice) : that.clientMonthPrice != null)
            return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (loadPercent != null ? !loadPercent.equals(that.loadPercent) : that.loadPercent != null) return false;
        if (person != null ? !person.equals(that.person) : that.person != null) return false;
        if (projectId != null ? !projectId.equals(that.projectId) : that.projectId != null) return false;

        return true;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TeamItemAbstract{");
        sb.append("id=").append(id);
        sb.append(", projectId=").append(projectId);
        sb.append(", personId=").append(getPersonId());
        if(person != null) {
            sb.append(", person.FIO=").append(person.getFIO());
        }
        sb.append(", loadPercent=").append(loadPercent);
        sb.append(", clientMonthPrice=").append(clientMonthPrice);
        sb.append('}');
        return sb.toString();
    }
}
