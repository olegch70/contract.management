package app.dto.history;

import app.beans.IdentificableById;
import app.dto.ExpenseDirectFact;
import app.dto.ExpenseDirectFactSuper;
import app.dto.history.HistoryFields;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 26.12.13
 * Time: 9:19
 */
@Entity
@Table(name="PRJ_EXPENSES_DIRECT_FACT_HIST")

public class ExpenseDirectFactHistory extends ExpenseDirectFactSuper {
    private static final long serialVersionUID = 1L;

    @Embedded
    HistoryFields history;

    public HistoryFields getHistory() {
        return history;
    }

    public void setHistory(HistoryFields history) {
        this.history = history;
    }

    @Override
    public String toString() {
        return "ExpenseDirectFactHistory { " + history.toString() + ", " + toStringInternal() + "}";
    }
}
