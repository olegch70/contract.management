package app.dto.history;

import app.dto.ExpenseDirectFactSuper;
import app.dto.IncomeSuper;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * author: Oleg Chamlay
 * Date: 26.12.13
 * Time: 9:19
 */
@Entity
@Table(name="PRJ_INCOME_HIST")

public class IncomeHistory extends IncomeSuper {
    private static final long serialVersionUID = 1L;

    @Embedded
    HistoryFields history;

    public HistoryFields getHistory() {
        return history;
    }

    public void setHistory(HistoryFields history) {
        this.history = history;
    }

    @Override
    public String toString() {
        return "Income { " + history.toString() + ", " + toStringInternal() + "}";
    }
}
