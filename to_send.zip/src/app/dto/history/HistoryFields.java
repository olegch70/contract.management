package app.dto.history;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

/**
 * Created by oleg on 19.08.2014.
 */
@Embeddable
public class HistoryFields {
    @Column(name = "HISTORY_ID")
    private Long id;

    @Column(name = "HISTORY_OPERATION")
    private String operation;

    @Column(name = "HISTORY_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date operationDate;

    @Column(name = "HISTORY_PERSON_ID")
    private Long personId;

    public Long getHistoryId() {
        return id;
    }

    public void setHistoryId(Long historyId) {
        this.id = historyId;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation.getValue();
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("");
        sb.append("historyId=").append(id);
        sb.append(", historyOperation='").append(operation).append('\'');
        sb.append(", historyOperationDate=").append(operationDate);
        sb.append(", historyPersonId=").append(personId);
        return sb.toString();
    }

    public void copyFrom(HistoryFields historyFields) {
        operation = historyFields.operation;
        operationDate = historyFields.operationDate;
        personId = historyFields.personId;
    }

    public static enum Operation {
        INSERT("I", "����������"), UPDATE("U", "���������"), DELETE("D", "��������");

        private String value;
        private String description;

        private Operation(String v, String d) {
            value = v;
            description = d;
        }
        public String getValue() {
            return value;
        }

        public String getDescription() {
            return description;
        }

        public static Operation getByValue(String v) {
            if(INSERT.getValue().equals(v)) {
                return INSERT;
            }
            if(UPDATE.getValue().equals(v)) {
                return UPDATE;
            }
            if(DELETE.getValue().equals(v)) {
                return DELETE;
            }
            return null;
        }
    }

}
