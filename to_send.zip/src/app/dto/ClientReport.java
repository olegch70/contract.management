package app.dto;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 10:49
 * To change this template use File | Settings | File Templates.
 */
public class ClientReport {

    private String caption;

    private BigDecimal sumAssignedContracts;

    private BigDecimal expensesActual;

    private BigDecimal incomeActual;

    private Date lastActivityPlannedEndDate;

    private Double actualCurrentFTE;

    private Double actualMiddleFTE;

    private BigDecimal plannedIncome;

    private BigDecimal planRent;

    private Client client;

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public BigDecimal getSumAssignedContracts() {
        return sumAssignedContracts;
    }

    public void setSumAssignedContracts(BigDecimal sumAssignedContracts) {
        this.sumAssignedContracts = sumAssignedContracts;
    }

    public BigDecimal getExpensesActual() {
        return expensesActual;
    }

    public void setExpensesActual(BigDecimal expensesActual) {
        this.expensesActual = expensesActual;
    }

    public BigDecimal getIncomeActual() {
        return incomeActual;
    }

    public void setIncomeActual(BigDecimal incomeActual) {
        this.incomeActual = incomeActual;
    }

    public Date getLastActivityPlannedEndDate() {
        return lastActivityPlannedEndDate;
    }

    public void setLastActivityPlannedEndDate(Date lastActivityPlannedEndDate) {
        this.lastActivityPlannedEndDate = lastActivityPlannedEndDate;
    }

    public Double getActualCurrentFTE() {
        return actualCurrentFTE;
    }

    public void setActualCurrentFTE(Double actualCurrentFTE) {
        this.actualCurrentFTE = actualCurrentFTE;
    }

    public Double getActualMiddleFTE() {
        return actualMiddleFTE;
    }

    public void setActualMiddleFTE(Double actualMiddleFTE) {
        this.actualMiddleFTE = actualMiddleFTE;
    }

    public BigDecimal getPlannedIncome() {
        return plannedIncome;
    }

    public void setPlannedIncome(BigDecimal plannedIncome) {
        this.plannedIncome = plannedIncome;
    }

    public BigDecimal getPlanRent() {
        return planRent;
    }

    public void setPlanRent(BigDecimal planRent) {
        this.planRent = planRent;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

}
