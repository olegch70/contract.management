package app.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 16:41
 * To change this template use File | Settings | File Templates.
 */

public class ProjectReport {

    private Long type;

    private String clientName;

    private String caption;

    private String number;

    private BigDecimal price;

    private BigDecimal  pricePlanned;

    private BigDecimal  teamCost;

    private Date startDate;

    private BigDecimal expense;

    private BigDecimal teamExpense;

    private BigDecimal income;

    private Date endDatePlan;

    private BigDecimal efficiencyProgn;

    private String comment;

    private Long projectId;

    private double gradeAverage;

    private Long clientId;

    private Long directionId;

    private double workDays;

    private double workingPersons;
    private double gradeSum;
    private double countPersonInTeam;

//    @Column(name = "CLIENT_ID")
//    private Long clientId;


    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    private Long statusId;

    private double planFTE;

    private double actualAverageFTE;

    private double actualCurrentFTE;

    private List<ProjectContract> projectContracts;

    private String projectTypeName;

    private String statusName;

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getTeamCost() {
        return teamCost;
    }

    public void setTeamCost(BigDecimal teamCost) {
        this.teamCost = teamCost;
    }

    public double getActualAverageFTE() {
        return actualAverageFTE;
    }

    public void setActualAverageFTE(double actualAverageFTE) {
        this.actualAverageFTE = actualAverageFTE;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public BigDecimal getExpense() {
        return expense;
    }

    public void setExpense(BigDecimal expense) {
        this.expense = expense;
    }

    public BigDecimal getTeamExpense() {
        return teamExpense;
    }

    public void setTeamExpense(BigDecimal teamExpense) {
        this.teamExpense = teamExpense;
    }

    public BigDecimal getIncome() {
        return income;
    }

    public void setIncome(BigDecimal income) {
        this.income = income;
    }

    public Date getEndDatePlan() {
        return endDatePlan;
    }

    public void setEndDatePlan(Date endDatePlan) {
        this.endDatePlan = endDatePlan;
    }

    public BigDecimal getEfficiencyProgn() {
        return efficiencyProgn;
    }

    public void setEfficiencyProgn(BigDecimal efficiencyProgn) {
        this.efficiencyProgn = efficiencyProgn;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public List<ProjectContract> getProjectContracts() {
        return projectContracts;
    }

    public void setProjectContracts(List<ProjectContract> projectContracts) {
        this.projectContracts = projectContracts;
    }

    public Long getStatusId() {
        return statusId;
    }

    public void setStatusId(Long statusId) {
        this.statusId = statusId;
    }

    public void setCommentForDisplay(String commentForDisplay) {
    }

    public String getCommentForDisplay() {
        if(comment == null) {
            return "";
        }
        return comment.substring(0, Math.min(20, comment.length()));
    }

    public double getPlanFTE() {
        return planFTE;
    }

    public void setPlanFTE(double planFTE) {
        this.planFTE = planFTE;
    }

    public void setPlanFTE(Double planFTE) {
        if(planFTE == null) {
            this.planFTE = 0;
        } else {
            this.planFTE = planFTE.doubleValue();
        }
    }

    public String getProjectTypeName() {
        return projectTypeName;
    }

    public void setProjectTypeName(String projectTypeName) {
        this.projectTypeName = projectTypeName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getStatusName() {
        return statusName;
    }

    public BigDecimal getPricePlanned() {
        return pricePlanned;
    }

    public void setPricePlanned(BigDecimal pricePlanned) {
        this.pricePlanned = pricePlanned;
    }

    public double getGradeAverage() {
        return gradeAverage;
    }

    public void setGradeAverage(double gradeAverage) {
        this.gradeAverage = gradeAverage;
    }

    public double getActualCurrentFTE() {
        return actualCurrentFTE;
    }

    public void setActualCurrentFTE(double actualCurrentFTE) {
        this.actualCurrentFTE = actualCurrentFTE;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getDirectionId() {
        return directionId;
    }

    public void setDirectionId(Long directionId) {
        this.directionId = directionId;
    }

    public double getWorkDays() {
        return workDays;
    }

    public void setWorkDays(Double workDays) {
        this.workDays = workDays != null ? workDays.doubleValue() : 0;
    }

    public void setWorkDays(double workDays) {
        this.workDays = workDays;
    }

    public Double getWorkingPersons() {
        return workingPersons;
    }

    public void setWorkingPersons(Double workingPersons) {
        this.workingPersons = workingPersons != null ? workingPersons.doubleValue() : 0;
    }

    public void setWorkingPersons(double workingPersons) {
        this.workingPersons = workingPersons;
    }

    public double getGradeSum() {
        return gradeSum;
    }

    public void setGradeSum(double gradeSum) {
        this.gradeSum = gradeSum;
    }

    public double getCountPersonInTeam() {
        return countPersonInTeam;
    }

    public void setCountPersonInTeam(double countPersonInTeam) {
        this.countPersonInTeam = countPersonInTeam;
    }

    public void incCountForAverage(double inc) {
        this.countPersonInTeam += inc;
    }

    public BigDecimal getCurrentBalance() {
        return income.subtract(teamExpense).subtract(expense);
    }
}
