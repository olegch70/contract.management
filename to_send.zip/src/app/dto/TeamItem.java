package app.dto;

import app.beans.IdentificableById;
import app.helpers.ConstantsHelper;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:59
 * To change this template use File | Settings | File Templates.
 */

@Entity
@Table(name="PRJ_PROJECTTEAM")
@NamedQueries({
        @NamedQuery(name="ProjectTeam.getByProjectIdPersonId",
                query="select t from TeamItem t where t.person = :person and t.projectId = :projectId"
        )
})
public class TeamItem extends TeamItemAbstract {
    @Transient
    private Date attachmentPlanEndDate;

    @Transient
    private Date legionnairePlanEndDate;

    @Transient
    private boolean legionarie;

    public Date getAttachmentPlanEndDate() {
        return attachmentPlanEndDate;
    }

    public void setAttachmentPlanEndDate(Date attachmentPlanEndDate) {
        this.attachmentPlanEndDate = attachmentPlanEndDate;
    }

    public Date getLegionnairePlanEndDate() {
        return legionnairePlanEndDate;
    }

    public void setLegionnairePlanEndDate(Date legionnairePlanEndDate) {
        this.legionnairePlanEndDate = legionnairePlanEndDate;
    }

    public void setLegionarie(boolean legionarie) {
        this.legionarie = legionarie;
    }

    public boolean isLegionarie() {
        return legionarie;
    }
}
