package app.dto;

import app.beans.IdentificableById;
import app.helpers.ConstantsHelper;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:59
 * To change this template use File | Settings | File Templates.
 */

@Entity
@Table(name="PRJ_PROJECTTEAM")
@NamedQueries({
//        @NamedQuery(name="ProjectTeam.getTeamForPerson",
//                query="select t " +
//                        " from TeamItem t " +
//                        " join Project p on p.id = t.projectId "+
//                        " where t.person = :person and t.projectId <> :currentProjectId" +
//                        "  and p.startDate <= :currentDate" +
//                        " order by t.id"
//        ),
        @NamedQuery(name="ProjectTeam.getByProjectIdPersonId",
                query="select t from TeamItem t where t.person = :person and t.projectId = :projectId"
        )
})
public class TeamItem implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "PROJECT_ID")
    private Long projectId;

    @Column(name = "LOAD_PERCENT")
    private Double loadPercent;

//    @Column(name = "PERSON_ID")
//    private Long personId;
//
//    @Column(name = "FROM_PROJECT_ID")
//    private Long fromProjectId;
//
//    @Column(name = "ATTACHMENT_PLAN_ENDDATE")
//    @Temporal(TemporalType.DATE)
    @Transient
    private Date attachmentPlanEndDate;

//    @Column(name = "LEGIONNAIRE_PLAN_ENDDATE")
//    @Temporal(TemporalType.DATE)
    @Transient
    private Date legionnairePlanEndDate;

    //@Transient
    @ManyToOne()
    @JoinColumn(nullable = true, insertable = true, updatable = true, unique = true,
            name = "PERSON_ID")
    private Person person;

    @Column(name = "CLIENT_MONTH_PRICE")
    private BigDecimal clientMonthPrice;

//    @Transient
//    private Position position;
//

    public Double getLoadPercent() {
        if(loadPercent == null) {
            return ConstantsHelper.DOUBLE_ZERO;
        }
        return loadPercent;
    }

    public void setLoadPercent(Double loadPercent) {
        this.loadPercent = loadPercent;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getPersonId() {
        if(person == null) {
            return null;
        }
        return person.getId();
    }

//    public void setPersonId(Long personId) {
//        this.personId = personId;
//    }

//    public Long getFromProjectId() {
//        return fromProjectId;
//    }
//
//    public void setFromProjectId(Long fromProjectId) {
//        this.fromProjectId = fromProjectId;
//    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Position getPosition() {
        if( person != null ) {
            return person.getPosition();
        }
        return null;
    }

    public Date getAttachmentPlanEndDate() {
        return attachmentPlanEndDate;
    }

    public void setAttachmentPlanEndDate(Date attachmentPlanEndDate) {
        this.attachmentPlanEndDate = attachmentPlanEndDate;
    }

    public Date getLegionnairePlanEndDate() {
        return legionnairePlanEndDate;
    }

    public void setLegionnairePlanEndDate(Date legionnairePlanEndDate) {
        this.legionnairePlanEndDate = legionnairePlanEndDate;
    }

    public BigDecimal getClientMonthPrice() {
        return clientMonthPrice;
    }

    public void setClientMonthPrice(BigDecimal clientMonthPrice) {
        this.clientMonthPrice = clientMonthPrice;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TeamItem teamItem = (TeamItem) o;
        if (!person.getId().equals(teamItem.person.getId())) return false;
        return true;
    }

    @Override
    public int hashCode() {
        return person.getId().hashCode();
    }
}
