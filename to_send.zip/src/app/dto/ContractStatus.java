package app.dto;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.12.13
 * Time: 14:50
 * To change this template use File | Settings | File Templates.
 */
public class ContractStatus {
    public static final ContractStatus ACTIVE = new ContractStatus(1L, "�������", false);
    public static final ContractStatus PAUSED = new ContractStatus(2L, "��������������", false);
    public static final ContractStatus CLOSED = new ContractStatus(3L, "�������", false);




    private Long id;
    private String name;
    private boolean disabled;
    public ContractStatus(Long id, String name, boolean disabled) {
        this.id = id;
        this.name = name;
        this.disabled = disabled;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }
}
