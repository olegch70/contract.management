package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 26.12.13
 * Time: 9:19
 */
@Entity
@Table(name="PRJ_EXPENSES_TEAM")
@NamedQueries({
        @NamedQuery(name = "ExpenseTeam.expensesExists",
                query = "select count(et) from ExpenseTeam et where et.personId = :personId"),
        @NamedQuery(name = "ExpenseTeam.expensesForPersonInProject",
                query = "select et from ExpenseTeam et where et.projectId =:projectId and et.personId = :personId")
})
public class ExpenseTeam implements IdentificableById, Serializable {

    private static final long serialVersionUID = 1L;

    public ExpenseTeam() {
//        LogSimple.debug(this, "created");
    }

    @Id
    @SequenceGenerator(name="SEQ_EXPTEAM_IDSEQ", sequenceName = "PRJ_EXPTEAM_IDSEQ", allocationSize = 100)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ_EXPTEAM_IDSEQ")
    private Long id;

    @Column(name = "PROJECT_ID")
    private Long projectId;

    @Column(name = "PERSON_ID")
    private Long personId;

    @Column(name = "DATE_EXP")
    @Temporal(TemporalType.DATE)
    private Date dateExp;

//    @Column(name = "TEAM_ID")
//    private Long teamId;
//
//    @Column(name = "PRICE")
    @Transient
    private BigDecimal price;

    @Column(name = "PRICE2")
    private BigInteger price2;

    @Column(name = "LOAD_PERCENT")
    private Double loadPercent;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
//        LogSimple.debug(this, "setProjectId( "+projectId+" )");
        this.projectId = projectId;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
//        LogSimple.debug(this, "setPersonId( "+personId+" )");
        this.personId = personId;
    }

    public Date getDateExp() {
        return dateExp;
    }

    public void setDateExp(Date dateExp) {
//        LogSimple.debug(this, "setDateExp( "+dateExp+" )");
        this.dateExp = dateExp;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setPrice2(BigInteger price2) {
        this.price2 = price2;
    }

    public BigInteger getPrice2() {
        return price2;
    }

    public Double getLoadPercent() {
        return loadPercent;
    }

    public void setLoadPercent(Double loadPercent) {
        this.loadPercent = loadPercent;
    }
}
