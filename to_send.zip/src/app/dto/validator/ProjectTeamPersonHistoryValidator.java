package app.dto.validator;

import app.dto.TeamItemHistory;
import app.helpers.LogSimple;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;

/**
 * Created by oleg on 19.07.2014.
 */

public class ProjectTeamPersonHistoryValidator implements ConstraintValidator<ProjectTeamPersonHistory, List<TeamItemHistory>> {

    @Override
    public void initialize(ProjectTeamPersonHistory projectTeamPersonHistory) {

    }

    @Override
    public boolean isValid(List<TeamItemHistory> teamItemHistory, ConstraintValidatorContext constraintValidatorContext) {
        LogSimple.debug("isValid called");
        return isValid(teamItemHistory);
    }

    public static boolean isValid(List<TeamItemHistory> history) {
        TeamItemHistory prevItem = null;
        for(TeamItemHistory currentItem: history) {
            if(prevItem != null) {
                if( ! prevItem.getPeriodStart().before(currentItem.getPeriodStart()) ) {
                    LogSimple.debug("prevItem.getPeriodStart ("+prevItem.getPeriodStart()+") >= currentItem.getPeriodStart("+currentItem.getPeriodStart()+")");
                    return false;
                }
                if( ! prevItem.getPeriodFinish().before(currentItem.getPeriodStart()) ) {
                    LogSimple.debug("prevItem.getPeriodFinish ("+prevItem.getPeriodFinish()+") >= currentItem.getPeriodStart("+currentItem.getPeriodStart()+")");
                    return false;
                }
            }
            if(  currentItem.getPeriodStart().after(currentItem.getPeriodFinish()) ) {
                LogSimple.debug("currentItem.getPeriodStart("+currentItem.getPeriodStart()+") > currentItem.getPeriodFinish("+currentItem.getPeriodFinish()+")");
                return false;
            }

            prevItem = currentItem;
        }
        return true;
    }
}
