package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:59
 * To change this template use File | Settings | File Templates.
 */

@Entity
@Table(name="PRJ_DEBUG_PROPERTIES")
@Cacheable(value = false)

@NamedQueries({
        @NamedQuery(name = "DebugProperties.getByCode",
        query = "select t from DebugProperty t where t.code = :code")
})
public class DebugProperty implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "CODE")
    private String code;

    @Column(name = "S_VALUE")
    private String stringValue;

    @Override
    public Long getId() {
        throw new RuntimeException("Illegal Call");
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }
}
