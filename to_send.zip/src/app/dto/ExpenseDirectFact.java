package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 26.12.13
 * Time: 9:19
 */
@Entity
@Table(name="PRJ_EXPENSES_DIRECT_FACT")
@NamedQueries({
        @NamedQuery(name="ExpenseDirectFact.summaForIdByPeriod",
        query = "select sum(t.summa) from ExpenseDirectFact t " +
                " where t.projectId = :projectId " +
                "   and t.dateExp between :startDate and :endDate")
//        ,@NamedQuery(name="ExpenseDirectFact.summaForId",
//        query = "select sum(t.summa) from ExpenseDirect t " +
//                " where t.projectId = :projectId ")
})
public class ExpenseDirectFact extends ExpenseDirectFactSuper {
    private static final long serialVersionUID = 1L;

    @Override
    public String toString() {
        return "ExpenseDirectFact {" + toStringInternal() + "}";
    }
}
