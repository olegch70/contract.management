package app.dto.report;

import app.dto.Person;

import java.math.BigInteger;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 10:49
 * To change this template use File | Settings | File Templates.
 */
public class ActivityPersonReport {

    private Person person;

    private String comment;
//    private Integer grade;
    private double workDays;
    private Long projectId;
    private String projectCode;
    private Date periodStart;
    private Date periodFinish;
    private Integer personGrade;
    private Double loadPercent;
    private Double fte;
    private BigInteger price2;
    private boolean continued = false;
    private boolean firstRow = false;
    private boolean activityContinued = false;


    private int npp;

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public double getWorkDays() {
        return workDays;
    }

    public void setWorkDays(double workDays) {
        this.workDays = workDays;
    }

//    public Integer getGrade() {
//        return grade;
//    }
//
//    public void setGrade(Integer value) {
//        this.grade = value;
//    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public String getProjectCode() {
        return projectCode;
    }

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public Date getPeriodStart() {
        return periodStart;
    }

    public void setPeriodStart(Date periodStart) {
        this.periodStart = periodStart;
    }

    public Date getPeriodFinish() {
        return periodFinish;
    }

    public void setPeriodFinish(Date periodFinish) {
        this.periodFinish = periodFinish;
    }

    public Integer getPersonGrade() {
        return personGrade;
    }

    public void setPersonGrade(Integer personGrade) {
        this.personGrade = personGrade;
    }

    public void setLoadPercent(Double loadPercent) {
        this.loadPercent = loadPercent;
    }

    public Double getLoadPercent() {
        return loadPercent;
    }

    public Double getFte() {
        return fte;
    }

    public void setFte(Double fte) {
        this.fte = fte;
    }

    public void setPrice2(BigInteger price2) {
        this.price2 = price2;
    }

    public BigInteger getPrice2() {
        return price2;
    }

    public void setContinued(boolean continued) {
        this.continued = continued;
    }

    public boolean isContinued() {
        return continued;
    }

    public boolean isActivityContinued() {
        return activityContinued;
    }

    public void setActivityContinued(boolean activityContinued) {
        this.activityContinued = activityContinued;
    }

    public boolean isFirstRow() {
        return firstRow;
    }

    public void setFirstRow(boolean firstRow) {
        this.firstRow = firstRow;
    }

    public void setNpp(int npp) {
        this.npp = npp;
    }

    public int getNpp() {
        return npp;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
