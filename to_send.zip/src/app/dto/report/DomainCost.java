package app.dto.report;

import app.helpers.ConstantsHelper;

import java.math.BigDecimal;

/**
 * author: Oleg Chamlay
 * Date: 16.04.14
 * Time: 11:43
 */
public class DomainCost {
    private Long directionId;
    private String caption;
    private BigDecimal expenseTeam;
    private BigDecimal expenseDirect;
    private BigDecimal income;
    private BigDecimal fotExpensePremium;
    private BigDecimal fotExpenseOvertime;
    private BigDecimal fotExpenseTeam;

    public DomainCost() {
        expenseTeam = ConstantsHelper.BIGDECIMAL_ZERO;
        expenseDirect = ConstantsHelper.BIGDECIMAL_ZERO;
        income = ConstantsHelper.BIGDECIMAL_ZERO;
    }

    public Long getDirectionId() {
        return directionId;
    }

    public void setDirectionId(Long directionId) {
        this.directionId = directionId;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public BigDecimal getExpenseTeam() {
        return expenseTeam;
    }

    public void setExpenseTeam(BigDecimal expenseTeam) {
        this.expenseTeam = expenseTeam;
    }

    public BigDecimal getExpenseDirect() {
        return expenseDirect;
    }

    public void setExpenseDirect(BigDecimal expenseDirect) {
        this.expenseDirect = expenseDirect;
    }

    public BigDecimal getIncome() {
        return income;
    }

    public void setIncome(BigDecimal income) {
        this.income = income;
    }

    public BigDecimal getFotExpensePremium() {
        return fotExpensePremium;
    }

    public void setFotExpensePremium(BigDecimal fotExpensePremium) {
        this.fotExpensePremium = fotExpensePremium;
    }

    public BigDecimal getFotExpenseOvertime() {
        return fotExpenseOvertime;
    }

    public void setFotExpenseOvertime(BigDecimal fotExpenseOvertime) {
        this.fotExpenseOvertime = fotExpenseOvertime;
    }

    public BigDecimal getFotExpenseTeam() {
        return fotExpenseTeam;
    }

    public void setFotExpenseTeam(BigDecimal fotExpenseTeam) {
        this.fotExpenseTeam = fotExpenseTeam;
    }
}
