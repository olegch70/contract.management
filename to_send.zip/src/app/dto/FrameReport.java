package app.dto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 10:49
 * To change this template use File | Settings | File Templates.
 */
public class FrameReport {

    private String caption;
    private String type;
    private BigDecimal priceQ1Plan;
    private BigDecimal priceQ2Plan;
    private BigDecimal priceQ3Plan;
    private BigDecimal priceQ4Plan;
    private BigDecimal priceQ1Actual;
    private BigDecimal priceQ2Actual;
    private BigDecimal priceQ3Actual;
    private BigDecimal priceQ4Actual;

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public BigDecimal getPriceQ1Plan() {
        return priceQ1Plan;
    }

    public void setPriceQ1Plan(BigDecimal priceQ1Plan) {
        this.priceQ1Plan = priceQ1Plan;
    }

    public BigDecimal getPriceQ2Plan() {
        return priceQ2Plan;
    }

    public void setPriceQ2Plan(BigDecimal priceQ2Plan) {
        this.priceQ2Plan = priceQ2Plan;
    }

    public BigDecimal getPriceQ3Plan() {
        return priceQ3Plan;
    }

    public void setPriceQ3Plan(BigDecimal priceQ3Plan) {
        this.priceQ3Plan = priceQ3Plan;
    }

    public BigDecimal getPriceQ4Plan() {
        return priceQ4Plan;
    }

    public void setPriceQ4Plan(BigDecimal priceQ4Plan) {
        this.priceQ4Plan = priceQ4Plan;
    }

    public BigDecimal getPriceQ1Actual() {
        return priceQ1Actual;
    }

    public void setPriceQ1Actual(BigDecimal priceQ1Actual) {
        this.priceQ1Actual = priceQ1Actual;
    }

    public BigDecimal getPriceQ2Actual() {
        return priceQ2Actual;
    }

    public void setPriceQ2Actual(BigDecimal priceQ2Actual) {
        this.priceQ2Actual = priceQ2Actual;
    }

    public BigDecimal getPriceQ3Actual() {
        return priceQ3Actual;
    }

    public void setPriceQ3Actual(BigDecimal priceQ3Actual) {
        this.priceQ3Actual = priceQ3Actual;
    }

    public BigDecimal getPriceQ4Actual() {
        return priceQ4Actual;
    }

    public void setPriceQ4Actual(BigDecimal priceQ4Actual) {
        this.priceQ4Actual = priceQ4Actual;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
