package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 15.08.14
 * Time: 11:32
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name="PRJ_CALENDAR")
public class CalendarDay implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy= GenerationType.IDENTITY, generator="SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "CALENDAR_DAY")
    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "DAY_TYPE")
    private int type;
    @Transient
    private String typeName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }
}
