package app.dto;

import app.beans.IdentificableById;
import app.helpers.LogSimple;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 26.12.13
 * Time: 9:19
 */
@MappedSuperclass
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class ExpenseDirectFactSuper implements IdentificableById, Serializable {

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    protected Long id;

    @Column(name = "PROJECT_ID")
    private Long projectId;

    @Column(name = "DATE_EXP")
    @Temporal(TemporalType.DATE)
    private Date dateExp;

    private BigDecimal summa;

    private String description;

    @Column(name = "CREATOR_ID")
    private Long creatorId;

    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;

    @Transient
    private String creatorFIO;

    @ManyToOne()
    @JoinColumn(name = "EXPENSE_TYPE_ID")
    private ExpenseType expenseType;

    @ManyToOne()
    @JoinColumn(name = "INITIATOR_ID")
    private Person person;

    private String destination;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Date getDateExp() {
        return dateExp;
    }

    public void setDateExp(Date dateExp) {
        this.dateExp = dateExp;
    }

    public BigDecimal getSumma() {
        return summa;
    }

    public void setSumma(BigDecimal price) {
        this.summa = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public ExpenseType getExpenseType() {
        return expenseType;
    }

    public void setExpenseType(ExpenseType expenseType) {
        this.expenseType = expenseType;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDestination() {
        return destination;
    }

    public Long getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Long creatorId) {
        this.creatorId = creatorId;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getCreatorFIO() {
        return creatorFIO;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ExpenseDirectFactSuper)) return false;
        ExpenseDirectFactSuper that = (ExpenseDirectFactSuper) o;

        if (!summa.equals(that.summa)) return false;
        if (!dateExp.equals(that.dateExp)) return false;
        if (expenseType != null ? !expenseType.equals(that.expenseType) : that.expenseType != null) return false;
        if (person != null ? !person.equals(that.person) : that.person != null) return false;
        if (destination != null ? !destination.equals(that.destination) : that.destination != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (projectId.longValue() != that.projectId.longValue()) return false;
//        if (!creatorId.equals(that.creatorId)) return false;
//        if (!creationDate.equals(that.creationDate)) return false;
        return true;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

    @Override
    public int hashCode() {
        int result = projectId.hashCode();
        result = 31 * result + dateExp.hashCode();
        result = 31 * result + summa.hashCode();
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + creatorId.hashCode();
        result = 31 * result + creationDate.hashCode();
        result = 31 * result + (expenseType != null ? expenseType.hashCode() : 0);
        result = 31 * result + (person != null ? person.hashCode() : 0);
        result = 31 * result + (destination != null ? destination.hashCode() : 0);
        return result;
    }

    public void setCreatorFIO(String creatorFIO) {
        this.creatorFIO = creatorFIO;
    }



    @Override
    public String toString() {
        return "ExpenseDirectFactSuper" +" {" + toStringInternal() + "}";
    }

    protected String toStringInternal() {
        return
                "id=" + id +
                ", projectId=" + projectId +
                ", dateExp=" + dateExp +
                ", summa=" + summa +
                ", description='" + description + '\'' +
                ", creatorId=" + creatorId +
                ", creationDate=" + creationDate +
                ", creatorFIO='" + creatorFIO + '\'' +
                ", expenseType=" + expenseType +
                ", person=" + person +
                ", destination='" + destination + '\'' +
                '}';
    }


    public void copyFrom(ExpenseDirectFactSuper item) {
        projectId = item.projectId;
        dateExp = item.dateExp;
        summa = item.summa;
        description = item.description;
        creatorId = item.creatorId;
        creationDate = item.creationDate;
        expenseType = item.expenseType;
        person = item.person;
        destination = item.destination;
    }
}
