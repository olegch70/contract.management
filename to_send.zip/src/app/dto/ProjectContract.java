package app.dto;

import app.beans.IdentificableById;
import app.helpers.SafeEquals;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 25.12.13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name="PRJ_PROJECT_CONTRACTS")
public class ProjectContract implements IdentificableById, Serializable {
    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "PROJECT_ID")
    private Long projectId;
    @Column(name = "PNUMBER")
    private String number;

    private BigDecimal price;

    private String description;

    @Column(name = "ASSIGN_DATE")
    @Temporal(TemporalType.DATE)
    private Date docDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProjectContract that = (ProjectContract) o;

        if(id == null) {
            return false;
        }

        if (!id.equals(that.id)) return false;

        return true;
    }

    public boolean fullEquals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProjectContract that = (ProjectContract) o;

        if (! SafeEquals.equals(description, that.description)) return false;
        if (! SafeEquals.equals(id, that.id)) return false;
        if (! SafeEquals.equals(number, that.number)) return false;
        if (! SafeEquals.equals(price, that.price)) return false;
        if (! SafeEquals.equals(projectId, that.projectId)) return false;
        if (! SafeEquals.equals(docDate, that.docDate)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        if(id == null) {
            return super.hashCode();
        }
        return id.hashCode();
    }

    public void setDocDate(Date docDate) {
        this.docDate = docDate;
    }

    public Date getDocDate() {
        return docDate;
    }
}
