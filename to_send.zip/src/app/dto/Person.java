package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:44
 * To change this template use File | Settings | File Templates.
 */
@NamedQueries({
        @NamedQuery(name = "Person.getPM",
                query = "select t from Person t " +
                        " where t.actual = true " +
                        "   and t.projectM = true " +
                        " order by t.lastName, t.firstName, t.middleName"),

        @NamedQuery(name = "Person.getTAM",
                query = "select t from Person t " +
                        " where t.actual = true " +
                        "   and t.technicalAM = true " +
                        " order by t.lastName, t.firstName, t.middleName"),

        @NamedQuery(name = "Person.getHR",
                query = "select t from Person t " +
                        " where t.actual = true " +
                        "   and t.HR = true " +
                        " order by t.lastName, t.firstName, t.middleName"),

        @NamedQuery(name = "Person.getFinManager",
                query = "select t from Person t " +
                        " where t.actual = true " +
                        "   and t.finManager = true " +
                        " order by t.lastName, t.firstName, t.middleName"),

        @NamedQuery(name = "Person.getByLoginName",
                query = "select t from Person t " +
                        " where t.actual = true " +
                "   and t.loginName = :loginName"),

        @NamedQuery(name = "Person.getByFIO",
        query = "select t from Person t " +
                " where t.actual = true " +
                "   and t.lastName = :lastName" +
                "   and t.firstName = :firstName" +
                "   and t.middleName = :middleName")
})


@Entity
@Table(name="PRJ_PERSON")
public class Person implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    private Long id;

    @Column(name = "FL_ACTUAL")
    private boolean actual = true;

    @Column(name = "EMPLOYMENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date employmentDate;

    @Column(name = "DISMISSAL_DATE")
    @Temporal(TemporalType.DATE)
    private Date dismissalDate;

    private String firstName;
    private String lastName;
    private String middleName;

//    @Column(name = "POSITION_ID")
//    private Long positionId;
    @ManyToOne()
    @JoinColumn(name = "POSITION_ID")
    Position position;

//    @Column(name = "MAINPROJECT_ID")
//    private Long mainProjectId;
//
    @ManyToOne()
    @JoinColumn(nullable = true, insertable = true, updatable = true, unique = true,
            name = "MAINPROJECT_ID")
    Project mainProject;

//    @Column(name = "DAY_PRICE")
    @Transient
    private BigDecimal dayPrice;

    @Transient
    private BigDecimal dayPrice21;

    @Transient
    private BigDecimal monthPrice21;

    private String loginName;

    private boolean technicalAM;

    private boolean projectM;

    private boolean HR;

    private boolean finManager;

    @Column(name = "ALLOW_SEARCH_PEOPLE")
    private boolean allowSearchPeople;

    @Column(name = "BUH_RECONCILIATION")
    private boolean buhReconciliation;

    private boolean onSite;

    @Column(name = "LEGIONNAIRE_STATE")
    private String legionnaireState;


    /** legionnairePercentOffer
     * �� ������� ��������� ������������ ��������� ������� ����� "������"
     * ���������� ��� �������������� � ������ �������
     * ���� ����� �������� �������� �� ����
     *     ���� ��������� ��������� � ��������� legionnaireState == LegionnaireState.READY
     * ����������� � �������� "������� -> ������ � ����������"
     *
     * ���������� ������ 0 ����� ��������� ��������� legionnaireState
     *    �� LegionnaireState.NONE ��� LegionnaireState.ISLEGIONNAIRE
     */

    @Column(name = "LEGIONNAIRE_PERCENT_OFFER")
    private Double legionnairePercentOffer;


    @Column(name = "LEGIONNAIRE_END_DATE")
    @Temporal(TemporalType.DATE)
    private Date legionnaireEndDate;

    /**
     * ������� �� ������� ��������� ������������ �� �������� �������
     * ���� ���������� � ��������� �������:
     *   �) ������������� � ������ ��������� ���������� � ������� ��������� �������
     *   �) �����������
     *      - ��� �������� ���������� �� ������� ������� (���������)
     *      - ��� ���������� ���������� � ������� �� ��������� �������
     */

    @Column(name = "LOAD_PERCENT")
    private Double loadPercent;

  /*@Column(name = "ATTACHED_STATE")
    private String attachedState;

    @Column(name = "ATTACHMENT_END_DATE")
    @Temporal(TemporalType.DATE)
    private Date attachmentEndDate;
  */

    @Transient
    private BigDecimal grade;

    private BigInteger grade2;

    @Column(name = "DAY_PRICE2")
    private BigInteger dayPrice2;

    @Column(name = "ALTERNATE_PM_ID")
    private Long alternatePMId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isActual() {
        return actual;
    }

    public void setActual(boolean actual) {
        this.actual = actual;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public String getFIO() {
        StringBuilder sb = new StringBuilder();
        return sb.append(lastName).append(" ").append(firstName).append(" ").append(middleName).toString();
    }

    public Long getPositionId() {
        if(position != null) {
           return position.getId();
        }
        return null;
    }

    public void setPositionId(Long positionId) {
        Position position = new Position();
        position.setId(positionId);
        this.position = position;
    }

    public Project getMainProject() {
        return mainProject;
    }

    public void setMainProject(Project mainProject) {
        this.mainProject = mainProject;
    }

    public Long getMainProjectId() {
        if(mainProject != null) {
            return mainProject.getId();
        }
        return null;
    }

    public void setMainProjectId(Long mainProjectId) {
        Project project = new Project();
        project.setId(mainProjectId);
        mainProject = project;
    }

    public BigDecimal getDayPrice() {
        return dayPrice;
    }

    public void setDayPrice(BigDecimal dayPrice) {
        this.dayPrice = dayPrice;
    }

    public String getPositionName() {
        if(position != null) {
            return position.getName();
        }
        return null;
    }

//    public void setPositionName(String position) {
//        this.positionName = position;
//    }

    public String getMainProjectString() {
        if(mainProject != null) {
            return "���������� #"+mainProject.getCode()+" "+getCurrentProjectManager()+" "+mainProject.getCommentForDisplay();
        }
        if(dismissalDate != null) {
            return "������";
        }
        return "��������";
    }

    public String getCurrentProjectManager() {
        if(mainProject.getProjectManager() == null) {
            return mainProject.getProjectManagerId().toString();
        } else {
            return mainProject.getProjectManager().getFIO();
        }
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public boolean isTechnicalAM() {
        return technicalAM;
    }

    public void setTechnicalAM(boolean technicalAM) {
        this.technicalAM = technicalAM;
    }

    public boolean isProjectM() {
        return projectM;
    }

    public void setProjectM(boolean projectM) {
        this.projectM = projectM;
    }

    public boolean isHR() {
        return HR;
    }

    public void setHR(boolean HR) {
        this.HR = HR;
    }

    public boolean isFinManager() {
        return finManager;
    }

    public void setFinManager(boolean finManager) {
        this.finManager = finManager;
    }

    public boolean isReadyForLegionnaire() {
        if(legionnaireState.equals(LegionnaireState.READY.getValue())){
            return true;
        }
        return false;
    }

    public void setReadyForLegionnaire(boolean value) {
        if(value) {
            legionnaireState = LegionnaireState.READY.getValue();
        } else {
            legionnaireState = LegionnaireState.NONE.getValue();
        }
    }

    public boolean isLegionnaire() {
        if(legionnaireState.equals(LegionnaireState.ISLEGIONNAIRE.getValue())){
            return true;
        }
        return false;
    }

    public void setLegionnaire(boolean value) {
        if(value) {
            legionnaireState = LegionnaireState.ISLEGIONNAIRE.getValue();
        } else {
            legionnaireState = LegionnaireState.NONE.getValue();
        }
    }

    public void setLegionnaireState(String legionnaireState) {
        this.legionnaireState = legionnaireState;
    }

    public String getLegionnaireState() {
        if(legionnaireState == null) {
            return LegionnaireState.NONE.getValue();
        }
        return legionnaireState;
    }

    public void setGrade(BigDecimal grade) {
        this.grade = grade;
    }

    public BigDecimal getGrade() {
        return grade;
    }

    public void setGrade2(BigInteger grade) {
        this.grade2 = grade;
    }

    public BigInteger getGrade2() {
        return grade2;
    }

    public boolean isOnSite() {
        return onSite;
    }

    public void setOnSite(boolean onSite) {
        this.onSite = onSite;
    }

    public BigInteger getDayPrice2() {
        return dayPrice2;
    }

    public void setDayPrice2(BigInteger dayPrice2) {
        this.dayPrice2 = dayPrice2;
    }

//    public Double getLoadPercentOnMainProject() {
//        if(loadPercent == null) {
//            return ConstantsHelper.DOUBLE_HUNDRED;
//        }
//        return loadPercent;
//    }
//
//    public void setLoadPercentOnMainProject(Double value) {
//        loadPercent = value;
//    }
//

    public BigDecimal getDayPrice21() {
        return dayPrice21;
    }

    public void setDayPrice21(BigDecimal dayPrice21) {
        this.dayPrice21 = dayPrice21;
    }

    public BigDecimal getMonthPrice21() {
        return monthPrice21;
    }

    public void setMonthPrice21(BigDecimal monthPrice21) {
        this.monthPrice21 = monthPrice21;
    }

    public Double getLegionnairePercentOffer() {
        return legionnairePercentOffer;
    }

    public void setLegionnairePercentOffer(Double legionnairePercentOffer) {
        this.legionnairePercentOffer = legionnairePercentOffer;
    }

    public void setAlternatePMId(Long altPMId) {
        this.alternatePMId = altPMId;
    }

    public Long getAlternatePMId() {
        return alternatePMId;
    }

    public static enum LegionnaireState {
        NONE("0"), READY("1"), ISLEGIONNAIRE("2");

        private String value;
        private LegionnaireState(String v) {
            value = v;
        }
        public String getValue() {
            return value;
        }
    }

    public Date getLegionnaireEndDate() {
        return legionnaireEndDate;
    }

    public void setLegionnaireEndDate(Date legionnaireEndDate) {
        this.legionnaireEndDate = legionnaireEndDate;
    }

    public Date getEmploymentDate() {
        return employmentDate;
    }

    public void setEmploymentDate(Date employmentDate) {
        this.employmentDate = employmentDate;
    }

    public Date getDismissalDate() {
        return dismissalDate;
    }

    public void setDismissalDate(Date dismissalDate) {
        this.dismissalDate = dismissalDate;
    }

    public boolean isAllowSearchPeople() {
        return allowSearchPeople;
    }

    public void setAllowSearchPeople(boolean allowSearchPeople) {
        this.allowSearchPeople = allowSearchPeople;
    }

    public boolean isBuhReconciliation() {
        return buhReconciliation;
    }

    public void setBuhReconciliation(boolean buhReconciliation) {
        this.buhReconciliation = buhReconciliation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Person)) return false;

        Person person = (Person) o;

        if (!id.equals(person.id)) return false;

        return true;
    }



    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Person{");
        sb.append("id=").append(id);
        sb.append(", actual=").append(actual);
        sb.append(", firstName='").append(firstName).append('\'');
        sb.append(", lastName='").append(lastName).append('\'');
        sb.append(", middleName='").append(middleName).append('\'');
        sb.append(", positionId=").append(getPositionId());
        sb.append(", mainProjectId=").append(getMainProjectId());
        sb.append(", dayPrice=").append(dayPrice2);
        sb.append(", grade=").append(grade2);
        sb.append(", loginName=").append(loginName);
        sb.append(", employmentDate=").append(employmentDate);
        sb.append(", dismissalDate=").append(dismissalDate);
        sb.append(", technicalAM=").append(technicalAM);
        sb.append(", allowSearchPeople=").append(allowSearchPeople);
        sb.append(", projectM=").append(projectM);
        sb.append(", legionnaireState=").append(legionnaireState);
        sb.append(", legionnaireEndDate=").append(legionnaireEndDate);
        sb.append(", loadPercent=").append(loadPercent);
        sb.append(", legionnairePercentOffer=").append(legionnairePercentOffer);
        sb.append('}');
        return sb.toString();
    }
}
