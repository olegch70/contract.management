package app.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 10:49
 * To change this template use File | Settings | File Templates.
 */
public class BenchPersonReport {

    private String FIO;

    private Date benchDate;
    private Date dismissalDate;

    private double benchDays;

    private List<BenchPersonProject> workProjects;

    private double workDays;

    private Double currentLoadPercent;

    private BigDecimal price;
    private Long personId;

    public String getFIO() {
        return FIO;
    }

    public void setFIO(String FIO) {
        this.FIO = FIO;
    }

    public Date getBenchDate() {
        return benchDate;
    }

    public void setBenchDate(Date benchDate) {
        this.benchDate = benchDate;
    }

    public double getBenchDays() {
        return benchDays;
    }

    public void setBenchDays(double benchDays) {
        this.benchDays = benchDays;
    }

    public List<BenchPersonProject> getWorkProjects() {
        return workProjects;
    }

    public void setWorkProjects(List<BenchPersonProject> workProjects) {
        this.workProjects = workProjects;
    }

    public double getWorkDays() {
        return workDays;
    }

    public void setWorkDays(double workDays) {
        this.workDays = workDays;
    }

    public Double getCurrentLoadPercent() {
        return currentLoadPercent;
    }

    public void setCurrentLoadPercent(Double currentLoadPercent) {
        this.currentLoadPercent = currentLoadPercent;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Date getDismissalDate() {
        return dismissalDate;
    }

    public void setDismissalDate(Date dismissalDate) {
        this.dismissalDate = dismissalDate;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public Long getPersonId() {
        return personId;
    }
}
