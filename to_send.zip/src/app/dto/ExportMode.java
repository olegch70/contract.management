package app.dto;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.12.13
 * Time: 14:50
 * To change this template use File | Settings | File Templates.
 */
public class ExportMode {
    public static final ExportMode WHOLE_TABLE = new ExportMode("��� �������", false);
    public static final ExportMode CURRENT_PAGE = new ExportMode("������� ��������", true);




    private String name;
    private boolean value;
    public ExportMode(String name, boolean value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }
}
