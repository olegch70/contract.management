package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 30.12.13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name="PRJ_USERS")
public class User implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    private Long id;

    private String login;

    private String password;

    @Column(name = "PASSWORD_DROP")
    private boolean passwordDrop;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isPasswordDrop() {
        return passwordDrop;
    }

    public void setPasswordDrop(boolean passwordDrop) {
        this.passwordDrop = passwordDrop;
    }
}
