package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * author: Oleg Chamlay
 * Date: 11.03.14
 * Time: 17:39
 */

@NamedQueries({
        @NamedQuery(name = "Grade.getByCode",
        query = "select t from Grade t where t.code = :code")
})

@Entity
@Table(name="PRJ_GRADE")

public class Grade implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    private Long id;

    private Integer code;

    @Transient
    private BigDecimal dayPrice;

    @Column(name = "DAY_PRICE2")
    private BigInteger dayPrice2;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public BigDecimal getDayPrice() {
        return dayPrice;
    }

    public void setDayPrice(BigDecimal dayPrice) {
        this.dayPrice = dayPrice;
    }

    public BigInteger getDayPrice2() {
        return dayPrice2;
    }

    public void setDayPrice2(BigInteger dayPrice2) {
        this.dayPrice2 = dayPrice2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Grade)) return false;

        Grade grade = (Grade) o;

        if (!id.equals(grade.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Grade{");
        sb.append("id=").append(id);
        sb.append(", dayPrice=").append(dayPrice2);
        sb.append('}');
        return sb.toString();
    }
}
