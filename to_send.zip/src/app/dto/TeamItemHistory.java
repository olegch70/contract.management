package app.dto;

import javax.persistence.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:59
 * To change this template use File | Settings | File Templates.
 */

@Entity
@Table(name="PRJ_PROJECTTEAM_HISTORY")
@NamedQueries({
        @NamedQuery(name="ProjectTeamHistory.getByProjectIdPersonId",
                query="select t from TeamItemHistory t where t.person.id = :personId and t.projectId = :projectId order by t.periodStart"
        ),
        @NamedQuery(name = "TeamItemHistory.personsFromHistory",
                query = "select t.person from TeamItemHistory t where t.projectId = :projectId" +
                        " group by t.person" +
                        " order by t.person.lastName, t.person.firstName"
        )
})
public class TeamItemHistory extends TeamItemAbstract {

    @Column(name = "PRICE2", nullable = false)
    private BigInteger price2;

    @Transient
    private BigDecimal price21day;

    @Column(name = "PERIOD_START", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date periodStart;

    @Column(name = "PERIOD_FINISH", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date periodFinish;

    public BigInteger getPrice2() {
        return price2;
    }

    public void setPrice2(BigInteger price2) {
        this.price2 = price2;
    }

    public BigDecimal getPrice21day() {
        return price21day;
    }

    public void setPrice21day(BigDecimal price21day) {
        this.price21day = price21day;
    }

    public Date getPeriodStart() {
        return periodStart;
    }

    public void setPeriodStart(Date periodStart) {
        this.periodStart = periodStart;
    }

    public Date getPeriodFinish() {
        return periodFinish;
    }

    public void setPeriodFinish(Date periodFinish) {
        this.periodFinish = periodFinish;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TeamItemHistory{");
        sb.append("periodStart=").append(periodStart);
        sb.append(", periodFinish=").append(periodFinish);
        sb.append("}+");
        sb.append(super.toString());
        return sb.toString();
    }

    @Override
    public boolean equalsFull(Object o) {
        if (this == o) return true;
        if (!(o instanceof TeamItemHistory)) return false;

        if (!super.equalsFull(o)) return false;

        TeamItemHistory that = (TeamItemHistory) o;

        if (!periodFinish.equals(that.periodFinish)) return false;
        if (!periodStart.equals(that.periodStart)) return false;
        if (!price2.equals(that.price2)) return false;

        return true;
    }
}
