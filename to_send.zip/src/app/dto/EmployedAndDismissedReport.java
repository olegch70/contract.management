package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

public class EmployedAndDismissedReport {

    private Person person;
    private String lastDirectionName;
    private int npp;

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getLastDirectionName() {
        return lastDirectionName;
    }

    public void setLastDirectionName(String lastDirectionName) {
        this.lastDirectionName = lastDirectionName;
    }

    public int getNpp() {
        return npp;
    }

    public void setNpp(int npp) {
        this.npp = npp;
    }
}
