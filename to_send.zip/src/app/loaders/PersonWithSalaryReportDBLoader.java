package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.Grade;
import app.dto.Person;
import app.helpers.GradeFieldsCryptor;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.report.dto.ReportDateFilter;
import app.salary.PersonSalaryDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "personWithSalaryReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class PersonWithSalaryReportDBLoader {
    @EJB
    CurrentDateBean currentDateBean;
    @EJB
    GradeDBLoader gradeDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    ExpenseTypeDBLoader expenseTypeDBLoader;
    @EJB
    PersonFieldsCryptor personFieldsCryptor;
    @EJB
    GradeFieldsCryptor gradeFieldsCryptor;

    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<PersonSalaryDto> getReportData(ReportDateFilter reportDateFilter) {
        Map<Integer, Grade> gradesMap;
        {
            List<Grade> grades = gradeDBLoader.getAll();
            gradesMap = new HashMap<Integer, Grade>(grades.size());
            for (Grade grade: grades) {
                gradeFieldsCryptor.decryptDayPrice(grade);
                gradesMap.put(grade.getCode(), grade);
            }
        }

        Date startDate = reportDateFilter.getStartDate();
        Date endDate = reportDateFilter.getEndDate();

        Query query = em.createQuery("select p from Person p " +
                " where ( p.employmentDate is null or p.employmentDate <= :endDate )" +
                "   and ( p.dismissalDate is null or p.dismissalDate >= :startDate )" +
                " order by p.lastName, p.firstName, p.middleName");
        query.setParameter("startDate", startDate);
        query.setParameter("endDate", endDate);
        List<Person> personsList = query.getResultList();
        List<PersonSalaryDto> resultList = new LinkedList<PersonSalaryDto>();

        for(Person person: personsList) {
            personFieldsCryptor.decryptGrade(person);
            PersonSalaryDto resultItem = new PersonSalaryDto();
            resultItem.setPerson(person);
            resultItem.setFIO(person.getFIO());
            resultList.add(resultItem);
//            Grade grade = gradesMap.get(new Integer(person.getGrade().intValue()));
//            person.setDayPrice21(grade.getDayPrice());
//            person.setMonthPrice21(grade.getDayPrice().multiply(ConstantsHelper.BIGDECIMAL_21));
        }

        return resultList;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}