package app.loaders;

import app.dto.Direction;

import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.Query;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "positionDBLoader")
@Named(value = "directionDBLoader")
@Stateless

public class DirectionDBLoader extends CommonDbLoader<Direction> {
    public static final Direction DIRECTION_BENCH = new Direction();
    static {
        DIRECTION_BENCH.setId(-1L);
        DIRECTION_BENCH.setName("��������");
    }

    @Override
    protected Class getEntityClass() {
        return Direction.class;
    }

    @Override
    protected Long getId(Direction entity) {
        return entity.getId();
    }

    @Override
    public List<Direction> getAll() {
        Query query = getEntityManager().createNamedQuery("Direction.getAll");
        List result = query.getResultList();
        return result;
    }
}
