package app.loaders;

import app.dto.Client;
import app.dto.Direction;
import app.dto.Person;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.Query;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 14:29
 * To change this template use File | Settings | File Templates.
 */
//@ManagedBean(name = "clientsDBLoader")
//@SessionScoped

@Named(value = "clientsDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)

public class ClientsDBLoader extends CommonDbLoader<Client>{

    @EJB
    private ProjectsDBLoader projectDBLoader;

    @EJB
    private PersonsDBLoader personsDBLoader;

    @EJB
    private DirectionDBLoader directionDBLoader;

    @Override
    protected Class getEntityClass() {
        return Client.class;
    }

    @Override
    protected Long getId(Client entity) {
        return entity.getId();
    }

    @Override
    public void enrichModel(List<Client> clients) {
        if(clients != null) {
            for(Client row : clients) {
                Person person = personsDBLoader.getById(row.getTechnicalAM());
                Direction direction = directionDBLoader.getById(row.getDirectionId());
                row.setTechnicalAMName(person.getLastName() + " " + person.getFirstName() + " " + person.getMiddleName());
                row.setDirectionName(direction.getName());
            }
        }
    }

    public List<Client> getByTechnicalAm(Long id) {
        return loadByFieldValue("technicalAM", id);
    }
    //ToDo оптимизировать запрос всего списка за один запрос в базу
    public List<Client> getClients() {
        Query query = getEntityManager().createNamedQuery("Clients.list");
        return query.getResultList();
    }

    public List<Client> getClientsByProjectM(Long personId) {
        Query query = getEntityManager().createNamedQuery("Project.getClientsByProjectM");
        query.setParameter("projectManagerId", personId);
        return query.getResultList();
    }

    public List<Client> getClientsForAuthorizedUser(Long personId, boolean isTechnicalAM, boolean isProjectM) {
        List<Client> result = new LinkedList<Client>();
            if(isTechnicalAM) {
                System.out.println("person is TAM");
                result.addAll(getByTechnicalAm(personId));
                System.out.println("person is TAM result = " + result);
            }
            if(isProjectM) {
                System.out.println("person is PM");
//                Collection<Long> collection = projectDBLoader.getClientsCollectionByPM(personId);
//                System.out.println("person is PM collection = " + collection);
                List<Client> clientsList = getClientsByProjectM(personId);
                System.out.println("person is PM "+clientsList.getClass()+" clientsList = " + clientsList);
                System.out.println("person is PM "+clientsList.getClass()+" for remove = " + result);
                clientsList.removeAll(result);
                System.out.println("person is PM clientsList after remove = " + clientsList);
                result.addAll(clientsList);
                System.out.println("person is PM result = " + result);
            }
        return result;
    }
}
