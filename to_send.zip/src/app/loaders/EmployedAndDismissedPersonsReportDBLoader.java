package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.EmployedAndDismissedReport;
import app.dto.Grade;
import app.dto.Person;
import app.helpers.GradeFieldsCryptor;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.report.dto.ReportDateFilter;
import app.salary.PersonSalaryDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "employedAndDismissedPersonsReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EmployedAndDismissedPersonsReportDBLoader {
    @EJB
    CurrentDateBean currentDateBean;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    ExpenseTypeDBLoader expenseTypeDBLoader;
    @EJB
    PersonFieldsCryptor personFieldsCryptor;
    @EJB
    GradeFieldsCryptor gradeFieldsCryptor;

    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<EmployedAndDismissedReport> getReportData(ReportDateFilter reportDateFilter, List<String> selectedDirectionIds) {

        Date startDate = reportDateFilter.getStartDate();
        Date endDate = reportDateFilter.getEndDate();

        Calendar calendar = Calendar.getInstance();
        calendar.set(2014, 5-1, 1, 0, 0, 0);
        Date fakeEmploymentDate = calendar.getTime();

        String sqlPart = "";

        boolean needEmploymentDate = false;

        if( ! (fakeEmploymentDate.before(startDate) || fakeEmploymentDate.after(endDate))) {
            sqlPart = " or p.employmentDate is null ";
            needEmploymentDate = true;
        }
        final String s = "select p from Person p " +
                " where ( p.employmentDate between :startDate and :endDate " + sqlPart + ")" +
                " or ( p.dismissalDate between :startDate and :endDate )" +
                " order by p.lastName, p.firstName, p.middleName";
        debug("personSql = " + s);
        Query query = em.createQuery(s);
        query.setParameter("startDate", startDate);
        query.setParameter("endDate", endDate);
        List<Person> personsList = query.getResultList();
        debug("personsList = " + personsList);
        query = em.createQuery("select max(et.dateExp) from ExpenseTeam et " +
                " where et.dateExp between :startDate and :endDate " +
                " and et.personId = :personId");
        query.setParameter("startDate", startDate);
        query.setParameter("endDate", endDate);

        Query projectsQuery = em.createQuery("select et.projectId from ExpenseTeam et " +
                " where et.dateExp = :lastWorkDate " +
                " and et.personId = :personId " +
                " order by et.loadPercent desc, et.id");

        Query projectQuery = em.createQuery("select p.client.directionId from Project p " +
                " where p.id = :projectId");

        Query directionNameQuery = em.createQuery("select d.name from Direction d " +
                " where d.id = :directionId");

        List<EmployedAndDismissedReport> result = new ArrayList<EmployedAndDismissedReport>(personsList.size());
        for(Person person: personsList) {
            debug("person = " + person.toString());
            if(needEmploymentDate && person.getEmploymentDate() == null) {
                person.setEmploymentDate(fakeEmploymentDate);
            }
            query.setParameter("personId", person.getId());
            Date lastWorkDate = (Date) query.getSingleResult();

            projectsQuery.setParameter("lastWorkDate", lastWorkDate);
            projectsQuery.setParameter("personId", person.getId());
            List<Long> projects = projectsQuery.getResultList();
            String directionName;
            if(projects.size() > 0) {
                Long lastProjectId = projects.get(0);

                projectQuery.setParameter("projectId", lastProjectId);
                Long directionId = (Long) projectQuery.getSingleResult();
                if( ! selectedDirectionIds.contains(directionId.toString())) {
                    debug("selectedDirectionId not contained in idsList - " + directionId);
                    continue;
                }
                directionNameQuery.setParameter("directionId", directionId);
                directionName = (String) directionNameQuery.getSingleResult();
            } else {
                directionName = "��������";
            }

            EmployedAndDismissedReport report = new EmployedAndDismissedReport();
            report.setPerson(person);
            report.setLastDirectionName(directionName);

            result.add(report);
        }
        TreeMap<String, EmployedAndDismissedReport> sortedResult = new TreeMap<String, EmployedAndDismissedReport>();
        for(EmployedAndDismissedReport item: result) {
            sortedResult.put(item.getLastDirectionName()+"_"+item.getPerson().getFIO(), item);
        }
        result.clear();
        result.addAll(sortedResult.values());
        int counter = 0;
        String currentDirectionName = "";
        for(EmployedAndDismissedReport item: result) {
            if( ! currentDirectionName.equals(item.getLastDirectionName())) {
                currentDirectionName = item.getLastDirectionName();
                counter = 1;
            }
            item.setNpp(counter++);
        }
        return result;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}