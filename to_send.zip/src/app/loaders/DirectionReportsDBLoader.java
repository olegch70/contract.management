package app.loaders;

import app.dto.Client;
import app.dto.Direction;
import app.dto.Project;
import app.dto.ProjectReport;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.ProjectReportHelper;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "directionReportsDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class DirectionReportsDBLoader {
    @EJB
    ClientReportsDBLoader clientReportsDBLoader;
    @EJB
    DirectionDBLoader directionDBLoader;
    @EJB
    ProjectsDBLoader projectsDBLoader;

    @PersistenceContext(unitName = ConstantsHelper.PERSISTENCE_UNIT_NAME)
    protected EntityManager em;

    public List<ProjectReport> getReportData(ReportDateFilter reportDateFilter, List<String> selectedDirectionsIds) {
        List<ProjectReport> reports = new LinkedList<ProjectReport>();
        Map<String, ProjectReport> directionReport = new TreeMap<String, ProjectReport>();
        reports = clientReportsDBLoader.getDirectionReportData(reportDateFilter, selectedDirectionsIds);
        for(ProjectReport report : reports) {
            Direction direction = directionDBLoader.getById(report.getDirectionId());
            String directionName = direction.getName();
            LogSimple.debug(this, "directionName = " + directionName);
            LogSimple.debug(this, "client directionId = " + report.getDirectionId());
            report.setCaption(directionName);
            ProjectReport sumReport = directionReport.get(directionName);
            if(sumReport == null) {
                sumReport = ProjectReportHelper.createProjectReport(directionName);
                sumReport.setDirectionId(direction.getId());
                directionReport.put(directionName, sumReport);
            }

            ProjectReportHelper.accumulate(sumReport, report);
        }
        reports.clear();

        reports.addAll(directionReport.values());

        // ������� � ����������� ������� ����� ������� ��� ������ � ������� � ���������� � ������� Sales

        // ������� ID ������� ��� ConstantsHelper.CLIENT_NAME_SALES
        Client clientSales = null;
        Query query = em.createQuery("select t from Client t where lower(t.name) = :lowerName");
        query.setParameter("lowerName", ConstantsHelper.CLIENT_NAME_SALES);
        List<Client> clientsByName = query.getResultList();
        if(clientsByName != null && clientsByName.size() > 0) {
            clientSales = clientsByName.get(0);
        }

        if(clientSales != null) {
            debug(" clientSales.id => "+ clientSales.getId());

            Query queryClientByDirection = em.createQuery("select t from Client t where t.directionId = :directionId");
            Query queryActivity = em.createQuery(
                    "select t from Project t where t.client = :clientSales and t.projectManagerId = :tamID");

            for (ProjectReport report : reports) {
                queryClientByDirection.setParameter("directionId", report.getDirectionId());
                List<Client> clientsByDirection = queryClientByDirection.getResultList();
                if (clientsByDirection != null && clientsByDirection.size() > 0) {
                    // TAM ����������� �� ��������
                    Long clientTAMid = clientsByDirection.get(0).getTechnicalAM();
                    debug(report.getCaption()+" TAMid => "+ clientTAMid);
                    // ����� ���������� �� ������� Sales
                    queryActivity.setParameter("clientSales", clientSales);
                    queryActivity.setParameter("tamID", clientTAMid);
                    List<Project> projects = queryActivity.getResultList();
                    projectsDBLoader.enrichModel(projects);
                    BigDecimal currentExpense = report.getExpense();
                    for(Project project: projects) {
                        currentExpense = currentExpense.add(project.getExpense());
                    }
                    debug("expense for "+report.getCaption()+": wo TAM => "+ report.getExpense()+ ", with TAM => "+ currentExpense);
                    report.setExpense(currentExpense);
                }
            }
        }

        return reports;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}