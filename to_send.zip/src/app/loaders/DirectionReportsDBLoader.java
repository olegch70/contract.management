package app.loaders;

import app.dto.*;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.helpers.ProjectReportHelper;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "clientReportsDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class DirectionReportsDBLoader {
    @EJB
    ClientReportsDBLoader clientReportsDBLoader;
    @EJB
    DirectionDBLoader directionDBLoader;
    @EJB
    PersonFieldsCryptor personFieldsCryptor;
    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<ProjectReport> getReportData(ReportDateFilter reportDateFilter, List<String> selectedDirectionsIds) {
        List<ProjectReport> reports = new LinkedList<ProjectReport>();
        Map<String, ProjectReport> directionReport = new TreeMap<String, ProjectReport>();
        reports = clientReportsDBLoader.getDirectionReportData(reportDateFilter, selectedDirectionsIds);
        for(ProjectReport report : reports) {
            Direction direction = directionDBLoader.getById(report.getDirectionId());
            String directionName = direction.getName();
            LogSimple.debug(this, "directionName = " + directionName);
            LogSimple.debug(this, "client directionId = " + report.getDirectionId());
            report.setCaption(directionName);
            ProjectReport sumReport = directionReport.get(directionName);
            if(sumReport == null) {
                sumReport = ProjectReportHelper.createProjectReport(directionName);
                directionReport.put(directionName, sumReport);
            }

            ProjectReportHelper.accumulate(sumReport, report);
        }
        reports.clear();

        reports.addAll(directionReport.values());

        return reports;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}