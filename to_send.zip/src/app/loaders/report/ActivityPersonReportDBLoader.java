package app.loaders.report;

import app.beans.DayPriceConverter;
import app.dto.ExpenseTeam;
import app.dto.Grade;
import app.dto.Person;
import app.dto.Project;
import app.dto.report.ActivityPersonReport;
import app.helpers.*;
import app.loaders.*;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "activityPersonReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class ActivityPersonReportDBLoader {
    public static String ORDER_PERSON = "person";
    public static String ORDER_ACTIVITY = "activity";

    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    ExpensesTeamDBLoader expensesTeamDBLoader;
    @EJB
    GradeDBLoader gradeDBLoader;
    @EJB
    PersonFieldsCryptor personFieldsCryptor;
    @EJB
    GradeFieldsCryptor gradeFieldsCryptor;
    @EJB
    DayPriceConverter dayPriceConverter;

    @EJB
    CalendarDBLoader calendarDBLoader;

    @PersistenceContext(unitName = ConstantsHelper.PERSISTENCE_UNIT_NAME)
    protected EntityManager em;

    public List<ActivityPersonReport> getReportData(ReportDateFilter reportDateFilter, String order) {
        Date startDate = reportDateFilter.getStartDate();
        Date endDate = reportDateFilter.getEndDate();
        double periodLengthInDays = DateHelper.calculateDaysBetweenTwoDatesInclusive(startDate, endDate);
        boolean orderByPerson = ORDER_PERSON.equals(order);

        Query query = em.createQuery("select t from Person t " +
                " where (t.employmentDate is null or t.employmentDate <= :endPeriod ) " +
                "   and (t.dismissalDate is null or t.dismissalDate >= :startPeriod )" +
                " order by t.lastName, t.firstName, t.middleName ");
        query.setParameter("startPeriod", startDate);
        query.setParameter("endPeriod", endDate);
        List<Person> persons = query.getResultList();
        Map<Long, Grade> gradesMap = loadGrades();
        Map<Long, Project> projectsMap = new HashMap<Long, Project>();
        Person tmpPerson = new Person();
        List<ActivityPersonReport> result = new LinkedList<ActivityPersonReport>();

        for(Person person: persons) {
            BigInteger lastDayPrice2 = null;
            Integer lastGrade = null;
            tmpPerson.setId(person.getId());
            Date _startDate = startDate;
            Date _endDate = endDate;
            if(person.getEmploymentDate() != null && person.getEmploymentDate().after(startDate)) {
                _startDate = person.getEmploymentDate();
            }
            if(person.getDismissalDate() != null && ! endDate.before(person.getDismissalDate())) {
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(person.getDismissalDate());
                calendar.add(Calendar.DAY_OF_MONTH, -1);
                _endDate = calendar.getTime();
            }

            List<ActivityPersonReport> personLoadOnActivities = readPersonLoadOnActivities(person.getId(),
                    _startDate, _endDate);
            if(personLoadOnActivities == null || personLoadOnActivities.size() == 0) {
                ActivityPersonReport reportItem = new ActivityPersonReport();
                reportItem.setPerson(person);
                tmpPerson.setGrade2(person.getGrade2());
                personFieldsCryptor.decryptGrade(tmpPerson);
                reportItem.setPersonGrade(tmpPerson.getGrade().intValue());
                result.add(reportItem);
            } else {
                Map<Date, ActivityPersonReport> sortResult = null;
                if(orderByPerson) {
                    sortResult = new TreeMap<Date, ActivityPersonReport>();
                }
                for (ActivityPersonReport reportItem : personLoadOnActivities) {
                    if(reportItem.getPrice2() != null && reportItem.getPrice2().equals(lastDayPrice2)) {
                        reportItem.setPersonGrade(lastGrade);
                    } else {
                        if(reportItem.getProjectId().longValue() == -1) {
                            // ��������
                            tmpPerson.setDayPrice2(person.getDayPrice2());
                        } else {
                            tmpPerson.setDayPrice2(reportItem.getPrice2());
                        }
                        personFieldsCryptor.decryptDayPrice(tmpPerson);
                        lastDayPrice2 = reportItem.getPrice2();
                        Long price365dayKey = getPrice365(tmpPerson.getDayPrice());
                        Grade grade = gradesMap.get(price365dayKey);
                        if(grade == null) {
                            debug("notFound grade for price365key => " + price365dayKey);
                            lastGrade = null;
                        } else {
                            reportItem.setPersonGrade(grade.getCode());
                            lastGrade = grade.getCode();
                            if(grade.getCode() == null || grade.getCode().intValue() == 0) {
                                debug("notFound grade for price365key => " + price365dayKey+ " grade => " + grade + " grade.getCode() => " + grade.getCode());
                            }
                        }
                    }
                    reportItem.setPerson(person);
                    Project project = projectsMap.get(reportItem.getProjectId());
                    if (project == null) {
                        if(reportItem.getProjectId().longValue() == -1 ) {
                            project = new Project();
                            project.setId(new Long(-1));
                            project.setCode("��������");
                        } else {
                            project = projectsDBLoader.getById(reportItem.getProjectId());
                        }
                        projectsMap.put(reportItem.getProjectId(), project);
                    }
                    reportItem.setProjectCode(project.getCode());
                    if(orderByPerson) {
                        if (null != sortResult.get(reportItem.getPeriodStart())) {
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTime(reportItem.getPeriodStart());
                            int cnt = 1;
                            do {
                                calendar.set(Calendar.MILLISECOND, cnt++);
                            } while (null != sortResult.get(calendar.getTime()));
                            sortResult.put(calendar.getTime(), reportItem);

                        } else {
                            sortResult.put(reportItem.getPeriodStart(), reportItem);
                        }
                    } else {
                        result.add(reportItem);
                    }
                }
                if(orderByPerson) {
                    boolean continued = false;
                    for (ActivityPersonReport reportItem : sortResult.values()) {
                        reportItem.setContinued(continued);
                        result.add(reportItem);
                        reportItem.setFirstRow( ! continued);
                        continued = true;
                    }
                }
            }
        }
        if(result.size() > 0) {
            if (orderByPerson) {
                int cnt = 1;
                for (ActivityPersonReport reportItem : result) {
                    if (!reportItem.isContinued()) {
                        reportItem.setNpp(cnt++);
                    }
                }
            } else {
                Map<String, ActivityPersonReport> sortResult = new TreeMap<String, ActivityPersonReport>();
                int cnt = 0;
                for (ActivityPersonReport reportItem : result) {
                    String projectCode = reportItem.getProjectCode();
                    if (projectCode == null) {
                        projectCode = "";
                        reportItem.setProjectCode(projectCode);
                    }
                    String key = projectCode + "_" + reportItem.getPerson().getFIO() + "_" + (cnt++);
                    sortResult.put(key, reportItem);
                }

                result.clear();
                result.addAll(sortResult.values());
                boolean continued = false;
                boolean firstRow = true;
                cnt = 0;
                String activityCode = null;
                Person prevPerson = null;
                for (ActivityPersonReport reportItem : result) {
                    if( ! reportItem.getProjectCode().equals(activityCode)) {
                        cnt = 0;
                        activityCode = reportItem.getProjectCode();
                        firstRow = true;
                        prevPerson = null;
                    }
                    continued = reportItem.getPerson().equals(prevPerson);
                    reportItem.setContinued(continued);
                    if(!continued) {
                        cnt++;
                    }
                    reportItem.setNpp(cnt);
                    prevPerson = reportItem.getPerson();
                    reportItem.setFirstRow(firstRow);
                    reportItem.setActivityContinued(! firstRow);
                    firstRow = false;
                }
            }
        }

        for (ActivityPersonReport reportItem : result) {
            if(reportItem.getPeriodStart() != null && reportItem.getPeriodFinish() != null) {
                reportItem.setWorkDays(
                        DateHelper.calculateDaysBetweenTwoDatesInclusive(
                                reportItem.getPeriodStart(),
                                reportItem.getPeriodFinish())
                );
            }
            if( periodLengthInDays != 0 && reportItem.getLoadPercent() != null) {
                reportItem.setFte(reportItem.getWorkDays() * reportItem.getLoadPercent() / 100 / periodLengthInDays);
            } else {
                reportItem.setFte(0d);
            }
        }

        return result;
    }

    private Long getPrice365(BigDecimal dayPrice) {
        return Math.round(dayPrice.doubleValue()*100);
    }

    private Map<Long, Grade> loadGrades() {
        Map<Long, Grade> result = new HashMap<Long, Grade>();
        for(Grade grade: gradeDBLoader.getAll()) {
            gradeFieldsCryptor.decryptFields(grade);
            BigDecimal gradeSumma = dayPriceConverter.convertPriceFrom21WorkDayToCalendarDay(grade.getDayPrice());
            result.put(getPrice365(gradeSumma), grade);
        }
        return result;
    }

    private List<ActivityPersonReport> readPersonLoadOnActivities(Long personId, Date startDate, Date endDate) {
        List<ExpenseTeam> expenses = expensesTeamDBLoader.loadByFieldValue("personId", personId,
                new String[]{"projectId", "dateExp", "loadPercent", "price2"});

        List<ActivityPersonReport> result = getActivityPersonReports(startDate, endDate, expenses);

        return result;
    }

    private List<ActivityPersonReport> getActivityPersonReports(Date startDate, Date endDate, List<ExpenseTeam> expenses) {
        List<ActivityPersonReport> result = new LinkedList<ActivityPersonReport>();
        if(endDate.before(startDate)) {
            return result;
        }
        Map<Date, BenchLoad> benchDates = getBenchLoadMap(startDate, endDate);
        detectAndAddActivites(startDate, endDate, result, benchDates, expenses);
        detectAndAddBench(startDate, endDate, result, benchDates);
        return result;
    }

    private void detectAndAddActivites(Date startDate, Date endDate, List<ActivityPersonReport> result, Map<Date, BenchLoad> benchDates, List<ExpenseTeam> expenses) {
        if(expenses.size() > 0) {
            Calendar calendar = Calendar.getInstance();
            Iterator<ExpenseTeam> iterator = expenses.iterator();
            ExpenseTeam expense = iterator.next();
            while(expense != null) {
                final long projectId = expense.getProjectId().longValue();

                while(    expense != null
                        && projectId == expense.getProjectId().longValue()
                        ) {
                    ActivityPersonReport reportItem = new ActivityPersonReport();
                    Date fromDate = expense.getDateExp();
                    Date toDate = fromDate;
                    calendar.setTime(fromDate);
                    calendar.set(Calendar.HOUR_OF_DAY, 0);
                    calendar.set(Calendar.MINUTE, 0);
                    calendar.set(Calendar.SECOND, 0);
                    calendar.set(Calendar.MILLISECOND, 0);

                    calendar.add(Calendar.DAY_OF_MONTH, 1);

                    Date nextDate = calendar.getTime();
                    double currentLoadPercent = expense.getLoadPercent().doubleValue();
                    BigInteger currentPrice2 = expense.getPrice2();
                    reportItem.setProjectId(projectId);
                    reportItem.setLoadPercent(expense.getLoadPercent());
                    reportItem.setPeriodStart(fromDate);
                    reportItem.setPrice2(currentPrice2);

                    Date toDatePrev = toDate;
                    while(    expense != null
                            && currentLoadPercent == expense.getLoadPercent().doubleValue()
                            && projectId == expense.getProjectId().longValue()
                            && currentPrice2.equals(expense.getPrice2())
                            && nextDate.after(expense.getDateExp())
                            ) {
                        toDatePrev = toDate;
                        if(iterator.hasNext()) {
                            expense = iterator.next();
                            if(projectId == expense.getProjectId().longValue()) {
                                toDate = expense.getDateExp();
                                calendar.add(Calendar.DAY_OF_MONTH, 1);
                                nextDate = calendar.getTime();
                            }
                        } else {
                            expense = null;
                        }
                    }

                    if(reportItem.getLoadPercent().doubleValue() > 0d ) {
                        reportItem.setPeriodFinish(toDatePrev);
                        if( ! ( reportItem.getPeriodStart().after(endDate) || reportItem.getPeriodFinish().before(startDate) )) {
                            if(reportItem.getPeriodStart().before(startDate) ) {
                                reportItem.setPeriodStart(startDate);
                            }
                            if(reportItem.getPeriodFinish().after(endDate)) {
                                reportItem.setPeriodFinish(endDate);
                            }

                            result.add(reportItem);
                            calendar.setTime(reportItem.getPeriodStart());
                            do {
                                BenchLoad benchLoad = benchDates.get(calendar.getTime());
                                benchLoad.load -= reportItem.getLoadPercent().doubleValue();
                                calendar.add(Calendar.DAY_OF_MONTH, 1);
                            } while ( ! calendar.getTime().after(reportItem.getPeriodFinish()));
                        }
                    }
                }
            }
        }
    }

    private double getWorkDatesInPeriod(Date periodStart, Date periodFinish) {
        return calendarDBLoader.getCountWorkDays(periodStart, periodFinish);
    }

    private Map<Date, BenchLoad> getBenchLoadMap(Date startDate, Date endDate) {
        Calendar calendar = Calendar.getInstance();
        Map<Date, BenchLoad> benchDates = new HashMap<Date, BenchLoad>((int) DateHelper.calculateDaysBetweenTwoDatesInclusive(startDate, endDate));
        calendar.setTime(startDate);
        do {
            benchDates.put(calendar.getTime(), new BenchLoad(calendar.getTime()));
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        } while ( ! calendar.getTime().after(endDate));
        return benchDates;
    }

    private void detectAndAddBench(Date startDate, Date endDate, List<ActivityPersonReport> result, Map<Date, BenchLoad> benchDates) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(endDate);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        BenchLoad endMarker = new BenchLoad(calendar.getTime());
        endMarker.load = 1000;
        benchDates.put(calendar.getTime(), endMarker);
        calendar.setTime(startDate);
        BenchLoad benchLoad = benchDates.get(calendar.getTime());
        Date fromDate = startDate;
        Date toDate = fromDate;
        Date toDatePrev = fromDate;
        double benchLoadPercentCurrent = Math.round(benchLoad.load * 100 ) / 100.0;
        double benchLoadPercent = 0;
        int guardCounter = benchDates.size()+1;
        do {
            benchLoad = benchDates.get(calendar.getTime());
            benchLoadPercent = Math.round(benchLoad.load * 100 ) / 100.0;
            if(benchLoadPercent != benchLoadPercentCurrent) {
                // ��������� ������� ��������
                if(benchLoadPercentCurrent == 0) {
                    // ������� �������� �� �������� ��� ����� ���� - ������ ��������� ��������� ������������ �� ��������
                } else {
                    // ������� �������� �� �������� �� ��� ����� ���� - ������ ��������� �� ��������� ������������ �� ��������
                    ActivityPersonReport reportItem = new ActivityPersonReport();
                    reportItem.setPeriodStart(fromDate);
                    reportItem.setPeriodFinish(toDatePrev);
                    reportItem.setProjectId(new Long(-1));
                    reportItem.setLoadPercent(new Double(benchLoadPercentCurrent));
//                    reportItem.setWorkDays(DateHelper.calculateDaysBetweenTwoDatesInclusive(reportItem.getPeriodStart(), reportItem.getPeriodFinish()));
                    result.add(reportItem);
                }
                fromDate = calendar.getTime();
                benchLoadPercentCurrent = benchLoadPercent;
                if(benchLoad.load == 1000) {
                    break;
                }
            }
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            toDatePrev = toDate;
            toDate = calendar.getTime();
            guardCounter--;
            if(guardCounter == 0) {
                // ��������� ������� - ���� ����� �������� ������ � �� ��������� ������� if(benchLoad.load == 1000)
                break;
            }
        } while ( true );
    }

    private static class BenchLoad {
        Date date;
        double load = 100;

        public BenchLoad(Date date) {
            this.date = date;
        }
    }


    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}