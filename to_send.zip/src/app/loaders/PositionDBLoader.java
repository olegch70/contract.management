package app.loaders;

import app.dto.Position;

import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.Query;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "positionDBLoader")
@Named(value = "positionDBLoader")
@Stateless
public class PositionDBLoader extends CommonDbLoader<Position> {

    @Override
    protected Class getEntityClass() {
        return Position.class;
    }

    @Override
    protected Long getId(Position entity) {
        return entity.getId();
    }

    @Override
    public List<Position> getAll() {
        Query query = getEntityManager().createNamedQuery("Position.getAll");
        List result = query.getResultList();
        return result;
    }

    public List<Position> getAllWithNotActual() {
        Query query = getEntityManager().createNamedQuery("Position.getAllWithNotActual");
        List result = query.getResultList();
        return result;
    }
}
