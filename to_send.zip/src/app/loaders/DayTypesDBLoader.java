package app.loaders;

import app.dto.ContractStatus;
import app.dto.DayType;

import javax.ejb.Stateless;
import javax.inject.Named;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.12.13
 * Time: 14:48
 * To change this template use File | Settings | File Templates.
 */
@Stateless
@Named(value = "dayTypesDBLoader")
public class DayTypesDBLoader {
    private static List<DayType> dayTypes;

    static {
        dayTypes = new LinkedList<DayType>();
        dayTypes.add(DayType.WORKDAY);
        dayTypes.add(DayType.HOLYDAY);
    }

    public List<DayType> getAll() {
        List<DayType> resulttt = new LinkedList<DayType>();
        for(DayType dt : dayTypes) {
            resulttt.add(new DayType(dt.getId(), dt.getName()));
        }
        return resulttt;
    }

    public DayType getWorkDayType() {
        return DayType.WORKDAY;
    }

    public DayType getById(int type) {
        List<DayType> dayTypes = getAll();
        for(DayType dt : dayTypes) {
            if(dt.getId() == type) {
                return dt;
            }
        }
        return null;
    }
}
