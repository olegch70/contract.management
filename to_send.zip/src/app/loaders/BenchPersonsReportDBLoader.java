package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.DateHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "benchPersonsReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class BenchPersonsReportDBLoader {
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    CurrentDateBean currentDateBean;
    @EJB
    PersonFieldsCryptor personFieldsCryptor;
    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<BenchPersonReport> getReportData(ReportDateFilter reportDateFilter) {
        Date currentDate = currentDateBean.getCurrentDate();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.set(Calendar.MONTH, 0);
        Date yearStart = calendar.getTime();
        Date startDate = reportDateFilter.getStartDate();
        Date endDate = reportDateFilter.getEndDate();


        Query query = em.createQuery("select distinct et.personId from ExpenseTeam et " +
                "where et.dateExp between :startPeriod and :endPeriod ");
        query.setParameter("startPeriod", startDate);
        query.setParameter("endPeriod", endDate);
        List<Object> personsInTeams = query.getResultList();

        query = em.createQuery("select et.personId, sum(et.loadPercent) from ExpenseTeam et " +
                "where et.dateExp between :startPeriod and :endPeriod " +
                "group by et.personId " +
                "having sum(et.loadPercent) < :targetLoadPercent");
        query.setParameter("startPeriod", startDate);
        query.setParameter("endPeriod", endDate);
        double daysBetween = DateHelper.calculateDaysBetweenTwoDatesInclusive(startDate, endDate);
        query.setParameter("targetLoadPercent", daysBetween*100);
        List<Object[]> personsInTeamsWithNotFullLoad = query.getResultList();
        List<Object> personsInTeamWithNotFullLoadCorrected = new LinkedList<Object>();
        for(Object[] row: personsInTeamsWithNotFullLoad) {
            final Object personId = row[0];
            debug("personId = " + personId);
            Person person = personsDBLoader.getById(personId);
            Date employmentDate = person.getEmploymentDate();
            debug("employmentDate = " + employmentDate);
            if(employmentDate == null) {
                debug("employmentDate = null");
                personsInTeamWithNotFullLoadCorrected.add(personId);
                continue;
            }
            if(employmentDate.before(startDate)) {
                debug("employmentDate before "+ startDate);
                personsInTeamWithNotFullLoadCorrected.add(personId);
                continue;
            }
            if(employmentDate.after(endDate)) {
                debug("employmentDate after "+ endDate);
                continue;
            }
            int userDaysBetween = (int) DateHelper.calculateDaysBetweenTwoDatesInclusive(employmentDate, endDate)*100;
            int loadPercentSum = ((Number) row[1]).intValue();
            debug("userDaysBetween = " + userDaysBetween + " loadPercentSum = " + loadPercentSum);
            if(loadPercentSum == userDaysBetween) {
                debug("loadlPercentSum = userDaysBetween");
                continue;
            }
            personsInTeamWithNotFullLoadCorrected.add(personId);
        }
        personsInTeams.removeAll(personsInTeamWithNotFullLoadCorrected);
        if(personsInTeams.size() < 1) {
            personsInTeams.add(-1L);
        }

        query = em.createQuery("select p.id, p.lastName, p.firstName, p.middleName, p.dayPrice2 from Person p " +
                "where p.id not in :personsInTeam");
        query.setParameter("personsInTeam", personsInTeams);
        List<Object[]> personsAtBench = query.getResultList();

        Map<String, BenchPersonReport> sortedReport = new TreeMap<String, BenchPersonReport>();
        Person fakePerson = new Person();
        for(Object[] row : personsAtBench) {
            BenchPersonReport report = new BenchPersonReport();
            report.setFIO(row[1] + " " + row[2] + " " + row[3]);
            BigInteger personPrice2 = (BigInteger) row[4];
            query = em.createQuery("select sum(et.loadPercent) from ExpenseTeam et " +
                    "where et.dateExp = :endPeriod " +
                    "and et.personId = :personId");
            //query.setParameter("startPeriod", startDate);
            query.setParameter("endPeriod", endDate);
            final Long personId = (Long) row[0];
            query.setParameter("personId", personId);
            Number currentLoadPercent = (Number) query.getSingleResult();
            if(currentLoadPercent != null) {
                report.setCurrentLoadPercent(currentLoadPercent.doubleValue());
            }

            query = em.createQuery("select max(et.dateExp) from ExpenseTeam et " +
                    "where et.personId = :personId " +
                    "and et.dateExp between :startPeriod and :endPeriod");
            query.setParameter("personId", personId);
            query.setParameter("startPeriod", startDate);
            query.setParameter("endPeriod", endDate);
            Date maxDate = (Date) query.getSingleResult();
            debug("maxDate = " + maxDate);
            if(maxDate == null) {
                maxDate = reportDateFilter.getStartDate();
            }
            calendar.setTime(maxDate);
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            report.setBenchDate(calendar.getTime());

            //���������� ����, ����� ���� ������� ��������� �� ��������
            query = em.createQuery("select sum(et.loadPercent)/100 from ExpenseTeam et " +
                    "where et.personId = :personId " +
                    "and et.dateExp >= :startPeriod " +
                    "and et.dateExp <= :endPeriod ");
            query.setParameter("personId", personId);
            query.setParameter("startPeriod", startDate);
            query.setParameter("endPeriod", endDate);

//            query = em.createQuery("select et.dateExp from ExpenseTeam et " +
//                    "where et.personId = :personId " +
//                    "and et.dateExp <= :startPeriod " +
//                    "and et.dateExp >= :endPeriod " +
//                    "group by et.dateExp " +
//                    "order by et.dateExp");
//            query.setParameter("personId", row[0]);
//            query.setParameter("startPeriod", reportDateFilter.getStartDate());
//            query.setParameter("endPeriod", reportDateFilter.getEndDate());
//            LogSimple.debug(this, "personId = " + row[0]);
//            LogSimple.debug(this, "currentDate = " + currentDate);
//            LogSimple.debug(this, "yearStart = " + yearStart);
//
//            List<Object> workDays = query.getResultList();
//            LogSimple.debug(this, "workDays = " + workDays);
//            Date curDate = yearStart;
//            LogSimple.debug(this, "curDate = " + curDate);
//            double benchDays = 0;
//            for(Object workDay : workDays) {
//                //ToDo ��������� ���� �� NULL ����� ����������
//                LogSimple.debug(this, "workDay = " + workDay);
//                double daysBetween = DateHelper.calculateDaysBetweenTwoDatesExclusive(curDate, (Date) workDay);
//                LogSimple.debug(this, "daysBetween = " + daysBetween);
//                if(daysBetween >= 1){
//                    LogSimple.debug(this, "daysBetween >= 1");
//                    benchDays = benchDays + daysBetween - 1;
//                    LogSimple.debug(this, "benchDays = " + benchDays);
//                }
//                curDate = (Date) workDay;
//                LogSimple.debug(this, "curDate = workDay = " + curDate);
//            }
            Number workDays = (Number) query.getSingleResult();
            if(workDays == null) {
                workDays = 0;
            }
            double benchDays = 0;
            LogSimple.debug(this, "workDays = " + workDays);
            LogSimple.debug(this, "daysBetween = " + daysBetween);
            if(daysBetween >= 1){
                LogSimple.debug(this, "daysBetween >= 1 after cycle");
                benchDays = daysBetween - workDays.doubleValue();
            }
            LogSimple.debug(this, "benchDays = " + benchDays);
            report.setBenchDays(benchDays);

            fakePerson.setId(personId);
            fakePerson.setDayPrice2(personPrice2);
            personFieldsCryptor.decryptDayPrice(fakePerson);
            report.setPrice(fakePerson.getDayPrice().multiply(new BigDecimal(report.getBenchDays())));

            query = em.createQuery("select et.projectId, count(et), et.loadPercent, max(et.dateExp) from ExpenseTeam et " +
                    "where " +
                    "et.personId = :personId " +
                    "and et.dateExp between :startPeriod and :endPeriod " +
                    "group by et.projectId, et.loadPercent");
            query.setParameter("personId", personId);
            query.setParameter("startPeriod", startDate);
            query.setParameter("endPeriod", endDate);

            List<Object[]> projectsDataList = query.getResultList();
            debug("projectsDataList = " + projectsDataList);
            List<BenchPersonProject> personsProjects = new LinkedList<BenchPersonProject>();
            for(Object[] projectData : projectsDataList) {
                debug("projectData = " + projectData);
                BenchPersonProject personsProject = new BenchPersonProject();
                Project curProject = projectsDBLoader.getById(projectData[0]);
                debug("curProject = " + curProject);
                personsProject.setCaption(" \"" + curProject.getClient().getName() + "\" " + curProject.getCode() + " "
                        + curProject.getNumber());
                personsProject.setWorkDays((Long) projectData[1]);
                personsProject.setLoadPercent((Double) projectData[2]);
                personsProject.setLastDateOnProject((Date) projectData[3]);
                debug("setCaption = " + curProject.getCode() + curProject.getNumber());
                debug("personsProject.getCaption = " + personsProject.getCaption());
                debug("setWorkDays = " + projectData[1]);
                debug("personsProject.getWorkDays() = " + personsProject.getWorkDays());
                debug("setLoadPercent = " + projectData[2]);
                debug("personsProject.getLoadPercent() = " + personsProject.getLoadPercent());
                personsProjects.add(personsProject);
            }
            debug("personsProjects = " + personsProjects);
            report.setWorkProjects(personsProjects);
            sortedReport.put(report.getFIO(), report);
        }

        List<BenchPersonReport> reports = new ArrayList<BenchPersonReport>(sortedReport.size());
        reports.addAll(sortedReport.values());
        return reports;
    }



    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}