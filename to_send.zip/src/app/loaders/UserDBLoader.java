package app.loaders;

import app.dto.User;

import javax.ejb.Stateless;
import javax.inject.Named;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "positionDBLoader")
@Named(value = "userDBLoader")
@Stateless
public class UserDBLoader extends CommonDbLoader<User> {

    public User getUserByLogin(String login) {
        List<User> users = loadByFieldValue("login", login);
        if(users.size() == 0) {
            return null;
        }
        return users.get(0);
    }

    @Override
    protected Class getEntityClass() {
        return User.class;
    }

    @Override
    protected Long getId(User entity) {
        return entity.getId();
    }
}
