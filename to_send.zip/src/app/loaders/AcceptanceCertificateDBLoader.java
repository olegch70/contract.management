package app.loaders;

import app.dto.AcceptanceCertificate;
import app.dto.Income;

import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

@Named(value = "acceptanceCertificateDBLoader")
@Stateless
public class AcceptanceCertificateDBLoader extends CommonDbLoader<AcceptanceCertificate> {

    @Override
    protected Class getEntityClass() {
        return AcceptanceCertificate.class;
    }

    @Override
    protected Long getId(AcceptanceCertificate entity) {
        return entity.getId();
    }

}
