package app.loaders;

import app.beans.DateFormatter;
import app.dto.*;
import app.dto.report.DomainCost;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.NumberToSpeak;
import app.helpers.PersonFieldsCryptor;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "domainCostReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class DomainCostReportDBLoader {
    @EJB
    PersonFieldsCryptor personFieldsCryptor;
    @EJB
    DirectionDBLoader directionDBLoader;
    @EJB
    ExpenseTypeDBLoader expenseTypeDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;

    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    private Map<Long, DomainCost> domainCostMap;

    public Collection<DomainCost> getReportData(ReportDateFilter reportDateFilter,
                                                List<String> selectedDirectionsIds,
                                                List<String> selectedActivityTypesIds
    ) {
        Map<Long, Person> personCache = new HashMap<Long, Person>();
        domainCostMap = new HashMap<Long, DomainCost>();
        StringBuilder directions = new StringBuilder();
        StringBuilder activityTypes = new StringBuilder();
        Calendar calendar = Calendar.getInstance();
        calendar.set(reportDateFilter.getYear(), reportDateFilter.getStartMonth()-1, 1, 0, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date startPeriod = calendar.getTime();

        calendar.set(Calendar.MONTH, reportDateFilter.getEndMonth()-1);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date endPeriod = calendar.getTime();
        final int iMonthPeriod = reportDateFilter.getEndMonth() - reportDateFilter.getStartMonth() + 1;
        String wherePartDirection = "";
        String wherePartActTypes = "";

        if(selectedDirectionsIds != null && selectedDirectionsIds.size() >= 1) {
            for(String directionId : selectedDirectionsIds) {
                if(directions.length() > 0) {
                    directions.append(", ");
                }
                directions.append(directionId);
            }
            wherePartDirection = "   and c.direction_Id in (" + directions.toString() + ") ";
        }

        if(selectedActivityTypesIds != null && selectedActivityTypesIds.size() >= 1) {
            for(String activityTypeId : selectedActivityTypesIds ) {
                if(activityTypes.length() > 0) {
                    activityTypes.append(", ");
                }
                activityTypes.append(activityTypeId);
            }
            wherePartActTypes = "   and p.type in (" + activityTypes.toString() + ") ";
        }

        {


            Query query = null;

            String sql = "select c.direction_id, et.person_Id, et.price2, sum(et.load_Percent/100) " +
                    " from prj_Expenses_Team et " +
                    " join prj_Project p on p.id = et.project_Id " +
                    " join prj_Client c on c.id = p.client_id " +
                    " where et.date_Exp between ? and ? " +
                    wherePartDirection +
                    wherePartActTypes +
                    " group by c.direction_Id, et.person_Id, et.price2";
            debug(sql);
            query = em.createNativeQuery(
                    sql);

            query.setParameter(1, startPeriod);
            query.setParameter(2, endPeriod);
            List<Object[]> teamExpenses = query.getResultList();
            BigDecimal bd365_div_12 = new BigDecimal((365d / 12d));
            BigDecimal daysPeriod = new BigDecimal(getDaysInPeriod(startPeriod, endPeriod));
            BigDecimal monthPeriod = new BigDecimal(iMonthPeriod);
            BigDecimal BD_21 = new BigDecimal(21);

            for(Object[] row: teamExpenses) {
                Long directionId = getLongValue((Number) row[0]);
                Long personId = getLongValue((Number) row[1]);
                BigInteger price2 = getBigInteger((Number) row[2]);
                BigDecimal loadPercent = getBigDecimal(row[3]);


                DomainCost domainCost = getDomainCost(directionId);

                Person person = personCache.get(personId);
                if(person == null) {
                    person = personsDBLoader.getById(personId);
                    person.setDayPrice2(price2);
                    personFieldsCryptor.decryptFields(person);
                    personCache.put(personId, person);
                }

                BigDecimal expenseTeam = domainCost.getExpenseTeam();
                // ����� �������� ������� ������� ���������� �� ������ � ������������� � ��������� � �������� 21 �������� ���.
                // �� ������ 2 ������ ������� ��������� ��������� �� �������
                // ������ � ���� ������ ���������� ������� ����������������� ������ 61 ���� * %_�������_�_��������
                //    => ��� �������� ��������� � ���������� loadPercent
                //  ������� ����������� �������� � ���� ����� loadPercent / ����������_����_�_�������

                BigDecimal loadDayAverage = loadPercent.divide(daysPeriod, 5, RoundingMode.HALF_UP);

                //  ����������� ��������� ��� ���������� �� ������� (365-�� �������) � �������� (21-�� �������)
                // ��������� �������: ������� ������� ��������� (������� �� 365)
                // �� ������� ��������� ������� ��������� ������ => �������� �� 12

                BigDecimal monthSummaFor21workDays = person.getDayPrice().multiply(bd365_div_12);

                BigDecimal summa = monthSummaFor21workDays.multiply(loadDayAverage).multiply(monthPeriod);

                domainCost.setExpenseTeam(expenseTeam.add(summa));

//                    debug(    " personId=> "+personId
//                            + " person.gradeId=> "+ person.getGrade()
//                            + " directionId=> "+ directionId
//                            + " loadDayAverage=> "+loadDayAverage.setScale(2, RoundingMode.HALF_UP)
//                            + " price21day=> "+(monthSummaFor21workDays.divide(BD_21, 1, BigDecimal.ROUND_HALF_UP))
//                            + " monthSummaFor21workDays=> "+monthSummaFor21workDays.setScale(2, RoundingMode.HALF_UP)
//                            +"  summa=> "+summa.setScale(2, RoundingMode.HALF_UP));


            }
        }

        {
            final String sql = "select c.direction_Id, sum(ed.summa), ed.EXPENSE_TYPE_ID " +
                    " from prj_Expenses_Direct ed " +
                    " join prj_Project p on p.id = ed.project_Id " +
                    " join prj_Client c on c.id = p.client_Id " +
                    " where ed.date_Exp between ? and ? " +
                    wherePartDirection +
                    " group by c.direction_Id, ed.EXPENSE_TYPE_ID" +
                    " order by c.direction_Id, ed.expense_type_id";
            Query query = em.createNativeQuery(sql);
            debug("sql = " + sql);
            debug("startDate = " + startPeriod);
            debug("endDate = " + endPeriod);
            query.setParameter(1, startPeriod);
            query.setParameter(2, endPeriod);
            List<Object[]> expensesDirect = query.getResultList();

            for(Object[] row: expensesDirect) {
                Long directionId = getLongValue((Number) row[0]);
                BigDecimal summa = getBigDecimal(row[1]);

                DomainCost domainCost = getDomainCost(directionId);
                if(isTeamExpense(row[2])) {
                    debug("isTeamExpense - true, row[2] = " + row[2]);
                    BigDecimal expense = domainCost.getExpenseTeam();
                    domainCost.setExpenseTeam(expense.add(summa));
                } else {
                    debug("isTeamExpense - false , row[2] = " + row[2]);
                    BigDecimal expenseDirect = domainCost.getExpenseDirect();
                    domainCost.setExpenseDirect(expenseDirect.add(summa));
                }
            }

        }

        {
            Query query = em.createNativeQuery(
                    "select c.direction_Id, sum(income.summa) " +
                            " from prj_Income income " +
                            " join prj_Project p on p.id = income.project_Id " +
                            " join prj_Client c on c.id = p.client_Id " +
                            " where income.date_income between ? and ? " +
                            wherePartDirection +
                            " group by c.direction_Id"
            );

            query.setParameter(1, startPeriod);
            query.setParameter(2, endPeriod);

            List<Object[]> incomes = query.getResultList();

            for(Object[] row: incomes) {
                Long directionId = getLongValue((Number) row[0]);
                BigDecimal summa = getBigDecimal(row[1]);
                DomainCost domainCost = getDomainCost(directionId);

                BigDecimal income = domainCost.getIncome();
                domainCost.setIncome(income.add(summa));
            }
        }

        Map<String, DomainCost> sortResult = new TreeMap<String, DomainCost>();

        for(DomainCost row: domainCostMap.values()) {
            sortResult.put(row.getCaption(), row);
        }

        Collection<DomainCost> result = new ArrayList<DomainCost>(sortResult.size());
        if(selectedDirectionsIds == null || selectedDirectionsIds.contains(DirectionDBLoader.DIRECTION_BENCH.getId().toString())) {
            Collection<DomainCost> benchDomainCost = getBenchCost(iMonthPeriod, startPeriod, endPeriod);
            result.addAll(benchDomainCost);
        }
        result.addAll(sortResult.values());
        return result;
    }

    private boolean isTeamExpense(Object o) {
        debug("isTeamExpense caled o = " + o);
        if(o == null) {
            return false;
        }
        final Long expTypeId = getLongValue((Number) o);
        debug("expTypeId = " + expTypeId);
        return expTypeId.equals(getDirectExpensePremiumId()) || expTypeId.equals(getDirectExpenseOvertimeId());
    }

    private Long directExpensesPremiumId;
    private Long getDirectExpensePremiumId() {
        debug("getDIrectExpensePremiumId called, dirExpPremId = " + directExpensesPremiumId);
        if(directExpensesPremiumId == null) {
            final List<ExpenseType> expTypesList = expenseTypeDBLoader.loadByFieldValue("code", ConstantsHelper.DIRECT_EXPENSE_TEAM_PREMIUM);
            debug("expTypesList = " + expTypesList);
            if(expTypesList != null && expTypesList.size() > 0) {
                directExpensesPremiumId = expTypesList.get(0).getId();
                debug("directExpensesPremiumId = " + directExpensesPremiumId);
            } else {
                directExpensesPremiumId = -1L;
            }
        }
        return directExpensesPremiumId;
    }

    private Long directExpensesOvertimeId;
    private Long getDirectExpenseOvertimeId() {
        debug("getDIrectExpenseOvertimeId called, dirExpOverId = " + directExpensesOvertimeId);
        if(directExpensesOvertimeId == null) {
            final List<ExpenseType> expTypesList = expenseTypeDBLoader.loadByFieldValue("code", ConstantsHelper.DIRECT_EXPENSE_TEAM_OVERTIME);
            debug("expTypesList = " + expTypesList);
            if(expTypesList != null && expTypesList.size() > 0) {
                directExpensesOvertimeId = expTypesList.get(0).getId();
                debug("directExpensesOvertimeId = " + directExpensesOvertimeId);
            } else {
                directExpensesOvertimeId = -1L;
            }
        }
        return directExpensesOvertimeId;
    }

    private Collection<DomainCost> getBenchCost(final int iMonthPeriod, final Date startDate, final Date endDate) {
        Query query = em.createNativeQuery(
                "select pers.id, pers.day_price2, sum(et.load_percent/100) fullLoadDays, \n" +
                        " pers.EMPLOYMENT_DATE, pers.DISMISSAL_DATE \n" +
                        " from prj_person pers \n" +
                        " left join prj_expenses_team et on et.person_id = pers.id \n" +
                        "                              and et.date_exp between ? and ? \n" +
                        " group by pers.id, pers.day_price2, pers.EMPLOYMENT_DATE, pers.DISMISSAL_DATE");

        query.setParameter(1, startDate);
        query.setParameter(2, endDate);
        List<Object[]> benchResult = query.getResultList();
        Person tmpPerson = new Person();

        double daysPeriod = getDaysInPeriod(startDate, endDate);
        BigDecimal benchTeamExpenses = ConstantsHelper.BIGDECIMAL_ZERO;
        final Double zeroDouble = new Double(0);
        DateFormatter dateFormatter = new DateFormatter();
        long countPersonWOgrade = 0;
        for(Object[] row: benchResult) {
            tmpPerson.setId(((Number) row[0]).longValue());
            tmpPerson.setDayPrice2(((BigDecimal) row[1]).toBigInteger());
            Date employmentDate = (Date) row[3];
            Date dismissalDate = (Date) row[4];
            personFieldsCryptor.decryptDayPrice(tmpPerson);
            if(tmpPerson.getDayPrice().compareTo(ConstantsHelper.BIGDECIMAL_GRADE_BIG) == 0) {
                // ��������� ����� ��� ������
                // � ����� ����������� ����������� ������� ��������� ���
                countPersonWOgrade++;
                continue;

            }
            Double fullLoadDays = zeroDouble;
            if(row[2] != null) {
                fullLoadDays = ((Number) row[2]).doubleValue();
            }
            double _daysPeriod = daysPeriod;
            Date _startDate = startDate;
            Date _endDate = endDate;
            if(employmentDate != null || dismissalDate != null) {
                if(employmentDate != null && employmentDate.after(startDate)) {
                    _startDate = employmentDate;
                }
                if(dismissalDate != null && dismissalDate.before(endDate)) {
                    _endDate = dismissalDate;
                }
                if(_startDate.before(_endDate))
                    _daysPeriod = getDaysInPeriod(_startDate, _endDate);
            }
            double daysOnBench = _daysPeriod - fullLoadDays;
            if(daysOnBench < 0) {
                daysOnBench = 0;
            }
            if(daysOnBench > 0) {
                final BigDecimal personBenchSumma = tmpPerson.getDayPrice().multiply(new BigDecimal(daysOnBench));
                debug("Days for personId = "+ tmpPerson.getId()+ ": days on bench => "+ daysOnBench
                        + ", full day on projects => "+ fullLoadDays+" for period (days "+ _daysPeriod+", months "+ iMonthPeriod +" )"+
                        " from "+ dateFormatter.formatDate(_startDate)
                        + " to "+ dateFormatter.formatDate(_endDate)
                        + " personPrice "+ tmpPerson.getDayPrice()
                        + " benchSumma "+ personBenchSumma
                );
                benchTeamExpenses = benchTeamExpenses.add(personBenchSumma);
            }
        }

        Collection <DomainCost> result = new ArrayList<DomainCost>(2);
        {
            DomainCost
                    benchReportRecord = new DomainCost();
//            final long longDaysPeriod = new Double(daysPeriod).longValue();
            final String nameOfPeriod = NumberToSpeak.getSpeakEnd(iMonthPeriod, "�����", "������", "�������", NumberToSpeak.SEX_MAN);

            String benchName = DirectionDBLoader.DIRECTION_BENCH.getName()
                    + " ( ������ : " + iMonthPeriod + " " + nameOfPeriod + " )";
            benchReportRecord.setCaption(benchName);
            benchReportRecord.setExpenseTeam(benchTeamExpenses);
            result.add(benchReportRecord);
        }

        if(countPersonWOgrade > 0) {

            String speakCountPerson = NumberToSpeak.getSpeakEnd(countPersonWOgrade, "���������", "����������", "�����������", NumberToSpeak.SEX_MAN).trim();
            String benchName = DirectionDBLoader.DIRECTION_BENCH.getName()
                    + ". " + countPersonWOgrade + " " + speakCountPerson.trim()+ " ��� ������.";

            DomainCost benchReportRecord = new DomainCost();
            benchReportRecord.setCaption(benchName);
            result.add(benchReportRecord);
        }
        return result;
    }

    private long getDaysInPeriod(final Date startDate, final Date endDate) {
        final int msecInDay = 1000 * 24 * 60 * 60;
        return 1 + (endDate.getTime() - startDate.getTime()) / msecInDay;
    }

    private BigInteger getBigInteger(Number o) {
        if(o instanceof BigInteger) {
            return (BigInteger) o;
        }

        if(o instanceof BigDecimal) {
            return ((BigDecimal) o).toBigInteger();
        }
        return new BigInteger(o.toString());
    }

    private Long getLongValue(Number o) {
        if(o instanceof Long) {
            return (Long) o;
        }

        return o.longValue();
    }

    private BigDecimal getBigDecimal(Object objSumma) {
        if(objSumma == null) {
            return ConstantsHelper.BIGDECIMAL_ZERO;
        }

        BigDecimal summa;
        if(objSumma instanceof BigDecimal) {
            summa = (BigDecimal) objSumma;
        } else {
            summa = new BigDecimal(((Number) objSumma).doubleValue());
        }
        return summa;
    }

    private DomainCost getDomainCost(Long directionId) {
        DomainCost domainCost = domainCostMap.get(directionId);
        if(domainCost == null) {
            domainCost = new DomainCost();
            domainCost.setDirectionId(directionId);
            domainCost.setCaption(directionDBLoader.getById(directionId).getName());
            domainCostMap.put(directionId, domainCost);
        }
        return domainCost;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}