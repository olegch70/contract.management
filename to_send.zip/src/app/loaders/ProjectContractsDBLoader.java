package app.loaders;

import app.dto.ProjectContract;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 25.12.13
 * Time: 11:22
 * To change this template use File | Settings | File Templates.
 */
@Stateless
@Named(value = "projectContractsDBLoader")
public class ProjectContractsDBLoader extends CommonDbLoader<ProjectContract>  {

    @Override
    protected Class getEntityClass() {
        return ProjectContract.class;
    }

    @Override
    protected Long getId(ProjectContract entity) {
        return entity.getId();
    }

    @TransactionAttribute(TransactionAttributeType.MANDATORY)
    public void update(List<ProjectContract> newList, List<ProjectContract> oldList) {
        Map<Long, ProjectContract> notNew = new HashMap<Long, ProjectContract>();

        for(ProjectContract row : newList){
            if(row.getId() != null && row.getId()<0){
                row.setId(null);
                addNew(row);
            } else {
                notNew.put(row.getId(), row);
            }
        }
        for(ProjectContract oldRow : oldList) {
            ProjectContract newRow = notNew.get(oldRow.getId());
            if(newRow == null){
                delete(oldRow.getId());
            } else {
                if(!newRow.fullEquals(oldRow)) {
                    update(newRow);
                }
            }
        }
    }


    public void deleteByProjectId(Long id) {
        for(ProjectContract item: loadByLinkedId("projectId", id) ) {
            delete(item.getId());
        }
    }

    public List<ProjectContract> loadByProjectId(Long id) {
        return loadByFieldValue("projectId", id, new String[]{"docDate", "number"});
    }
}
