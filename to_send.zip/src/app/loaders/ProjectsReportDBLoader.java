package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "projectsReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class ProjectsReportDBLoader {
    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    ProjectTeamDBLoader projectTeamDBLoader;
    @EJB
    ClientsDBLoader clientsDBLoader;
    @EJB
    ProjectContractsDBLoader projectContractsDBLoader;
    @EJB
    ExpensesDirectDBLoader expensesDirectDBLoader;
    @EJB
    IncomeDBLoader incomeDBLoader;
    @EJB
    PersonFieldsCryptor personFieldsCryptor;
    @EJB
    CurrentDateBean currentDateBean;
    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<ProjectReport> getReportDataByClientId(Long clientId, ReportDateFilter reportDateFilter) {
        List<ProjectReport> reports = new LinkedList<ProjectReport>();
        LogSimple.debug(this, "clientsDBLoader.getById clientId= " + clientId);
        Client client = clientsDBLoader.getById(clientId);
        List<Project> projects = projectsDBLoader.loadByFieldValue("client", client);
        ProjectReport report;
        Date currentDate = currentDateBean.getCurrentDate();
        for(Project project : projects) {
            if(project.getStartDate().after(reportDateFilter.getEndDate())) {
               continue;
            }
            if(project.getEndDatePlan().before(reportDateFilter.getStartDate())) {
               continue;
            }
            report = new ProjectReport();
            report.setProjectId(project.getId());
            report.setCaption(project.getCode());
            report.setComment(project.getComment());
            report.setClientId(project.getClient().getId());
            report.setDirectionId(project.getClient().getDirectionId());

            Query query = em.createQuery("select sum(t.summa) from Income t " +
                    "where t.projectId = :prjId and t.dateIncome between :startDate and :endDate");
            query.setParameter("prjId", project.getId());
            query.setParameter("startDate", reportDateFilter.getStartDate());
            query.setParameter("endDate", reportDateFilter.getEndDate());
            BigDecimal income = (BigDecimal) query.getSingleResult();
            if(income == null){
                income = new BigDecimal(0);
            }
            report.setIncome(income);

//            query = em.createQuery("select sum(t.price) from ProjectContract t " +
//                    "where t.projectId = :prjId and t.docDate between :startDate and :endDate");
//            query.setParameter("prjId", project.getId());
//            query.setParameter("startDate", reportDateFilter.getStartDate());
//            query.setParameter("endDate", reportDateFilter.getEndDate());
//            BigDecimal price = (BigDecimal) query.getSingleResult();
            BigDecimal price = project.getPrice();
            debug("price = " + price);
            if(price == null){
                price = new BigDecimal(0);
            }
            report.setPrice(price);


            double expensesActual = 0;
            for(ExpenseDirect expDirect : expensesDirectDBLoader.loadByProjectId(project.getId())) {
                if(expDirect.getDateExp().before(reportDateFilter.getEndDate())
                        && expDirect.getDateExp().after(reportDateFilter.getStartDate())) {
                    expensesActual = expensesActual + expDirect.getSumma().doubleValue();
                }
            }
            report.setExpense(new BigDecimal(expensesActual));

            // ������� �� �������
            query = em.createQuery("select sum(t.loadPercent), t.personId, t.price2, t.dateExp from ExpenseTeam t " +
                    " where t.projectId = :projId and t.dateExp between :startDate and :endDate" +
                    " group by t.personId, t.price2, t.dateExp");
            query.setParameter("projId", project.getId());
            query.setParameter("startDate", reportDateFilter.getStartDate());
            query.setParameter("endDate", reportDateFilter.getEndDate());
            List<Object[]> teamExp = query.getResultList();
            Person fakePerson = new Person();

            double teamExpenses = 0;
            for(Object[] row : teamExp) {
                fakePerson.setId((Long) row[1]);
                fakePerson.setDayPrice2((BigInteger) row[2]);
                personFieldsCryptor.decryptDayPrice(fakePerson);
                teamExpenses = teamExpenses + (fakePerson.getDayPrice().doubleValue()*(Double) row[0])/(ConstantsHelper.DOUBLE_HUNDRED);
            }

            report.setTeamExpense(new BigDecimal(teamExpenses));

            report.setEndDatePlan(project.getEndDatePlan());
            report.setPlanFTE(project.getPlanFTE());
            price = report.getPrice();
            if(price == null || price.toString().trim().isEmpty()) {
                price = new BigDecimal(0);
            }
            report.setEfficiencyProgn(price.subtract(new BigDecimal(expensesActual)));

            if(
                    project.getPriceQ1() != null ||
                    project.getPriceQ2() != null ||
                    project.getPriceQ3() != null ||
                    project.getPriceQ4() != null
                    ) {

                report.setPricePlanned(project.getPriceQ1().add(project.getPriceQ2())
                        .add(project.getPriceQ3()).add(project.getPriceQ4()));

            } else {
                report.setPricePlanned(project.getPrice());
            }


            query = em.createQuery("select sum(t.loadPercent)/100 from ExpenseTeam t " +
                    " where t.projectId = :prjId and t.dateExp between :startDate and :endDate");
            query.setParameter("prjId", project.getId());
            query.setParameter("startDate", reportDateFilter.getStartDate());
            query.setParameter("endDate", reportDateFilter.getEndDate());
            Double workingPersons = (Double) query.getSingleResult();

            query = em.createNativeQuery("select count(*) from ( " +
                    "select et.date_exp from prj_expenses_team et " +
                    "where et.project_id = ?  " +
                    "and et.date_exp between ? and ? " +
                    "group by et.date_exp)");
            query.setParameter(1, project.getId());
            query.setParameter(2, reportDateFilter.getStartDate());
            query.setParameter(3, reportDateFilter.getEndDate());
            Double workDays = ((Number) query.getSingleResult()).doubleValue();

            if(workingPersons == null) {
                workingPersons = new Double(0);
            }
            if(workDays.doubleValue() != 0) {
                report.setWorkDays(workDays);
                report.setWorkingPersons(workingPersons);
                report.setActualAverageFTE(workingPersons / workDays);
            }

            query = em.createQuery("select sum(t.loadPercent)/100 from ExpenseTeam t " +
                    " where t.projectId = :prjId and t.dateExp = :curDate");
            query.setParameter("prjId", project.getId());
            query.setParameter("curDate", currentDate);
            Double actualCurrentFTE = (Double) query.getSingleResult();

            if(actualCurrentFTE != null) {
                report.setActualCurrentFTE(actualCurrentFTE);
            }

//            if(project.getStartDate().before(currentDate)) {
//                report.setActualAverageFTE(actualMiddleFTE / DateHelper.calculateDaysBetweenTwoDatesInclusive(project.getStartDate(), currentDate));
//            } else {
//                report.setActualAverageFTE(0);
//            }

            //������� �������� ������ �� ������� �� ������� ������
            List<TeamItem> team = projectTeamDBLoader.getByProjectId(project.getId());
            double gradeSum = 0;
            for(TeamItem row : team) {
                fakePerson.setId(row.getPersonId());
                fakePerson.setGrade2(row.getPerson().getGrade2());
                personFieldsCryptor.decryptGrade(fakePerson);
                gradeSum = gradeSum + fakePerson.getGrade().doubleValue();
            }
            if(team.size() > 0) {
                report.setGradeAverage(gradeSum/team.size());
            }

            reports.add(report);
        }
        return reports;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}