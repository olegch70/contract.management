package app.loaders.history;

import app.dto.history.IncomeHistory;
import app.loaders.CommonDbLoader;

import javax.ejb.Stateless;
import javax.inject.Named;

/**
 * Created by oleg on 19.08.2014.
 */
@Named(value = "incomeHistoryDBLoader")
@Stateless
public class IncomeHistoryDBLoader extends CommonDbLoader<IncomeHistory> {

    @Override
    protected Class getEntityClass() {
        return IncomeHistory.class;
    }

}
