package app.loaders.history;

import app.dto.history.ExpenseDirectFactHistory;
import app.loaders.CommonDbLoader;

import javax.ejb.Stateless;
import javax.inject.Named;

/**
 * Created by oleg on 19.08.2014.
 */
@Named(value = "expensesDirectFactHistoryDBLoader")
@Stateless
public class ExpensesDirectFactHistoryDBLoader extends CommonDbLoader<ExpenseDirectFactHistory> {

    @Override
    protected Class getEntityClass() {
        return ExpenseDirectFactHistory.class;
    }

}
