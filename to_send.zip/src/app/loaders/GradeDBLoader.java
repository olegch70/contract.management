package app.loaders;

import app.dto.Grade;
import app.helpers.GradeFieldsCryptor;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.Query;
import javax.transaction.*;
import java.util.List;

/**
 * User: user7598
 * Date: 18.12.13
 * Time: 14:13
 */
@Named(value = "gradeDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class GradeDBLoader extends CommonDbLoader<Grade>{

    @EJB
    GradeFieldsCryptor gradeFieldsCryptor;

    @Override
    protected Class getEntityClass() {
        return Grade.class;
    }

    @Override
    protected Long getId(Grade entity) {
        return entity.getId();
    }

    public Grade getByCode(Number code) {
        Query query = getEntityManager().createNamedQuery("Grade.getByCode");
        query.setParameter("code", code);
        List<Grade> result = query.getResultList();
        if(result.size() > 0) {
            Grade result0 = result.get(0);
            gradeFieldsCryptor.decryptFields(result0);
            return result0;
        }
        return null;
    }

    @Override
    protected void afterAddEntityToDb(Grade entity) throws HeuristicRollbackException, HeuristicMixedException, NotSupportedException, RollbackException, SystemException {
        gradeFieldsCryptor.encryptFields(entity);
        em.persist(entity);
    }

    @Override
    protected void afterUpdateEntityInDb(Grade entity, Grade mergedEntity) {
        mergedEntity.setDayPrice(entity.getDayPrice());
        gradeFieldsCryptor.encryptFields(mergedEntity);
        em.persist(mergedEntity);
    }

    public void enrichModel(List<Grade> model) {
        for(Grade grade: model) {
            gradeFieldsCryptor.decryptFields(grade);
        }
    }
}
