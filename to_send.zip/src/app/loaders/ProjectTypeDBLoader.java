package app.loaders;

import app.dto.ProjectType;

import javax.ejb.Stateless;
import javax.inject.Named;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.12.13
 * Time: 14:48
 * To change this template use File | Settings | File Templates.
 */
//@ManagedBean(name = "projectTypeDBLoader")
//@SessionScoped
@Stateless
@Named(value = "projectTypeDBLoader")
public class ProjectTypeDBLoader {
    private static List<ProjectType> projectTypes;

    static {projectTypes = new LinkedList<ProjectType>();
        projectTypes.add(ProjectType.FIX);
        projectTypes.add(ProjectType.FRAME);
        projectTypes.add(ProjectType.OUTSTAFF);
        projectTypes.add(ProjectType.PROJECT);
        projectTypes.add(ProjectType.PRESALE_A);
        projectTypes.add(ProjectType.PRESALE_B);
    }

    public List<ProjectType> getAll() {
        return projectTypes;
    }

    public ProjectType getProjectTypeById(Long id) {
        for(ProjectType row : getAll()) {
            if(row.getId().equals(id)) {
                return row;
            }
        }
        return null;
    }


}
