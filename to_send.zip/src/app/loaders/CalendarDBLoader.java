package app.loaders;

import app.dto.CalendarDay;
import app.dto.DayType;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 15.08.14
 * Time: 11:38
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "calendarDBLoader")
@Stateless
public class CalendarDBLoader extends CommonDbLoader<CalendarDay> {

    @EJB
    DayTypesDBLoader dayTypesDBLoader;
    private static final List<Integer> workDayTypes;

    static {
        workDayTypes = new ArrayList<Integer>(1);
        workDayTypes.add(new Integer(DayType.WORKDAY.getId()));
    }

    @Override
    protected Class getEntityClass() {
        return CalendarDay.class;
    }

    @Override
    protected Long getId(CalendarDay entity) {
        return entity.getId();
    }

    public double getCountWorkDays(Date periodStart, Date periodFinish) {
        Query query = getEntityManager().createNamedQuery("Calendar.countWorkDays");
        query.setParameter("dFrom", periodStart);
        query.setParameter("dTo", periodFinish);
        query.setParameter("types", workDayTypes);
        Number count = (Number) query.getSingleResult();
        return count.doubleValue();
    }

    @Override
    public List<CalendarDay> getAll() {
        return getAll(new String[]{"date"});

    }


}
