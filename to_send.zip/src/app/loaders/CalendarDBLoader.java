package app.loaders;

import app.dto.CalendarDay;
import app.dto.DayType;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 15.08.14
 * Time: 11:38
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "calendarDBLoader")
@Stateless
public class CalendarDBLoader extends CommonDbLoader<CalendarDay> {

    @EJB
    DayTypesDBLoader dayTypesDBLoader;
    private static final List<Integer> workDayTypes;

    static {
        workDayTypes = new ArrayList<Integer>(1);
        workDayTypes.add(new Integer(DayType.WORKDAY.getId()));
    }

    @Override
    protected Class getEntityClass() {
        return CalendarDay.class;
    }

    @Override
    protected Long getId(CalendarDay entity) {
        return entity.getId();
    }

    public double getCountWorkDays(Date periodStart, Date periodFinish) {
        Query query = getEntityManager().createNamedQuery("Calendar.countWorkDays");
        query.setParameter("dFrom", periodStart);
        query.setParameter("dTo", periodFinish);
        query.setParameter("types", workDayTypes);
        Number count = (Number) query.getSingleResult();
        return count.doubleValue();
    }

    public List<CalendarDay> getCalendarDaysByYear(Integer year) {
        List<CalendarDay> result = new LinkedList<CalendarDay>();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, 0, 1, 0, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date startPeriod = calendar.getTime();

        calendar.set(year, 11, 31, 0, 0, 0);
        Date endPeriod = calendar.getTime();
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select t.id, t.date, t.type from CalendarDay t " +
                        " where t.date between :fromDate and :toDate" +
                        " order by t.date");
        query.setParameter("fromDate", startPeriod);
        query.setParameter("toDate", endPeriod);
        List<Object[]> resultList = query.getResultList();
        for(Object[] row: resultList) {
            CalendarDay item = new CalendarDay();
            item.setId((Long) row[0]);
            item.setDate((Date) row[1]);
            item.setType((Integer) row[2]);
            result.add(item);
        }
        return result;
    }
}
