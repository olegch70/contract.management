package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "presaleReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class PresaleReportDBLoader {
    @EJB
    CurrentDateBean currentDateBean;
    @EJB
    ProjectTypeDBLoader projectTypeDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    ExpenseTypeDBLoader expenseTypeDBLoader;
    @EJB
    PersonFieldsCryptor personFieldsCryptor;

    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<ProjectReport> getReportData(ReportDateFilter reportDateFilter) {
        List<ProjectReport> reports = new LinkedList<ProjectReport>();
        Date startDate = reportDateFilter.getStartDate();
        Date endDate = reportDateFilter.getEndDate();
        List<Long> projectTypeIds = projectTypeDBLoader.getPresaleTypeIds();

        Query query = em.createQuery("select p.id, p.client, p.code, p.comment, p.endDatePlan from Project p " +
                " where p.type in :projectTypeIds");
        query.setParameter("projectTypeIds", projectTypeIds);
        List<Object[]> projectsList = query.getResultList();

        for(Object[] project: projectsList) {
            ProjectReport report = new ProjectReport();

            Client client = (Client) project[1];
            report.setClientName(client.getName());

            String caption = (String) project[2];
            report.setCaption(caption);

            String comment = (String) project[3];
            report.setComment(comment);

            Date endDatePlan = (Date) project[4];
            report.setEndDatePlan(endDatePlan);
            report.setExpense(ConstantsHelper.BIGDECIMAL_ZERO);
            report.setTeamExpense(ConstantsHelper.BIGDECIMAL_ZERO);

            Long id = (Long) project[0];

            query = em.createQuery("select p.expenseType, p.summa from ExpenseDirect p " +
                    " where p.projectId = :projectId" +
                    " and p.dateExp between :startDate and :endDate");
            query.setParameter("projectId", id);
            query.setParameter("startDate", startDate);
            query.setParameter("endDate", endDate);
            List<Object[]> expenseList = query.getResultList();
            for(Object[] expDirect: expenseList) {
                ExpenseType expType = ((ExpenseType) expDirect[0]);
                Long expTypeId = -2L;
                if(expType != null) {
                    expTypeId = expType.getId();
                }
                BigDecimal expSum = (BigDecimal) expDirect[1];
                if(expTypeId.equals(getDirectExpenseOvertimeId()) || expTypeId.equals(getDirectExpensePremiumId())) {
                    report.setTeamExpense(report.getTeamExpense().add(expSum));
                } else {
                    report.setExpense(report.getExpense().add(expSum));
                }
            }

            query = em.createQuery("select sum(t.loadPercent), t.personId, t.price2, t.dateExp from ExpenseTeam t " +
                    " where t.projectId = :projId" +
                    " and t.dateExp >= :startDate and t.dateExp <= :endDate" +
                    " group by t.personId, t.price2, t.dateExp");
            query.setParameter("projId", id);
            query.setParameter("startDate", startDate);
            query.setParameter("endDate", endDate);
            List<Object[]> teamExp = query.getResultList();
            Person fakePerson = new Person();
            BigDecimal expensesActual = ConstantsHelper.BIGDECIMAL_ZERO;
            for(Object[] row : teamExp) {
                fakePerson.setId((Long) row[1]);
                fakePerson.setDayPrice2((BigInteger) row[2]);
                personFieldsCryptor.decryptDayPrice(fakePerson);
                expensesActual = expensesActual.add(fakePerson.getDayPrice().multiply(new BigDecimal((Double) row[0])).divide(ConstantsHelper.BIGDECIMAL_HUNDRED));
            }
            report.setTeamExpense(report.getTeamExpense().add(expensesActual));
            if(report.getExpense().compareTo(ConstantsHelper.BIGDECIMAL_ZERO) == 0
                    && report.getTeamExpense().compareTo(ConstantsHelper.BIGDECIMAL_ZERO) == 0) {
                continue;
            }
            debug("report = " + report);
            reports.add(report);
        }

        return reports;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

    private Long directExpensesPremiumId;
    private Long getDirectExpensePremiumId() {
        debug("getDIrectExpensePremiumId called, dirExpPremId = " + directExpensesPremiumId);
        if(directExpensesPremiumId == null) {
            final List<ExpenseType> expTypesList = expenseTypeDBLoader.loadByFieldValue("code", ConstantsHelper.DIRECT_EXPENSE_TEAM_PREMIUM);
            debug("expTypesList = " + expTypesList);
            if(expTypesList != null && expTypesList.size() > 0) {
                directExpensesPremiumId = expTypesList.get(0).getId();
                debug("directExpensesPremiumId = " + directExpensesPremiumId);
            } else {
                directExpensesPremiumId = -1L;
            }
        }
        return directExpensesPremiumId;
    }

    private Long directExpensesOvertimeId;
    private Long getDirectExpenseOvertimeId() {
        debug("getDIrectExpenseOvertimeId called, dirExpOverId = " + directExpensesOvertimeId);
        if(directExpensesOvertimeId == null) {
            final List<ExpenseType> expTypesList = expenseTypeDBLoader.loadByFieldValue("code", ConstantsHelper.DIRECT_EXPENSE_TEAM_OVERTIME);
            debug("expTypesList = " + expTypesList);
            if(expTypesList != null && expTypesList.size() > 0) {
                directExpensesOvertimeId = expTypesList.get(0).getId();
                debug("directExpensesOvertimeId = " + directExpensesOvertimeId);
            } else {
                directExpensesOvertimeId = -1L;
            }
        }
        return directExpensesOvertimeId;
    }

}