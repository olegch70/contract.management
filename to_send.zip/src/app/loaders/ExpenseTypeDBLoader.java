package app.loaders;

import app.beans.RootChecker;
import app.dto.ExpenseType;
import app.dto.Person;
import app.helpers.ConstantsHelper;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.Query;
import java.util.Iterator;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "positionDBLoader")
@Named(value = "expenseTypeDBLoader")
@Stateless

public class ExpenseTypeDBLoader extends CommonDbLoader<ExpenseType> {
    @EJB
    private RootChecker rootChecker;

    @Override
    protected Class getEntityClass() {
        return ExpenseType.class;
    }

    @Override
    protected Long getId(ExpenseType entity) {
        return entity.getId();
    }

    @Override
    public List<ExpenseType> getAll() {
        Query query = getEntityManager().createNamedQuery("ExpenseType.getAll");
        List result = query.getResultList();
        return result;
    }

    public List<ExpenseType> getListForAuthorizedUser(Person authorisedUser) {
        Query query = getEntityManager().createNamedQuery("ExpenseType.getAll");
        List<ExpenseType> result  = query.getResultList();
        if ( ! rootChecker.isRoot(authorisedUser) && ! authorisedUser.isBuhReconciliation() ) {
            Iterator<ExpenseType> itr = result.iterator();
            while (itr.hasNext()) {
                ExpenseType expenseType = itr.next();
                if (expenseType != null && ConstantsHelper.DIRECT_EXPENSE_AHO.equals(expenseType.getCode())) {
                    itr.remove();
                }
            }
        }
        return result;
    }
}
