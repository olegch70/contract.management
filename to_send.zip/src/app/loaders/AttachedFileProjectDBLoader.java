package app.loaders;

import app.dto.AttachedFileProject;

import javax.ejb.Stateless;
import javax.inject.Named;

/**
 * Created by oleg on 31.07.2014.
 */
@Named(value = "attachedFileProjectDBLoader")
@Stateless
public class AttachedFileProjectDBLoader extends CommonDbLoader<AttachedFileProject> {
    @Override
    protected Class getEntityClass() {
        return AttachedFileProject.class;
    }
}
