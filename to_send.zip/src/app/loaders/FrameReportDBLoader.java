package app.loaders;

import app.beans.CurrentDateBean;
import app.beans.DateFormatter;
import app.dto.FrameReport;
import app.dto.Project;
import app.dto.ProjectType;
import app.helpers.LogSimple;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class FrameReportDBLoader {
    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    ProjectTypeDBLoader projectTypeDBLoader;
    @EJB
    ClientsDBLoader clientsDBLoader;
    @EJB
    IncomeDBLoader incomeDBLoader;
    @EJB
    CurrentDateBean currentDateBean;
    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<FrameReport> getReportData(Integer reportYear, List<String> reportQuartersForCheck, List<String> projectTypesForShow) {

        Date currentDate = currentDateBean.getCurrentDate();
        //Client client = clientsDBLoader.getById(clientId);
        StringBuffer projectTypesForQuery = new StringBuffer();
        for(String projectType : projectTypesForShow) {
            if(projectTypesForQuery.length() > 0) {
                projectTypesForQuery.append(", ");
            }
            projectTypesForQuery.append(projectType);
        }
        debug("projectTypesForShow = " + projectTypesForShow);
        debug("projectTypesForQuery.toString() = " + projectTypesForQuery.toString());

        //������ ���������� ������� ���� "�����" � "Presale - B", � ������ Q1-Q4(�������� ����������� �����) �
        // 1st-4th_Quarter(����������� ����������� �����), ���� "0", ���� ��������� ���� ���.
        Query query = em.createNativeQuery("select  " +
                "p.price_q1, " +
                "nvl(( " +
                "select sum(inc1.summa) from prj_income inc1 " +
                "where project_id = p.id " +
                "and date_income between ? /* 1 */ and ? /* 2 */" +
                "), 0) as first_Quarter,  " +
                "p.price_q2,  " +
                "nvl(( " +
                "select sum(inc1.summa) from prj_income inc1 " +
                "where project_id = p.id " +
                "and date_income between ? /* 3 */ and ? /* 4 */   " +
                "), 0) as sec_Quarter, " +
                "p.price_q3, " +
                "nvl(( " +
                "select sum(inc1.summa) from prj_income inc1 " +
                "where project_id = p.id " +
                "and date_income between ? /* 5 */ and ? /* 6 */ " +
                "), 0) as third_Quarter, " +
                "p.price_q4, " +
                "nvl(( " +
                "select sum(inc1.summa) from prj_income inc1 " +
                "where project_id = p.id " +
                "and date_income between ? /* 7 */ and ? /* 8 */ " +
                "), 0) as fourth_Quarter, p.id, p.type " +
                "from prj_project p " +
                "where p.type in ("+projectTypesForQuery.toString()+") and p.start_date between ? /* 9 */ and ? /* 10 */");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);

        calendar.set(Calendar.YEAR, reportYear);
        calendar.set(Calendar.MONTH, 0);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        Date yearStart = calendar.getTime();
        query.setParameter(1, calendar.getTime());
        debug(calendar.getTime());

        calendar.set(Calendar.MONTH, 2);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        query.setParameter(2, calendar.getTime());
        debug(calendar.getTime());

        calendar.set(Calendar.MONTH, 3);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        query.setParameter(3, calendar.getTime());
        debug(calendar.getTime());

        calendar.set(Calendar.MONTH, 5);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        query.setParameter(4, calendar.getTime());
        debug(calendar.getTime());

        calendar.set(Calendar.MONTH, 6);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        query.setParameter(5, calendar.getTime());
        debug(calendar.getTime());

        calendar.set(Calendar.MONTH, 8);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        query.setParameter(6, calendar.getTime());
        debug(calendar.getTime());

        calendar.set(Calendar.MONTH, 9);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        query.setParameter(7, calendar.getTime());
        debug(calendar.getTime());

        calendar.set(Calendar.MONTH, 11);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        query.setParameter(8, calendar.getTime());
        debug(calendar.getTime());
        Date yearEnd = calendar.getTime();

        query.setParameter(9, yearStart);
        query.setParameter(10, yearEnd);

        List<Object[]> projects = query.getResultList();
        List<FrameReport> reports = new ArrayList<FrameReport>(projects.size());
        List<ProjectType> projectTypes = projectTypeDBLoader.getAll();
        for(Object[] project : projects) {
            FrameReport report = new FrameReport();
            Project curProject = projectsDBLoader.getById(project[8]);
            report.setCaption("\""+curProject.getClient().getName()+"\"" + " " + curProject.getCode());
            debug("projectId = " + project[8]);
            debug("projectTypeId = " + project[9]);
            debug("projectTypeId.class = " + project[9].getClass());
            debug("project[0] = " + project[0]);
            debug("project[0] = " + project[0].getClass());
            report.setPriceQ1Plan((BigDecimal) project[0]);
            debug("project[1] = " + project[1]);
            debug("project[1] = " + project[1].getClass());
            report.setPriceQ1Actual((BigDecimal) project[1]);
            debug("project[2] = " + project[2]);
            debug("project[2] = " + project[2].getClass());
            report.setPriceQ2Plan((BigDecimal) project[2]);
            debug("project[3] = " + project[3]);
            debug("project[3] = " + project[3].getClass());
            report.setPriceQ2Actual((BigDecimal) project[3]);
            debug("project[4] = " + project[4]);
            debug("project[4] = " + project[4].getClass());
            report.setPriceQ3Plan((BigDecimal) project[4]);
            debug("project[5] = " + project[5]);
            debug("project[5] = " + project[5].getClass());
            report.setPriceQ3Actual((BigDecimal) project[5]);
            debug("project[6] = " + project[6]);
            debug("project[6] = " + project[6].getClass());
            report.setPriceQ4Plan((BigDecimal) project[6]);
            debug("project[7] = " + project[7]);
            debug("project[7] = " + project[7].getClass());
            report.setPriceQ4Actual((BigDecimal) project[7]);
            for(ProjectType curType : projectTypes) {
                debug("curTypeId = "+curType.getId());
                if(curType.getId().equals(((Number)project[9]).longValue())) {
                    debug("curTypeId = "+curType.getId() +" equal project[9] = " + project[9]);
                    report.setType(curType.getName());
                }
            }
            boolean add = false;
            if(reportQuartersForCheck == null || reportQuartersForCheck.size() == 0) {
                add = true;
            } else {
                if(reportQuartersForCheck.contains("1")) {
                    if(report.getPriceQ1Actual().compareTo(report.getPriceQ1Plan()) < 0){
                        add = true;
                    }
                }
                if(reportQuartersForCheck.contains("2")) {
                    if(report.getPriceQ2Actual().compareTo(report.getPriceQ2Plan()) < 0){
                        add = true;
                    }
                }
                if(reportQuartersForCheck.contains("3")) {
                    if(report.getPriceQ3Actual().compareTo(report.getPriceQ3Plan()) < 0){
                        add = true;
                    }
                }
                if(reportQuartersForCheck.contains("4")) {
                    if(report.getPriceQ4Actual().compareTo(report.getPriceQ4Plan()) < 0){
                        add = true;
                    }
                }
            }
            if(add == true) {
                reports.add(report);
            }
        }
        return reports;
    }


    DateFormatter dateFormatter = new DateFormatter();

    private void debug(Date time) {
        debug(dateFormatter.formatDate(time));
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}