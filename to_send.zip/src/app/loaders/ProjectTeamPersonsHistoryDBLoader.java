package app.loaders;

import app.beans.CurrentDateBean;
import app.beans.DayPriceConverter;
import app.dto.Person;
import app.dto.TeamItemHistory;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.Query;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:58
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "projectTeamPersonsHistoryDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class ProjectTeamPersonsHistoryDBLoader extends CommonDbLoader<TeamItemHistory> {
    @EJB
    PersonsDBLoader personsDBLoader;
//    @ManagedProperty(value = "#{positionDBLoader}")
    @EJB
    PositionDBLoader positionDBLoader;
//    @ManagedProperty(value = "#{expensesTeamDBLoader}")
    @EJB
    ExpensesTeamDBLoader expensesTeamDBLoader;
    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    ProjectContractsDBLoader projectContractsDBLoader;
    @EJB
    CurrentDateBean currentDateBean;

    @Inject
    PersonFieldsCryptor personFieldsCryptor;

    @Inject
    DayPriceConverter dayPriceConverter;

    @Override
    protected Class getEntityClass() {
        return TeamItemHistory.class;
    }

    public List<Person> getPersons(Long projectId) {
        Query q = getEntityManager().createNamedQuery("TeamItemHistory.personsFromHistory");
        q.setParameter("projectId", projectId);
        return q.getResultList();
    }

    public List<TeamItemHistory> getByProjectIdPersonId(Long projectId, Long personId) {
        Query q = getEntityManager().createNamedQuery("ProjectTeamHistory.getByProjectIdPersonId");
        q.setParameter("projectId", projectId);
        q.setParameter("personId", personId);
        return q.getResultList();
    }

    public void enrichModel(List<TeamItemHistory> model) {
        Person tmpPerson = new Person();
        for(TeamItemHistory item: model) {
            tmpPerson.setId(item.getPersonId());
            tmpPerson.setDayPrice2(item.getPrice2());
            personFieldsCryptor.decryptDayPrice(tmpPerson);

            item.setPrice21day(dayPriceConverter.convertPriceFromCalendarDayTo21WorkDay(tmpPerson.getDayPrice()).multiply(ConstantsHelper.BIGDECIMAL_21));
        }
    }

    private void log(String s) {
        LogSimple.debug(this, s);
    }
}
