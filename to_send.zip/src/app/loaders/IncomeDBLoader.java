package app.loaders;

import app.dto.Income;
import app.dto.history.HistoryFields;
import app.dto.history.IncomeHistory;
import app.loaders.history.IncomeHistoryDBLoader;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "incomeDBLoader")
@Named(value = "incomeDBLoader")
@Stateless
public class IncomeDBLoader extends CommonDbLoader<Income> {
    @EJB
    IncomeHistoryDBLoader historyDBLoader;

    @Override
    protected Class getEntityClass() {
        return Income.class;
    }

    @Override
    protected Long getId(Income entity) {
        return entity.getId();
    }

    public Number getProjectIncomeSum(Long projectId, Date from, Date to) {
        EntityManager em = getEntityManager();
        Query qDelete = em.createQuery(
                "select sum(t.summa) from Income t " +
                        " where t.projectId = :projectId " +
                        "   and t.dateIncome between :fromDate and :toDate");
        qDelete.setParameter("projectId", projectId);
        qDelete.setParameter("fromDate", from, TemporalType.DATE);
        qDelete.setParameter("toDate", to, TemporalType.DATE);
        return (Number) qDelete.getSingleResult();
    }

    public Number getProjectIncomeSum(Long projectId, Date to) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from Income t " +
                        " where t.projectId = :projectId " +
                        "   and t.dateIncome <= :toDate");
        query.setParameter("projectId", projectId);
        query.setParameter("toDate", to, TemporalType.DATE);
        return (Number) query.getSingleResult();
    }

    public Number getProjectIncomeSum(Long projectId) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from Income t " +
                        " where t.projectId = :projectId ");
        query.setParameter("projectId", projectId);
        return (Number) query.getSingleResult();
    }


    public Map<Long, Number> getProjectsIncomeSum(List<Long> projectsIds) {
        String sql = "select t.projectId, sum(t.summa) from Income t " +
                                " where t.projectId in ( projectIdsParameters ) " +
                                " group by t.projectId";

        return getLongNumberMap(sql, projectsIds);
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void addNew(Income item, HistoryFields historyFields) {
        addNew(item);
        addHistory(item, historyFields, HistoryFields.Operation.INSERT);
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(Income item, HistoryFields historyFields) {
        Income oldValue = getByIdDetached(item.getId());

        update(item);
        if(oldValue.getDescription() == null && item.getDescription() != null ) {
            oldValue.setDescription("");
        }
        if( ! item.equals(oldValue) ) {
            addHistory(item, historyFields, HistoryFields.Operation.UPDATE);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void delete(Long id, HistoryFields historyFields) {
        Income oldValue = getByIdDetached(id);
        delete(id);
        addHistory(oldValue, historyFields, HistoryFields.Operation.DELETE);
    }

    protected void addHistory(Income item, HistoryFields historyFields, HistoryFields.Operation historyOperation) {
        IncomeHistory historyItem = new IncomeHistory();
        historyItem.copyFrom(item);
        HistoryFields _historyFields = new HistoryFields();
        _historyFields.copyFrom(historyFields);
        _historyFields.setHistoryId(item.getId());
        _historyFields.setOperation(historyOperation);
        historyItem.setHistory(_historyFields);
        historyItem.setId(null);
        historyDBLoader.addNew(historyItem);
    }
}
