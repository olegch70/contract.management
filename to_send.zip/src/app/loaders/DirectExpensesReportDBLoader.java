package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "projectsReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class DirectExpensesReportDBLoader {
    @EJB
    CurrentDateBean currentDateBean;
    @EJB
    ProjectTypeDBLoader projectTypeDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    ExpenseTypeDBLoader expenseTypeDBLoader;

    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<DirectExpenseReport> getReportDataByClientsIds(List<String> clientsIds, ReportDateFilter reportDateFilter) {
        List<DirectExpenseReport> reports = new LinkedList<DirectExpenseReport>();
        StringBuffer clientsIdsForQuery = new StringBuffer();
        for(String clientId : clientsIds) {
            if(clientsIdsForQuery.length() > 0) {
                clientsIdsForQuery.append(", ");
            }
            clientsIdsForQuery.append(clientId);
        }
        Query query = em.createNativeQuery("select cl.name, pr.code, ed.date_exp, ed.expense_type_id, ed.summa, ed.initiator_id, ed.description from prj_expenses_direct ed " +
                "join prj_project pr on pr.id = ed.project_id " +
                "join prj_client cl on cl.id = pr.client_id " +
                "where cl.id in (" + clientsIdsForQuery.toString() + ") and ed.date_exp between ? /*1*/ and ? /*2*/");
        query.setParameter(1, reportDateFilter.getStartDate());
        query.setParameter(2, reportDateFilter.getEndDate());

        List<Object[]> expensesDirect = (List<Object[]>) query.getResultList();
        for(Object[] row : expensesDirect) {
            DirectExpenseReport report = new DirectExpenseReport();
            report.setClientName((String) row[0]);
            report.setCaption((String) row[1]);
            report.setDate((Date) row[2]);
            if(row[3] != null) {
                report.setType(expenseTypeDBLoader.getById(((BigDecimal)row[3]).longValue()).getName());
            }
            report.setPrice((BigDecimal) row[4]);
            if(row[5] != null) {
                report.setInitiator(personsDBLoader.getById(((BigDecimal)row[5]).longValue()).getFIO());
            }
            report.setComment((String) row[6]);
            reports.add(report);
        }
        return reports;
    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}