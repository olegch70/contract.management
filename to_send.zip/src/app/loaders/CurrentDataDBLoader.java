package app.loaders;

import app.dto.DebugProperty;
import app.helpers.LogSimple;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.Query;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 14:29
 * To change this template use File | Settings | File Templates.
 */
//@ManagedBean(name = "clientsDBLoader")
//@SessionScoped

@Named(value = "currentDateDebugDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class CurrentDataDBLoader extends CommonDbLoader<DebugProperty>{

    public static final String CURRENT_DATE_CODE = "currentDate";

    @Override
    protected Class getEntityClass() {
        return DebugProperty.class;
    }

    @Override
    protected Object getId(DebugProperty entity) {
        return entity.getCode();
    }

    public Date getCurrentDate() {
        Query query = getEntityManager().createNamedQuery("DebugProperties.getByCode");
        query.setParameter("code", CURRENT_DATE_CODE);
        List<DebugProperty> resultList = query.getResultList();
        if(resultList.size() == 0) {
            LogSimple.debug(this, "getCurrentDate. нет записи для code = 'currentDate'");
            return null;
        }
        if(resultList.size() > 1) {
            LogSimple.debug(this, "getCurrentDate. записей для code = 'currentDate' больше одной");
            return null;
        }

        // dd.mm.yyyy
        // 0123456789
        String stringDate = resultList.get(0).getStringValue();
        if(stringDate == null) {
            LogSimple.debug(this, "getCurrentDate. запись для code = 'currentDate' имеет пустое поле S_VALUE");
            return null;
        }

        if(stringDate.length() != 10) {
            LogSimple.debug(this, "getCurrentDate. запись для code = 'currentDate'. Значение поля S_VALUE должно быть вида 28.12.2000");
            return null;
        }
        try {
            return convertStringToDate(stringDate);
        } catch (Throwable t) {
            LogSimple.debug(this, "getCurrentDate. запись для code = 'currentDate'. " +
                    "Ошибка при обработке значения поля S_VALUE = " + stringDate + "\n" + t.getMessage());
            return null;
        }


    }



    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public void setCurrentDate(Date date) {
        DebugProperty debugProperty;
        String value = convertDateToString(date);

        List<DebugProperty> list = loadByFieldValue("code", CURRENT_DATE_CODE);
        if(list.size() < 1) {
            debugProperty = new DebugProperty();
            debugProperty.setCode(CURRENT_DATE_CODE);
            debugProperty.setStringValue(value);
            addNew(debugProperty);
        } else {
            debugProperty = list.get(0);
            debugProperty.setStringValue(value);
            update(debugProperty);
        }
    }

    /**
     *
     * @param stringDate dd.mm.yyyy
     * @return
     */

    public Date convertStringToDate(String stringDate) {
        int day = Integer.parseInt(stringDate.substring(0, 2));
        int month = Integer.parseInt(stringDate.substring(3, 5)) - 1;
        int year = Integer.parseInt(stringDate.substring(6, 10));
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day, 0, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    /**
     *
     * @param date
     * @return "dd.mm.yyyy"
     */
    public String convertDateToString(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        return (day < 10 ? "0" : "") + day + "."+ (month < 10 ? "0" : "") + month + "."+year;
    }


}
