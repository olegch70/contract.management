package app.loaders;

import app.dto.ContractStatus;
import app.dto.ExportMode;
import app.helpers.LogSimple;

import javax.ejb.Stateless;
import javax.inject.Named;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.12.13
 * Time: 14:48
 * To change this template use File | Settings | File Templates.
 */
//@ManagedBean(name = "projectTypeDBLoader")
//@SessionScoped
@Stateless
@Named(value = "exportModesDBLoader")
public class ExportModesDBLoader {
    private static List<ExportMode> exportModes;

    static {
        exportModes = new LinkedList<ExportMode>();
        exportModes.add(ExportMode.WHOLE_TABLE);
        exportModes.add(ExportMode.CURRENT_PAGE);
    }

    public List<ExportMode> getAll() {
        List<ExportMode> result = new LinkedList<ExportMode>();
        for(ExportMode em : exportModes) {
            result.add(new ExportMode(em.getName(), em.isValue()));
        }
        return result;
    }

}
