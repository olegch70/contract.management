package app.loaders;

import app.dto.ContractStatus;

import javax.ejb.Stateless;
import javax.inject.Named;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.12.13
 * Time: 14:48
 * To change this template use File | Settings | File Templates.
 */
@Stateless
@Named(value = "contractStatusDBLoader")
public class ContractStatusDBLoader {
    private static List<ContractStatus> contractStatuses;

    static {
        contractStatuses = new LinkedList<ContractStatus>();
        contractStatuses.add(ContractStatus.ACTIVE);
        contractStatuses.add(ContractStatus.PAUSED);
        contractStatuses.add(ContractStatus.CLOSED);
    }

    public List<ContractStatus> getAll() {
        List<ContractStatus> resulttt = new LinkedList<ContractStatus>();
        for(ContractStatus cs : contractStatuses) {
            resulttt.add(new ContractStatus(cs.getId(), cs.getName(), false));
        }
        return resulttt;
    }

    public List<ContractStatus> getPresaleAStatuses() {
        List<ContractStatus> result = new LinkedList<ContractStatus>();
        result = getAll();
        return result;
    }

    public List<ContractStatus> disableClosedStatus(List<ContractStatus> editableList) {
        List<ContractStatus> result = new LinkedList<ContractStatus>();
        result.addAll(editableList);
        for(ContractStatus cs : result) {
            if(ContractStatus.CLOSED.getName().equals(cs.getName())) {
                result.remove(cs);
                cs.setDisabled(true);
                result.add(cs);
            }
        }
        return result;
    }

    public List<ContractStatus> getOnOffStatuses() {
        List<ContractStatus> resultt;
        resultt = getAll();
        Iterator iterator = resultt.iterator();
        while(iterator.hasNext()) {
            if (iterator.next().equals(ContractStatus.PAUSED)) {
                iterator.remove();
            }
        }
        return resultt;
    }
}
