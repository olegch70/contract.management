package app.loaders.directexpensefact;

import app.beans.RootChecker;
import app.dto.ExpenseDirectFact;
import app.dto.ExpenseType;
import app.dto.Person;
import app.loaders.CommonDbLoader;
import app.loaders.ExpenseTypeDBLoader;
import app.loaders.PersonsDBLoader;
import app.loaders.ProjectsDBLoader;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

@Named(value = "expensesDirectFactDBLoader")
@Stateless
public class ExpensesDirectFactDBLoader extends CommonDbLoader<ExpenseDirectFact> {

    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    ExpenseTypeDBLoader expenseTypeDBLoader;

    @EJB
    private RootChecker rootChecker;

    @Override
    protected Class getEntityClass() {
        return ExpenseDirectFact.class;
    }

    @Override
    protected Long getId(ExpenseDirectFact entity) {
        return entity.getId();
    }

    public List<ExpenseDirectFact> getListForAuthorizedUser(Long projectId, Person authorisedUser) {
        List<ExpenseDirectFact> result = loadByFieldValue("projectId", projectId, new String[]{"dateExp", "summa"});

        List<ExpenseType> expenseTypes = expenseTypeDBLoader.getListForAuthorizedUser(authorisedUser);
        Map<ExpenseType, ExpenseType> mapExpenseType = new HashMap<ExpenseType, ExpenseType>(expenseTypes.size());
        for(ExpenseType item: expenseTypes) {
            mapExpenseType.put(item, item);
        }

        Iterator<ExpenseDirectFact> itr = result.iterator();
        while (itr.hasNext()) {
            ExpenseDirectFact item = itr.next();
            ExpenseType expenseType = item.getExpenseType();
            if ( mapExpenseType.get(expenseType) == null ) {
                itr.remove();
            }
        }
        return result;
    }

    public Number getProjectExpensesDirectSum(Long projectId, Date from, Date to) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from ExpenseDirectFact t " +
                        " where t.projectId = :projectId " +
                        "   and t.dateExp between :fromDate and :toDate");
        query.setParameter("projectId", projectId);
        query.setParameter("fromDate", from, TemporalType.DATE);
        query.setParameter("toDate", to, TemporalType.DATE);
        return (Number) query.getSingleResult();
    }

    public Number getProjectExpensesDirectSum(Long projectId) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from ExpenseDirectFact t " +
                        " where t.projectId = :projectId ");
        query.setParameter("projectId", projectId);
        return (Number) query.getSingleResult();
    }

    public Map<Long, Number> getProjectsExpensesDirectSum(List<Long> projectsIds, Date currentDate) {
        String sql = "select t.projectId, sum(t.summa) from ExpenseDirectFact t " +
                " where t.projectId in ( projectIdsParameters ) " +
                "   and t.dateExp <= :currentDate " +
                " group by t.projectId";
        return getLongNumberMap(sql, projectsIds, new String[] {"currentDate"}, new Object[]{currentDate});
    }

    public Map<Long, Number> getProjectsExpensesDirectSumPlan(List<Long> projectsIds, Date currentDate) {
        String sql = "select t.projectId, sum(t.summa) from ExpenseDirectFact t " +
                " where t.projectId in ( projectIdsParameters ) " +
                "   and t.dateExp > :currentDate " +
                " group by t.projectId";

        return getLongNumberMap(sql, projectsIds, new String[] {"currentDate"}, new Object[]{currentDate});
    }

    public List<ExpenseDirectFact> loadByProjectId(Long id) {
        return loadByLinkedId("projectId", id, new String[]{"dateExp", "summa"});
    }

    public Number getSumma(Long id) {
        Query q = em.createNamedQuery("ExpenseDirectFact.summaForId");
        q.setParameter("projectId", id);
        return (Number) q.getSingleResult();
    }

    public Number getSumma(Long id, Date startDate, Date endDate) {
        Query q = em.createNamedQuery("ExpenseDirectFact.summaForIdByPeriod");
        q.setParameter("projectId", id);
        q.setParameter("startDate", startDate, TemporalType.DATE);
        q.setParameter("endDate", endDate, TemporalType.DATE);
        return (Number) q.getSingleResult();
    }
}
