--------------------------------------------------------
--  DDL for Table PRJ_DIRECTION
--------------------------------------------------------

  CREATE TABLE "PRJ_DIRECTION" 
   (	"ID" NUMBER(38,0), 
	"NAME" VARCHAR2(255 CHAR)
   ) ;
