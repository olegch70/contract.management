--------------------------------------------------------
--  Ref Constraints for Table PRJ_EXPENSES_DIRECT
--------------------------------------------------------

  ALTER TABLE "PRJ_EXPENSES_DIRECT" ADD CONSTRAINT "PRJ_EXPENSES_DIRECT_FK_PRJ" FOREIGN KEY ("PROJECT_ID")
	  REFERENCES "PRJ_PROJECT" ("ID") ENABLE;
