--------------------------------------------------------
--  DDL for Index I_PRJ_SPECIALITY_NAME
--------------------------------------------------------

  CREATE UNIQUE INDEX "I_PRJ_SPECIALITY_NAME" ON "PRJ_SPECIALITY" ("FL_ACTUAL") 
  ;
