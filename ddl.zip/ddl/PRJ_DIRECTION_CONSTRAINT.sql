--------------------------------------------------------
--  Constraints for Table PRJ_DIRECTION
--------------------------------------------------------

  ALTER TABLE "PRJ_DIRECTION" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "PRJ_DIRECTION" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "PRJ_DIRECTION" ADD CONSTRAINT "PRJ_DIRECTION_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;
