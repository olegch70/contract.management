--------------------------------------------------------
--  DDL for Index PRJ_EXPENSES_DIRECT_I_PRJ_DAT
--------------------------------------------------------

  CREATE INDEX "PRJ_EXPENSES_DIRECT_I_PRJ_DAT" ON "PRJ_EXPENSES_DIRECT" ("PROJECT_ID", "DATE_EXP") 
  ;
