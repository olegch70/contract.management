--------------------------------------------------------
--  DDL for Index PRJ_PROJECTTEAM_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_PROJECTTEAM_PK" ON "PRJ_PROJECTTEAM" ("ID") 
  ;
