--------------------------------------------------------
--  DDL for Index I_PRJ_PERSON_LASTN
--------------------------------------------------------

  CREATE INDEX "I_PRJ_PERSON_LASTN" ON "PRJ_PERSON" ("LASTNAME") 
  ;
