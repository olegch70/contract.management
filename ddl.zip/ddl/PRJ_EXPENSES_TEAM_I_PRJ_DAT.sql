--------------------------------------------------------
--  DDL for Index PRJ_EXPENSES_TEAM_I_PRJ_DAT
--------------------------------------------------------

  CREATE INDEX "PRJ_EXPENSES_TEAM_I_PRJ_DAT" ON "PRJ_EXPENSES_TEAM" ("PROJECT_ID", "DATE_EXP") 
  ;
