--------------------------------------------------------
--  DDL for Table PRJ_INCOME
--------------------------------------------------------

  CREATE TABLE "PRJ_INCOME" 
   (	"ID" NUMBER(38,0), 
	"PROJECT_ID" NUMBER(38,0), 
	"DATE_INCOME" DATE, 
	"SUMMA" NUMBER(17,2), 
	"DESCRIPTION" VARCHAR2(4000 CHAR)
   ) ;
