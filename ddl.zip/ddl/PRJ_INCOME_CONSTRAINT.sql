--------------------------------------------------------
--  Constraints for Table PRJ_INCOME
--------------------------------------------------------

  ALTER TABLE "PRJ_INCOME" MODIFY ("DATE_INCOME" NOT NULL ENABLE);
  ALTER TABLE "PRJ_INCOME" MODIFY ("PROJECT_ID" NOT NULL ENABLE);
  ALTER TABLE "PRJ_INCOME" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "PRJ_INCOME" ADD CONSTRAINT "PRJ_INCOME_ID" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;
