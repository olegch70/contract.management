--------------------------------------------------------
--  DDL for Index PRJ_EXPENSES_TEAM_UK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_EXPENSES_TEAM_UK" ON "PRJ_EXPENSES_TEAM" ("PROJECT_ID", "PERSON_ID", "DATE_EXP") 
  ;
