--------------------------------------------------------
--  Ref Constraints for Table PRJ_INCOME
--------------------------------------------------------

  ALTER TABLE "PRJ_INCOME" ADD CONSTRAINT "PRJ_INCOME_FK_PRJ" FOREIGN KEY ("PROJECT_ID")
	  REFERENCES "PRJ_PROJECT" ("ID") ENABLE;
