--------------------------------------------------------
--  DDL for Index PRJ_PROJECT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_PROJECT_PK" ON "PRJ_PROJECT" ("ID") 
  ;
