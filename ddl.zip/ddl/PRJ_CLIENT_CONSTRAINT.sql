--------------------------------------------------------
--  Constraints for Table PRJ_CLIENT
--------------------------------------------------------

  ALTER TABLE "PRJ_CLIENT" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "PRJ_CLIENT" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "PRJ_CLIENT" ADD CONSTRAINT "PRJ_CLIENT_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;
