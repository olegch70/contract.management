--------------------------------------------------------
--  Constraints for Table PRJ_POSITION
--------------------------------------------------------

  ALTER TABLE "PRJ_POSITION" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "PRJ_POSITION" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "PRJ_POSITION" ADD CONSTRAINT "PK_PRJ_POSITION" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;
