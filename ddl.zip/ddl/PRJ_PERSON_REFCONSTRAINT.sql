--------------------------------------------------------
--  Ref Constraints for Table PRJ_PERSON
--------------------------------------------------------

  ALTER TABLE "PRJ_PERSON" ADD CONSTRAINT "PRJ_PERSON_FK_ALTERNATE_PM" FOREIGN KEY ("ALTERNATE_PM_ID")
	  REFERENCES "PRJ_PERSON" ("ID") ENABLE;
  ALTER TABLE "PRJ_PERSON" ADD CONSTRAINT "PRJ_PERSON_FK_POSITION" FOREIGN KEY ("POSITION_ID")
	  REFERENCES "PRJ_POSITION" ("ID") ENABLE;
