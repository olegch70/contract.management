--------------------------------------------------------
--  Ref Constraints for Table PRJ_EXPENSES_TEAM
--------------------------------------------------------

  ALTER TABLE "PRJ_EXPENSES_TEAM" ADD CONSTRAINT "PRJ_EXPENSES_TEAM_FK_PRJ" FOREIGN KEY ("PROJECT_ID")
	  REFERENCES "PRJ_PROJECT" ("ID") ENABLE;
  ALTER TABLE "PRJ_EXPENSES_TEAM" ADD CONSTRAINT "PRJ_EXPENSES_TEAM_FK_PERS" FOREIGN KEY ("PERSON_ID")
	  REFERENCES "PRJ_PERSON" ("ID") ENABLE;
