--------------------------------------------------------
--  DDL for Index PRJ_INCOME_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_INCOME_ID" ON "PRJ_INCOME" ("ID") 
  ;
