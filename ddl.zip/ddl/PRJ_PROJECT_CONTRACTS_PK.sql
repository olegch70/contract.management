--------------------------------------------------------
--  DDL for Index PRJ_PROJECT_CONTRACTS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_PROJECT_CONTRACTS_PK" ON "PRJ_PROJECT_CONTRACTS" ("ID") 
  ;
