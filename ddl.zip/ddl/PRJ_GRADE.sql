--------------------------------------------------------
--  DDL for Table PRJ_GRADE
--------------------------------------------------------

  CREATE TABLE "PRJ_GRADE" 
   (	"ID" NUMBER(38,0), 
	"CODE" NUMBER(4,0), 
	"DAY_PRICE2" NUMBER(38,0), 
	"DAY_PRICE_SAV" NUMBER(38,0)
   ) ;
