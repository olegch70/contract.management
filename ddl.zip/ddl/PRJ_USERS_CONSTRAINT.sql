--------------------------------------------------------
--  Constraints for Table PRJ_USERS
--------------------------------------------------------

  ALTER TABLE "PRJ_USERS" MODIFY ("LOGIN" NOT NULL ENABLE);
  ALTER TABLE "PRJ_USERS" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "PRJ_USERS" ADD CONSTRAINT "PRJ_USERS_UK_LOGIN" UNIQUE ("LOGIN")
  USING INDEX  ENABLE;
  ALTER TABLE "PRJ_USERS" ADD CONSTRAINT "PRJ_USERS_PK" PRIMARY KEY ("ID")
  USING INDEX  ENABLE;
