--------------------------------------------------------
--  DDL for Index PRJ_EXPENSES_TEAM_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_EXPENSES_TEAM_ID" ON "PRJ_EXPENSES_TEAM" ("ID") 
  ;
