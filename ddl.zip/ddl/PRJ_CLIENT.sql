--------------------------------------------------------
--  DDL for Table PRJ_CLIENT
--------------------------------------------------------

  CREATE TABLE "PRJ_CLIENT" 
   (	"ID" NUMBER(38,0), 
	"NAME" VARCHAR2(250 CHAR), 
	"TECHNICAL_AM_ID" NUMBER(38,0), 
	"DIRECTION_ID" NUMBER(38,0), 
	"TEAM_PERCENT" NUMBER(38,5), 
	"CONTRACTS_PERCENT" NUMBER(38,5)
   ) ;

   COMMENT ON COLUMN "PRJ_CLIENT"."TECHNICAL_AM_ID" IS 'Technical Account Manager - ������� �� �������';
