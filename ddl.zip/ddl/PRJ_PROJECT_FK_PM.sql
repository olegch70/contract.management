--------------------------------------------------------
--  DDL for Index PRJ_PROJECT_FK_PM
--------------------------------------------------------

  CREATE INDEX "PRJ_PROJECT_FK_PM" ON "PRJ_PROJECT" ("PROJECT_MANAGER_ID") 
  ;
