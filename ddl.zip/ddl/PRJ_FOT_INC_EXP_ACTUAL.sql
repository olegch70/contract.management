--------------------------------------------------------
--  DDL for Table PRJ_FOT_INC_EXP_ACTUAL
--------------------------------------------------------

  CREATE TABLE "PRJ_FOT_INC_EXP_ACTUAL" 
   (	"ID" NUMBER(38,0), 
	"DATE_FACT" DATE, 
	"FOT" NUMBER(38,5), 
	"EXPENSE" NUMBER(38,5), 
	"INCOME" NUMBER(38,5), 
	"OVERTIME" NUMBER(38,5), 
	"PREMIUM" NUMBER(38,5)
   ) ;
