--------------------------------------------------------
--  DDL for Index PRJ_GRADE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_GRADE_PK" ON "PRJ_GRADE" ("ID") 
  ;
