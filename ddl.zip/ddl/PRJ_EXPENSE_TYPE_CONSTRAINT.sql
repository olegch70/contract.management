--------------------------------------------------------
--  Constraints for Table PRJ_EXPENSE_TYPE
--------------------------------------------------------

  ALTER TABLE "PRJ_EXPENSE_TYPE" MODIFY ("ID" NOT NULL ENABLE);
