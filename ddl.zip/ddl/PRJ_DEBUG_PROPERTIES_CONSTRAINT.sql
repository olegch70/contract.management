--------------------------------------------------------
--  Constraints for Table PRJ_DEBUG_PROPERTIES
--------------------------------------------------------

  ALTER TABLE "PRJ_DEBUG_PROPERTIES" MODIFY ("CODE" NOT NULL ENABLE);
  ALTER TABLE "PRJ_DEBUG_PROPERTIES" ADD CONSTRAINT "PRJ_DEBUG_PROPERTIES_PK" PRIMARY KEY ("CODE")
  USING INDEX  ENABLE;
