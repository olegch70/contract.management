--------------------------------------------------------
--  DDL for Index PRJ_INCOME_I_PRJ_DAT
--------------------------------------------------------

  CREATE INDEX "PRJ_INCOME_I_PRJ_DAT" ON "PRJ_INCOME" ("PROJECT_ID", "DATE_INCOME") 
  ;
