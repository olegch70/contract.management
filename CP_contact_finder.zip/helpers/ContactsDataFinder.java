package app.helpers;

import app.dto.Client;
import app.dto.Person;
import app.dto.Project;
import app.dto.TeamItem;
import app.loaders.ClientsDBLoader;
import app.loaders.PersonsDBLoader;
import app.loaders.ProjectsDBLoader;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 04.11.14
 * Time: 17:39
 * To change this template use File | Settings | File Templates.
 */
@Stateless
public class ContactsDataFinder {
    public static final String PHONES_KEY = "phones";
    public static final String EMAILS_KEY = "emails";
    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    ClientsDBLoader clientsDBLoader;
    @EJB
    PersonsDBLoader personsDBLoader;

    public Map<String, List<String>> getContactsInfo(Long projectId) {
        Project curProject = projectsDBLoader.getById(projectId);

        Client curClient = clientsDBLoader.getById(curProject.getClientId());

        Long tamID = curClient.getTechnicalAM();

        Person projManager = personsDBLoader.getById(curProject.getProjectManagerId());
        Person tecAccManager = personsDBLoader.getById(tamID);

        List<String> phonesList = new LinkedList<String>();
        phonesList.add(projManager.getContactPhone());
        phonesList.add(tecAccManager.getContactPhone());

        List<String> emailsList = new LinkedList<String>();
        emailsList.add(projManager.getEmail());
        emailsList.add(tecAccManager.getEmail());

        Map<String, List<String>> result = new HashMap<String, List<String>>();
        result.put(PHONES_KEY, phonesList);
        result.put(EMAILS_KEY, emailsList);

        return result;
    }
}
