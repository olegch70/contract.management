package app.helpers;

import app.dto.Client;
import app.dto.Person;
import app.dto.Project;
import app.dto.TeamItem;
import app.loaders.ClientsDBLoader;
import app.loaders.PersonsDBLoader;
import app.loaders.ProjectsDBLoader;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 04.11.14
 * Time: 17:39
 * To change this template use File | Settings | File Templates.
 */
@Stateless
public class DataSendHelper {

    public void sendChangeNotification(Map<String, List<String>> emailAndPhone, List<TeamItem> editedList, List<TeamItem> oldList) {
        LogSimple.debug("sending for phones: " + emailAndPhone.get("phones") + " emails: " + emailAndPhone.get("emails")
                + " data: editedList: " + editedList.size() + " oldList: " + oldList.size());
    }
}
