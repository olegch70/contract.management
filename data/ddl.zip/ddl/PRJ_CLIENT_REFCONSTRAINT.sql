--------------------------------------------------------
--  Ref Constraints for Table PRJ_CLIENT
--------------------------------------------------------

  ALTER TABLE "PRJ_CLIENT" ADD CONSTRAINT "PRJ_CLIENT_FK_DIRECTION" FOREIGN KEY ("DIRECTION_ID")
	  REFERENCES "PRJ_DIRECTION" ("ID") ENABLE;
