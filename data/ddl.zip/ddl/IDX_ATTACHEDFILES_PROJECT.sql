--------------------------------------------------------
--  DDL for Index IDX_ATTACHEDFILES_PROJECT
--------------------------------------------------------

  CREATE INDEX "IDX_ATTACHEDFILES_PROJECT" ON "PRJ_ATTACHEDFILES_PROJECT" ("PROJECT_ID") 
  ;
