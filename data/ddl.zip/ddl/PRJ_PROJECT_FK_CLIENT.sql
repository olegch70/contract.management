--------------------------------------------------------
--  DDL for Index PRJ_PROJECT_FK_CLIENT
--------------------------------------------------------

  CREATE INDEX "PRJ_PROJECT_FK_CLIENT" ON "PRJ_PROJECT" ("CLIENT_ID") 
  ;
