--------------------------------------------------------
--  DDL for Index PRJ_GRADE_UK_CODE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_GRADE_UK_CODE" ON "PRJ_GRADE" ("CODE") 
  ;
