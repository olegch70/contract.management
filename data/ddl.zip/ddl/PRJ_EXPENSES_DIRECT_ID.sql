--------------------------------------------------------
--  DDL for Index PRJ_EXPENSES_DIRECT_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_EXPENSES_DIRECT_ID" ON "PRJ_EXPENSES_DIRECT" ("ID") 
  ;
