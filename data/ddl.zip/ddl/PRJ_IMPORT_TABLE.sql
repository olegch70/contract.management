--------------------------------------------------------
--  DDL for Table PRJ_IMPORT_TABLE
--------------------------------------------------------

  CREATE TABLE "PRJ_IMPORT_TABLE" 
   (	"CODE" NUMBER(4,0), 
	"FIO" VARCHAR2(500 CHAR), 
	"ID" NUMBER, 
	"GRADE2" NUMBER(32,0), 
	"LASTNAME" VARCHAR2(200 CHAR), 
	"FIRSTNAME" VARCHAR2(200 CHAR), 
	"MIDDLENAME" VARCHAR2(200 CHAR)
   ) ;
