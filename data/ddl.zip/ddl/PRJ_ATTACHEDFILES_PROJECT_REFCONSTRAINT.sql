--------------------------------------------------------
--  Ref Constraints for Table PRJ_ATTACHEDFILES_PROJECT
--------------------------------------------------------

  ALTER TABLE "PRJ_ATTACHEDFILES_PROJECT" ADD CONSTRAINT "FK_ATTACHEDFILES_PROJECT" FOREIGN KEY ("PROJECT_ID")
	  REFERENCES "PRJ_PROJECT" ("ID") ON DELETE CASCADE ENABLE;
