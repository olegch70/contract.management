--------------------------------------------------------
--  Constraints for Table PRJ_SPECIALITY
--------------------------------------------------------

  ALTER TABLE "PRJ_SPECIALITY" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "PRJ_SPECIALITY" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "PRJ_SPECIALITY" ADD CONSTRAINT "I_PRJ_SPECIALITY_PK" PRIMARY KEY ("ID") DEFERRABLE
  USING INDEX  ENABLE;
