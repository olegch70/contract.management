--------------------------------------------------------
--  Ref Constraints for Table PRJ_PROJECT
--------------------------------------------------------

  ALTER TABLE "PRJ_PROJECT" ADD CONSTRAINT "PRJ_PROJECT_FK_CLIENT" FOREIGN KEY ("CLIENT_ID")
	  REFERENCES "PRJ_CLIENT" ("ID") ENABLE;
  ALTER TABLE "PRJ_PROJECT" ADD CONSTRAINT "PRJ_PROJECT_FK_MANAGER" FOREIGN KEY ("PROJECT_MANAGER_ID")
	  REFERENCES "PRJ_PERSON" ("ID") ENABLE;
