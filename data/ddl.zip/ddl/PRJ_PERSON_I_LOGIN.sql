--------------------------------------------------------
--  DDL for Index PRJ_PERSON_I_LOGIN
--------------------------------------------------------

  CREATE INDEX "PRJ_PERSON_I_LOGIN" ON "PRJ_PERSON" ("LOGINNAME") 
  ;
