--------------------------------------------------------
--  DDL for Index PRJ_DIRECTION_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_DIRECTION_PK" ON "PRJ_DIRECTION" ("ID") 
  ;
