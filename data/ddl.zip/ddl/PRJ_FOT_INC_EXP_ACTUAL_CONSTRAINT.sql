--------------------------------------------------------
--  Constraints for Table PRJ_FOT_INC_EXP_ACTUAL
--------------------------------------------------------

  ALTER TABLE "PRJ_FOT_INC_EXP_ACTUAL" MODIFY ("ID" NOT NULL ENABLE);
