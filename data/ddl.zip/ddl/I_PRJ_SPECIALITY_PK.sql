--------------------------------------------------------
--  DDL for Index I_PRJ_SPECIALITY_PK
--------------------------------------------------------

  CREATE INDEX "I_PRJ_SPECIALITY_PK" ON "PRJ_SPECIALITY" ("ID") 
  ;
