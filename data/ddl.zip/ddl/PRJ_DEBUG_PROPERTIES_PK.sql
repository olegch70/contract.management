--------------------------------------------------------
--  DDL for Index PRJ_DEBUG_PROPERTIES_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_DEBUG_PROPERTIES_PK" ON "PRJ_DEBUG_PROPERTIES" ("CODE") 
  ;
