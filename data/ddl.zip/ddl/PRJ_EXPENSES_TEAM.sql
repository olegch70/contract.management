--------------------------------------------------------
--  DDL for Table PRJ_EXPENSES_TEAM
--------------------------------------------------------

  CREATE TABLE "PRJ_EXPENSES_TEAM" 
   (	"ID" NUMBER(38,0), 
	"PROJECT_ID" NUMBER(38,0), 
	"PERSON_ID" NUMBER(38,0), 
	"DATE_EXP" DATE, 
	"PRICE" NUMBER(17,6), 
	"TEAM_ID" NUMBER(38,0), 
	"PRICE2" NUMBER(38,0), 
	"LOAD_PERCENT" NUMBER(5,2)
   ) ;

   COMMENT ON COLUMN "PRJ_EXPENSES_TEAM"."TEAM_ID" IS '������ �� ������ � PRJ_PROJECTTEAM';
