--------------------------------------------------------
--  DDL for Index PK_PRJ_POSITION
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_PRJ_POSITION" ON "PRJ_POSITION" ("ID") 
  ;
