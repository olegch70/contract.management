--------------------------------------------------------
--  DDL for Index PRJ_PERSON_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_PERSON_PK" ON "PRJ_PERSON" ("ID") 
  ;
