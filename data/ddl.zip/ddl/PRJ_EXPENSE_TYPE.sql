--------------------------------------------------------
--  DDL for Table PRJ_EXPENSE_TYPE
--------------------------------------------------------

  CREATE TABLE "PRJ_EXPENSE_TYPE" 
   (	"ID" NUMBER(38,0), 
	"CODE" VARCHAR2(255 CHAR), 
	"NAME" VARCHAR2(255 CHAR)
   ) ;
