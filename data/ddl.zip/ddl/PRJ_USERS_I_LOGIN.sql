--------------------------------------------------------
--  DDL for Index PRJ_USERS_I_LOGIN
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_USERS_I_LOGIN" ON "PRJ_USERS" ("LOGIN") 
  ;
