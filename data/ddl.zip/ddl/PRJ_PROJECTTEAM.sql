--------------------------------------------------------
--  DDL for Table PRJ_PROJECTTEAM
--------------------------------------------------------

  CREATE TABLE "PRJ_PROJECTTEAM" 
   (	"ID" NUMBER, 
	"PROJECT_ID" NUMBER, 
	"PERSON_ID" NUMBER, 
	"LOAD_PERCENT" NUMBER(5,2), 
	"CLIENT_MONTH_PRICE" NUMBER(15,0)
   ) ;
