--------------------------------------------------------
--  DDL for Index PRJ_ATTACHEDFILES_PROJECT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_ATTACHEDFILES_PROJECT_PK" ON "PRJ_ATTACHEDFILES_PROJECT" ("ID") 
  ;
