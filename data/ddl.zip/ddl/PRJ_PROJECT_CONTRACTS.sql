--------------------------------------------------------
--  DDL for Table PRJ_PROJECT_CONTRACTS
--------------------------------------------------------

  CREATE TABLE "PRJ_PROJECT_CONTRACTS" 
   (	"ID" NUMBER(38,0), 
	"PROJECT_ID" NUMBER(38,0), 
	"PNUMBER" VARCHAR2(50 CHAR), 
	"DESCRIPTION" VARCHAR2(4000 CHAR), 
	"PRICE" NUMBER(38,2), 
	"ASSIGN_DATE" DATE
   ) ;
