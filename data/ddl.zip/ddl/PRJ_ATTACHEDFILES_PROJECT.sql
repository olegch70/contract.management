--------------------------------------------------------
--  DDL for Table PRJ_ATTACHEDFILES_PROJECT
--------------------------------------------------------

  CREATE TABLE "PRJ_ATTACHEDFILES_PROJECT" 
   (	"ID" NUMBER(38,0), 
	"PROJECT_ID" NUMBER(38,0), 
	"DATE_MODIFICATION" TIMESTAMP (6) DEFAULT sysdate, 
	"FILE_NAME" VARCHAR2(250 CHAR), 
	"DESCRIPTION" VARCHAR2(2000 CHAR), 
	"CONTENT" BLOB, 
	"CONTENT_LENGTH_BYTE" NUMBER(10,0)
   ) ;
