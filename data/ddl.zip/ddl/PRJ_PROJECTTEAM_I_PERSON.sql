--------------------------------------------------------
--  DDL for Index PRJ_PROJECTTEAM_I_PERSON
--------------------------------------------------------

  CREATE INDEX "PRJ_PROJECTTEAM_I_PERSON" ON "PRJ_PROJECTTEAM" ("PERSON_ID") 
  ;
