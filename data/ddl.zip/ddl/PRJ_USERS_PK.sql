--------------------------------------------------------
--  DDL for Index PRJ_USERS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_USERS_PK" ON "PRJ_USERS" ("ID") 
  ;
