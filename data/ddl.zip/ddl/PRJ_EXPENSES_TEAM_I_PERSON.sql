--------------------------------------------------------
--  DDL for Index PRJ_EXPENSES_TEAM_I_PERSON
--------------------------------------------------------

  CREATE INDEX "PRJ_EXPENSES_TEAM_I_PERSON" ON "PRJ_EXPENSES_TEAM" ("PERSON_ID") 
  ;
