--------------------------------------------------------
--  DDL for Index PRJ_PROJECTTEAM_UK_PRJ_PERS
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_PROJECTTEAM_UK_PRJ_PERS" ON "PRJ_PROJECTTEAM" ("PROJECT_ID", "PERSON_ID") 
  ;
