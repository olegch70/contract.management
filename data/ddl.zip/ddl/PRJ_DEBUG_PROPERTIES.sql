--------------------------------------------------------
--  DDL for Table PRJ_DEBUG_PROPERTIES
--------------------------------------------------------

  CREATE TABLE "PRJ_DEBUG_PROPERTIES" 
   (	"CODE" VARCHAR2(50 CHAR), 
	"S_VALUE" VARCHAR2(4000 CHAR)
   ) ;
