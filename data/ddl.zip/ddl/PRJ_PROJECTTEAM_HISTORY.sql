--------------------------------------------------------
--  DDL for Table PRJ_PROJECTTEAM_HISTORY
--------------------------------------------------------

  CREATE TABLE "PRJ_PROJECTTEAM_HISTORY" 
   (	"ID" NUMBER, 
	"PROJECT_ID" NUMBER, 
	"PERSON_ID" NUMBER, 
	"LOAD_PERCENT" NUMBER(5,2), 
	"CLIENT_MONTH_PRICE" NUMBER(15,0), 
	"PERIOD_START" DATE, 
	"PERIOD_FINISH" DATE, 
	"PRICE2" NUMBER(38,0)
   ) ;
