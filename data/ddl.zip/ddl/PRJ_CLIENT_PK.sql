--------------------------------------------------------
--  DDL for Index PRJ_CLIENT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PRJ_CLIENT_PK" ON "PRJ_CLIENT" ("ID") 
  ;
