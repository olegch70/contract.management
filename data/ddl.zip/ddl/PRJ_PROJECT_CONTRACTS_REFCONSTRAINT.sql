--------------------------------------------------------
--  Ref Constraints for Table PRJ_PROJECT_CONTRACTS
--------------------------------------------------------

  ALTER TABLE "PRJ_PROJECT_CONTRACTS" ADD CONSTRAINT "PRJ_PROJECT_CONTRACTS_PRJ_FK1" FOREIGN KEY ("PROJECT_ID")
	  REFERENCES "PRJ_PROJECT" ("ID") ON DELETE CASCADE ENABLE;
