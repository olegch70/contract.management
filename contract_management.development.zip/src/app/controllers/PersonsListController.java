package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.RootChecker;
import app.beans.UiTableHelper;
import app.dto.Person;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.helpers.UIMessages;
import app.loaders.PersonsDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 16:09
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "personsListController")
@ViewScoped
public class PersonsListController extends AbstractTableController {

    public static final String FILTER_KEY_SHOW_GRADE_ONE = "showGradeOne";
    public static final String FILTER_KEY_SHOW_DISMISSED = "showDismissed";
    private static final String VIEW_NAME = "personsList";

    @EJB
    private PersonsDBLoader personsDBLoader;

    @EJB
    private PersonFieldsCryptor personFieldsCryptor;

    @EJB
    private RootChecker rootChecker;

    private List<Person> listOfItems;

    public void childInitModel() {
        getUiTableHelper().calledFromInit(parameters, personsDBLoader);
    }

    public List<Person> getItems() {
        LogSimple.debug(this, "getItems start.");
        if(listOfItems == null ) {
            listOfItems = personsDBLoader.getAll(new String[]{"lastName", "firstName", "middleName"});
            if(getShowDismissed()) {
                listOfItems = getDismissedPersons(listOfItems);
            } else {
                listOfItems = getWorkingPersons(listOfItems);
            }

            if(getShowGradeOne() ) {
                listOfItems = getGradeOnePersons(listOfItems);
            }
//            LogSimple.debug(this, "getItems start");
            personsDBLoader.enrichModel(listOfItems);
        }
        LogSimple.debug(this, "getItems finished");
        return listOfItems;
    }

    private interface Filter<Class> {
        boolean accept(Class item);
    }

    private List<Person> getWorkingPersons(List<Person> listOfItems) {
        return filterList(listOfItems, new Filter<Person>() {
            public boolean accept(Person person) {
                return person.getDismissalDate() == null;
            }
        });
    }

    private List<Person> getDismissedPersons(List<Person> listOfItems) {
        return filterList(listOfItems, new Filter<Person>() {
            public boolean accept(Person person) {
                return person.getDismissalDate() != null;
            }
        });
    }

    private List<Person> filterList(List<Person> listOfItems, Filter filter) {
        List<Person> result = new LinkedList<Person>();
        for(Person person: listOfItems) {
            if(filter.accept(person)) {
                result.add(person);
            }
        }
        return result;
    }

    private List<Person> getGradeOnePersons(List<Person> listOfItems) {
        final Person fakePerson = new Person();
        return filterList(listOfItems, new Filter<Person>() {
            public boolean accept(Person person) {
                try {
                    fakePerson.setId(person.getId());
                    fakePerson.setGrade2(person.getGrade2());
                    personFieldsCryptor.decryptGrade(fakePerson);
                    return fakePerson.getGrade().compareTo(ConstantsHelper.BIGDECIMAL_ONE) == 0;
                } catch (Throwable t) {
                    LogSimple.debug(this, "getGradeOnePersons. personId = "+ person.getId()+ " grade2 => "+ person.getGrade2()+ " grade => "+ fakePerson.getGrade());
                }
                return true;
            }
        });
    }

    public void showPersonsWithoutGrade() {
        listOfItems = getPersonsWithoutGrade(getItems());
    }

    private List<Person> getPersonsWithoutGrade(List<Person> listOfItems) {
        final Person fakePerson = new Person();

        return filterList(listOfItems, new Filter<Person>() {
            public boolean accept(Person person) {
                fakePerson.setId(person.getId());
                fakePerson.setDayPrice2(person.getDayPrice2());
                personFieldsCryptor.decryptDayPrice(fakePerson);
                if(fakePerson.getDayPrice().compareTo(ConstantsHelper.BIGDECIMAL_GRADE_BIG)==0) {
                    return true;
                }
                return false;
            }
        });
    }

    public String doTimeLineShow(){
        final String result = "system/timeLinePersonPage?personId=" + getSelectedItem().getId()
                +"&backPath=" + getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        return result;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCall(AbstractController caller){
        return doCallByOwnerId(VIEW_NAME, caller, null);
    }

    public String add() {
        return EditPersonController.doCallAdd(this);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return EditPersonController.doCallEditByRecordId(this, getSelectedItem().getId());
    }

    @Override
    protected void deleteInternal() {
        personsDBLoader.delete(getSelectedItem().getId());
    }

    private Person getSelectedItem() {
        return (Person) getSelectedItemSuper();
    }

    public String editUser() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return EditUserController.doCallEditUserByRecordId(this, getSelectedItem().getId());
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public boolean getCurrentUserIsRoot() {
        return rootChecker.isRoot(authorisedUser.getPerson());
    }

    public void setShowDismissed(Boolean value ) {
        uiTableHelper.getFieldFilter().put(FILTER_KEY_SHOW_DISMISSED, value);
        reloadFromDb();
    }

    public Boolean getShowDismissed() {
        return getBooleanFilerValue(FILTER_KEY_SHOW_DISMISSED);
    }

    public void setShowGradeOne(Boolean value) {
        uiTableHelper.getFieldFilter().put(FILTER_KEY_SHOW_GRADE_ONE, value);
        reloadFromDb();
    }

    public Boolean getShowGradeOne() {
        return getBooleanFilerValue(FILTER_KEY_SHOW_GRADE_ONE);
    }

    private Boolean getBooleanFilerValue(String filterKey) {
        Object result = uiTableHelper.getFieldFilter().get(filterKey);
        return getBooleanSafe(result);
    }

    private void reloadFromDb() {
        listOfItems = null;
        getItems();
    }

    private Boolean getBooleanSafe(Object result) {
        if(result == null) {
            return Boolean.FALSE;
        }

        if( ! (result instanceof Boolean) ) {
            return false;
        }

        return (Boolean) result;
    }

}
