package app.controllers;

import app.dto.ExpenseDirect;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.loaders.ExpensesDirectDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 18:30
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectDirectExpensesController")
@ViewScoped
public class ProjectDirectExpensesController extends AbstractTableController  {
    private static final String VIEW_NAME = "projectDirectExpenses";
    @EJB
    private ExpensesDirectDBLoader expensesDirectDBLoader;
    private String infoForDeletingRow;

    public String add() {
        return EditDirectExpenseController.doCallAdd(this, parentId);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return EditDirectExpenseController.doCallEditByRecordId(this, parentId, getSelectedItem().getId());
    }

    @Override
    public void deleteInternal() {
        expensesDirectDBLoader.delete(getSelectedItem().getId());
    }

    private ExpenseDirect getSelectedItem() {
        return (ExpenseDirect) uiTableHelper.getSelectedItem();
    }

    public static String doCallByProjectId(AbstractController caller, Long projectId){
        return doCallByOwnerId(VIEW_NAME, caller, projectId);
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public String getInfoForDeletingRow() {
        return infoForDeletingRow;
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public List<ExpenseDirect> getItems() {
        return expensesDirectDBLoader.getListForAuthorizedUser(parentId, authorisedUser.getPerson());

    }

}
