package app.controllers;

import app.dto.ProjectContract;
import app.loaders.ProjectsDBLoader;
import app.loaders.ProjectContractsDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 25.12.13
 * Time: 10:52
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="projectContractsPriceListController")
@ViewScoped
public class ProjectContractsPriceListController extends AbstractTableController {

    private static final String VIEW_NAME = "projectContractsPriceList";
    @EJB
    private ProjectsDBLoader projectsDBLoader;
    @EJB
    private ProjectContractsDBLoader projectContractsDBLoader;

    @Override
    protected void childInitModel() {
        getUiTableHelper().calledFromInit(parameters, projectContractsDBLoader);
    }

    public List<ProjectContract> getContracts() {
        return EditProjectController.getProjectContractsFromContext(conversationUuid, getViewNavigationHelperModel().getSessionDataHolder());
    }

    public static String doCallByProjectId(AbstractController caller, Long projectId){
        return doCallByOwnerId(VIEW_NAME, caller, projectId);
    }

    public String add() {
        return EditProjectContractController.doCallAdd(this, parentId);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return EditProjectContractController.doCallEditByRecordId(this, getUiTableHelper().getSelectedItem().getId());
    }

    @Override
    protected void deleteInternal() {
        getContracts().remove(getUiTableHelper().getSelectedItem());
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }
}
