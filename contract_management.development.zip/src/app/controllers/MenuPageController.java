package app.controllers;
 
import app.beans.AuthorisedUserViewScoped;
import app.beans.RootChecker;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 19.12.13
 * Time: 17:23
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "menuPageController")
@ViewScoped
public class MenuPageController {

    @EJB
    private RootChecker rootChecker;

    @ManagedProperty(value="#{authorisedUserViewBean}")
    private AuthorisedUserViewScoped authorisedUser;

    private String localUuid;
    private String conversationUuid;

    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        initializeUuid();
        localUuid = conversationUuid+"_StartPageController";
        System.out.println("localUuid = " + localUuid);

    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    public String goToClientsList() {
        return  "clientsList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToPersons() {
        return  "personsList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToPositions() {
        return  "positionsList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToReports() {
        return  "reportsPage?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToDirectories() {
        return  "directoriesPage?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToSystem() {
        return  "system/systemPage?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToInOutFinance() {
        return "finInputMoneyList?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String goToPersonAddToTeam() {
        return "hrPersonAddToTeam?backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        return facesContext.getViewRoot().getViewId();
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

}
