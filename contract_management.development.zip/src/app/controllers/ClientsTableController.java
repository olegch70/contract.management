package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.SelectedClientAccessor;
import app.beans.UiTableHelper;
import app.controllers.datamodel.ClientsDataModel;
import app.dto.Client;
import app.dto.Person;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.helpers.ViewNavigationHelper;
import app.loaders.ClientsDBLoader;
import app.loaders.ProjectsDBLoader;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;

import javax.ejb.EJB;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 14:19
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "clientsTableController")
@ViewScoped
public class ClientsTableController extends AbstractTableController {
    @EJB
    private ClientsDBLoader clientsDBLoader;
    @EJB
    private ProjectsDBLoader projectDBLoader;
    @ManagedProperty(value="#{selectedClientAccessor}")
    private SelectedClientAccessor selectedClientAccessor;
    private ClientsDataModel clientsDataModel;
    final static String VIEW_NAME = "clientsList";

    @Override
    protected void childInitModel() {
        getUiTableHelper().calledFromInit(parameters, clientsDBLoader);
    }

    @Override
    protected void deleteInternal() {
        clientsDBLoader.delete(getSelectedItem().getId());
        clientsDataModel = null;
    }

    private Client getSelectedItem() {
        return (Client) getSelectedItemSuper();
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public ClientsDataModel getClients() {
        LogSimple.debug(this, "getClients() started");
        if(clientsDataModel == null) {
            LogSimple.debug(this, "clientsDataModel == null");
//            Person person = authorisedUser.getPerson();
            List<Client> result = clientsDBLoader.getClientsForAuthorizedUser(authorisedUser.getPerson());
//            boolean isRoot = authorisedUser.getCurrentUserIsRoot();
//            if(isRoot) {
//                result = clientsDBLoader.getClients();
//            } else if(person != null) {
//                result
//                        = clientsDBLoader
//                        .getClientsForAuthorizedUser(
//                                person.getId(),
//                                person.isTechnicalAM(),
//                                person.isProjectM()
//                        );
//            } else {
//                result = new LinkedList<Client>();
//            }

            clientsDBLoader.enrichModel(result);
            ClientsDataModel clientsDataModel = new ClientsDataModel(result);
            clientsDataModel.setClientsDBLoader(clientsDBLoader);

            this.clientsDataModel = clientsDataModel;
        }
        LogSimple.debug(this, "getClients() finished");
        return clientsDataModel;
    }

    public String addClient() {
        return EditClientController.doCallAdd(this);
    }

    public String editClient() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }

        if( ! currentUserIsRoot() && ! currentUserIsTamInSelectedClient()) {
            displayUIMessage("���� ������ ��������� ��� ���� ����� ���������������.");
            return null;
        }
        getUiTableHelper().registerItemForRefreshItemInFuture(getUiTableHelper().getSelectedItem());
        return EditClientController.doCallEditByRecordId(this, getSelectedItem().getId());
    }

    private boolean currentUserIsTamInSelectedClient() {
        return getSelectedItem().getTechnicalAM().equals(getAuthorisedUser().getPerson().getId());
    }

    private boolean currentUserIsRoot() {
        return getAuthorisedUser().getCurrentUserIsRoot();
    }

    public String goToProjects() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        selectedClientAccessor.setSelectedClient(conversationUuid, getSelectedItem());
        return ProjectsTableController.doCallByClientId(this, getSelectedItem().getId());
    }

    public String doCallAndCreateUUID() {
        String conversationUuid = UUID.randomUUID().toString();
        return ViewNavigationHelper.prepareForCallAndGetURL(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid, VIEW_NAME);
    }

    @Override
    protected void beforeDoBack() {
        selectedClientAccessor.removeSelectedClient(conversationUuid);
    }

    @Override
    protected void afterDoBack() {
        ViewNavigationHelper.removeModelForConversation(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid);
    }

    public void onRowSelect(SelectEvent event) {
        FacesMessage msg = new FacesMessage("Client Selected", ((Client) event.getObject()).getName());
        FacesContext.getCurrentInstance().addMessage(null, msg);

        FacesContext fc = FacesContext.getCurrentInstance();
        ConfigurableNavigationHandler nav = (ConfigurableNavigationHandler) fc.getApplication().getNavigationHandler();
        nav.performNavigation(goToProjects());
    }

    public SelectedClientAccessor getSelectedClientAccessor() {
        return selectedClientAccessor;
    }

    public void setSelectedClientAccessor(SelectedClientAccessor selectedClientAccessor) {
        this.selectedClientAccessor = selectedClientAccessor;
    }

}
