package app.controllers;
 
import app.beans.AuthorisedUserViewScoped;
import app.beans.SelectedClientAccessor;
import app.controllers.datamodel.ClientsDataModel;
import app.dto.Client;
import app.helpers.LogSimple;
import app.loaders.ClientsDBLoader;
import app.loaders.ProjectsDBLoader;
import org.primefaces.event.SelectEvent;

import javax.ejb.EJB;
import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 14:19
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "reportClientsForChooseTableController")
@ViewScoped
public class ReportClientsForChooseTableController {

    //@ManagedProperty(value="#{clientsDBLoader}")
    @EJB
    private ClientsDBLoader clientsDBLoader;
    @EJB
    private ProjectsDBLoader projectDBLoader;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    private AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{selectedClientAccessor}")
    private SelectedClientAccessor selectedClientAccessor;
    private String backPath;
    private String localUuid;
    private String conversationUuid;
    private Map parameters;
    private Client selectedClient;
    ClientsDataModel clientsDataModel;
    private List<Client> filteredRows;

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public void initModel() {
        System.out.println("conversationUuid = " + conversationUuid);
        localUuid = getConversationUuid()+"_ReportClientsForChooseTableController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            backPath = (String) parameters.get("backPath");
        }
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public Client getSelectedClient() {
        System.out.println(" getSelectedClient = " + selectedClient);
        return selectedClient;
    }

    public void setSelectedClient(Client selectedClient) {
        System.out.println(" setSelectedClient = " + selectedClient);
        this.selectedClient = selectedClient;
    }

    public ClientsDataModel getClients() {
        LogSimple.debug(this, "getClients() started");
        if(clientsDataModel == null) {
            LogSimple.debug(this, "clientsDataModel == null");
            List<Client> result;
            result = clientsDBLoader.getClientsForAuthorizedUser(authorisedUser.getPerson());
            clientsDBLoader.enrichModel(result);
            ClientsDataModel clientsDataModel = new ClientsDataModel(result);
            clientsDataModel.setClientsDBLoader(clientsDBLoader);

            this.clientsDataModel = clientsDataModel;
        }
        LogSimple.debug(this, "getClients() finished");
        return clientsDataModel;
    }

    public List<Client> getFilteredRows() {
        return filteredRows;
    }

    public void setFilteredRows(List<Client> filteredRows) {
        this.filteredRows = filteredRows;
        LogSimple.debug(this, "setFilteredRows");
        parameters.put("filteredRows", this.filteredRows);
    }

    public String goToClientReport(){
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        selectedClientAccessor.setSelectedClient(conversationUuid, selectedClient);
        return  "clientReport?clientId="+selectedClient.getId()
                +"&backPath="+getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";

    }

    public String doBack() {
        selectedClientAccessor.removeSelectedClient(conversationUuid);
        removeModelFromSession();
        return  backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void onRowSelect(SelectEvent event) {
        FacesMessage msg = new FacesMessage("Client Selected", ((Client) event.getObject()).getName());
        FacesContext.getCurrentInstance().addMessage(null, msg);
        LogSimple.debug(this, "event = " + event.toString());
        LogSimple.debug(this, "event = " + event.getObject().getClass());
        LogSimple.debug(this, "event = " + ((Client) event.getObject()).getId());

        FacesContext fc = FacesContext.getCurrentInstance();
        ConfigurableNavigationHandler nav = (ConfigurableNavigationHandler) fc.getApplication().getNavigationHandler();
        nav.performNavigation(goToClientReport());
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        return facesContext.getViewRoot().getViewId();
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(selectedClient != null) {
            return true;
        }

        displayUIMessage("�������� ������� ������.");
        return false;
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public SelectedClientAccessor getSelectedClientAccessor() {
        return selectedClientAccessor;
    }

    public void setSelectedClientAccessor(SelectedClientAccessor selectedClientAccessor) {
        this.selectedClientAccessor = selectedClientAccessor;
    }
}
