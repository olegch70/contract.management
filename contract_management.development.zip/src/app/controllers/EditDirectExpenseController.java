package app.controllers;

import app.dto.ExpenseDirect;
import app.dto.ExpenseType;
import app.dto.Person;
import app.helpers.ViewNavigationHelper;
import app.loaders.ExpenseTypeDBLoader;
import app.loaders.ExpensesDirectDBLoader;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editDirectExpenseController")
@ViewScoped
public class EditDirectExpenseController extends AbstractEditController {

    private static final String VIEW_NAME = "editDirectExpense";
    public static final String EXPENSE_ID_KEY = "expenseId";
    public static final String PROJECT_ID_KEY = "projectId";

    @EJB
    private ExpensesDirectDBLoader expensesDirectDBLoader;
    @EJB
    private PersonsDBLoader personsDBLoader;
    @EJB
    private ExpenseTypeDBLoader expenseTypeDBLoader;

    private Long expenseId;
    private boolean copyProjectTillEnd;
    private String command;
    private Long projectId;
    private Long initiatorPersonId;
    private Long expenseTypeId;
    private ExpenseDirect expenseDirect;
    private List<Person> expInitiators;
    private List<ExpenseType> expenseTypes;

    public void childInitModel(){
        System.out.println("initModel() in EditProjectContractController started");
        expenseId = (Long) parameters.get(EXPENSE_ID_KEY);
        projectId = (Long) parameters.get(PROJECT_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        expInitiators = personsDBLoader.getAll(new String[]{"lastName", "firstName", "middleName"});
        expenseTypes = expenseTypeDBLoader.getAll();
        if(command.equals(COMMAND_ADD)){
            expenseDirect = new ExpenseDirect();
            expenseDirect.setProjectId(projectId);
        } else {
            List<ExpenseDirect> expDirList = expensesDirectDBLoader.loadByLinkedId("projectId", projectId);
            for(ExpenseDirect row : expDirList)
            {
                if(row.getId().equals(expenseId)){
                    expenseDirect = row;
                    break;
                }
            }
            System.out.println("expenseDirect = " + expenseDirect);
        }
        if(expenseDirect.getPerson() != null) {
            initiatorPersonId = expenseDirect.getPerson().getId();
        }
        if(expenseDirect.getExpenseType() != null) {
            expenseTypeId = expenseDirect.getExpenseType().getId();
        }

        System.out.println("initModel() in EditProjectContractController finished");
    }

    public List<Person> getExpInitiators() {
        return expInitiators;
    }

    public static String doCallAdd(AbstractController caller, Long projectId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long projectId, Long expenseId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(EXPENSE_ID_KEY, expenseId);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        paramModel[0].put(COMMAND_KEY, "edit");
        return result;
    }

    public String saveExpense() {
        System.out.println("saveExpense in edit expense called");
        expenseDirect.setPerson(personsDBLoader.getById(initiatorPersonId));
        expenseDirect.setExpenseType(expenseTypeDBLoader.getById(expenseTypeId));
        if(command.equals(COMMAND_ADD)){
            expensesDirectDBLoader.addAndCopyTillProjectEnd(projectId, expenseDirect, copyProjectTillEnd);
        } else {
            expensesDirectDBLoader.updateAndCopyTillProjectEnd(projectId, expenseDirect, copyProjectTillEnd);
            System.out.println("saveExpense in edit expense updated");
        }
        return doBack();
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public boolean isDestinationRendered() {
        return authorisedUser.getCurrentUserIsRoot();
    }

    public ExpenseDirect getExpenseDirect() {
        return expenseDirect;
    }

    public void setExpenseDirect(ExpenseDirect expenseDirect) {
        this.expenseDirect = expenseDirect;
    }

    public Long getInitiatorPersonId() {
        return initiatorPersonId;
    }

    public void setInitiatorPersonId(Long initiatorPersonId) {
        this.initiatorPersonId = initiatorPersonId;
    }

    public List<ExpenseType> getExpenseTypes() {
        return expenseTypes;
    }

    public void setExpenseTypes(List<ExpenseType> expenseTypes) {
        this.expenseTypes = expenseTypes;
    }

    public Long getExpenseTypeId() {
        return expenseTypeId;
    }

    public void setExpenseTypeId(Long expenseTypeId) {
        this.expenseTypeId = expenseTypeId;
    }

    public boolean isCopyProjectTillEnd() {
        return copyProjectTillEnd;
    }

    public void setCopyProjectTillEnd(boolean copyProjectTillEnd) {
        this.copyProjectTillEnd = copyProjectTillEnd;
    }
}
