package app.controllers;

import app.dto.ExpenseDirect;
import app.dto.ExpenseType;
import app.dto.Person;
import app.loaders.ExpenseTypeDBLoader;
import app.loaders.ExpensesDirectDBLoader;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editDirectExpenseController")
@ViewScoped
public class EditDirectExpenseController {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    //@ManagedProperty(value="#{expensesDirectDBLoader}")
    @EJB
    private ExpensesDirectDBLoader expensesDirectDBLoader;
    @EJB
    private PersonsDBLoader personsDBLoader;
    @EJB
    private ExpenseTypeDBLoader expenseTypeDBLoader;

    private Long expenseId;
    private String backPath;
    private String command;
    private Long projectId;
    private Long initiatorPersonId;
    private Long expenseTypeId;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private ExpenseDirect expenseDirect;
    private List<Person> expInitiators;
    private List<ExpenseType> expenseTypes;

    public void initModel(){
        System.out.println("initModel() in EditProjectContractController started");
        initializeUuid();
        localUuid = getConversationUuid()+"_editDirectExpenseController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("projectId", projectId);
            System.out.println("parameters.put(projectId = " + projectId);
            parameters.put("expenseId", expenseId);
            System.out.println("parameters.put(expenseId = " + expenseId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            expInitiators = personsDBLoader.getAll(new String[]{"lastName", "firstName", "middleName"});
            expenseTypes = expenseTypeDBLoader.getAll();

            if(command.equals("add")){
                expenseDirect = new ExpenseDirect();
                expenseDirect.setProjectId(projectId);
            } else {
                List<ExpenseDirect> expDirList = expensesDirectDBLoader.loadByLinkedId("projectId", projectId);
                for(ExpenseDirect row : expDirList)
                {
                    if(row.getId().equals(expenseId)){
                        expenseDirect = row;
                        break;
                    }
                }
                System.out.println("expenseDirect = " + expenseDirect);
            }
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            System.out.println("parameters expenseId = " + parameters.get("expenseId"));
            expenseId = (Long) parameters.get("expenseId");
            backPath = (String) parameters.get("backPath");
        }
        if(expenseDirect.getPerson() != null) {
            initiatorPersonId = expenseDirect.getPerson().getId();
        }
        if(expenseDirect.getExpenseType() != null) {
            expenseTypeId = expenseDirect.getExpenseType().getId();
        }

        System.out.println("initModel() in EditProjectContractController finished");
    }

    public List<Person> getExpInitiators() {
        return expInitiators;
    }

    public String saveExpense() {
        System.out.println("saveExpense in edit expense called");
        expenseDirect.setPerson(personsDBLoader.getById(initiatorPersonId));
        expenseDirect.setExpenseType(expenseTypeDBLoader.getById(expenseTypeId));
        if(command.equals("add")){
            expensesDirectDBLoader.addNew(expenseDirect);
        } else {
            expensesDirectDBLoader.update(expenseDirect);
            System.out.println("saveExpense in edit expense updated");
        }
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String doBack() {
        removeModelFromSession();
        System.out.println("backPath on doBack = " + backPath);
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public ExpenseDirect getExpenseDirect() {
        return expenseDirect;
    }

    public void setExpenseDirect(ExpenseDirect expenseDirect) {
        this.expenseDirect = expenseDirect;
    }

    public void setExpenseId(Long expenseId) {
        this.expenseId = expenseId;
    }

    public Long getExpenseId() {
        return expenseId;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String getCommand() {
        return command;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public ExpensesDirectDBLoader getExpensesDirectDBLoader() {
        return expensesDirectDBLoader;
    }

    public void setExpensesDirectDBLoader(ExpensesDirectDBLoader expensesDirectDBLoader) {
        this.expensesDirectDBLoader = expensesDirectDBLoader;
    }

    public Long getInitiatorPersonId() {
        return initiatorPersonId;
    }

    public void setInitiatorPersonId(Long initiatorPersonId) {
        this.initiatorPersonId = initiatorPersonId;
    }

    public List<ExpenseType> getExpenseTypes() {
        return expenseTypes;
    }

    public void setExpenseTypes(List<ExpenseType> expenseTypes) {
        this.expenseTypes = expenseTypes;
    }

    public Long getExpenseTypeId() {
        return expenseTypeId;
    }

    public void setExpenseTypeId(Long expenseTypeId) {
        this.expenseTypeId = expenseTypeId;
    }
}
