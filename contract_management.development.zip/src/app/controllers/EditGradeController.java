package app.controllers;

import app.dto.Grade;
import app.helpers.LogSimple;
import app.loaders.GradeDBLoader;
import app.loaders.PositionDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 14:36
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editGradeController")
@ViewScoped
public class EditGradeController {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    @EJB
    private GradeDBLoader gradeDBLoader;
    private String backPath;
    private String command;
    private Long gradeId;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private Grade grade;

    public void initModel(){
        System.out.println("initModel() in editGradeController started");
        localUuid = getConversationUuid()+"_editGradeController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("gradeId", gradeId);
            System.out.println("parameters.put(gradeId = " + gradeId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            if(command.equals("add")){
                grade = new Grade();
            } else {
                grade = gradeDBLoader.getById(gradeId);
                grade = gradeDBLoader.getByCode(grade.getCode());
            }
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            System.out.println("parameters gradeId = " + parameters.get("gradeId"));
            gradeId = (Long) parameters.get("gradeId");
            backPath = (String) parameters.get("backPath");
        }

        System.out.println("initModel() in editGradeController finished");
    }

    public String save() {
        LogSimple.debug(this, " ����� = " + grade.getCode());
        if(command.equals("add")){
            gradeDBLoader.addNew(grade);
        } else {
            System.out.println("saveGrade called");
            gradeDBLoader.update(grade);
            System.out.println("saveGrade updated");
        }
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String doBack() {
        removeModelFromSession();
        System.out.println("backPath on doBack = " + backPath);
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public Long getGradeId() {
        return gradeId;
    }

    public void setGradeId(Long gradeId) {
        this.gradeId = gradeId;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }
}
