package app.controllers;

import app.beans.FormatterUtil;
import app.dto.Person;
import app.dto.TeamItem;
import app.helpers.LogSimple;
import app.helpers.TeamEditHelper;
import app.loaders.PersonsDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 16:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="addPersonInTeamController")
@ViewScoped
public class AddPersonInTeamController {

    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    //@ManagedProperty(value="#{personsDBLoader}")
    @EJB
    private PersonsDBLoader personsDBLoader;
    private String backPath;
    private String conversationUuid;
    private Map parameters;
    private String localUuid;
//    private List<Long> selectedPersonsForAdd;
    private List<Person> persons;
    private String filterValue;
    private List<Person> filteredRows;
    private Set<Long> addedPersons = new HashSet<Long>();

    private String legionnaireEndDate;
    private String percentLoad;
    private double dPercentLoad;
    private String legionnaireFIO;

    private BigDecimal clientMonthPrice;

    public void initModel() throws AbortProcessingException {
        initializeUuid();
//        if(selectedPersonsForAdd == null) {
//            selectedPersonsForAdd = new LinkedList<Long>();
//        }
        localUuid = getConversationUuid()+"_addPersonInTeamController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);

        for(TeamItem teamItem : TeamEditHelper.getModel(sessionDataHolder, getConversationUuid()) ) {
            addedPersons.add(teamItem.getPersonId());
        }
        LogSimple.debug(this, "addedPersons.size() = "+addedPersons.size());

        if(parameters == null) {
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null"+parameters);
            backPath = (String) parameters.get("backPath");
        }
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public String doBack(){
//        System.out.println(" selectedPersonsForAddddddd = " + selectedPersonsForAdd);
//        TeamEditHelper.addEmployeesInTeam(selectedPersonsForAdd, sessionDataHolder, conversationUuid);
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }


    public void doShowInfoDialog(Long id) {
        personId_inInfoDialog = id;
        Person person = personsDBLoader.getById(personId_inInfoDialog);
        legionnaireFIO = person.getFIO();

        if(person.getMainProjectId() != null) {
            legionnaireEndDate = FormatterUtil.formatDateLong(person.getLegionnaireEndDate());
            dPercentLoad = person.getLegionnairePercentOffer();
        } else {
            dPercentLoad = 100;
            legionnaireEndDate = null;
        }
        percentLoad = FormatterUtil.formatDouble(dPercentLoad) + " %";
        RequestContext rc = RequestContext.getCurrentInstance();
        rc.execute("PF('dlgInfo').show()");
    }

    private Long personId_inInfoDialog;

    public void doAddCurrent(){
        doAdd(personId_inInfoDialog);
        personId_inInfoDialog = null;
        legionnaireEndDate = null;
        percentLoad = null;
        dPercentLoad = 0;
        legionnaireFIO = null;
        clientMonthPrice = null;
    }

    public void doAdd(Long id){
        System.out.println(" selected row id = " + id);
//        selectedPersonsForAdd.add(id);

        addedPersons.add(id);
//        Person person = personsDBLoader.getById(id);
        Person person = personsDBLoader.getByIdDetached(id);
        TeamItem addTeamItemDto = new TeamItem();
        addTeamItemDto.setLoadPercent(dPercentLoad);
        addTeamItemDto.setClientMonthPrice(clientMonthPrice);
        boolean added = TeamEditHelper.addEmployeesInTeam(person, sessionDataHolder, conversationUuid,
                addTeamItemDto);

        if(! added ) {
            displayUIMessage("��������� ��� ������� � ������� �������.");
        }

//        selectedPersonsForAdd.clear();
//        if(persons != null ) {
//            Person personForRemove = new Person();
//            personForRemove.setId(id);
//            persons.remove(personForRemove);
//        }
//        System.out.println(" selectedPersonsForAdd = " + selectedPersonsForAdd);
    }

    private void displayUIMessage(String message) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(message));
    }

    public List<Person> getPersons() {
        System.out.println("getPersons => start");
        if(persons == null) {
        long tStart = System.currentTimeMillis();
            persons = personsDBLoader.getAllowedToIncludeIntoTeam();
        long tEnd = System.currentTimeMillis();
        System.out.println("getPersons => persons.size() " + persons.size()+ " loadTime = "+ (tEnd - tStart)+ " ms");
//        personsDBLoader.enrichModel(persons);
        long tEnd2 = System.currentTimeMillis();
        System.out.println("getPersons => enrichModel = "+ (tEnd2 - tEnd)+ " ms");
        }
        System.out.println("getPersons => finish");
        return persons;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public void setFilteredRows(List<Person> filteredRows) {
        this.filteredRows = filteredRows;
    }

    public List<Person> getFilteredRows() {
        if(filteredRows == null) {
            filteredRows = getPersons();
        }
        return filteredRows;
    }

    public boolean notIncludedIntoTeam(Long id) {
        return ! addedPersons.contains(id);
    }

    public boolean showButton(Long id) {
        if(notIncludedIntoTeam(id)) {
            Person currentPerson = personsDBLoader.getById(id);
            if(currentPerson.getMainProject() != null) {
                if( ! currentPerson.isReadyForLegionnaire()) {
                    return false;
                }
            }
        } else {
            return false;
        }
        return true;
    }

    public String getLegionnaireEndDate() {
        return legionnaireEndDate;
    }

    public void setLegionnaireEndDate(String legionnaireEndDate) {
        this.legionnaireEndDate = legionnaireEndDate;
    }

    public String getPercentLoad() {
        return percentLoad;
    }

    public void setPercentLoad(String percentLoad) {
        this.percentLoad = percentLoad;
    }

    public BigDecimal getClientMonthPrice() {
        return clientMonthPrice;
    }

    public void setClientMonthPrice(BigDecimal clientMonthPrice) {
        this.clientMonthPrice = clientMonthPrice;
    }

    public boolean isClientMonthPriceRendered() {
        return TeamEditHelper.needShowClientMonthPrice(sessionDataHolder, conversationUuid);
    }


    public void setLegionnaireFIO(String legionnaireFIO) {
        this.legionnaireFIO = legionnaireFIO;
    }

    public String getLegionnaireFIO() {
        return legionnaireFIO;
    }

    public boolean isLegionnaire() {
        return legionnaireEndDate != null;
    }
}
