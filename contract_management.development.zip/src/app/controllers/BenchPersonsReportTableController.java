package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.LogSimple;
import app.loaders.BenchPersonsReportDBLoader;
import app.report.dto.ReportDateFilter;
import org.primefaces.event.ToggleEvent;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "benchPersonsReportTableController")
@ViewScoped
public class BenchPersonsReportTableController {

    private String backPath;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private ReportDateFilter reportDateFilter;
    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private BenchPersonsReportDBLoader benchPersonsReportDBLoader;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    private List<BenchPersonReport> reportItems;
    private List<BenchPersonProject> reportPersonProjectsItems;

    public void initModel() {
        debug("conversationUuid = " + conversationUuid);
        localUuid = getConversationUuid()+"_benchPersonsReportTableController";
        debug("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            debug("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            debug("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            String x = "parameters ! = null " + parameters;
            debug(x);
            backPath = (String) parameters.get("backPath");
        }
    }

    public List<BenchPersonReport> getItems() {
        return reportItems;
    }

    public List<BenchPersonProject> getReportItems() {
        return reportPersonProjectsItems;
    }

    public void onRowToggle(ToggleEvent event) {
        debug("onRowToggle executed. ((BenchPersonReport) event.getData()).getFIO() = "+ ((BenchPersonReport) event.getData()).getFIO());
        reportPersonProjectsItems = ((BenchPersonReport) event.getData()).getWorkProjects();
    }

    private void saveModelInSession() {
        debug("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        debug("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public String doBack() {
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getLocalUuid() {
        return localUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public void doFilter() {
        debug("doFilter executed");
        reportItems = benchPersonsReportDBLoader.getReportData(reportDateFilter);
        debug("reportItems = " + reportItems.size());

    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }
}
