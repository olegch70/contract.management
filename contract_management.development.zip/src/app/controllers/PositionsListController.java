package app.controllers;

import app.dto.Person;
import app.dto.Position;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.loaders.PersonsDBLoader;
import app.loaders.PositionDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 16:09
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "positionsListController")
@ViewScoped
public class PositionsListController extends AbstractTableController {

    private static final String VIEW_NAME = "positionsList";
    @EJB
    private PositionDBLoader positionDBLoader;
    private List<Position> filteredRows;

    public void childInitModel() {
        getUiTableHelper().calledFromInit(parameters, positionDBLoader);
    }

    public List<Position> getItems() {
        return positionDBLoader.getAllWithNotActual();
    }

    public static String doCall(AbstractController caller){
        return doCallByOwnerId(VIEW_NAME, caller, null);
    }

    public String add() {
        return EditPositionController.doCallAdd(this);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return EditPositionController.doCallEditByRecordId(this, getSelectedItem().getId());
    }

    @Override
    protected void deleteInternal() {
        positionDBLoader.delete(getSelectedItem().getId());
    }

    private Position getSelectedItem() {
        return (Position) getSelectedItemSuper();
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public void setFilteredRows(List<Position> filteredRows) {
        this.filteredRows = filteredRows;
        LogSimple.debug(this, "setFilteredRows");
        parameters.put("filteredRows", this.filteredRows);

    }

    public List<Position> getFilteredRows() {
        LogSimple.debug(this, "getFilteredRows");
        if(filteredRows == null) {
            filteredRows = getItems();
        }
        return filteredRows;
    }
}
