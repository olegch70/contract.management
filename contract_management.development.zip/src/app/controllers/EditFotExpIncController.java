package app.controllers;

import app.dto.FotExpIncActual;
import app.helpers.ViewNavigationHelper;
import app.loaders.FotExpIncDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 17:06
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editFotExpIncController")
@ViewScoped
public class EditFotExpIncController extends AbstractEditController {
    public static final String FOT_EXP_INC_ACTUAL_ID_KEY = "fotExpIncActualId";
    private static final String VIEW_NAME = "editFotExpIncActual";
    @EJB
    private FotExpIncDBLoader fotExpIncDBLoader;
    private Long fotExpIncActualId;
    private FotExpIncActual fotExpIncActual;

    public void childInitModel() {
        fotExpIncActualId = (Long) parameters.get(FOT_EXP_INC_ACTUAL_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        if(command.equals(COMMAND_ADD)){
            fotExpIncActual = new FotExpIncActual();
        } else {
            fotExpIncActual = fotExpIncDBLoader.getById(fotExpIncActualId);
        }
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCallAdd(AbstractController caller){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long id){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(FOT_EXP_INC_ACTUAL_ID_KEY, id);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        return result;
    }

    public String save() {
        if(command.equals(COMMAND_ADD)){
            fotExpIncDBLoader.addNew(fotExpIncActual);
        } else {
            fotExpIncDBLoader.update(fotExpIncActual);
        }
        return doBack();
    }

    public FotExpIncActual getFotExpIncActual() {
        return fotExpIncActual;
    }

    public void setFotExpIncActual(FotExpIncActual fotExpIncActual) {
        this.fotExpIncActual = fotExpIncActual;
    }
}
