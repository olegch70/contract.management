package app.controllers;

import app.dto.ExpenseDirect;
import app.dto.Income;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.loaders.ExpensesDirectDBLoader;
import app.loaders.IncomeDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 18:30
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectIncomeController")
@ViewScoped
public class ProjectIncomeController extends AbstractTableController {

    private static final String VIEW_NAME = "projectIncome";

    @EJB
    private IncomeDBLoader incomeDBLoader;
    //private Income selectedIncome;
    private String infoForDeletingRow;

    public static String doCallByProjectId(AbstractController caller, Long projectId){
        return doCallByOwnerId(VIEW_NAME, caller, projectId);
    }

    public String add() {
        return EditIncomeController.doCallAdd(this, parentId);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return EditIncomeController.doCallEditByRecordId(this, parentId, getSelectedItem().getId());
    }

    private Income getSelectedItem() {
        return (Income) getSelectedItemSuper();
    }

    @Override
    protected void deleteInternal() {
        incomeDBLoader.delete(getSelectedItem().getId());
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public String getInfoForDeletingRow() {
        return infoForDeletingRow;
    }

    public List<Income> getIncome() {
        return incomeDBLoader.loadByFieldValue("projectId", parentId, new String[]{"dateIncome"});
    }
}
