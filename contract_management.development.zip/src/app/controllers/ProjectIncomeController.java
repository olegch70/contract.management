package app.controllers;

import app.dto.ExpenseDirect;
import app.dto.Income;
import app.helpers.LogSimple;
import app.loaders.ExpensesDirectDBLoader;
import app.loaders.IncomeDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 18:30
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectIncomeController")
@ViewScoped
public class ProjectIncomeController {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    //@ManagedProperty(value="#{incomeDBLoader}")
    @EJB
    private IncomeDBLoader incomeDBLoader;
    private Long projectId;
    private String backPath;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private Income selectedIncome;
    private String infoForDeletingRow;

    public void initModel() {
        initializeUuid();
        localUuid = getConversationUuid()+"_projectIncomeController";
        System.out.println("localUuid = " + localUuid);
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            System.out.println("parameters = = null");
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("projectId", projectId);
            System.out.println("parameters.put(projectId = " + projectId);
            parameters.put("backPath", backPath);
            System.out.println("parameters.put(backPath = " + backPath);
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null ");
            System.out.println("parameters projectId = " + parameters.get("projectId"));
            projectId = (Long) parameters.get("projectId");
            backPath = (String) parameters.get("backPath");
        }
    }

    private void initializeUuid() {
        if(conversationUuid == null) {
            System.out.println("conversationUuid = = null ");
            conversationUuid = UUID.randomUUID().toString();
            System.out.println("conversationUuid = " + conversationUuid);
        }
    }

    public String addIncome() {
        return "editIncome?command=add"
                +"&backPath="+getCurrentPath()
                +"&projectId="+ projectId
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public String editIncome() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        return "editIncome?command=edit"
                +"&backPath="+getCurrentPath()
                +"&projectId="+ projectId
                +"&incomeId="+ selectedIncome.getId()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void deleteIncome() {
        incomeDBLoader.delete(selectedIncome.getId());
    }

    public String doBack() {
        removeModelFromSession();
        return backPath + "?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void showDeleteConfirmation() {
        if( ! checkSelectedAndDisplayWarning()) {
            return;
        }
        infoForDeletingRow = "" + selectedIncome.getId();
        LogSimple.debug(this, "showDeleteConfirmation selectedRow = " + selectedIncome.getId());
        RequestContext.getCurrentInstance().execute("PF('dlgConfirm').show()");
    }

    private boolean checkSelectedAndDisplayWarning() {
        if(selectedIncome != null) {
            return true;
        }

        displayUIMessage("�������� ������� ������.");
        return false;
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }


    public String getInfoForDeletingRow() {
        return infoForDeletingRow;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public List<Income> getIncome() {
        return incomeDBLoader.loadByFieldValue("projectId", projectId, new String[]{"dateIncome"});
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public IncomeDBLoader getIncomeDBLoader() {
        return incomeDBLoader;
    }

    public void setIncomeDBLoader(IncomeDBLoader incomeDBLoader) {
        this.incomeDBLoader = incomeDBLoader;
    }

    public void setSelectedIncome(Income selectedIncome) {
        this.selectedIncome = selectedIncome;
    }

    public Income getSelectedIncome() {
        return selectedIncome;
    }
}
