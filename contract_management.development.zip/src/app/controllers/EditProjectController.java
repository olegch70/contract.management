package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.dto.*;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.loaders.*;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 18:21
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean (name= "editProjectController")
@ViewScoped
public class EditProjectController extends AbstractEditController{

    private static final String VIEW_NAME = "editProject";
    public static final String PROJECT_ID_KEY = "projectId";
    public static final String CLIENT_ID_KEY = "projectId";
    public static final String PROJECT_TYPE_ID_KEY = "projectTypeId";
    private static final String PROJECT_CONTRACTS = "projectContracts";
    private static final String PROJECT_KEY = "project";

    private Long projectId;
    private Project project;
    @EJB
    private ProjectsDBLoader projectsDBLoader;
    @EJB
    private ClientsDBLoader clientsDBLoader;
    @EJB
    private ProjectTypeDBLoader projectTypeDBLoader;
    @EJB
    private PersonsDBLoader personsDBLoader;
    @EJB
    private ProjectContractsDBLoader projectContractsDBLoader;
    @EJB
    private ContractStatusDBLoader contractStatusDBLoader;
    @EJB
    private ProjectTeamDBLoader projectTeamDBLoader;

    private String projectTypeName;
    private Long clientId;
    private Long projectTypeId;

    public void childInitModel() throws AbortProcessingException {
        clientId = (Long) parameters.get(CLIENT_ID_KEY);
        projectTypeId = (Long) parameters.get(PROJECT_TYPE_ID_KEY);
        projectId = (Long) parameters.get(PROJECT_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        project = (Project) parameters.get(PROJECT_KEY);
        if(project == null) {
            if(isAddMode()){
                project = new Project();
                project.setType(projectTypeId);
                project.setClientId(clientId);
                project.setClient(clientsDBLoader.getById(clientId));
                project.setStatusId(ContractStatus.ACTIVE.getId());
            }
            if(command.equals(COMMAND_EDIT)){
                project = projectsDBLoader.getById(projectId);
                project.setProjectContracts(null);
            }
            parameters.put(PROJECT_KEY, project);
        }

    }

    public static String doCallAdd(AbstractController caller, Long clientId, String viewName, Long projectTypeId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(),
                viewName, paramModel, VIEW_NAME);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        paramModel[0].put(CLIENT_ID_KEY, clientId);
        paramModel[0].put(PROJECT_TYPE_ID_KEY, projectTypeId);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, String viewName, Long projectId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(),
                viewName, paramModel, VIEW_NAME);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        return result;
    }

    public BigDecimal getAssignedContractsSum() {
        prepareContractsForShow();
        return projectsDBLoader.getAssignedContractsSum(project.getProjectContracts());
    }

    public String getAssignedContractsNumbers() {
        prepareContractsForShow();
        return projectsDBLoader.getAssignedContractsNumbers(project.getProjectContracts());
    }

    public List<ContractStatus> getStatuses() {
        List<ContractStatus> result = new LinkedList<ContractStatus>();
        if(project.getType().equals(ProjectType.PRESALE_A.getId())) {
            result.addAll(contractStatusDBLoader.getPresaleAStatuses());
        } else {
            result.addAll(contractStatusDBLoader.getOnOffStatuses());
        }
        if( ! authorisedUser.isTechnicalAM() || ! authorisedUser.getCurrentUserIsRoot()) {
            result = contractStatusDBLoader.disableClosedStatus(result);
        }
        return result;
    }

    public String saveProject() {
        if(isFrameProject() || isPresaleBProject()) {
            addTotalPriceForQ4Project();
        } else {
            project.setPrice(getAssignedContractsSum());
        }
        if( ! isFrameProject()) {
            project.setNumber(getAssignedContractsNumbers());
        }
        if(command.equals(COMMAND_ADD)){
            projectsDBLoader.addNew(project);
        } else {
            if(isNotActiveProject()) {
                projectTeamDBLoader.dropTeamList(project.getId());
                LogSimple.debug(this, "Team has been dropped in project with Id = " + project.getId());
            }
            projectsDBLoader.update(project);
        }
        return doBack();
    }

    private boolean isNotActiveProject() {
        if(project.getStatusId().equals(ContractStatus.CLOSED.getId())
                || project.getStatusId().equals(ContractStatus.PAUSED.getId())) {
            return true;
        }
        return false;
    }

    private boolean isPresaleBProject() {
        return project.getType().equals(ProjectType.PRESALE_B.getId());
    }

    private boolean isFrameProject() {
        return project.getType().equals(ProjectType.FRAME.getId());
    }

    private void addTotalPriceForQ4Project() {
        BigDecimal price = project.getPriceQ1().add(project.getPriceQ2()).add(project.getPriceQ3()).add(project.getPriceQ4());
        project.setPrice(price);
    }

    public boolean isAddMode() {
        if(COMMAND_ADD.equals(command)) {
            return true;
        }
        return false;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public String goToContractsPrices() {
        prepareContractsForShow();
        return ProjectContractsPriceListController.doCallByProjectId(this, projectId);
    }



    private void prepareContractsForShow() {
        if(project.getProjectContracts() == null) {
            project.setProjectContracts(projectContractsDBLoader.loadByProjectId(projectId));
            debug("" + project.getProjectContracts());
        }
    }

    public static List<ProjectContract> getProjectContractsFromContext(String conversationUuid,
                                                                       SessionDataHolder sessionDataHolder){
        Project project = getProjectFromContext(conversationUuid, sessionDataHolder);
        return project.getProjectContracts();
    }

    public static Project getProjectFromContext(String conversationUuid,
                                                SessionDataHolder sessionDataHolder){
        Map parameters = ViewNavigationHelper.getModel(sessionDataHolder, conversationUuid, VIEW_NAME);
        Project project = (Project) parameters.get(PROJECT_KEY);
        return project;
    }

    public List<Person> getPersons() {
        final List<Person> result = personsDBLoader.getPM();
        if( ! authorisedUser.getCurrentUserIsRoot() ) {
            if( ! authorisedUser.getPerson().getId().equals(getProject().getClient().getTechnicalAM())) {
                final List<Person> currentUserList = new ArrayList<Person>(1);
                currentUserList.add(personsDBLoader.getById(authorisedUser.getPerson().getId()));
                result.retainAll(currentUserList);
            }
        }
        return result;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Project getProject() {
        return project;
    }

    public boolean isNotAllowedToEditFields() {
        if(authorisedUser.getPerson().isFinManager()) {
            return true;

        }
        return false;
    }

    public boolean isNotAllowedToEditFieldsQ() {
        if(authorisedUser.getCurrentUserIsRoot()) {
            // root ����� ������ �������� Q-���
            return false;
        }
        boolean result = isNotAllowedToEditFields();
        if(result) {
            // FinManager �� ����� ������ ����� Q-���
            return result;
        }

        if(COMMAND_ADD.equals(command) ) {
            // ������ �������� Q-��� ����� ��� ���������� 
            return false;
        }

        return true;
    }

    public boolean isNotAllowedToEditFte() {
        if(authorisedUser.getCurrentUserIsRoot()) {
            // root ����� ������ �������� FTE
            return false;
        }
        boolean result = isNotAllowedToEditFields();
        if(result) {
            // FinManager �� ����� ������ FTE
            return result;
        }

        if(COMMAND_ADD.equals(command) ) {
            // ������ �������� FTE ����� ��� ����������
            return false;
        }

        return true;
    }
}
