package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.SelectedProjectAccessor;
import app.dto.Client;
import app.dto.ContractStatus;
import app.dto.Project;
import app.dto.ProjectType;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.loaders.ClientsDBLoader;
import app.loaders.ContractStatusDBLoader;
import app.loaders.ProjectTeamDBLoader;
import app.loaders.ProjectsDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import java.security.InvalidParameterException;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 15:47
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "projectsTableController")
@ViewScoped
public class ProjectsTableController extends AbstractTableController {
    private static final String VIEW_NAME = "projectsList";
    private static final String HR_VIEW_NAME = "hrPersonAddToTeam";
    private static final String FIN_VIEW_NAME = "finInputMoneyList";
    @EJB
    private ProjectsDBLoader projectsDBLoader;
    @EJB
    private ContractStatusDBLoader contractStatusDBLoader;
    @EJB
    private ProjectTeamDBLoader projectTeamDBLoader;
    @EJB
    private ClientsDBLoader clientsDBLoader;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{selectedProjectAccessor}")
    SelectedProjectAccessor selectedProjectAccessor;
    private List<Project> projects;
    private SelectItem[] statusOptions;
    private Client client;

    public static final String FILTER_KEY_SHOW_WITHOUT_COEFF = "showWOCoeff";

    @Override
    public void childInitModel() {
        createContractStatusOptionsForFilter();
        projectsDBLoader.setUseClientKoeff( ! getShowItemsWOCoeff());
        getUiTableHelper().calledFromInit(parameters, projectsDBLoader);
    }

    private void createContractStatusOptionsForFilter() {
        List<ContractStatus> csList = contractStatusDBLoader.getAll();
        String[] statuses = new String[csList.size()];
        for(int i = 0; i < csList.size(); i++) {
            statuses[i] = csList.get(i).getName();
        }
        statusOptions = createFilterOptions(statuses);
    }

    public String doCallFinInputMoneyListAndCreateUUID() {
        String conversationUuid = UUID.randomUUID().toString();
        return ViewNavigationHelper.prepareForCallAndGetURL(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid, FIN_VIEW_NAME, null, VIEW_NAME);
    }

    public String doCallHRPersonAddToTeamAndCreateUUID() {
        String conversationUuid = UUID.randomUUID().toString();
        return ViewNavigationHelper.prepareForCallAndGetURL(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid, HR_VIEW_NAME, null, VIEW_NAME);
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        return currentPath;
    }

    public List<Project> getProjects() {
        long tStart = System.currentTimeMillis();
        boolean isRoot = authorisedUser.getCurrentUserIsRoot();
        try {
            if(projects == null && parentId != null) {
                projects = projectsDBLoader
                        .getProjectsForAuthorizedUser(
                                authorisedUser.getPerson().getId(),
                                authorisedUser.isTechnicalAM(),
                                authorisedUser.isProjectM(),
                                isRoot,
                                parentId
                        );
            }
            return projects;
        } finally {
            long tFinish = System.currentTimeMillis();
            LogSimple.debug(this, "getProject() finish. "+(tFinish - tStart)+ " ms");
        }
    }

    public List<Project> getProjectsForFinance() {
        projects = projectsDBLoader.getNotClosedProjectsForFin();
        return projects;
    }

    private String getURLStringForAddViewAndPrepareToRedirect(String projectType, Long projectTypeId) {
        debug("projectType = " + projectType);
        debug("parentId = " + parentId);
        selectedProjectAccessor.removeSelectedProject(conversationUuid);
        return EditProjectController.doCallAdd(this, parentId, projectType, projectTypeId);
    }

    private String getViewNameByProjectTypeId(Long id) {
        if(ProjectType.FIX.getId().equals(id)) {
            return "editTradeFix";
        }
        if(ProjectType.FRAME.getId().equals(id)) {
            return "editTradeFrame";
        }
        if(ProjectType.OUTSTAFF.getId().equals(id)) {
            return "editTradeOutStaff";
        }
        if(ProjectType.PROJECT.getId().equals(id)) {
            return "editTradeProject";
        }
        if(ProjectType.PRESALE_A.getId().equals(id)) {
            return "editTradePresaleA";
        }
        if(ProjectType.PRESALE_B.getId().equals(id)) {
            return "editTradePresaleB";
        }
        throw new InvalidParameterException("Unknown project type id = " + id);
    }

    public String doAddFix() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.FIX.getId()), ProjectType.FIX.getId());
    }

    public String doAddFrame() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.FRAME.getId()), ProjectType.FRAME.getId());
    }

    public String doAddOutStaff() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.OUTSTAFF.getId()), ProjectType.OUTSTAFF.getId());
    }

    public String doAddProject() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.PROJECT.getId()), ProjectType.PROJECT.getId());
    }

    public String doAddPresaleA() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.PRESALE_A.getId()), ProjectType.PRESALE_A.getId());
    }

    public String doAddPresaleB() {
        return getURLStringForAddViewAndPrepareToRedirect(getViewNameByProjectTypeId(ProjectType.PRESALE_B.getId()), ProjectType.PRESALE_B.getId());
    }

    public String doEdit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        final String viewNameByProjectTypeId = getViewNameByProjectTypeId(getSelectedItem().getType());
        final Long selectedProjectId = getSelectedItem().getId();
        return EditProjectController.doCallEditByRecordId(this, viewNameByProjectTypeId, selectedProjectId);
    }

    private Project getSelectedItem() {
        return (Project) uiTableHelper.getSelectedItem();
    }

    public String goToDirectExpenses() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return ProjectDirectExpensesController.doCallByProjectId(this, getSelectedItem().getId());
    }

    public String goToIncome(){
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return ProjectIncomeController.doCallByProjectId(this, getSelectedItem().getId());
    }

    public String doTimeLineShow(){
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        final String result = "system/timeLinePage?projectId=" + getSelectedItem().getId()
                +"&backPath=" + getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        return result;
    }

    public String doShowGraphIncomeExpenses(){
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        getCurrentSelectedProjectForHeaderInfo();
        final String result = "system/graphIncomeExpenses?projectId=" + getSelectedItem().getId()
                +"&backPath=" + getCurrentPath()
                +"&conversationUuid="+conversationUuid
                +"&faces-redirect=true";
        return result;
    }

    protected void deleteInternal() {
        projectsDBLoader.delete(getSelectedItem().getId());
        projects = null;

    }

    public String doEditTeam() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        if(isClosed()) {
            displayUIMessage("������ �������� ������� � �������� ����������");
            return "";
        }
        if(isPaused()) {
            displayUIMessage("������ �������� ������� � ���������������� ����������");
            return "";
        }
        getCurrentSelectedProjectForHeaderInfo();
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return TeamTableController.doCallByProjectId(this, getSelectedItem().getId());
    }

    public static String doCallByClientId(AbstractController caller, Long clientId){
        return doCallByOwnerId(VIEW_NAME, caller, clientId);
    }

    private boolean isPaused() {
        return getSelectedItem().getStatusId().equals(ContractStatus.PAUSED.getId());
    }

    private boolean isClosed() {
        return getSelectedItem().getStatusId().equals(ContractStatus.CLOSED.getId());
    }

    @Override
    protected void beforeDoBack() {
        selectedProjectAccessor.removeSelectedProject(conversationUuid);
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    private SelectItem[] createFilterOptions(String[] data)  {
        SelectItem[] options = new SelectItem[data.length + 2];

        options[0] = new SelectItem("", "���");
        options[1] = new SelectItem("��", "�� �������");
        for(int i = 0; i < data.length; i++) {
            options[i + 2] = new SelectItem(data[i], data[i]);
        }

        return options;
    }

    public SelectItem[] getStatusOptions() {
        return statusOptions;
    }

    private void getCurrentSelectedProjectForHeaderInfo() {
        selectedProjectAccessor.removeSelectedProject(conversationUuid);
        selectedProjectAccessor.setSelectedProject(conversationUuid, getSelectedItem());
    }

    public Client getClient() {
        if(client == null) {
            client = clientsDBLoader.getById(parentId);
        }
        return client;
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public SelectedProjectAccessor getSelectedProjectAccessor() {
        return selectedProjectAccessor;
    }

    public void setSelectedProjectAccessor(SelectedProjectAccessor selectedProjectAccessor) {
        this.selectedProjectAccessor = selectedProjectAccessor;
    }

    public boolean allowAddActivity() {
        if(authorisedUser.getCurrentUserIsRoot() && ! authorisedUser.isCurrentUserIsRootReadOnly()) {
            // root ����� ��������� ����������
            return true;
        }
        if(parentId == null) {
            return false;
        }
        if( authorisedUser.getPerson().getId().equals(getClient().getTechnicalAM())) {
            if(authorisedUser.getPerson().isTechnicalAM()) {
                return true;
            }
        }

        return false;
    }

    public boolean allowEdit() {
        if(authorisedUser.getCurrentUserIsRoot()) {
            // root ����� ������������� ����������
            return true;
        }

        if(parentId == null) {
            return false;
        }

        if( authorisedUser.getPerson().getId().equals(getClient().getTechnicalAM())) {
            if(authorisedUser.getPerson().isTechnicalAM()) {
                return true;
            }
        }

        return false;
    }

    public void setShowItemsWOCoeff(Boolean value) {
        uiTableHelper.getFieldFilter().put(FILTER_KEY_SHOW_WITHOUT_COEFF, value);
        projectsDBLoader.setUseClientKoeff(!value);
        reloadFromDb();
    }

    public Boolean getShowItemsWOCoeff() {
        return getBooleanFilterValue(FILTER_KEY_SHOW_WITHOUT_COEFF);
    }

    private Boolean getBooleanFilterValue(String filterKey) {
        Object result = uiTableHelper.getFieldFilter().get(filterKey);
        return getBooleanSafe(result);
    }

    private void reloadFromDb() {
        projects = null;
        getProjects();
    }

    private Boolean getBooleanSafe(Object result) {
        if(result == null) {
            return Boolean.FALSE;
        }

        if( ! (result instanceof Boolean) ) {
            return false;
        }

        return (Boolean) result;
    }

}
