package app.controllers;

import app.beans.AuthorisedUser;
import app.beans.AuthorisedUserViewScoped;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.helpers.ViewNavigationHelperModel;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 21.05.14
 * Time: 11:50
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractController {

    @ManagedProperty(value="#{authorisedUser}")
    protected AuthorisedUser authorisedUserForCheckValid;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    protected AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{viewNavigationHelperModel}")
    private ViewNavigationHelperModel viewNavigationHelperModel;
    protected String conversationUuid;
    protected Map parameters;

    public void initModel() {
        conversationUuid = getViewNavigationHelperModel().getConversationUuid();
        final SessionDataHolder sessionDataHolder = getViewNavigationHelperModel().getSessionDataHolder();
        if(authorisedUserForCheckValid.getUser() == null) {
            debug("initModel authorised user = null");
            ViewNavigationHelper.redirectTo("loginPage");
            return;
        }
        if( ! ViewNavigationHelper.checkValidCall(getViewNavigationHelperModel())) {
            debug("call isn't valid");
            ViewNavigationHelper.redirectToActualPage(sessionDataHolder,
                    conversationUuid, "������������ ����� ��������");
            return;
        }
        parameters = ViewNavigationHelper.getModel(getViewNavigationHelperModel(), getModelName());

        final String messageForInit = ViewNavigationHelper.getAndRemoveMessageForInit(sessionDataHolder, conversationUuid);
        if(messageForInit != null)    {
            displayUIMessage(messageForInit);
        }

        try {
            loadValuesFromModel();
            childInitModel();
            ViewNavigationHelper.setExpectableAsActual(sessionDataHolder, conversationUuid);
        } catch (Throwable throwable) {
            logException("exception in initModel ", throwable);
            ViewNavigationHelper.redirectToActualPage(sessionDataHolder,
                    conversationUuid, "�� ������� ������� �� ��������.");
            //ToDo ��������� ���������� �����������
        }
    }

    protected void loadValuesFromModel() {

    }

    protected void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    protected void debug(String msg) {
        LogSimple.debug(this, msg);
    }

    protected void logException(String msg, Throwable e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        pw.flush();
        sw.flush();
        debug(msg + "\n" + sw.toString());
    }

    protected void childInitModel() {

    }

    protected void beforeDoBack() {
    }

    protected void afterDoBack() {
    }

    public String doBack() {
        beforeDoBack();
        final String result = ViewNavigationHelper.doBack(getViewNavigationHelperModel(), getModelName());
        afterDoBack();
        return result;
    }

    public abstract String getModelName();

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public ViewNavigationHelperModel getViewNavigationHelperModel() {
        return viewNavigationHelperModel;
    }

    public void setViewNavigationHelperModel(ViewNavigationHelperModel viewNavigationHelperModel) {
        this.viewNavigationHelperModel = viewNavigationHelperModel;
    }

    public AuthorisedUser getAuthorisedUserForCheckValid() {
        return authorisedUserForCheckValid;
    }

    public void setAuthorisedUserForCheckValid(AuthorisedUser authorisedUserForCheckValid) {
        this.authorisedUserForCheckValid = authorisedUserForCheckValid;
    }
}
