package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.CurrentDateBean;
import app.dto.Client;
import app.dto.DirectExpenseReport;
import app.dto.ExpenseType;
import app.helpers.DirectExpensesReportHelper;
import app.helpers.LogSimple;
import app.loaders.ClientsDBLoader;
import app.loaders.DirectExpensesReportDBLoader;
import app.loaders.ExpenseTypeDBLoader;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 24.03.14
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "directExpensesReportTableController")
@ViewScoped
public class DirectExpensesReportTableController {

    @EJB
    private CurrentDateBean currentDateBean;
    @EJB
    private ExpenseTypeDBLoader expenseTypeDBLoader;
    @EJB
    private DirectExpensesReportDBLoader directExpensesReportDBLoader;
    @EJB
    private ClientsDBLoader clientsDBLoader;
    @ManagedProperty(value="#{authorisedUserViewBean}")
    AuthorisedUserViewScoped authorisedUser;
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    private List<DirectExpenseReport> reportItems;
    private BigDecimal itog;
    private List<String> selectedClients;
    private String backPath;
    private String conversationUuid;
    private String localUuid;
    private Map parameters;
    private List<Client> clientsForFilter;
    private ReportDateFilter reportDateFilter;
    private List<String> selectedExpTypes;
    private List<ExpenseType> expTypes;

    public void initModel() {
        localUuid = getConversationUuid()+"_directExpensesReportTableController";
        parameters = (Map) sessionDataHolder.get(localUuid);
        if(parameters == null) {
            sessionDataHolder.printDebug();
            parameters = new HashMap();
            parameters.put("backPath", backPath);
            clientsForFilter = clientsDBLoader.getClientsForAuthorizedUser(authorisedUser.getPerson());
            expTypes = expenseTypeDBLoader.getListForAuthorizedUser(authorisedUser.getPerson());
            parameters.put("clientsForFilter", clientsForFilter);
            parameters.put("expTypes", expTypes);
            List<Client> clientsList = clientsForFilter;
            List<ExpenseType> expTypesList = expTypes;
            selectedClients = new ArrayList<String>(clientsList.size());
            for(Client client: clientsList) {
                selectedClients.add(Long.toString(client.getId()));
            }
            selectedExpTypes = new ArrayList<String>(expTypesList.size());
            for(ExpenseType type: expTypesList) {
                selectedExpTypes.add(Long.toString(type.getId()));
            }
            saveModelInSession();
        } else {
            System.out.println("parameters ! = null "+parameters);
            backPath = (String) parameters.get("backPath");
            clientsForFilter = (List<Client>) parameters.get("clientsForFilter");
            expTypes = (List<ExpenseType>) parameters.get("expTypes");
        }
    }

    private String getCurrentPath() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        String currentPath = facesContext.getViewRoot().getViewId();
        System.out.println("currentPath = " + currentPath);
        return currentPath;
    }

    public List<ExpenseType> getExpTypes() {
        return expenseTypeDBLoader.getListForAuthorizedUser(authorisedUser.getPerson());
    }

    public void setExpTypes(List<ExpenseType> expTypes) {
        this.expTypes = expTypes;
    }

    public List<DirectExpenseReport> getItems() {
        return reportItems;
    }

    private void saveModelInSession() {
        System.out.println("called saveModelInSession");
        sessionDataHolder.add(localUuid, parameters);
    }

    private void removeModelFromSession() {
        System.out.println("called removeModelFromSession");
        sessionDataHolder.remove(localUuid);
    }

    public String doBack() {
        removeModelFromSession();
        return backPath+"?conversationUuid="+conversationUuid
                +"&faces-redirect=true";
    }

    public void doFilter() {
        LogSimple.debug(this, "doFilter executed");
        reportItems = directExpensesReportDBLoader.getReportDataByClientsIds(selectedClients, selectedExpTypes, getReportDateFilter());
        itog = DirectExpensesReportHelper.accumulateItog(reportItems);
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public void setBackPath(String backPath) {
        this.backPath = backPath;
    }

    public String getBackPath() {
        return backPath;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }



    public ReportDateFilter getReportDateFilter() {
        if(reportDateFilter == null){
            reportDateFilter = new ReportDateFilter();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDateBean.getCurrentDate());
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.MONTH, 0);
            reportDateFilter.setStartDate(calendar.getTime());
            reportDateFilter.setEndDate(currentDateBean.getCurrentDate());
        }
        return reportDateFilter;
    }

    public void setReportDateFilter(ReportDateFilter reportDateFilter) {
        this.reportDateFilter = reportDateFilter;
    }

    public String getLocalUuid() {
        return localUuid;
    }

    public void setLocalUuid(String localUuid) {
        this.localUuid = localUuid;
    }

    public Map getParameters() {
        return parameters;
    }

    public void setParameters(Map parameters) {
        this.parameters = parameters;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    public List<Client> getClientsForFilter() {
        return clientsForFilter;
    }

    public void setClientsForFilter(List<Client> clientsForFilter) {
        this.clientsForFilter = clientsForFilter;
    }

    public List<String> getSelectedClients() {
        return selectedClients;
    }

    public void setSelectedClients(List<String> selectedClients) {
        this.selectedClients = selectedClients;
    }

    public BigDecimal getItog() {
        return itog;
    }

    public void setItog(BigDecimal itog) {
        this.itog = itog;
    }

    public List<String> getSelectedExpTypes() {
        return selectedExpTypes;
    }

    public void setSelectedExpTypes(List<String> selectedExpTypes) {
        this.selectedExpTypes = selectedExpTypes;
    }
}
