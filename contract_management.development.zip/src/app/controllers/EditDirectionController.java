package app.controllers;

import app.dto.Direction;
import app.dto.Grade;
import app.helpers.LogSimple;
import app.helpers.ViewNavigationHelper;
import app.loaders.DirectionDBLoader;
import app.loaders.GradeDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.03.14
 * Time: 14:36
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editDirectionController")
@ViewScoped
public class EditDirectionController extends AbstractEditController {
    public static final String DIRECTION_ID_KEY = "directionId";
    private static final String VIEW_NAME = "editDirection";
    @EJB
    private DirectionDBLoader directionDBLoader;
    private Direction direction;
    private Long directionId;

    public void childInitModel(){
        directionId = (Long) parameters.get(DIRECTION_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        if(command.equals(COMMAND_ADD)){
            direction = new Direction();
        } else {
            direction = directionDBLoader.getById(directionId);
        }
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public static String doCallAdd(AbstractController caller){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long id){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(DIRECTION_ID_KEY, id);
        paramModel[0].put(COMMAND_KEY, COMMAND_EDIT);
        return result;
    }

    public String save() {
        if(command.equals(COMMAND_ADD)){
            directionDBLoader.addNew(direction);
        } else {
            directionDBLoader.update(direction);
        }
        return doBack();
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }
}
