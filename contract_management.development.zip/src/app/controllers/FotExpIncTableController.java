package app.controllers;

import app.dto.FotExpIncActual;
import app.helpers.LogSimple;
import app.helpers.UIMessages;
import app.helpers.ViewNavigationHelper;
import app.loaders.FotExpIncDBLoader;
import org.primefaces.context.RequestContext;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 16:09
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "fotExpIncTableController")
@ViewScoped
public class FotExpIncTableController extends AbstractTableController {
    private static final String VIEW_NAME = "fotExpIncList";
    @EJB
    private FotExpIncDBLoader fotExpIncDBLoader;
    private List<FotExpIncActual> items;

    public void childInitModel() {
        getUiTableHelper().calledFromInit(parameters, fotExpIncDBLoader);
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public String doCallAndCreateUUID() {
        String conversationUuid = UUID.randomUUID().toString();
        return ViewNavigationHelper.prepareForCallAndGetURL(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid, VIEW_NAME);
    }

    public static String doCall(AbstractController caller){
        return doCallByOwnerId(VIEW_NAME, caller, null);
    }

    public String add() {
        return EditFotExpIncController.doCallAdd(this);
    }

    public String edit() {
        if( ! checkSelectedAndDisplayWarning()) {
            return null;
        }
        uiTableHelper.registerItemForRefreshItemInFuture(getSelectedItem());
        return EditFotExpIncController.doCallEditByRecordId(this, getSelectedItem().getId());
    }

    @Override
    protected void deleteInternal() {
        fotExpIncDBLoader.delete(getSelectedItem().getId());
    }

    private FotExpIncActual getSelectedItem() {
        return (FotExpIncActual) getSelectedItemSuper();
    }

    public List<FotExpIncActual> getItems() {
        return fotExpIncDBLoader.getAll();
    }
}
