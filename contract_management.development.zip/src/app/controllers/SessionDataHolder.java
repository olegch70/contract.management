package app.controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 19.12.13
 * Time: 14:02
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="sessionController")
@SessionScoped
public class SessionDataHolder {
    private Map parameters = new HashMap();

    public void add(String key, Object object) {
        parameters.put(key, object);
    }

    public Object get(String id) {
        return parameters.get(id);
    }

    public void remove(String id) {
        parameters.remove(id);
    }

    public void removeDataForConversationUUID(String uuid){
        //ToDo ������� ��� ������������ � uuid
    }

    public void printDebug(){
        System.out.println(parameters.toString());
    }

    public void removeData() {
        parameters = new HashMap();
    }
}
