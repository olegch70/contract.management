package app.controllers;

import app.dto.ExpenseDirect;
import app.dto.Income;
import app.helpers.ViewNavigationHelper;
import app.loaders.ExpensesDirectDBLoader;
import app.loaders.IncomeDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 27.12.13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "editIncomeController")
@ViewScoped
public class EditIncomeController extends AbstractEditController {

    private static final String VIEW_NAME = "editIncome";
    public static final String INCOME_ID_KEY = "incomeId";
    public static final String PROJECT_ID_KEY = "projectId";

    @EJB
    private IncomeDBLoader incomeDBLoader;
    private Long incomeId;
    private Long projectId;
    private Income income;

    public void childInitModel(){
        incomeId = (Long) parameters.get(INCOME_ID_KEY);
        projectId = (Long) parameters.get(PROJECT_ID_KEY);
        command = (String) parameters.get(COMMAND_KEY);
        if(command.equals(COMMAND_ADD)){
            income = new Income();
            income.setProjectId(projectId);
        } else {
            List<Income> incomeList = incomeDBLoader.loadByLinkedId(PROJECT_ID_KEY, projectId);
            for(Income row : incomeList)
            {
                if(row.getId().equals(incomeId)){
                    income = row;
                    break;
                }
            }
        }
        System.out.println("initModel() in editIncomeController finished");
    }

    public String save() {
        if(command.equals(COMMAND_ADD)){
            incomeDBLoader.addNew(income);
        } else {
            incomeDBLoader.update(income);
            System.out.println("saveIncome in edit income updated");
        }
        return doBack();
    }

    public static String doCallAdd(AbstractController caller, Long projectId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(COMMAND_KEY, COMMAND_ADD);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        return result;
    }

    public static String doCallEditByRecordId(AbstractController caller, Long projectId, Long incomeId){
        Map[] paramModel = new Map[1];
        final String result = ViewNavigationHelper.prepareForCallAndGetURL(caller.getViewNavigationHelperModel(), VIEW_NAME, paramModel);
        paramModel[0].put(INCOME_ID_KEY, incomeId);
        paramModel[0].put(PROJECT_ID_KEY, projectId);
        paramModel[0].put(COMMAND_KEY, "edit");
        return result;
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }

    public Income getIncome() {
        return income;
    }

    public void setIncome(Income income) {
        this.income = income;
    }

}
