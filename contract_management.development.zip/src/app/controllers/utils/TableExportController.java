package app.controllers.utils;

import app.dto.ExportMode;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.05.14
 * Time: 11:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "tableExportController")
@ViewScoped
public class TableExportController {
    private boolean currentExportMode;
    private List<ExportMode> exportModeList;

    public boolean getCurrentExportMode() {
        return currentExportMode;
    }

    public void setCurrentExportMode(boolean currentExportMode) {
        this.currentExportMode = currentExportMode;
    }

//    public boolean isCurrentPageExportMode() {
//        return currentExportMode;
//    }

    public List<ExportMode> getExportModeList() {
        if(exportModeList == null) {
            exportModeList = new LinkedList<ExportMode>();
            exportModeList.add(new ExportMode(ExportMode.WHOLE_TABLE.getName(), false));
            exportModeList.add(new ExportMode(ExportMode.CURRENT_PAGE.getName(), true));
        }
        return exportModeList;
    }

    public void setExportModeList(List<ExportMode> exportModeList) {
        this.exportModeList = exportModeList;
    }

}
