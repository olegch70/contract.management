package app.controllers;

import app.beans.AuthorisedUserViewScoped;
import app.beans.RootChecker;
import app.helpers.ViewNavigationHelper;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 12.03.14
 * Time: 12:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "directoriesPageController")
@ViewScoped
public class DirectoriesPageController extends AbstractController {

    private static final String VIEW_NAME = "directoriesPage";
    @EJB
    private RootChecker rootChecker;

    public String doCallAndCreateUUID() {
        String conversationUuid = UUID.randomUUID().toString();
        return ViewNavigationHelper.prepareForCallAndGetURL(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid, VIEW_NAME);
    }

    @Override
    protected void afterDoBack() {
        ViewNavigationHelper.removeModelForConversation(getViewNavigationHelperModel().getSessionDataHolder(), conversationUuid);
    }

    public String goToPersons() {
        return PersonsListController.doCall(this);
    }

    public String goToPositions() {
        return PositionsListController.doCall(this);
    }

    public String goToGrades() {
        return GradesListController.doCall(this);
    }

    public String goToDirections() {
        return DirectionsListController.doCall(this);
    }

    public String goToExpTypes() {
        return ExpensesTypesListController.doCall(this);
    }

    @Override
    public String getModelName() {
        return VIEW_NAME;
    }
}
