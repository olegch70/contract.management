package app.controllers.system;

import app.beans.AuthorisedUserViewScoped;
import app.beans.RootChecker;
import app.system.upd.GradeDbUpdater;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 19.12.13
 * Time: 17:23
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name= "systemMenuPageController")
@ViewScoped
public class SystemMenuPageController {

    @EJB
    private RootChecker rootChecker;

    @EJB
    private GradeDbUpdater gradeDbUpdater;

    @ManagedProperty(value="#{authorisedUserViewBean}")
    private AuthorisedUserViewScoped authorisedUser;


    public boolean getCurrentUserIsRoot() {
        if(authorisedUser == null) {
            return false;
        }
        return rootChecker.isRoot(authorisedUser.getPerson());
    }

    private void displayUIMessage(String errorText) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorText));
    }

    public AuthorisedUserViewScoped getAuthorisedUser() {
        return authorisedUser;
    }

    public void setAuthorisedUser(AuthorisedUserViewScoped authorisedUser) {
        this.authorisedUser = authorisedUser;
    }

    public void runUpdatePriceFromGrade() throws Throwable {
        try {
            gradeDbUpdater.updateAllFromGrade();
        } catch (Throwable th) {
            displayUIMessage("runUpdatePriceFromGrade failed");
            return;
        }
        displayUIMessage("runUpdatePriceFromGrade executed");
    }
}
