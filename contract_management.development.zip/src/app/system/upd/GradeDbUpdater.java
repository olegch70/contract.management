package app.system.upd;

import app.beans.DayPriceConverter;
import app.dto.ExpenseTeam;
import app.dto.Grade;
import app.dto.Person;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.loaders.ExpensesTeamDBLoader;
import app.loaders.GradeDBLoader;
import app.loaders.PersonsDBLoader;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.List;

/**
 * author: Oleg Chamlay
 * Date: 11.03.14
 * Time: 17:38
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class GradeDbUpdater {

    @EJB
    GradeDBLoader gradeDBLoader;

    @EJB
    PersonsDBLoader personsDBLoader;

    @EJB
    private PersonFieldsCryptor personFieldsCryptor;

    @EJB
    ExpensesTeamDBLoader expensesTeamDBLoader;

    @EJB
    private DayPriceConverter dayPriceConverter;

    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public void updateAllFromGrade() {
        final String s = "Decrypted grades => ";
        debug(s);
        List<Person> persons = personsDBLoader.getAll();
        for(Person person: persons) {
            personFieldsCryptor.decryptFields(person);
            Grade decryptedGrade = gradeDBLoader.getByCode(person.getGrade());
            double gradeId = -1;

            Integer code = null;
            BigDecimal dayPrice21 = null;
            if(decryptedGrade != null) {
                code = decryptedGrade.getCode();
                dayPrice21 = decryptedGrade.getDayPrice();
                person.setDayPrice(dayPriceConverter.convertPriceFrom21WorkDayToCalendarDay(dayPrice21));
            } else {
                dayPrice21 = ConstantsHelper.BIGDECIMAL_GRADE_BIG;
                person.setDayPrice(ConstantsHelper.BIGDECIMAL_GRADE_BIG);
            }
            personFieldsCryptor.encryptFields(person);
            debug(  "user.FIO = " + person.getFIO() +
                    ", code = " + code +
                    ", dayPrice21 = " + dayPrice21 +
                    ", dayPrice365 = " + person.getDayPrice() +
                    ", dayPrice2 = " + person.getDayPrice2()
            );
            person.setDayPrice(null);
            person.setGrade(null);
            personsDBLoader.update(person);
        }

        for(Person person: persons) {
            List<ExpenseTeam> expenses = expensesTeamDBLoader.loadByFieldValue("personId", person.getId());
            for(ExpenseTeam expenseTeam : expenses) {
                expenseTeam.setPrice2(person.getDayPrice2());
                expensesTeamDBLoader.update(expenseTeam);
            }
        }

    }

    private void debug(String s) {
        LogSimple.debug(this, s);
    }
}
