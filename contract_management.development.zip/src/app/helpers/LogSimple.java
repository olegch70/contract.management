package app.helpers;

import app.loaders.ProjectsReportDBLoader;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * author: Oleg Chamlay
 * Date: 24.12.13
 * Time: 12:14
 */
public class LogSimple {
    private final static Log logger = new Log();

    private static class Log {
        private void log(String s) {
            System.out.println(s);
        }

       public void info(String s) {
           log(s);
       }

       public void debug(String s) {
           log(s);
       }

       public void error(String s) {
           log(s);
       }
   }

    public static void info(Object obj, String s) {
        Log log = getLogger(obj);
        log.info(s);
    }

    public static MeasureVO debugWithMeasureStart(Object obj, String s) {
        MeasureVO result = new MeasureVO();
        debug(obj, s);
        return result;
    }

    public static MeasureIntermediateVO debugWithIntermediateMeasureStart(Object obj, String s) {
        MeasureIntermediateVO result = new MeasureIntermediateVO();
        addMeasureLap(s, result);
        debug(obj, s);
        return result;
    }

    private static void addMeasureLap(String s, MeasureIntermediateVO result) {
        MeasureVO started = new MeasureVO();
        started.label = s;
        result.marks.add(started);
    }

    public static void debugWithMeasureFinish(Object obj, String s, MeasureVO measureVO) {
        MeasureVO finishedMeasure = new MeasureVO();
        debugWithMeasureFinish(obj, s, measureVO, finishedMeasure);
    }

    private static void debugWithMeasureFinish(Object obj, String s, MeasureVO measureVO, MeasureVO finishedMeasure) {
        long duration = finishedMeasure.duration(measureVO);
        if(duration > 0) {
            debug(obj, " duration " + duration + " ms. "+s);
        }
    }

    public static void debugWithMeasureFinish(Object obj, String s, MeasureIntermediateVO measureIntermediateVO) {
        Iterator<MeasureVO> iterator = measureIntermediateVO.marks.iterator();
        MeasureVO startVo = iterator.next();
        MeasureVO prevVo = startVo;
        MeasureVO vo = null;
        while(iterator.hasNext()) {
            vo = iterator.next();
            debugWithMeasureFinish(obj, "from "+ prevVo.label + " to " + vo.label, prevVo, vo);
            prevVo = vo;
        }
        if(vo == null) {
            vo = new MeasureVO();
        }
        debugWithMeasureFinish(obj, "from "+ startVo.label + " to " + s, startVo, vo);
    }

    public static void debugWithMeasureLap(String s, MeasureIntermediateVO measureIntermediateVO) {
        addMeasureLap(s, measureIntermediateVO);
    }


    public static void debug(Object obj, String s) {
        Log log = getLogger(obj);
        log.debug(obj.getClass().getName() + "@" + Integer.toHexString(obj.hashCode()) + " " + s);
//        System.out.println(Thread.currentThread().getName()+ " " + obj.getClass().getName() + " " + s);
    }

    public static void error(Object obj, String s) {
        Log log = getLogger(obj);
        log.error(s);
//        System.out.println(Thread.currentThread().getName()+ " " + obj.getClass().getName() + " " + s);
    }

/*
    public static void error(Object obj, Exception ex) {
        Log log = getLogger(obj);
        log.error(ex);
//        error(obj, ex.getMessage());
    }
*/

    public static void error(Object obj, Throwable ex) {
        StringWriter stw = new StringWriter();
        PrintWriter pw = new PrintWriter(stw);
        ex.printStackTrace(pw);
        getLogger(obj).error(ex.toString()+"\n"+stw.toString());
    }

    private static Log getLogger(Object obj) {
        return logger;
//        return org.apache.commons.logging.LogFactory.getLog(obj.getClass());
    }

    public static class MeasureVO {
        private final long timeMark;
        private String label;

        public MeasureVO() {
            this.timeMark = System.currentTimeMillis();
        }

        public long duration(MeasureVO measureVO) {
            return timeMark - measureVO.timeMark;
        }
    }

    public static class MeasureIntermediateVO {
        final List<MeasureVO> marks = new LinkedList<MeasureVO>();
    }
}

