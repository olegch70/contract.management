package app.helpers;

import app.controllers.SessionDataHolder;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.05.14
 * Time: 11:35
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean
@ViewScoped
public class ViewNavigationHelperModel {
    @ManagedProperty(value="#{sessionController}")
    private SessionDataHolder sessionDataHolder;
    public static final String CONVERSATION_UUID_PARAMETER_NAME = "conversationUuid";
    public static final String CALL_MARKER_PARAMETER_NAME = "callMarker";
    private String conversationUuid;
    private String callMarker;

    public String getConversationUuidParameterName() {
        return CONVERSATION_UUID_PARAMETER_NAME;
    }

    public String getCallMarkerParameterName() {
        return CALL_MARKER_PARAMETER_NAME;
    }

    public String getCallMarker() {
        return callMarker;
    }

    public void setCallMarker(String callMarker) {
        this.callMarker = callMarker;
    }

    public String getConversationUuid() {
        return conversationUuid;
    }

    public void setConversationUuid(String conversationUuid) {
        this.conversationUuid = conversationUuid;
    }

    public SessionDataHolder getSessionDataHolder() {
        return sessionDataHolder;
    }

    public void setSessionDataHolder(SessionDataHolder sessionDataHolder) {
        this.sessionDataHolder = sessionDataHolder;
    }

    @Override
    public String toString() {
        return "ViewNavigationHelperModel{" +
                "sessionDataHolder=" + sessionDataHolder +
                ", conversationUuid='" + conversationUuid + '\'' +
                ", callMarker='" + callMarker + '\'' +
                '}';
    }
}
