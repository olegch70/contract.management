package app.loaders;

import app.dto.ExpenseDirect;
import app.dto.Project;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "expensesDirectDBLoader")
@Named(value = "expensesDirectDBLoader")
@Stateless
public class ExpensesDirectDBLoader extends CommonDbLoader<ExpenseDirect> {

    @EJB
    ProjectsDBLoader projectsDBLoader;

    @Override
    protected Class getEntityClass() {
        return ExpenseDirect.class;
    }

    @Override
    protected Long getId(ExpenseDirect entity) {
        return entity.getId();
    }

    @Override
    public void update(ExpenseDirect entity) {
        super.update(entity);
        Project project = projectsDBLoader.getById(entity.getProjectId());
    }

    public Number getProjectExpensesDirectSum(Long projectId, Date from, Date to) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from ExpenseDirect t " +
                        " where t.projectId = :projectId " +
                        "   and t.dateExp between :fromDate and :toDate");
        query.setParameter("projectId", projectId);
        query.setParameter("fromDate", from, TemporalType.DATE);
        query.setParameter("toDate", to, TemporalType.DATE);
        return (Number) query.getSingleResult();
    }

    public Number getProjectExpensesDirectSum(Long projectId) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from ExpenseDirect t " +
                        " where t.projectId = :projectId ");
        query.setParameter("projectId", projectId);
        return (Number) query.getSingleResult();
    }

    public Map<Long, Number> getProjectsExpensesDirectSum(List<Long> projectsIds, Date currentDate) {
        String sql = "select t.projectId, sum(t.summa) from ExpenseDirect t " +
                                " where t.projectId in ( projectIdsParameters ) " +
                                "   and t.dateExp <= :currentDate " +
                                " group by t.projectId";

        return getLongNumberMap(sql, projectsIds, new String[] {"currentDate"}, new Object[]{currentDate});
    }

    public Map<Long, Number> getProjectsExpensesDirectSumPlan(List<Long> projectsIds, Date currentDate) {
        String sql = "select t.projectId, sum(t.summa) from ExpenseDirect t " +
                                " where t.projectId in ( projectIdsParameters ) " +
                                "   and t.dateExp > :currentDate " +
                                " group by t.projectId";

        return getLongNumberMap(sql, projectsIds, new String[] {"currentDate"}, new Object[]{currentDate});
    }

    public List<ExpenseDirect> loadByProjectId(Long id) {
        return loadByLinkedId("projectId", id);
    }

    public Number getSumma(Long id) {
        Query q = em.createNamedQuery("ExpenseDirect.summaForId");
        q.setParameter("projectId", id);
        return (Number) q.getSingleResult();
    }

    public Number getSumma(Long id, Date startDate, Date endDate) {
        Query q = em.createNamedQuery("ExpenseDirect.summaForIdByPeriod");
        q.setParameter("projectId", id);
        q.setParameter("startDate", startDate, TemporalType.DATE);
        q.setParameter("endDate", endDate, TemporalType.DATE);
        return (Number) q.getSingleResult();
    }
}
