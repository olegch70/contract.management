package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.*;
import app.helpers.DateHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "benchPersonsReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class BenchPersonsReportDBLoader {
    @EJB
    PersonsDBLoader personsDBLoader;
    @EJB
    ProjectsDBLoader projectsDBLoader;
    @EJB
    CurrentDateBean currentDateBean;
    @EJB
    PersonFieldsCryptor personFieldsCryptor;
    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

    public List<BenchPersonReport> getReportData(ReportDateFilter reportDateFilter) {
        Date currentDate = currentDateBean.getCurrentDate();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.set(Calendar.MONTH, 0);
        Date yearStart = calendar.getTime();
        Date startDate = reportDateFilter.getStartDate();
        Date endDate = reportDateFilter.getEndDate();


        Query query = em.createQuery("select distinct et.personId from ExpenseTeam et " +
                "where et.dateExp between :startPeriod and :endPeriod ");
        query.setParameter("startPeriod", startDate);
        query.setParameter("endPeriod", endDate);
        List<Object> personsInTeams = query.getResultList();

        query = em.createQuery("select et.personId, sum(et.loadPercent) from ExpenseTeam et " +
                "where et.dateExp between :startPeriod and :endPeriod " +
                "group by et.personId " +
                "having sum(et.loadPercent) < :targetLoadPercent");
        query.setParameter("startPeriod", startDate);
        query.setParameter("endPeriod", endDate);
        double daysBetween = DateHelper.calculateDaysBetweenTwoDatesInclusive(startDate, endDate);
        query.setParameter("targetLoadPercent", daysBetween*100);
        List<Object[]> personsInTeamsWithNotFullLoad = query.getResultList();
        List<Object> personsInTeamWithNotFullLoadCorrected = new LinkedList<Object>();
        for(Object[] row: personsInTeamsWithNotFullLoad) {
            final Object personId = row[0];
            debug("personId = " + personId);
            Person person = personsDBLoader.getById(personId);
            Date employmentDate = person.getEmploymentDate();
            Date dismissalDate = person.getDismissalDate();
            debug("employmentDate = " + employmentDate);
            if(employmentDate == null) {
                debug("employmentDate = null");
                personsInTeamWithNotFullLoadCorrected.add(personId);
                continue;
            }
            if(employmentDate.before(startDate)) {
                debug("employmentDate before "+ startDate);
                personsInTeamWithNotFullLoadCorrected.add(personId);
                continue;
            }
            if(employmentDate.after(endDate)) {
                continue;
            }
            int userDaysBetween = (int) DateHelper.calculateDaysBetweenTwoDatesInclusive(employmentDate, endDate)*100;
            int loadPercentSum = ((Number) row[1]).intValue();
            debug("userDaysBetween = " + userDaysBetween + " loadPercentSum = " + loadPercentSum);
            if(loadPercentSum == userDaysBetween) {
                debug("loadlPercentSum = userDaysBetween");
                continue;
            }
            personsInTeamWithNotFullLoadCorrected.add(personId);
        }
        personsInTeams.removeAll(personsInTeamWithNotFullLoadCorrected);
        if(personsInTeams.size() < 1) {
            personsInTeams.add(-1L);
        }

        query = em.createQuery("select p.id, p.lastName, p.firstName, p.middleName, p.dayPrice2, p.employmentDate, p.dismissalDate from Person p " +
                "where p.id not in :personsInTeam " +
                "  and (p.employmentDate is null or p.employmentDate <= :endDate)" +
                "  and (p.dismissalDate is null or p.dismissalDate >= :startDate)" +
                "");
        query.setParameter("personsInTeam", personsInTeams);
        query.setParameter("startDate", startDate);
        query.setParameter("endDate", endDate);
        List<Object[]> personsAtBench = query.getResultList();

        Map<String, BenchPersonReport> sortedReport = new TreeMap<String, BenchPersonReport>();
        Person fakePerson = new Person();
        for(Object[] row : personsAtBench) {
            BenchPersonReport report = new BenchPersonReport();
            report.setFIO(row[1] + " " + row[2] + " " + row[3]);
            BigInteger personPrice2 = (BigInteger) row[4];
            Date personEmploymentDate = (Date) row[5];
            Date personDismissalDate = (Date) row[6];
            query = em.createQuery("select sum(et.loadPercent) from ExpenseTeam et " +
                    "where et.dateExp = :endPeriod " +
                    "and et.personId = :personId");
            //query.setParameter("startPeriod", startDate);
            query.setParameter("endPeriod", endDate);
            final Long personId = (Long) row[0];
            query.setParameter("personId", personId);
            Number currentLoadPercent = (Number) query.getSingleResult();
            if(currentLoadPercent != null) {
                report.setCurrentLoadPercent(currentLoadPercent.doubleValue());
            }

            query = em.createQuery("select max(et.dateExp) from ExpenseTeam et " +
                    "where et.personId = :personId " +
                    "and et.dateExp between :startPeriod and :endPeriod");
            query.setParameter("personId", personId);
            query.setParameter("startPeriod", startDate);
            query.setParameter("endPeriod", endDate);
            Date maxDate = (Date) query.getSingleResult();
            debug("maxDate = " + maxDate);
            if(maxDate == null) {
                if(personEmploymentDate == null || personEmploymentDate.before(reportDateFilter.getStartDate())) {
                    report.setBenchDate(reportDateFilter.getStartDate());
                } else {
                    report.setBenchDate(personEmploymentDate);
                }
            } else {
                if(maxDate.before(reportDateFilter.getEndDate())) {
                    report.setBenchDate(reportDateFilter.getEndDate());
                } else {
                    report.setBenchDate(null);
                }
            }

            //���������� ����, ����� ���� ������� ��������� �� ��������
            query = em.createQuery("select sum(et.loadPercent)/100 from ExpenseTeam et " +
                    "where et.personId = :personId " +
                    "and et.dateExp >= :startPeriod " +
                    "and et.dateExp <= :endPeriod ");
            query.setParameter("personId", personId);
            query.setParameter("startPeriod", startDate);
            query.setParameter("endPeriod", endDate);

            Number workDays = (Number) query.getSingleResult();
            if(workDays == null) {
                workDays = 0;
            }
            double benchDays = 0;
            LogSimple.debug(this, "workDays = " + workDays);
            LogSimple.debug(this, "daysBetween = " + daysBetween);
            double userDaysBetween = daysBetween;
            if(personEmploymentDate != null || personDismissalDate != null) {
                Date fromDate;
                if(personEmploymentDate == null || personEmploymentDate.before(startDate)) {
                    fromDate = startDate;
                } else {
                    fromDate = personEmploymentDate;
                }

                Date toDate;
                if(personDismissalDate == null || personDismissalDate.after(endDate)) {
                    toDate = endDate;
                } else {
                    toDate = personDismissalDate;
                }
                userDaysBetween = DateHelper.calculateDaysBetweenTwoDatesInclusive(fromDate, toDate);
            }
            if(userDaysBetween >= 1){
                LogSimple.debug(this, "userDaysBetween >= 1 after cycle");
                benchDays = userDaysBetween - workDays.doubleValue();
            }
            if(benchDays < 0) {
                continue;
            }
            LogSimple.debug(this, "benchDays = " + benchDays);
            report.setBenchDays(benchDays);

            fakePerson.setId(personId);
            fakePerson.setDayPrice2(personPrice2);
            personFieldsCryptor.decryptDayPrice(fakePerson);
            report.setPrice(fakePerson.getDayPrice().multiply(new BigDecimal(report.getBenchDays())));

            query = em.createQuery("select et.projectId, count(et), et.loadPercent, max(et.dateExp) from ExpenseTeam et " +
                    "where " +
                    "et.personId = :personId " +
                    "and et.dateExp between :startPeriod and :endPeriod " +
                    "group by et.projectId, et.loadPercent");
            query.setParameter("personId", personId);
            query.setParameter("startPeriod", startDate);
            query.setParameter("endPeriod", endDate);

            List<Object[]> projectsDataList = query.getResultList();
            debug("projectsDataList = " + projectsDataList);
            List<BenchPersonProject> personsProjects = new LinkedList<BenchPersonProject>();
            for(Object[] projectData : projectsDataList) {
                debug("projectData = " + projectData);
                BenchPersonProject personsProject = new BenchPersonProject();
                Project curProject = projectsDBLoader.getById(projectData[0]);
                debug("curProject = " + curProject);
                personsProject.setCaption(" \"" + curProject.getClient().getName() + "\" " + curProject.getCode() + " "
                        + curProject.getNumber());
                personsProject.setWorkDays((Long) projectData[1]);
                personsProject.setLoadPercent((Double) projectData[2]);
                personsProject.setLastDateOnProject((Date) projectData[3]);
                debug("setCaption = " + curProject.getCode() + curProject.getNumber());
                debug("personsProject.getCaption = " + personsProject.getCaption());
                debug("setWorkDays = " + projectData[1]);
                debug("personsProject.getWorkDays() = " + personsProject.getWorkDays());
                debug("setLoadPercent = " + projectData[2]);
                debug("personsProject.getLoadPercent() = " + personsProject.getLoadPercent());
                personsProjects.add(personsProject);
            }
            debug("personsProjects = " + personsProjects);
            report.setWorkProjects(personsProjects);
            sortedReport.put(report.getFIO(), report);
        }

        List<BenchPersonReport> reports = new ArrayList<BenchPersonReport>(sortedReport.size());
        reports.addAll(sortedReport.values());
        return reports;
    }



    private void debug(String s) {
        LogSimple.debug(this, s);
    }

}