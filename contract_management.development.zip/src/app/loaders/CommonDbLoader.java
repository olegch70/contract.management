package app.loaders;

import app.beans.IdentificableById;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.*;
import javax.persistence.criteria.*;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.Metamodel;
import javax.transaction.*;
import javax.transaction.RollbackException;
import java.util.*;

/**
 * author: Oleg Chamlay
 * Date: 23.12.13
 * Time: 13:02
 */

@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class CommonDbLoader<EntityClass extends IdentificableById> {
//    abstract protected Class<? extends EntityClass> getEntityClass();
//
//    abstract protected Long getId(EntityClass entity);

    protected Class<? extends EntityClass> getEntityClass() {
        throw new UnsupportedOperationException();
    }

    protected Object getId(EntityClass entity)  {
            return entity.getId();
    }

//    @PersistenceUnit(name = "jdbc/project" )
//    protected EntityManagerFactory emf;

    @PersistenceContext(unitName = "ContractManagement")
    protected EntityManager em;

//    @Resource
//    protected UserTransaction utx;

    protected EntityManager getEntityManager() {
        return em;
//        return emf.createEntityManager();
    }

//    /**
//     * ����� �������������� ����� ��� ���������� ����� ������� �� ���������� � �������
//     * �������� ����� ���� �������� ����
//     * @param entity
//     */
//    protected void afterLoadEntityFromDb(EntityClass entity) {
//    }
//

    public void enrichModel(List<EntityClass> items){
    }

    /**
     * ����� �������������� ����� ��� ���������� ����� ������� ���������� � ����������� �������
     * �������� ����� ���� ������ ����������� � �������� ������
     * @param entity
     */
    protected void afterAddEntityToDb(EntityClass entity)
            throws HeuristicRollbackException, HeuristicMixedException, NotSupportedException, RollbackException, SystemException {
    }

    /**
     * ����� �������������� ����� ��� ���������� ����� ������� ���������� � ����������� �������
     * �������� ����� ���� ������ ����������� � �������� ������
     * @param entity
     */

    protected void afterUpdateEntityInDb(EntityClass entity) {
    }

    protected void afterUpdateEntityInDb(EntityClass entity, EntityClass mergedEntity) {
        this.afterUpdateEntityInDb(entity);
    }

    /**
     * ����� �������������� ����� ��� �������� ������� � ����������� �������
     * @param entity
     */

    protected void beforeDeleteEntityInDb(EntityClass entity) throws HeuristicRollbackException, HeuristicMixedException, NotSupportedException, RollbackException, SystemException {
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public EntityClass getByIdDetached(Object id) {
        EntityClass result = getById(id);
        em.detach(result);
        return result;
    }

    public EntityClass getById(Object id) {
        debug( "getById started");
        EntityClass result;
        Query query = em.createQuery(
                "select t from "+ getEntityClassName() + " t " +
                        " where t.id = :id ");
        query.setParameter("id", id);

        result = (EntityClass) query.getSingleResult();

//        afterLoadEntityFromDb(result);
        debug("getById finished");
        return result;
    }

    private void debug(String s) {
       // LogSimple.debug(this, s);
    }

    public List<EntityClass> loadByLinkedId(String fieldNameForLinkedId, Long linkedId) {
        return loadByFieldValue(fieldNameForLinkedId, linkedId);
    }

    public List<EntityClass> loadByFieldValue(String fieldName, Object fieldValue) {
        return loadByFieldValue(fieldName, fieldValue, null);
    }

    public List<EntityClass> loadByFieldValue(String fieldName, Object fieldValue, String[] orderFields) {
        List<EntityClass> result;
        String sOrderFields = getOrderByString(orderFields);

        String sql = "select t from "+ getEntityClassName() + " t " +
                                " where t."+fieldName+" = :value ";

        if(sOrderFields.length() > 0) {
            sql = sql + "\n order by "+ sOrderFields;
        }

        Query query = em.createQuery(sql);
        query.setParameter("value", fieldValue);
        result = query.getResultList();
        return result;
    }

    public List<EntityClass> loadByFieldValue_slow(String fieldName, Object fieldValue) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery cq = cb.createQuery();
        Root<EntityClass> entityRoot = cq.from(getEntityClass());
        cq.select(entityRoot);
        Path<String> pathId = entityRoot.get(fieldName);
        Predicate wherIdEqual = cb.equal(pathId, fieldValue);
        cq.where(wherIdEqual);
        Query q = em.createQuery(cq);
        List<EntityClass> result = q.getResultList();
        return result;
    }

    private String getEntityClassName() {

        String className = getEntityClass().getName();
        className = className.substring(className.lastIndexOf('.')+1);
        debug("getEntityClassName => "+ className);
        return className;
    }

    protected String getIdFieldName() {
        return "id";
    }

    /**
     *
     * @return
     */
    public List<EntityClass> getAll() {
        return getAll(new String[]{});

    }

    /**
     *
     * @param orderFields "field_name" ��� "field_name desc"
     * @return
     */
    public List<EntityClass> getAll(String[] orderFields) {
        debug("getAll start");

        String sOrderFields = getOrderByString(orderFields);

        String entityClassName = getEntityClassName();
        String sql = "select t from "+ entityClassName + " t ";

        if(sOrderFields.length() > 0) {
            sql = sql + "\n order by "+ sOrderFields;
        }

        debug(sql);
        Query query = em.createQuery(sql);
        List<EntityClass> result = query.getResultList();
        debug("getAll finished");
        return result;
    }

    private String getOrderByString(String[] orderFields) {
        if(orderFields == null || orderFields.length < 1) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for(String fieldName: orderFields) {
            if(sb.length() > 0) {
                sb.append(", ");
            }

            sb.append("t.").append(fieldName);
        }

        return sb.toString();
    }

    /**
     *
     * @param orderFields "field_name" ��� "field_name:desc"
     * @return
     */
    public List<EntityClass> getAll_slow(String ... orderFields) {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery cq = cb.createQuery();
            Root<EntityClass> entityRoot = cq.from(getEntityClass());
            Metamodel metamodel = em.getMetamodel();
            EntityType<EntityClass> entityType =  (EntityType<EntityClass>) metamodel.entity(getEntityClass());
            cq.select(entityRoot);
            if(orderFields != null) {
                ArrayList<Order> orderBy = new ArrayList<Order>(orderFields.length);
                for(String fieldName: orderFields) {
                    fieldName = fieldName.trim();
                    int posDesc = fieldName.toUpperCase().indexOf(":DESC");
                    boolean asc = true;
                    if(posDesc > 0) {
                        fieldName = fieldName.substring(0, posDesc);
                        asc = false;
                    }
                    if(fieldName.length() > 0) {
                        javax.persistence.criteria.Path<String> path = entityRoot.get(fieldName);
                        debug("javax.persistence.criteria.Path<String> path => "+path);
                        javax.persistence.criteria.Order order;
                        if(asc) {
                            order = cb.asc(path);
                        } else {
                            order = cb.desc(path);
                        }
                        orderBy.add(order);
                    }
                }
                if(orderBy.size() > 0) {
                    cq.orderBy(orderBy);
                }
            }
            Query q = em.createQuery(cq);
            List<EntityClass> result = q.getResultList();
//            for(EntityClass entity: result) {
//                afterLoadEntityFromDb(entity);
//            }
            return result;
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void addNew(EntityClass entity) {
        assertAllowAdd();
        try {
            em.persist(entity);
            afterAddEntityToDb(entity);
            em.flush();
        } catch(Throwable t) {
            throw new RuntimeException(t);
        }
    }

    private void assertAllowAdd() {
    }

    private void assertAllowDelete() {
    }

    private void assertAllowUpdate() {
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void delete(Long id) {
        assertAllowDelete();
        try {
            EntityClass entity;
            try {
                entity = em.getReference(getEntityClass(), id);
                getId(entity);
            } catch (EntityNotFoundException ex) {
                throw ex;
            }
            beforeDeleteEntityInDb(entity);
            em.remove(entity);
            em.flush();

        } catch(Throwable t){
            throw new RuntimeException(t);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(EntityClass entity) {
        assertAllowUpdate();
//        try {
            EntityClass entityMerged = (EntityClass) em.merge(entity);
            getId(entity);
            afterUpdateEntityInDb(entity, entityMerged);
//            em.flush();
//        } catch(Throwable t) {
//            throw new RuntimeException(t);
//        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void addNew(List<EntityClass> entityList) {
        if(entityList == null){
            return;
        }
        for(EntityClass row : entityList) {
            addNew(row);
        }
    }

    protected Map<Long, Number> getLongNumberMap(String sql, List<Long> projectsIds) {
        return getLongNumberMap(sql, projectsIds, null, null);
    }

    // ToDo ��������� - ������ ������ projectsIds - �������� �� �������� ��������� � ������
    // ToDo � �������� ������ ����� ������  
    protected Map<Long, Number> getLongNumberMap(String sql, List<Long> projectsIds,
                                                 String[] parametersName, Object[] parametersValue) {
        List<Object[]> parameters = new ArrayList<Object[]>(projectsIds.size());

        int npp = 1;
        for(Long id: projectsIds) {
            Object[] container = new Object[]{"param_"+npp, id};
            parameters.add(container);
            npp++;
        }

        StringBuilder sb = new StringBuilder();
        for(Object[] container: parameters) {
            if(sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(':').append(container[0]);
        }

        String sqlWithProjectIds = sql.replaceFirst("projectIdsParameters", sb.toString());

        Query query = em.createQuery(sqlWithProjectIds);

        for(Object[] container: parameters) {
            if(sb.length() > 0) {
                sb.append(", ");
            }

            sb.append(container[0]);
            query.setParameter((String) container[0], container[1]);
        }

        if(parametersName != null) {
            for(int i = 0; i < parametersName.length; i++) {
                query.setParameter(parametersName[i], parametersValue[i]);
            }
        }

        List<Object[]> resultList = query.getResultList();
        Map<Long, Number> result = new HashMap<Long, Number>(resultList.size());
        for(Object[] row: resultList) {
            Long id = (Long) row[0];
            Number value = (Number) row[1];
            result.put(id, value);
        }
        return result;
    }

    public List<EntityClass> listObjectsAsType(List<?> listAsClass) {
        List<EntityClass> result = new ArrayList<EntityClass>(listAsClass.size());
        result.addAll(result);
        return result;
    }

    public List<EntityClass> getBySqlWithParams(String sql, Map<String, Object> parameters) {
        Query q = em.createQuery(sql, getClass());
        for(Map.Entry<String, Object> paramEntry: parameters.entrySet()) {
            Object paramValue = paramEntry.getValue();
            if(paramValue instanceof Date) {
                q.setParameter(paramEntry.getKey(), (Date) paramValue, TemporalType.DATE);
            } else {
                q.setParameter(paramEntry.getKey(), paramValue);
            }
        }
        return q.getResultList();
    }

//    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
//    public EntityClass getById_slow(Long id) {
//        LogSimple.debug(this, "getById started");
//        CriteriaBuilder cb = em.getCriteriaBuilder();
//        CriteriaQuery cq = cb.createQuery();
//        Root<EntityClass> entityRoot = cq.from(getEntityClass());
//        cq.select(entityRoot);
//        javax.persistence.criteria.Path<String> pathId = entityRoot.get(getIdFieldName());
//        Predicate wherIdEqual = cb.equal(pathId, id);
//        cq.where(wherIdEqual);
//        Query q = em.createQuery(cq);
//        EntityClass result = (EntityClass) q.getSingleResult();
//        afterLoadEntityFromDb(result);
//        LogSimple.debug(this, "getById finished");
//        return result;
//    }
//

}
