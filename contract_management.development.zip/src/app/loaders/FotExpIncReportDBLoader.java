package app.loaders;

import app.beans.DateFormatter;
import app.dto.FotExpIncActual;
import app.dto.FotExpIncReport;
import app.dto.Person;
import app.dto.report.DomainCost;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.NumberToSpeak;
import app.helpers.PersonFieldsCryptor;
import app.report.dto.ReportDateFilter;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 11:00
 * To change this template use File | Settings | File Templates.
 */
@Named(value = "FotExpIncReportDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class FotExpIncReportDBLoader {
    @EJB
    DomainCostReportDBLoader domainCostReportDBLoader;
    @EJB
    FotExpIncDBLoader fotExpIncDBLoader;

    public FotExpIncReport getReportData(ReportDateFilter reportDateFilter) {
        FotExpIncReport result = new FotExpIncReport();
        result.setFotAct(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setFotCalc(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setExpenseAct(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setExpenseCalc(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setIncomeAct(ConstantsHelper.BIGDECIMAL_ZERO);
        result.setIncomeCalc(ConstantsHelper.BIGDECIMAL_ZERO);

        Collection<DomainCost> domainCostList = domainCostReportDBLoader.getReportData(reportDateFilter, null, null);
        List<FotExpIncActual> fotExpIncActualList = fotExpIncDBLoader.getFotIncExpActual(reportDateFilter);

        for(DomainCost row: domainCostList) {
            result.setFotCalc(result.getFotCalc().add(row.getExpenseTeam()));
            result.setExpenseCalc(result.getExpenseCalc().add(row.getExpenseDirect()));
            result.setIncomeCalc(result.getIncomeCalc().add(row.getIncome()));
        }
        for(FotExpIncActual row: fotExpIncActualList) {
            result.setFotAct(result.getFotAct().add(row.getFot()));
            result.setExpenseAct(result.getExpenseAct().add(row.getExpense()));
            result.setIncomeAct(result.getIncomeAct().add(row.getIncome()));
        }
        result.setFotDiff(result.getFotAct().subtract(result.getFotCalc()));
        result.setExpenseDiff(result.getExpenseAct().subtract(result.getExpenseCalc()));
        result.setIncomeDiff(result.getIncomeAct().subtract(result.getIncomeCalc()));
        return result;
    }

}