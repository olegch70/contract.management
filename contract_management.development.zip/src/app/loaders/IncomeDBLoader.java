package app.loaders;

import app.dto.Income;

import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "incomeDBLoader")
@Named(value = "incomeDBLoader")
@Stateless
public class IncomeDBLoader extends CommonDbLoader<Income> {

    @Override
    protected Class getEntityClass() {
        return Income.class;
    }

    @Override
    protected Long getId(Income entity) {
        return entity.getId();
    }

    public Number getProjectIncomeSum(Long projectId, Date from, Date to) {
        EntityManager em = getEntityManager();
        Query qDelete = em.createQuery(
                "select sum(t.summa) from Income t " +
                        " where t.projectId = :projectId " +
                        "   and t.dateIncome between :fromDate and :toDate");
        qDelete.setParameter("projectId", projectId);
        qDelete.setParameter("fromDate", from, TemporalType.DATE);
        qDelete.setParameter("toDate", to, TemporalType.DATE);
        return (Number) qDelete.getSingleResult();
    }

    public Number getProjectIncomeSum(Long projectId, Date to) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from Income t " +
                        " where t.projectId = :projectId " +
                        "   and t.dateIncome <= :toDate");
        query.setParameter("projectId", projectId);
        query.setParameter("toDate", to, TemporalType.DATE);
        return (Number) query.getSingleResult();
    }

    public Number getProjectIncomeSum(Long projectId) {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select sum(t.summa) from Income t " +
                        " where t.projectId = :projectId ");
        query.setParameter("projectId", projectId);
        return (Number) query.getSingleResult();
    }


    public Map<Long, Number> getProjectsIncomeSum(List<Long> projectsIds) {
        String sql = "select t.projectId, sum(t.summa) from Income t " +
                                " where t.projectId in ( projectIdsParameters ) " +
                                " group by t.projectId";

        return getLongNumberMap(sql, projectsIds);
    }

}
