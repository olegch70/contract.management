package app.loaders;

import app.beans.CurrentDateBean;
import app.dto.Person;
import app.dto.Position;
import app.dto.Project;
import app.helpers.ConstantsHelper;
import app.helpers.LogSimple;
import app.helpers.PersonFieldsCryptor;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 18.12.13
 * Time: 14:13
 * To change this template use File | Settings | File Templates.
 */
//@ManagedBean(name = "personsDBLoader")
//@SessionScoped
@Named(value = "personsDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class PersonsDBLoader extends CommonDbLoader<Person>{

    @EJB
    PositionDBLoader positionDBLoader;

    @EJB
    ProjectsDBLoader projectsDBLoader;

    @EJB
    private PersonFieldsCryptor personFieldsCryptor;

    @EJB
    private CurrentDateBean currentDateBean;

    @Override
    protected Class getEntityClass() {
        return Person.class;
    }

    @Override
    protected Long getId(Person entity) {
        return entity.getId();
    }
//
    @Override
    public Person getById(Object id) {
        return decryptFields(super.getById(id));
    }

    private Person decryptFields(Person person) {
        personFieldsCryptor.decryptFields(person);
        return person;
    }

    //    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
//    public void enrichModel(List<Person> model) {
//        LogSimple.debug(this, "enrichModel started");
//        Map<Long, String> cache = new HashMap<Long, String>();
//        for(Person item : model){
//            String positionName;
//            positionName = cache.get(item.getPositionId());
//            if(positionName == null) {
//            LogSimple.debug(this, "positionDBLoader.getById started");
//                positionName = positionDBLoader.getById(item.getPositionId()).getName();
//            LogSimple.debug(this, "positionDBLoader.getById finished");
//                cache.put(item.getPositionId(), positionName);
//        }
//            item.setPositionName(positionName);
//        }
//        LogSimple.debug(this, "enrichModel finished");
//    }

    public List<Person> getPM() {
        return getEntityManager().createNamedQuery("Person.getPM").getResultList();
    }

    public List<Person> getTechAM() {
        return getEntityManager().createNamedQuery("Person.getTAM").getResultList();
    }

    public List<Person> getHR() {
        return getEntityManager().createNamedQuery("Person.getHR").getResultList();
    }

    public List<Person> getFinManager() {
        return getEntityManager().createNamedQuery("Person.getFinManager").getResultList();
    }

    public Person getByLoginName(String login) {
        Query query = getEntityManager().createNamedQuery("Person.getByLoginName");
        query.setParameter("loginName", login);
        List<Person> result = query.getResultList();
        if(result.size() > 0) {
            return result.get(0);
        }
        return null;
    }

    public Person getByFIO(Person person) {
        Query query = getEntityManager().createNamedQuery("Person.getByFIO");
        query.setParameter("firstName", person.getFirstName().trim());
        query.setParameter("lastName", person.getLastName().trim());
        query.setParameter("middleName", person.getMiddleName().trim());
        List<Person> result = query.getResultList();
        if(result.size() > 0) {
            return result.get(0);
        }
        return null;
    }

    /**
     * Функция выбирает сотрудников которые являются сотрудниками на текущий момент
     * @return Список сотрудников
     */
    public List<Person> getAllowedToIncludeIntoTeam() {
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select t from Person t " +
                        " where ( t.dismissalDate is null or t.dismissalDate > :currentDate ) " +
                        "   order by t.lastName, t.firstName, t.lastName");
        query.setParameter("currentDate", currentDateBean.getCurrentDate());
        List<Person> resultList = query.getResultList();
        enrichModel(resultList);
        return resultList;
    }

    @Override
    public void enrichModel(List<Person> resultList) {
        for(Person person: resultList) {
            Project mainProject = person.getMainProject();
            if(mainProject != null) {
                Long projectManagerId = mainProject.getProjectManagerId();
                Person projectManager = getById(projectManagerId);
                mainProject.setProjectManager(projectManager);
            }
        }
    }

    /**
     * Попробовать установить основной проект у Сотрудника
     * @param person - сотрудник
     * @param project - проект
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void trySetMainProjectId(Person person, Project project) {
        if(person.getMainProjectId() == null) {
            person.setMainProject(project);
            person.setLegionnaireEndDate(null);
            person.setLegionnaire(false);
            update(person);
        }
    }

    /**
     * Попробовать удалить основной проект у Сотрудника
     * @param person - сотрудник
     * @param projectId - id проекта на котором должен быть сотрудник перед вызовом метода
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void tryRemoveMainProjectId(Person person, Long projectId) {
        if(projectId.equals(person.getMainProjectId())) {
            person.setMainProject(null);
            person.setReadyForLegionnaire(false);
            person.setLegionnaireEndDate(null);
            person.setLegionnairePercentOffer(null);
            update(person);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public void updateFromUI(Person entity) {
        Person oldPersonData = getById(entity.getId());
        BigInteger oldPrice2 = oldPersonData.getDayPrice2();
        BigInteger oldGrade2 = oldPersonData.getGrade2();
        if(entity.getGrade2() == null) {
            throw new IllegalArgumentException("Person.grade == null");
        }
        update(entity);
        if( ! entity.getDayPrice2().equals(oldPrice2) ) {
            Person tmpPerson = new Person();
            tmpPerson.setId(entity.getId());
            tmpPerson.setGrade2(oldGrade2);
            personFieldsCryptor.decryptGrade(tmpPerson);
            BigDecimal oldGrade = tmpPerson.getGrade();

            tmpPerson.setGrade2(entity.getGrade2());
            personFieldsCryptor.decryptGrade(tmpPerson);
            BigDecimal newGrade = tmpPerson.getGrade();
            if(oldGrade == null || oldGrade.compareTo(ConstantsHelper.GRADE_NO_GRADE) == 0 && oldGrade.compareTo(newGrade) != 0) {
                // Изменился грейд сотрудника с "пустого" на реальный
                // значит нужно изменить стоимость сотрудника во всех командах активностей за все даты
                projectsDBLoader.updatePersonPrice2ForAllDates(entity);
            } else {
            // Обновим информацию о стоимости сотрудника в день в информации о затратах
                //   на команду во всех активностях с текущей даты
            projectsDBLoader.updatePersonPrice2(entity);
        }
    }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(Person entity) {
        if(entity.getMainProject() != null) {
            Project project = null;
            LogSimple.debug(this, "try update mainProject = "+ entity.getMainProjectId());
            if(entity.getMainProjectId() != null) {
                project = projectsDBLoader.getById(entity.getMainProjectId());
            }
            LogSimple.debug(this, "update mainProject = "+ entity.getMainProjectId());
            entity.setMainProject(project);
        }

        if(entity.getPosition() != null) {
            Position position = positionDBLoader.getById(entity.getPositionId());
            entity.setPosition(position);
        }
        super.update(entity);
    }

    @Override
    protected void afterUpdateEntityInDb(Person person, Person mergedPerson) {
        // поле dayPrice должно быть transient (т.е. не сохраняется в БД)
        mergedPerson.setDayPrice(person.getDayPrice());
    }
}
