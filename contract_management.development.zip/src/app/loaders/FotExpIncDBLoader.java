package app.loaders;

import app.dto.FotExpIncActual;
import app.report.dto.ReportDateFilter;

import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:42
 * To change this template use File | Settings | File Templates.
 */

//@SessionScoped
//@ManagedBean(name = "incomeDBLoader")
@Named(value = "fotExpIncDBLoader")
@Stateless
public class FotExpIncDBLoader extends CommonDbLoader<FotExpIncActual> {

    @Override
    protected Class getEntityClass() {
        return FotExpIncActual.class;
    }

    @Override
    protected Long getId(FotExpIncActual entity) {
        return entity.getId();
    }

    public List<FotExpIncActual> getFotIncExpActual(ReportDateFilter reportDateFilter) {
        List<FotExpIncActual> result = new LinkedList<FotExpIncActual>();

        Calendar calendar = Calendar.getInstance();
        calendar.set(reportDateFilter.getYear(), reportDateFilter.getStartMonth()-1, 1, 0, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date startPeriod = calendar.getTime();

        calendar.set(Calendar.MONTH, reportDateFilter.getEndMonth()-1);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date endPeriod = calendar.getTime();
        EntityManager em = getEntityManager();
        Query query = em.createQuery(
                "select t.date, t.fot, t.expense, t.income from FotExpIncActual t " +
                        " where t.date between :fromDate and :toDate");
        query.setParameter("fromDate", startPeriod);
        query.setParameter("toDate", endPeriod);
        List<Object[]> resultList = query.getResultList();
        for(Object[] row: resultList) {
            FotExpIncActual report = new FotExpIncActual();
            report.setDate((Date) row[0]);
            report.setExpense((BigDecimal) row[2]);
            report.setFot((BigDecimal) row[1]);
            report.setIncome((BigDecimal) row[3]);
            result.add(report);
        }


        return result;
    }

}
