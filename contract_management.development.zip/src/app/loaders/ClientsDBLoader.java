package app.loaders;

import app.beans.RootChecker;
import app.dto.Client;
import app.dto.Direction;
import app.dto.Person;
import app.helpers.ConstantsHelper;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Named;
import javax.persistence.Query;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 14:29
 * To change this template use File | Settings | File Templates.
 */
//@ManagedBean(name = "clientsDBLoader")
//@SessionScoped

@Named(value = "clientsDBLoader")
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)

public class ClientsDBLoader extends CommonDbLoader<Client>{

    @EJB
    private ProjectsDBLoader projectDBLoader;

    @EJB
    private PersonsDBLoader personsDBLoader;

    @EJB
    private DirectionDBLoader directionDBLoader;

    @EJB
    private RootChecker rootChecker;

    @Override
    protected Class getEntityClass() {
        return Client.class;
    }

    @Override
    protected Long getId(Client entity) {
        return entity.getId();
    }

    @Override
    public void enrichModel(List<Client> clients) {
        if(clients != null) {
            for(Client row : clients) {
                Person person = personsDBLoader.getById(row.getTechnicalAM());
                Direction direction = directionDBLoader.getById(row.getDirectionId());
                row.setTechnicalAMName(person.getLastName() + " " + person.getFirstName() + " " + person.getMiddleName());
                row.setDirectionName(direction.getName());
            }
        }
    }

    public List<Client> getByTechnicalAm(Long id) {
        return loadByFieldValue("technicalAM", id, new String[] {"name"});
    }
    //ToDo оптимизировать запрос всего списка за один запрос в базу
    public List<Client> getClients() {
        Query query = getEntityManager().createNamedQuery("Clients.list");
        return query.getResultList();
    }

    public List<Client> getClientsByProjectM(Long personId) {
        Query query = getEntityManager().createNamedQuery("Project.getClientsByProjectM");
        query.setParameter("projectManagerId", personId);
        return query.getResultList();
    }

    public List<Client> getClientsForAuthorizedUser(Person authorisedUser) {
        List<Client> result;
        if(authorisedUser != null) {
            if (rootChecker.isRoot(authorisedUser) ) {
                result = getClients();
                if(rootChecker.isRootNoSales(authorisedUser)) {
                    Iterator<Client> itr = result.iterator();
                    while(itr.hasNext()) {
                        Client client = itr.next();
                        if(ConstantsHelper.CLIENT_NAME_SALES.equals(client.getName().toLowerCase())) {
                            itr.remove();
                            break;
                        }
                    }
                }
            } else {
                result = getClientsForAuthorizedUser(
                        authorisedUser.getId(),
                        authorisedUser.isTechnicalAM(),
                        authorisedUser.isProjectM()
                        );
            }
        } else {
            result = new LinkedList<Client>();
        }
        return result;
    }

    private List<Client> getClientsForAuthorizedUser(Long personId, boolean isTechnicalAM, boolean isProjectM) {
        List<Client> result = new LinkedList<Client>();
            if(isTechnicalAM) {
                result.addAll(getByTechnicalAm(personId));
            }
            if(isProjectM) {
                List<Client> clientsList = getClientsByProjectM(personId);
                clientsList.removeAll(result);
                result.addAll(clientsList);
            }
        return result;
    }
}
