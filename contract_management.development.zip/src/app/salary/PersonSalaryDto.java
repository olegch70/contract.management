package app.salary;

import app.dto.Person;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 28.04.14
 * Time: 12:30
 * To change this template use File | Settings | File Templates.
 */
public class PersonSalaryDto {
    private String FIO;
    private int workedDays;
    private BigDecimal salary;
    private List<String> messages;
    private Person person;

    public String getFIO() {
        return FIO;
    }

    public void setFIO(String FIO) {
        this.FIO = FIO;
    }

    public int getWorkedDays() {
        return workedDays;
    }

    public void setWorkedDays(int workedDays) {
        this.workedDays = workedDays;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public void addMessage(String s) {
        if(messages == null) {
            messages = new LinkedList<String>();
        }
        messages.add(s);
    }

    public List<String> getMessages() {
        return messages;
    }

    @Override
    public String toString() {
        return "PersonSalaryDto{" +
                "FIO='" + FIO + '\'' +
                ", workedDays=" + workedDays +
                ", salary=" + salary +
                ", messages=" + messages +
                "}\n";
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Person getPerson() {
        return person;
    }
}
