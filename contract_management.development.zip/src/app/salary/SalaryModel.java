package app.salary;

import java.math.BigDecimal;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 28.04.14
 * Time: 12:27
 * To change this template use File | Settings | File Templates.
 */
public class SalaryModel {
    private Date date;
    private List<PersonSalaryDto> personsSalary;
    private BigDecimal itog;
    private List<String> messages;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public List<PersonSalaryDto> getPersonsSalary() {
        return personsSalary;
    }

    public void setPersonsSalary(List<PersonSalaryDto> personsSalary) {
        this.personsSalary = personsSalary;
    }

    public void setItog(BigDecimal itog) {
        this.itog = itog;
    }

    public BigDecimal getItog() {
        return itog;
    }

    public void addMessage(String s) {
        if(messages == null) {
            messages = new LinkedList<String>();
        }
        messages.add(s);
    }

    public List<String> getMessages() {
        return messages;
    }

    @Override
    public String toString() {
        return "SalaryModel{" +
                "date=" + date +
                ", itog=" + itog +
                ",\n messages=" + messages +
                ",\n personsSalary=" + personsSalary +
                '}';
    }
}
