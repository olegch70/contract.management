package app.beans;

import java.security.NoSuchAlgorithmException;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 09.01.14
 * Time: 16:59
 * To change this template use File | Settings | File Templates.
 */
public class PasswordHasher {
    private static String salt = "MegaSalt_forSecure_Password";

    public static String computeHashS(String login, String password) {
        return byteArrayToHexString(computeHash(password +salt+login));
    }

    public static byte[] computeHash(String x)
    {
        java.security.MessageDigest d =null;
        try {
            d = java.security.MessageDigest.getInstance("SHA-1");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        d.reset();
        d.update(x.getBytes());
        return  d.digest();
    }

    public static String byteArrayToHexString(byte[] b){
        StringBuffer sb = new StringBuffer(b.length * 2);
        for (int i = 0; i < b.length; i++){
            int v = b[i] & 0xff;
            if (v < 16) {
                sb.append('0');
            }
            sb.append(Integer.toHexString(v));
        }
        return sb.toString().toUpperCase();
    }

    public static boolean validatePassword(String password) {
        if(password == null || password.trim().length() == 0) {
            return false;
        }
        return true;
    }
}
