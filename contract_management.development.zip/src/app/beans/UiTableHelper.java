package app.beans;

import app.controllers.utils.DataTableUIValuesHolder;
import app.dto.Grade;
import app.loaders.CommonDbLoader;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created by oleg on 13.05.2014.
 */
@ManagedBean(name=UiTableHelper.UI_TABLE_HELPER)
@ViewScoped
public class UiTableHelper<DtoClass extends IdentificableById> extends DataTableUIValuesHolder {
    public final static String UI_TABLE_HELPER = "uiTableHelper";
    public final static String UI_TABLE_HELPER_EL = "#{"+UI_TABLE_HELPER+"}";
    public static final String UI_TABLE_HELPER_KEY = "uiTableHelper.key";

    public void calledFromInit(Map<String, Object> mapValueHolder, final CommonDbLoader<DtoClass> loader) {
        ValuesHolder valuesHolder = (ValuesHolder) mapValueHolder.get(UI_TABLE_HELPER_KEY);
        if(valuesHolder == null) {
            saveValues(mapValueHolder);
        } else {
            restoreValues(mapValueHolder);
            processItemsToRefresh(loader);
        }
    }

    public void saveValues(Map<String, Object> mapValueHolder) {
        mapValueHolder.put(UI_TABLE_HELPER_KEY, getValuesHolder());
    }

    public void restoreValues(Map<String, Object> mapValueHolder) {
        setValuesHolder((ValuesHolder) mapValueHolder.get(UI_TABLE_HELPER_KEY));
    }

    public Map getFieldFilter() {
        return getValuesHolder().getFilterFieldValues();
    }
}
