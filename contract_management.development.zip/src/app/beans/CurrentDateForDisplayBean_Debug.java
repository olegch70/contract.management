package app.beans;

import app.helpers.LogSimple;
import app.loaders.CurrentDataDBLoader;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 26.12.13
 * Time: 17:11
 * To change this template use File | Settings | File Templates.
 */
@ManagedBean(name="currentDateForDisplayBeanDebug")
@SessionScoped
public class CurrentDateForDisplayBean_Debug {

    @EJB
    CurrentDateBean currentDateBean;

    @EJB
    CurrentDataDBLoader currentDataDBLoader;

    Date currentDateDebugValue;

    public Date getCurrentDate(){
        return currentDateBean.getCurrentDate();
    }

    public String getCurrentDateForEdit(){
        return currentDataDBLoader.convertDateToString(currentDateBean.getCurrentDate());
    }


    public void setCurrentDateForEdit(String date) {
        LogSimple.debug(this, "setCurrentDateBean called");
        currentDataDBLoader.setCurrentDate(currentDataDBLoader.convertStringToDate(date));
    }
}
