package app.beans;

import app.dto.Person;

import javax.ejb.Stateless;

/**
 * author: Oleg Chamlay
 * Date: 22.01.14
 * Time: 10:08
 */
@Stateless
public class RootChecker {
    public boolean isRoot(Person person) {
        final String loginName = person.getLoginName();
        if("k.sharendo".equals(loginName)) {
            return true;
        }

        if("e.kozyrev".equals(loginName)) {
            return true;
        }

        if("k.chamlai".equals(loginName)) {
            return true;
        }

        if("k.chamlay".equals(loginName)) {
            return true;
        }

        if("o.chamlay".equals(loginName)) {
            return true;
        }

        return isRootReadOnly(loginName) || isRootNoSales(loginName);
//        return false;
    }

    public boolean isRootReadOnly(Person person) {
        final String loginName = person.getLoginName();
        return isRootReadOnly(loginName);
    }

    public boolean isRootReadOnly(String loginName) {
        if("y.latin".equals(loginName)) {
            return true;
        }

        if("ylatin".equals(loginName)) {
            return true;
        }
        return false;
    }


    public boolean isRootNoSales(Person person) {
        final String loginName = person.getLoginName();
        return isRootNoSales(loginName);
    }

    public boolean isRootNoSales(String loginName) {
        if("a.karpunin".equals(loginName)) {
            return true;
        }

        if("akarpunin".equals(loginName)) {
            return true;
        }
        return false;
    }


}
