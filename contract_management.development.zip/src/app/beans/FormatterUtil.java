package app.beans;

import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;
import java.util.Calendar;
import java.util.Date;

/**
 * author: Oleg Chamlay
 * Date: 17.01.14
 * Time: 10:07
 */
@ManagedBean(name = "fmtutl")
@RequestScoped
public class FormatterUtil {
    public String formatBoolean(boolean val) {
        return formatBoolean(val, "[   ]", "[ X ]");
    }

    public String formatBoolean(boolean val, String valueForTrue, String valueForFalse) {
        if(val) {
            return valueForTrue ;
        } else {
            return valueForFalse ;
        }
    }

    public static String formatDouble(Double val) {
        return String.format("%1$.2f", val);
    }

    public static String formatDateLong(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        StringBuilder sb = new StringBuilder();
        int fieldValue = calendar.get(Calendar.DAY_OF_MONTH);
        if(fieldValue < 10) {
           sb.append("0");
        }
        sb.append(fieldValue);
        sb.append(".");

        fieldValue = calendar.get(Calendar.MONTH)+1;
        if(fieldValue < 10) {
           sb.append("0");
        }
        sb.append(fieldValue);
        sb.append(".");

        fieldValue = calendar.get(Calendar.YEAR);
        sb.append(fieldValue);
        return sb.toString();
    }
}
