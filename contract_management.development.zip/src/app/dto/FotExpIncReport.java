package app.dto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 16:41
 * To change this template use File | Settings | File Templates.
 */

public class FotExpIncReport {

    private Date date;
    private BigDecimal fotAct;
    private BigDecimal expenseAct;
    private BigDecimal incomeAct;
    private BigDecimal fotCalc;
    private BigDecimal expenseCalc;
    private BigDecimal incomeCalc;
    private BigDecimal fotDiff;
    private BigDecimal expenseDiff;
    private BigDecimal incomeDiff;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public BigDecimal getFotAct() {
        return fotAct;
    }

    public void setFotAct(BigDecimal fotAct) {
        this.fotAct = fotAct;
    }

    public BigDecimal getExpenseAct() {
        return expenseAct;
    }

    public void setExpenseAct(BigDecimal expenseAct) {
        this.expenseAct = expenseAct;
    }

    public BigDecimal getIncomeAct() {
        return incomeAct;
    }

    public void setIncomeAct(BigDecimal incomeAct) {
        this.incomeAct = incomeAct;
    }

    public BigDecimal getFotCalc() {
        return fotCalc;
    }

    public void setFotCalc(BigDecimal fotCalc) {
        this.fotCalc = fotCalc;
    }

    public BigDecimal getExpenseCalc() {
        return expenseCalc;
    }

    public void setExpenseCalc(BigDecimal expenseCalc) {
        this.expenseCalc = expenseCalc;
    }

    public BigDecimal getIncomeCalc() {
        return incomeCalc;
    }

    public void setIncomeCalc(BigDecimal incomeCalc) {
        this.incomeCalc = incomeCalc;
    }

    public BigDecimal getFotDiff() {
        return fotDiff;
    }

    public void setFotDiff(BigDecimal fotDiff) {
        this.fotDiff = fotDiff;
    }

    public BigDecimal getExpenseDiff() {
        return expenseDiff;
    }

    public void setExpenseDiff(BigDecimal expenseDiff) {
        this.expenseDiff = expenseDiff;
    }

    public BigDecimal getIncomeDiff() {
        return incomeDiff;
    }

    public void setIncomeDiff(BigDecimal incomeDiff) {
        this.incomeDiff = incomeDiff;
    }
}
