package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 17.12.13
 * Time: 14:21
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name="PRJ_CLIENT")
@NamedQueries({
        @NamedQuery(name = "Clients.list",
        query = "select t from Client t order by t.name")
})
public class Client implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    @Column(name = "ID")
    private Long id;
    private String name;
    @Column(name = "DIRECTION_ID")
    private Long directionId;
    @Column(name = "TECHNICAL_AM_ID")
    private Long technicalAM;
    @Column(name = "TEAM_PERCENT")
    private double teamPercent;
    @Column(name = "CONTRACTS_PERCENT")
    private double contractsPercent;
    @Transient
    private String technicalAMName;
    @Transient
    private String directionName;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTechnicalAM() {
        return technicalAM;
    }

    public void setTechnicalAM(Long technicalAM) {
        this.technicalAM = technicalAM;
    }

    public Long getDirectionId() {
        return directionId;
    }

    public void setDirectionId(Long direction) {
        this.directionId = direction;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Client client = (Client) o;

        if(id == null) {
            return super.equals(o);
        }

        if (!id.equals(client.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        if(id != null) {
        return id.hashCode();
        } else {
            return super.hashCode();
        }
    }

    public void setTechnicalAMName(String technicalAMName) {
        this.technicalAMName = technicalAMName;
    }

    public String getTechnicalAMName() {
        return technicalAMName;
    }

    public String getDirectionName() {
        return directionName;
    }

    public void setDirectionName(String directionName) {
        this.directionName = directionName;
    }

    public double getTeamPercent() {
        return teamPercent;
    }

    public void setTeamPercent(double teamCoeff) {
        this.teamPercent = teamCoeff;
    }

    public double getContractsPercent() {
        return contractsPercent;
    }

    public void setContractsPercent(double contractsCoeff) {
        this.contractsPercent = contractsCoeff;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Client{");
        sb.append("id=").append(id);
        sb.append(", name='").append(name).append('\'');
        sb.append(", technicalAM=").append(technicalAM);
        sb.append(", technicalAMName='").append(technicalAMName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}


