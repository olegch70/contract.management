package app.dto;

import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 10:49
 * To change this template use File | Settings | File Templates.
 */
public class BenchPersonProject {

    private String caption;

    private Long workDays;

    private Double loadPercent;

    private Date lastDateOnProject;

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Long getWorkDays() {
        return workDays;
    }

    public void setWorkDays(Long workDays) {
        this.workDays = workDays;
    }

    public Double getLoadPercent() {
        return loadPercent;
    }

    public void setLoadPercent(Double loadPercent) {
        this.loadPercent = loadPercent;
    }

    public Date getLastDateOnProject() {
        return lastDateOnProject;
    }

    public void setLastDateOnProject(Date lastDateOnProject) {
        this.lastDateOnProject = lastDateOnProject;
    }
}
