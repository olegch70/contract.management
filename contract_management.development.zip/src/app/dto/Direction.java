package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * author: Oleg Chamlay
 * Date: 11.03.14
 * Time: 17:39
 */

@Entity
@Table(name="PRJ_DIRECTION")

@NamedQueries({
        @NamedQuery(name = "Direction.getAll",
                query = "select t from Direction t order by t.name"
        )
}
)

public class Direction implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    private Long id;

    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
