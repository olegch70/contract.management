package app.dto;

import app.beans.IdentificableById;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 20.12.13
 * Time: 12:44
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name="PRJ_POSITION")
@NamedQueries({
        @NamedQuery(name = "Position.getAll",
                query = "select t from Position t where t.actual = true order by t.name"
        ),
        @NamedQuery(name = "Position.getAllWithNotActual",
                query = "select t from Position t order by t.name"
        )
}
)
public class Position implements IdentificableById, Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name="SEQ", sequenceName = "PRJ_IDSEQ", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.IDENTITY, generator="SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "FL_ACTUAL")
    private boolean actual = true;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isActual() {
        return actual;
    }

    public void setActual(boolean actual) {
        this.actual = actual;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Position{");
        sb.append("id=").append(id);
        sb.append(", name='").append(name).append('\'');
        sb.append(", actual=").append(actual);
        sb.append('}');
        return sb.toString();
    }
}
