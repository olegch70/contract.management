package app.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: user7598
 * Date: 05.02.14
 * Time: 10:49
 * To change this template use File | Settings | File Templates.
 */
public class AlternatePMReport {

    private String FIO;

    private Double currentLoadPercent;

    private List<BenchPersonProject> workProjects;

    public String getFIO() {
        return FIO;
    }

    public void setFIO(String FIO) {
        this.FIO = FIO;
    }

    public Double getCurrentLoadPercent() {
        return currentLoadPercent;
    }

    public void setCurrentLoadPercent(Double currentLoadPercent) {
        this.currentLoadPercent = currentLoadPercent;
    }

    public List<BenchPersonProject> getWorkProjects() {
        return workProjects;
    }

    public void setWorkProjects(List<BenchPersonProject> workProjects) {
        this.workProjects = workProjects;
    }
}
